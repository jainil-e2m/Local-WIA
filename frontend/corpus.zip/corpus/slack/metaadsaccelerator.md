# #metaadsaccelerator

Private channel · `C082DURRJ2U`
Pulled 2026-09-25 by `corpus/fetch-slack.mjs`.

347 parent messages · 514 thread replies · 60 files downloaded · 37 left in place.
Covers 2024-11-22 → 2026-09-24.

Thread replies are indented with `>`. Every message links back to Slack, so a
candidate drawn from here carries its source the way a transcript quote carries
a timecode.

## Not downloaded — over the 25 MB cap

These stayed in Slack. The link needs the bot token in an `Authorization`
header; a plain browser fetch returns a login page with a 200.

| File | Size | Link |
|---|---|---|
| Impromptu Zoom Meeting - Aug 27 2026.mp4 | 111.6 MB | [download](https://files.slack.com/files-pri/T03P5A3L1DK-F0BV7JV5JBY/download/impromptu_zoom_meeting_-_aug_27_2026.mp4) |
| Impromptu Zoom Meeting - Aug 20 2026.mp4 | 195 MB | [download](https://files.slack.com/files-pri/T03P5A3L1DK-F0BR7PJHLJK/download/impromptu_zoom_meeting_-_aug_20_2026.mp4) |
| Impromptu Zoom Meeting - Aug 6 2026.mp4 | 147.9 MB | [download](https://files.slack.com/files-pri/T03P5A3L1DK-F0BNW9PMBK6/download/impromptu_zoom_meeting_-_aug_6_2026.mp4) |
| Impromptu Zoom Meeting - Jun 18 2026.mp4 | 116.2 MB | [download](https://files.slack.com/files-pri/T03P5A3L1DK-F0BBQC9PL1F/download/impromptu_zoom_meeting_-_jun_18_2026.mp4) |
| Impromptu Zoom Meeting - Jun 11 2026.mp4 | 114.3 MB | [download](https://files.slack.com/files-pri/T03P5A3L1DK-F0B9XJ69DK7/download/impromptu_zoom_meeting_-_jun_11_2026.mp4) |
| Impromptu Zoom Meeting - May 28 2026.mp4 | 186.1 MB | [download](https://files.slack.com/files-pri/T03P5A3L1DK-F0B6YR4RXFW/download/impromptu_zoom_meeting_-_may_28_2026.mp4) |
| Impromptu Zoom Meeting - May 7 2026.mp4 | 189.7 MB | [download](https://files.slack.com/files-pri/T03P5A3L1DK-F0B2DF6MH4J/download/impromptu_zoom_meeting_-_may_7_2026.mp4) |
| Impromptu Zoom Meeting - Apr 23 2026.mp4 | 240.9 MB | [download](https://files.slack.com/files-pri/T03P5A3L1DK-F0AUS0BTDMZ/download/impromptu_zoom_meeting_-_apr_23_2026.mp4) |
| Impromptu Zoom Meeting - Mar 5 2026.mp4 | 178.2 MB | [download](https://files.slack.com/files-pri/T03P5A3L1DK-F0AJE8U45TR/download/impromptu_zoom_meeting_-_mar_5_2026.mp4) |
| Impromptu Zoom Meeting - Feb 12 2026.mp4 | 413.1 MB | [download](https://files.slack.com/files-pri/T03P5A3L1DK-F0AEK5L5NFM/download/impromptu_zoom_meeting_-_feb_12_2026.mp4) |
| Impromptu Zoom Meeting - Feb 5 2026.mp4 | 211.3 MB | [download](https://files.slack.com/files-pri/T03P5A3L1DK-F0ADXQ86T7B/download/impromptu_zoom_meeting_-_feb_5_2026.mp4) |
| Impromptu Zoom Meeting - Jan 15 2026.mp4 | 226.7 MB | [download](https://files.slack.com/files-pri/T03P5A3L1DK-F0A91PL1W1Y/download/impromptu_zoom_meeting_-_jan_15_2026.mp4) |
| Impromptu Zoom Meeting - Jan 8 2026.mp4 | 193.6 MB | [download](https://files.slack.com/files-pri/T03P5A3L1DK-F0A7NRHKPU2/download/impromptu_zoom_meeting_-_jan_8_2026.mp4) |
| video1466989976.mp4 | 99.4 MB | [download](https://files.slack.com/files-pri/T03P5A3L1DK-F0A59B689B8/download/video1466989976.mp4) |
| video1242634249.mp4 | 52.2 MB | [download](https://files.slack.com/files-pri/T03P5A3L1DK-F0A4EF7GAAZ/download/video1242634249.mp4) |
| Impromptu Zoom Meeting - Dec 5 2025.mp4 | 77 MB | [download](https://files.slack.com/files-pri/T03P5A3L1DK-F0A1ED9R8MD/download/impromptu_zoom_meeting_-_dec_5_2025.mp4) |
| Impromptu Zoom Meeting - Nov 20 2025.mp4 | 168 MB | [download](https://files.slack.com/files-pri/T03P5A3L1DK-F09US5GDXJM/download/impromptu_zoom_meeting_-_nov_20_2025.mp4) |
| Impromptu Zoom Meeting - Nov 6 2025 (1).mp4 | 230.6 MB | [download](https://files.slack.com/files-pri/T03P5A3L1DK-F09S2A8PLG1/download/impromptu_zoom_meeting_-_nov_6_2025__1_.mp4) |
| Impromptu Zoom Meeting - Oct 30 2025.mp4 | 175.6 MB | [download](https://files.slack.com/files-pri/T03P5A3L1DK-F09PMDENTMZ/download/impromptu_zoom_meeting_-_oct_30_2025.mp4) |
| Impromptu Zoom Meeting - Oct 23 2025.mp4 | 256.9 MB | [download](https://files.slack.com/files-pri/T03P5A3L1DK-F09P5MGSZL0/download/impromptu_zoom_meeting_-_oct_23_2025.mp4) |
| Impromptu Zoom Meeting - Oct 9 2025.mp4 | 165.9 MB | [download](https://files.slack.com/files-pri/T03P5A3L1DK-F09KR59PA02/download/impromptu_zoom_meeting_-_oct_9_2025.mp4) |
| Impromptu Zoom Meeting - Oct 2 2025.mp4 | 316.3 MB | [download](https://files.slack.com/files-pri/T03P5A3L1DK-F09JKSS21T6/download/impromptu_zoom_meeting_-_oct_2_2025.mp4) |
| Impromptu Zoom Meeting - Sep 25 2025.mp4 | 174.1 MB | [download](https://files.slack.com/files-pri/T03P5A3L1DK-F09H45Z522H/download/impromptu_zoom_meeting_-_sep_25_2025.mp4) |
| Impromptu Zoom Meeting - Sep 18 2025.mp4 | 387.4 MB | [download](https://files.slack.com/files-pri/T03P5A3L1DK-F09G0F72RDG/download/impromptu_zoom_meeting_-_sep_18_2025.mp4) |
| Impromptu Zoom Meeting - Sep 11 2025 (1).mp4 | 196.9 MB | [download](https://files.slack.com/files-pri/T03P5A3L1DK-F09EZ53U8GL/download/impromptu_zoom_meeting_-_sep_11_2025__1_.mp4) |
| Impromptu Zoom Meeting - Sep 4 2025 (1).mp4 | 335 MB | [download](https://files.slack.com/files-pri/T03P5A3L1DK-F09DL296XFU/download/impromptu_zoom_meeting_-_sep_4_2025__1_.mp4) |
| Impromptu Zoom Meeting - Aug 28 2025.mp4 | 145.3 MB | [download](https://files.slack.com/files-pri/T03P5A3L1DK-F09DB9REFJL/download/impromptu_zoom_meeting_-_aug_28_2025.mp4) |
| Impromptu Zoom Meeting - Aug 21 2025 (1).mp4 | 365 MB | [download](https://files.slack.com/files-pri/T03P5A3L1DK-F09BAP12SGK/download/impromptu_zoom_meeting_-_aug_21_2025__1_.mp4) |
| Impromptu Zoom Meeting - Aug 14 2025.mp4 | 132.1 MB | [download](https://files.slack.com/files-pri/T03P5A3L1DK-F09A9J97JLT/download/impromptu_zoom_meeting_-_aug_14_2025.mp4) |
| Impromptu Zoom Meeting - Jul 31 2025 (1).mp4 | 117.9 MB | [download](https://files.slack.com/files-pri/T03P5A3L1DK-F098AK05ELW/download/impromptu_zoom_meeting_-_jul_31_2025__1_.mp4) |
| Impromptu Zoom Meeting - Jul 24 2025.mp4 | 316.2 MB | [download](https://files.slack.com/files-pri/T03P5A3L1DK-F097RBD7YRF/download/impromptu_zoom_meeting_-_jul_24_2025.mp4) |
| Impromptu Zoom Meeting - Jul 17 2025.mp4 | 133.3 MB | [download](https://files.slack.com/files-pri/T03P5A3L1DK-F096HJXGSRJ/download/impromptu_zoom_meeting_-_jul_17_2025.mp4) |
| Impromptu Zoom Meeting - Jul 10 2025.mp4 | 261.6 MB | [download](https://files.slack.com/files-pri/T03P5A3L1DK-F095B6B8AJG/download/impromptu_zoom_meeting_-_jul_10_2025.mp4) |
| Impromptu Zoom Meeting - Jul 3 2025.mp4 | 184 MB | [download](https://files.slack.com/files-pri/T03P5A3L1DK-F0948A5JNLV/download/impromptu_zoom_meeting_-_jul_3_2025.mp4) |
| Impromptu Zoom Meeting - Jun 26 2025.mp4 | 289.4 MB | [download](https://files.slack.com/files-pri/T03P5A3L1DK-F0938LKMYN6/download/impromptu_zoom_meeting_-_jun_26_2025.mp4) |
| Impromptu Zoom Meeting - Jun 19 2025.mp4 | 181.5 MB | [download](https://files.slack.com/files-pri/T03P5A3L1DK-F0926TR9XS9/download/impromptu_zoom_meeting_-_jun_19_2025.mp4) |
| Impromptu Zoom Meeting - Jun 12 2025.mp4 | 368.2 MB | [download](https://files.slack.com/files-pri/T03P5A3L1DK-F091KNR6MSM/download/impromptu_zoom_meeting_-_jun_12_2025.mp4) |

---

**Whitney Hodges** · 2024-11-22 15:42 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1732290122396579)
@Jenni @Jacqueline Hood I'd love it if you could please use the link below to join our FB group for the Meta program. I'll handle responding to all clients in the group  (for now), but I think it would be great for y'all to be inside, so you can see what questions are being asked. Thank you!!

<https://www.facebook.com/share/g/1GJSUrPzRJ/>

**Nicole Bautista** · 2024-11-26 19:29 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1732649369815919)
Hi <!channel>, Toryn posted a question in the group. Here’s the content for your reference.

_Hey Hey Peeps...question for the group..._

_Recently before joining we had / experimented with a ad linked to a "Free" Guide that we had put together...the page over time (maybe a few weeks) got about 2K views and 17 downloads which were seen / added to a Flo Desk campaign..._

_Now that I've joined, I'm curious if something like this is potentially good for an Exposure ad at maybe $1 or $2 a day just to our Cold Audience...just thinking it might be a nice addition to drum up some potential prospects and folks for our Retagets?_ 

_Is that something you all suggest or recommend? Here's a link to the existing page and also the Freebie: <https://exquisitesoundsentertainment.lpages.co/weddings-lead-magnet-062024/?fbclid=IwY2xjawGzALRleHRuA2FlbQIxMQABHVl0Wfr_34cRWiV_6ZL1lqy-YsPKjQ7qWdiVo7soq1T2AsgwnixXNr3i3A_aem_VBO0fY33FflDCuFo79--pw|Link>_
> **Whitney Hodges** · 2024-11-26 20:24 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1732652673075229)
> @Nicole Bautista Thanks! I responded in the group

**Whitney Hodges** · 2024-11-27 15:16 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1732720592745569)
has renamed the channel from "metafbgroupquestions" to "metafbgroup"

**Whitney Hodges** · 2024-11-27 15:17 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1732720659827069)
@Nicole Bautista Hi! The office hours post didn't publish today. It looks like it's scheduled for 7:30am PST. I think your VPN is in San Francisco, so that's probably why. Can you try again with this? It needs to be 7:30am CST or 5:30am PST. Thanks!
> **Nicole Bautista** · 2024-11-27 16:53 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1732726388083239)
> Hi @Whitney Hodges! Please let me know if the date and time look good. Thanks! <https://www.facebook.com/groups/862602926059301/admin_assistant/?source=admin_home|Facebook group>

**Nicole Bautista** · 2024-12-04 17:42 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1733334134507799)
Hi @Jacqueline Hood  @Whitney Hodges, I’ve created the <https://docs.google.com/document/d/1dqvbMqz6Zlsfi1pYncrhTbioDueQLjpjC08duOFBIPs/edit?usp=sharing|graphic post and caption> for tomorrow’s office hours. Please take a look and let me know if there’s anything you'd like to change.

Also, @Jacqueline Hood, could you confirm what time your office hour will be tomorrow?

**Nicole Bautista** · 2024-12-04 18:28 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1733336926898079)
@Whitney Hodges Hi! Here's the draft for the<https://docs.google.com/document/d/1TdP-KBtrBUWhPHp6Rr9maY6Nt2LNStMv4il5MMS0SJE/edit?usp=sharing| Office hours recording.>
> **Whitney Hodges** · 2024-12-04 18:30 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1733337036156109)
> Can I have edit access, please? @Nicole Bautista
> **Nicole Bautista** · 2024-12-04 18:31 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1733337062822119)
> yes!
> **Whitney Hodges** · 2024-12-04 18:33 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1733337216657559)
> @Nicole Bautista Ok, simplified it. It's now approved and you can use this same template every week, just change the date at the beginning. Thank you!
> **Nicole Bautista** · 2024-12-04 18:36 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1733337386263909)
> @Whitney Hodges Noted on this. Thanks!
> **Nicole Bautista** · 2024-12-06 19:30 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1733513420479769)
> @Whitney Hodges Hi! <https://docs.google.com/document/d/1dqvbMqz6Zlsfi1pYncrhTbioDueQLjpjC08duOFBIPs/edit?usp=sharing|Here's the post announcement copy>.

**Jacqueline Hood** · 2024-12-05 20:12 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1733429532423619)
@Nicole Bautista I'm so sorry I missed this yesterday! My office hours will be the first Thursday of the month 9-10am PST :slightly_smiling_face:
> **Nicole Bautista** · 2024-12-05 20:51 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1733431907533489)
> @Jacqueline Hood No worries! thanks for this

**Nicole Bautista** · 2024-12-06 16:16 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1733501796594739)
<https://app.gohighlevel.com/v2/location/Xi40zxmRvW8Pbyk5DYHp/memberships/courses/products/6ffc485b-4102-4df7-9628-f0bcc22ba713>

**Nicole Bautista** · 2024-12-09 17:05 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1733763953988549)
@Whitney Hodges Hi! Here's the draft copy for the post. <https://docs.google.com/document/d/1TqawpSe70S7TuLGi5eOh8uV__pcgoIYBXmbcoMUwJgo/edit?usp=sharing|Link here>
> **Whitney Hodges** · 2024-12-09 17:08 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1733764091414809)
> @Nicole Bautista If you can update to the new pretty Zoom room link, all of this is approved
> **Nicole Bautista** · 2024-12-09 17:11 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1733764313748839)
> @Whitney Hodges I’ve already updated the Zoom link and will post the first reminder now. Are you the one who will schedule the post for Wednesday?
> **Nicole Bautista** · 2024-12-09 17:29 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1733765399832039)
> Hi @Whitney Hodges! I’ve added the reminder email for our FB Members. <https://docs.google.com/document/d/1TqawpSe70S7TuLGi5eOh8uV__pcgoIYBXmbcoMUwJgo/edit?usp=sharing|Link here>
> **Whitney Hodges** · 2024-12-09 17:34 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1733765649584669)
> @Nicole Bautista Next to when, it says today. Fix that and it should be good to go. I would just email everyone individually
> **Nicole Bautista** · 2024-12-09 17:40 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1733766033245349)
> @Whitney Hodges Just to clarify, I am the one who will email them individually, right?
> **Whitney Hodges** · 2024-12-09 17:41 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1733766105489389)
> @Nicole Bautista yes, please. Just send individual emails from the hello gmail
> **Nicole Bautista** · 2024-12-09 17:42 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1733766126317749)
> @Whitney Hodges Got it. Thanks!
> **Nicole Bautista** · 2024-12-10 16:42 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1733848965136819)
> @Whitney Hodges Hi! I’ve already edited the<https://www.facebook.com/groups/862602926059301/scheduled_posts| reminder post >for tomorrow. It will go out in 20 hours.

**Whitney Hodges** · 2024-12-11 15:13 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1733930034688569)
@Nicole Bautista For the weeks of Christmas and New Year's, I'd like to move office hours to Friday mornings. Can you please draft an announcement post for this?
> **Nicole Bautista** · 2024-12-11 15:19 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1733930379827089)
> @Whitney Hodges Will do!
> **Nicole Bautista** · 2024-12-12 15:35 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1734017732869349)
> @Whitney Hodges Hi! Here's the <https://docs.google.com/document/d/1TqawpSe70S7TuLGi5eOh8uV__pcgoIYBXmbcoMUwJgo/edit?usp=sharing|draft of the announcement post. >

**Nicole Bautista** · 2024-12-11 15:39 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1733931556537889)
Hi @Whitney Hodges!

Just a quick update—I’ve already fixed the design for the mobile view of our course portal. Let me know if you’d like to try it out.

When I grant access to the course, the member will receive an email with a link. They just need to click the link, create a password, and they’re all set.

Would you like me to edit this welcome email that will be sent to our members?
📎 Screenshot 2024-12-11 at 11.38.38 PM.png (png, saved as `files/F084NQ40J2W-Screenshot_2024-12-11_at_11.38.38_PM.png`)
> **Nicole Bautista** · 2024-12-13 15:36 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1734104194927689)
> @Whitney Hodges Hi! Here’s the edited <https://app.gohighlevel.com/v2/location/Xi40zxmRvW8Pbyk5DYHp/memberships/courses/settings/email-settings|Welcome email for the portal>. Let me know if this is the image you were referring to.

**Nicole Bautista** · 2024-12-18 16:47 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1734540460389689)
@Whitney Hodges Hi! Just posted the recorded office hours.

**Nicole Bautista** · 2024-12-20 17:57 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1734717422250269)
@Whitney Hodges Hi! Here’s the<https://docs.google.com/document/d/1TqawpSe70S7TuLGi5eOh8uV__pcgoIYBXmbcoMUwJgo/edit?usp=sharing| email copy draft >and the<https://www.canva.com/design/DAGWTYwpVHM/mHn5pWlVPGOCaMzsR-FBKA/edit?utm_content=DAGWTYwpVHM&amp;utm_campaign=designshare&amp;utm_medium=link2&amp;utm_source=sharebutton| two graphics> for the next two weeks. Let me know if you need any changes to this. Thanks!
> **Whitney Hodges** · 2024-12-20 18:11 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1734718266954309)
> @Nicole Bautista I made some minor tweaks. This is all approved. Can you send the emails out today, please?
> **Nicole Bautista** · 2024-12-20 18:12 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1734718345371069)
> @Whitney Hodges sure, I'll send the email.
> **Whitney Hodges** · 2024-12-20 18:16 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1734718587715339)
> @Nicole Bautista can you please check to make sure office hours are updated on my calendar for the next two weeks too?
> **Nicole Bautista** · 2024-12-20 18:20 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1734718806017479)
> @Whitney Hodges I'll update the calendar.

**Nicole Bautista** · 2024-12-26 16:21 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1735230097242799)
Hi @Whitney Hodges! I’ve scheduled the <https://www.facebook.com/groups/862602926059301/scheduled_posts|posts for 12/27 and 01/03>. Please let me know if the dates and times look good. Thanks!

**Nicole Bautista** · 2024-12-26 16:21 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1735230110711389)
Hi @Whitney Hodges, Just a heads-up—Toryn left a comment on our Facebook post. Let me know if you’d like me to respond.

_"Perfect!!! I see you Friday! Have a Merry Xmas!"_
> **Whitney Hodges** · 2024-12-26 16:53 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1735231994126529)
> I liked the post. No need to respond

**Whitney Hodges** · 2025-01-17 18:42 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1737139323715879)
@Nicole Bautista in Dubsado, can you create a feedback questionnaire for the 3 month program? I'd like to request feedback from Toryn and Janet soon
> **Nicole Bautista** · 2025-01-17 19:21 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1737141716365969)
> @Whitney Hodges Here's the  <https://hello.dubsado.com/form/form-builder/edit/678aa5fc9f3976003a52d0ae|feedback form. >Let me know if you want any changes. Thanks!

**Whitney Hodges** · 2025-01-20 15:16 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1737386181506989)
<!channel> Reminder to myself that on our team call tomorrow, I'd like for us to look at our collective availability to schedule a meeting to discuss the 3-Month program and how to streamline it

**Nicole Bautista** · 2025-01-30 18:47 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1738262870415209)
@Whitney Hodges @Jenni Amelia posted a note in our FB group. Here it is for reference:

_"I NEVER remember the office hours meetings! Just a suggestion, but have you considered sending a reminder email on the morning of the meetings with the Zoom link?_
_In other news, our ads are performing VERY WELL and I'm so thankful for that!! The conversion from people that go to our inquiry landing page, which is where the ad directs them, to people that actually inquire is very low. Yesterday I took two fields off of our inquiry form to see if that would help. Currently, MTD we've seen 840 visits to the inquiry landing page and only 39 people have inquired (11 of those are for sure through the ad campaign)._ 
_While I do not want 840 leads coming through our pipeline, I would expect the inquiry number to be around 115 as our average conversion for that point in the funnel is around 14%. The 39 inquiries seems strangely low._ 
_If you can speak to this on here or in our call next week, or both, it would help me greatly."_  

@Whitney Hodges Let me know if you'd like me to draft a reminder email for our 3-month clients.
> **Whitney Hodges** · 2025-01-30 19:07 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1738264034225489)
> @Nicole Bautista yes, please set it up, so that all program participants receive a reminder email every Wednesday morning. You can probably automate this inside ghl
> **Nicole Bautista** · 2025-01-30 23:14 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1738278891881259)
> @Whitney Hodges Hi! I’ve created the<https://app.gohighlevel.com/location/Xi40zxmRvW8Pbyk5DYHp/workflow/21f82db7-57ce-4580-8ad2-d6513f992d48| reminder workflow for your review>, along with the draft email copy. Let me know if you'd like me to make any changes. Thanks!
> **Whitney Hodges** · 2025-02-04 13:50 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1738677014187829)
> @Nicole Bautista I think this looks good. I can't tell if this is going to repeatedly email people every Wednesday though. Let's try it this week, and keep an eye out to see if it automatically happens next week. Please put this on my calendar for Wednesday morning, so I can manually send an email if they don't go out
> **Nicole Bautista** · 2025-02-04 15:05 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1738681514336699)
> @Whitney Hodges Got it! I’ve already set a reminder on your calendar.

**Whitney Hodges** · 2025-02-05 16:10 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1738771834325409)
@Nicole Bautista Janet and Toryn were both at office hours but there was a gap in between. Can you edit that part out and then upload to the FB group today please?
> **Nicole Bautista** · 2025-02-05 17:31 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1738776698935939)
> @Whitney Hodges Hi! I've already uploaded the meeting.

**Nicole Bautista** · 2025-02-26 16:14 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1740586477727209)
@Whitney Hodges Hi! I just want to confirm if someone attended the office hours — I don’t see the call recording on my end. Thanks!
> **Whitney Hodges** · 2025-02-26 16:15 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1740586553913469)
> Lol that's because I forgot to end the meeting. You should see it now. Janet was the only attendee

**Nicole Bautista** · 2025-03-05 16:10 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1741191037726409)
@Whitney Hodges Hi! just to confirm — did someone make it to the office hours?
> **Whitney Hodges** · 2025-03-05 16:18 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1741191492953419)
> Yes, fathom wasn't working, so I had to record on my computer. Once I get it uploaded, I'll let you know

**Nicole Bautista** · 2025-03-19 15:08 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1742396881175529)
@Whitney Hodges Hi! Do we have a recording for the office hour?
> **Whitney Hodges** · 2025-03-19 15:09 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1742396997643329)
> @Nicole Bautista Yes, it's in fathom
> **Whitney Hodges** · 2025-03-19 15:10 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1742397021043479)
> Elsa was there at the beginning. Then there's a gap and Janet was there a little after 9am
> **Nicole Bautista** · 2025-03-19 15:12 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1742397158361069)
> @Whitney Hodges Okay, Thank you!

**Whitney Hodges** · 2025-04-02 14:10 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1743603039991479)
@Nicole Bautista I did a lot of screensharing while Elsa was in office hours today. Can you please blur out any other client's names/account numbers while I was in Meta Ads Manager and also in our Google Drive?

Also, Elsa gave really great feedback on the call. Can you please add the video clip and turn it into a written testimonial inside our Social Proof, folder?
> **Nicole Bautista** · 2025-04-02 15:01 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1743606090839089)
> @Whitney Hodges Will do!

**Nicole Bautista** · 2025-04-02 15:05 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1743606328477059)
Hi @Jacqueline Hood, will you be holding office hours tomorrow?

**Jacqueline Hood** · 2025-04-02 17:34 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1743615286141439)
Yes! I just realized I have another meeting scheduled for 9:30am though. Should we adjust mine to 8:30-9:30am?
> **Nicole Bautista** · 2025-04-02 17:44 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1743615877458319)
> @Jacqueline Hood Yes, that works! I'll go ahead and add Beth and Alicia to the reminder. Is this in PST?
> **Whitney Hodges** · 2025-04-02 19:31 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1743622288595869)
> @Jacqueline Hood Do you think we should exclude Beth since she had us turn off all of her ads?
> **Jacqueline Hood** · 2025-04-02 23:59 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1743638349235699)
> @Whitney Hodges I don't think it hurts to include her!

**Whitney Hodges** · 2025-04-02 19:31 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1743622314959119)
has renamed the channel from "metafbgroup" to "metaads3monthimmersive"

**Whitney Hodges** · 2025-04-02 19:32 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1743622337271409)
@daniela This is a brand new offer, so although I don't have specific client results or case studies to share, I'm happy to show you more about the Meta Ad Accounts from some of our clients to give you a better feel for what to potentially expect. <https://www.loom.com/share/0fcabba7b4b240e691d66c1766aee1db?sid=237f59e1-999a-4e84-a1c6-9308797328ad|Please check out this video I recorded for you.>

**Whitney Hodges** · 2025-04-17 00:45 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1744850712701799)
@daniela I put some more thought into the 9 steps for the Meta Ads offer. <https://docs.google.com/presentation/d/18cIX02Mbus0QbW-wGLln96Glteybi_9Gww5wKPCYlDk/edit?usp=sharing|See pages 16 and 22.> I think this will play into the ILEA training and curriculum development. Your feedback is welcome! Do you think we should create a visual representation of the steps like last time?
> **daniela** · 2025-04-17 01:12 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1744852349042339)
> Sweet - I'll take a look! I do think having the visual icons is helpful, I can work on that, too. I am caught up on the AltAgency Workshop Training as well as the call replay, it's a great structure - working on restructuring the presentation with all of that in mind.

**daniela** · 2025-04-30 19:42 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1746042149056309)
@Whitney Hodges GHL is actively making improvements this year to their "communities" feature (and are really trying to be competitive with "Skool" from what I can tell).  I'm braindumping a bit here while it's fresh on my mind so that we can chat more about it later!

I'm messing around with a test group inside of the LeadLock subaccount, and it's actually pretty cool - it looks so similar to the Alt Agency stuff, with built-in leaderboards and progress trackers. They can also show the programs in a similar way where they have the learning materials set up where you can click into each focused program (it's almost like looking at each "course" as more of a "module" if that makes sense).  So there's an order of operations - so we have to create the Course(s) first, then connect them to the Group.

There are also abilities to set up Member "Levels" that can unlock other courses (so there may be a way we can strategically set this up where the curriculum is actually split among several unique "courses"  so that each milestone can unlock the next set of content.  For example, we can have the welcome + foundations portion as a standalone "course" that they get upon registering, and can have a second "course" that has the content around the phases of campaign rollouts that becomes available either manually when we are ready to "start", or we can separate out the phases and have those unlock upon launching each!

Just like Skool, it has tabs to organize Discussions, Learning, Members, Events, Leaderboard, etc.

I also think we can separate out the Live Support elements (so the call links can be associated with "events" in the group, and meeting replays can maybe live in a separate "course" from the other curriculim, etc.)

If we wanted to charge a separate ongoing fee for continued access to that after the 3 months are complete, I'm not sure if in order to remove them from the "discussion" and other areas though if that means removing them from the group entirely, but they continue to have access to the course materials?

I do note that there is an existing Meta Ads VIP Immersive Experience course product inside of the WIA subaccount, and that it currently houses all the replay videos - but I also only see one member in there.

Let me know if it's ok if I start building out the bones of this infrastructure inside of the WIA subaccount? I don't want to step on anyone's toes, but think it might be easier for me to actually figure it out by building the real thing instead of continuing with video research.
> **Whitney Hodges** · 2025-04-30 19:45 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1746042349553669)
> Yes, have at it! Nicole did start to build a course but didn't get very far. I think she is the only member
> **daniela** · 2025-04-30 22:15 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1746051350367779)
> Awesome - I'm shifting focus to ILEA workshop, but wanted to share a walkthrough of some stuff I figured out for the <https://www.loom.com/share/0199a5d706ba4c4bbf4627e559817829?sid=cf17ceec-c604-4a0d-93ee-aeb72754d5c1|community element in LeadLock!>
> **Whitney Hodges** · 2025-04-30 22:24 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1746051852437709)
> @daniela I think this looks really great! It would not have crossed my mind to build the modules as "courses". I really like the aesthetic of that! Do we have the flexibility to list the courses in whatever order we choose? For example, if we decide we need to add a step in between two existing courses, will we be able to do that easily?
> **Whitney Hodges** · 2025-04-30 22:24 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1746051859468319)
> What a productive day!!
> **daniela** · 2025-04-30 22:34 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1746052482184809)
> Yes -we can re-order the courses however is needed!

**Whitney Hodges** · 2025-05-07 17:03 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1746637426477879)
has renamed the channel from "metaads3monthimmersive" to "metaadsimmersive"

**daniela** · 2025-05-07 17:03 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1746637427405379)
<https://docs.google.com/spreadsheets/d/16BrqKxaaguipyaGMbj-Vr4yjL79-dkKQ95chJDbe1Xg/edit?usp=sharing|Meta Ads Immersive Spreadsheet>

**Whitney Hodges** · 2025-05-15 19:06 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1747336018949479)
@Jacqueline Hood We have our first signed contract for the new Meta Ads Immersive Experience!

I need to create a scheduler for kickoff calls the week of June 9th. I'm hoping our availability will align, so I can create a booking link that includes both of us. I'll let you take a look before I send it out.

@daniela I'm thinking that we need to have some sort of questionnaire tied to booking the kickoff call. And I'm thinking I'll just let her know that access to the portal will be in the next week or two. Anything else we should be considering at this point that you can think of?
> **Jacqueline Hood** · 2025-05-16 01:18 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1747358319528969)
> woohoo!! :smile:

**Whitney Hodges** · 2025-05-15 19:11 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1747336273419429)
@daniela Also, I'm a little confused because I got an alert that Sully paid $500. I guess I didn't realize there's the option not to PIF on Dubsado invoices? Or did you set up a payment plan?
> **daniela** · 2025-05-15 19:21 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1747336873295369)
> Hm. I did not set up a payment plan
> **daniela** · 2025-05-15 19:22 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1747336967282809)
> I'll look into the settings to see if there's something I can change to require full payment.
> 
> I think as long as this person pays in full by the start date, we're good to stick to that rate. We can communicate this in a reminder email at some point before the end of May
> **Whitney Hodges** · 2025-05-15 19:23 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1747336995593959)
> I haven't looked in Dubsado yet, but it looks like she paid $500 x2, so I'm assuming she's using different MOP
> **daniela** · 2025-05-15 19:23 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1747337033475309)
> Ah ok that makes sense. I do think Dubsado gives a space to enter the payment amount
> **Whitney Hodges** · 2025-05-15 19:25 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1747337107722969)
> I think that's done. She didn't ask for a payment plan, and I assume she's going to pay the remainder soon. I may sign off on counter signing until I receive. I'll reach out to her tomorrow to check in
> **daniela** · 2025-05-15 19:25 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1747337118979169)
> It does look like a "pay in full" payment plan is already part of the settings (these are settings inside the Proposal which generates the invoice upon submission)
> 📎 Screen Shot 2025-05-15 at 2.24.32 PM.png (png, saved as `files/F08SDFFTQRL-Screen_Shot_2025-05-15_at_2.24.32_PM.png`)
> **daniela** · 2025-05-15 19:26 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1747337163776169)
> We have the option to create a TY Page redirect! I'll look into setting this up and getting tracking on it
> **daniela** · 2025-05-15 19:26 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1747337187339539)
> And then if we did want to create workflow automations around this, we can have the project status trigger it

**Whitney Hodges** · 2025-05-16 15:36 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1747409797508959)
@daniela Hi! I can't seem to find where the curriculum spreadsheet with all the different presentation and video links is located, but I just recorded a <https://www.loom.com/share/1fe449f0b3a84febb5bd8fbe378a90a4|quick loom> for a client on how to access the Ads Library of competitors and thought this may be worth incorporating somewhere in the course
> **daniela** · 2025-05-16 17:44 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1747417443935779)
> Here's that <https://docs.google.com/spreadsheets/d/16BrqKxaaguipyaGMbj-Vr4yjL79-dkKQ95chJDbe1Xg/edit?usp=sharing|sheet >- I put it in the WIA | Resources folder, but feel free to move it somewhere else if that makes it easier for you to find!

**Whitney Hodges** · 2025-05-16 15:54 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1747410843560419)
@daniela Something else that has been on my mind is how to merge what we're currently offering for past meta ads immersive clients with this new cohort. 

For example, Janet is currently a monthly member for $197 accessing my office hours once per week. And Elsa is planning to rejoin soon as well. Should we give them access to the curriculum? Should new students have access to that office hours call but only once all their campaigns have launched?

I'm also thinking that giving access to the curriculum could be a way to reengage past immersive clients who didn't opt for the ongoing membership. Same thing for past Meta Ads VIP Day clients. We just wouldn't be building any campaigns for them since that work has already been done. 

What do you think?
> **daniela** · 2025-05-16 17:47 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1747417676425499)
> I love the idea of giving past clients access to the curriculum. I think it may be helpful for the new clients to access some sort of office hours for support/accountability with their ad content creation pieces. But if you want to keep the groups separate at first, that works too - but I don't think that's necessary

**Whitney Hodges** · 2025-05-21 18:08 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1747850902809149)
@Jacqueline Hood Hi! We're working on the <https://weddingindustryads.com/meta-immersive-kickoff|scheduler for the Meta Ads Immersive Experience Kickoff Call>. We want appointments to begin the week of the 9th. As of right now, you and I don't have much overlapping availability. Is your attached personal availability in LeadLock accurate? If not, can you please update. Thank you!!
📎 image.png (png, saved as `files/F08T6CQ1BDH-image.png`)

**Jacqueline Hood** · 2025-05-21 22:54 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1747868056243879)
@Whitney Hodges this is accurate, yes. But if I need to open something else up I can!
I'm just trying to be proactive before summer in terms of how many days I am booking calls with the kids home from school :slightly_smiling_face:
> **Whitney Hodges** · 2025-05-22 00:03 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1747872203463969)
> @Jacqueline Hood Ok! I opened up my availability for late afternoons/early evenings, and that gives us more overlap. <https://weddingindustryads.com/meta-immersive-kickoff|You can check it out here.> However, the times are kind of late for people who are CST or EST.  Also, we do have verbal commitment from a florist/event stylist who is in the UK, so all of these times would be in the middle of the night for her.
> 
> I know you have Friday mornings open for general availability for calls, but it looks like on the 13th and 20th of June you have full-day conflicts. Would you be open to opening up your morning availability on Monday, June 9th and potentially Monday, June 16th in lieu of those Fridays?
> 
> Lmk what you think! I know summer is crazy. Layla's last day of school is tomorrow :melting_face:
> **Jacqueline Hood** · 2025-05-22 13:27 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1747920479357469)
> Morning! Yes, that makes sense completely for our CST/EST and overseas clients. I can open up some time :slightly_smiling_face:
> June 20th I opened up and I can add in some time June 9th and 16th as well. I'll go in and adjust the calendar!
> **Whitney Hodges** · 2025-05-22 13:31 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1747920680221979)
> @Jacqueline Hood ok great! Please let me know once complete and then I'll send this over to Sully, so she can book her call. Thank you so much!!
> **Jacqueline Hood** · 2025-05-22 13:32 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1747920735781519)
> Done :slightly_smiling_face:

**Whitney Hodges** · 2025-05-22 21:56 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1747950971620849)
@Christina Hill Hi! Which (if any) of these clients, do you think may be a good fit for the Meta Ads Immersive Experience? Essentially, who has had great results from their Google Ads VIP Day but would also be enjoyable to work with in an ongoing collaborative way?

Leah Daniels
Michael Gregory
Davis &amp; Grey Farms
Cedarmont Farms
Eloping in Ireland
> **Christina Hill** · 2025-05-23 18:05 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1748023547786859)
> Michael Gregory
> 
> Cedarmont Farms
> 
> Davis &amp; Grey Farms (Note: They may be a good candidate. They haven't had the best results from Google Ads, but they are open to try different things and plan to do a promotion around September)
> 
> @Whitney Hodges

**daniela** · 2025-05-23 20:57 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1748033868561919)
Hi @Whitney Hodges ! Just sending an update - I reached out to Shannon Vondy and she's down to do an IG live with me next week to promote this offer :partying_face:
I'll do it through our WIA IG account - her audience is definitely aligned for us (and her profile has over 4k followers) so it should be pretty great exposure
> **Whitney Hodges** · 2025-05-23 20:58 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1748033926443079)
> Amazing thank you!

**daniela** · 2025-05-26 17:37 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1748281034478749)
Update for @Whitney Hodges on progress so far  building out the community and course elements in LeadLock:
<https://www.loom.com/share/4536b92dd61f4de4af3d6683ac40115d?sid=fa99ba59-5ce5-44b5-9c32-c731838a4d37>

**Whitney Hodges** · 2025-05-28 18:40 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1748457603686359)
@Jacqueline Hood Hi! Daniela and I are meeting right now and talking about the Meta Ads Immersive Experience. We want to bring you up to speed on the vision and talk about execution in more detail. Any chance you are available for a meeting on Monday? Daniela will be OOO Tues-Fri next week, and I'll be OOO Wed-Fri. Let me know what you think!!

**Jacqueline Hood** · 2025-05-28 18:47 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1748458065832709)
absolutely! I have lots of space on Monday :slightly_smiling_face:
> **Whitney Hodges** · 2025-05-28 18:49 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1748458166419239)
> K just sent you an invite! Lmk if the time doesn't work for you for whatever reason

**daniela** · 2025-05-29 22:01 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1748556078480009)
• Intake Questionnaire:	<https://weddingindustryads.com/meta-ads-immersive-questionnaire>
• Join the Group / Create your login link: <https://members.weddingindustryads.com/communities/groups/community/home?invite=6838cfc0c50c1d549ceaf1b>

**Whitney Hodges** · 2025-05-29 22:02 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1748556142239969)
<https://weddingindustryads.com/meta-immersive-kickoff>

**Whitney Hodges** · 2025-05-30 00:11 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1748563902356029)
@Jacqueline Hood Hi! Before we meet Monday, I wanted to share with you the <https://www.canva.com/design/DAGnL3jsSSE/3vDtI24EK9lre2K-JoHOkQ/edit|pitch deck I've been using for my Meta Ads Immersive Experience calls>. This should give you a feel for how I'm selling the program.
> **Jacqueline Hood** · 2025-06-03 15:44 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1748965440304469)
> This looks great!! Aww all the feels seeing those results and testimonials from our clients. So good!

**Whitney Hodges** · 2025-06-02 11:22 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1748863329914539)
@daniela Hi! I've been trying to figure out automating the next step after the Meta Ads Immersive Experience contract is signed and invoice is paid. From what I can tell using Zapier isn't going to be a viable option.

I was hoping a redirect url might work, and I could make that a trigger for kicking off a GHL workflow. But now I see a note in Dubsado that redirect urls don't work if your proposal includes a contract or invoice.

I've tried adding a workflow from the public proposal options, so we can send the welcome email that way, but with this option, the email gets sent write after the proposal is accepted. Users will receive the email even if they haven't signed the contract or paid the invoice.

I've also tried building a workflow from scratch (no idea if I'm doing it right), but it appears the trigger would be when any invoice is paid.

It definitely feels like I'm spinning my wheels at this point. Would you mind checking with Josie to see if she knows a way to send a canned email in Dubsado based on invoice payment of a particular package?
📎 image.png (png, saved as `files/F0908KT2ZDE-image.png`)
> **daniela** · 2025-06-02 16:14 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1748880862554939)
> I have a meeting with Josie this afternoon - we will take a look at that together.
> **daniela** · 2025-06-02 22:15 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1748902517792419)
> Hi @Whitney Hodges - I know it's late, we are looking at this now. Does the canned email already exist in Dubsado?
> **Whitney Hodges** · 2025-06-02 22:17 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1748902674494839)
> @daniela No, it doesn't, but if you can just confirm if it's possible and give me a quick how-to on how to do it. I can get it set up.
> 
> The other thing I was wondering is if there is an automated way the final version of the contract can get sent to the client once I've countersigned
> **Whitney Hodges** · 2025-06-02 22:21 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1748902898992399)
> Now that I've seen the limitations on the zaps and considering we're moving all schedulers and several questionnaires out of Dubsado, I'm less inclined to use Dubsado for contracts unless it is a full-service client
> **daniela** · 2025-06-02 22:25 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1748903128263179)
> We are able to send a welcome email from Dubsado when the form is submitted - I'll send you a loom in a minute!
> **Whitney Hodges** · 2025-06-02 22:29 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1748903382191229)
> The proposal form? I had figured out that part. But if someone doesn't actually sign the contract and pay the invoice, I don't want them to receive a welcome email yet
> **daniela** · 2025-06-02 22:40 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1748904044154569)
> Dubsado is so confusing...
> **Whitney Hodges** · 2025-06-02 22:45 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1748904323193979)
> I think Christopher from AltAgency can help us move payments and contracts for our productized offers into GHL. We could probably even hire him to do it if pricing makes sense. Looks like he's the one that set up AltAgency's stuff. <https://simpleautomations.io/>
> **daniela** · 2025-06-02 22:45 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1748904352750289)
> Ok I think we figured it out - since the trigger is a "paid invoice" and we are using 100% discount code to test, we needed to push the workflow through manually, but you can go ahead and add the email copy to that workflow (or link it to a canned email)
> **Whitney Hodges** · 2025-06-02 22:47 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1748904432216119)
> Ok! Help me understand. Does this email go out to anyone who pays an invoice or only to paid invoices for this particular package?
> **daniela** · 2025-06-02 22:48 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1748904493644749)
> Should be just for this package - i connected this workflow to both the full price and into rate proposals for the meta ads immersive
> **daniela** · 2025-06-02 22:53 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1748904793297679)
> Here's a loom: <https://www.loom.com/share/16dee2d6e9774869a02c38f688f5ca65?sid=df5bea88-d4fe-4248-895b-572d792cf24b>
> **Whitney Hodges** · 2025-06-02 23:03 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1748905383091929)
> @daniela Thank you for that video. Dubsado makes things way more complicated than they need to be. :melting_face:
> 
> What do you think for the email below? This is super similar to what I got when we joined AltAgency. I think we keep it simple instead of having a general welcome email plus a next steps email. Let's just tell them what to do right away
> 
> _Subject: Welcome to the Meta Ads Immersive Experience!_ :sparkles: _Here's your first move..._
> 
> _Hi!_
> 
> _You just made the amazing decision to join the Meta Ads Immersive Experience. It's time to hit the ground running!_
> 
> _Let's keep this simple - your only job right now is to get into our members area in LeadLock and check out the Start Here course._
> 
> _That's where all the magic begins!_
> 
> _Here's what to do:_
> 1. _<https://members.weddingindustryads.com/communities/groups/community/home?invite=6838cfc0c50c1d549ceaf1b|Click this link to join our Wedding Industry Ads community in LeadLock.>_
> 2. _Create your profile_
> 3. _Request to join our private group The VAULT by WIA (We'll approve you within a few hours during business hours, or first thing next business day)_
> 4. _Once you're in, head straight to "Start Here" and follow the yellow brick road_ 
> _That's it! No need to overthink this part - just click that link and let's get this journey started._
> 
> _Can't wait to see you inside!_
> 
> _Team WIA_
> 
> _P.S. If you requested access during business hours, you should be approved within a few hours. Otherwise, we'll get you set up first thing next business day!_
> **daniela** · 2025-06-02 23:17 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1748906250557229)
> Love it - I think this is perfect
> **Whitney Hodges** · 2025-06-02 23:20 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1748906459551109)
> K I'm going to go ahead and add it as a canned email now and connect it to the workflow\
> **Whitney Hodges** · 2025-06-02 23:25 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1748906716352289)
> @daniela Does the link in the email above still work? This is what I'm seeing. Maybe this is because I had created an account then was removed?
> **Whitney Hodges** · 2025-06-02 23:25 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1748906740899279)
> 📎 image.png (png, saved as `files/F08V0UJLG8M-image.png`)
> **Whitney Hodges** · 2025-06-02 23:28 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1748906900349059)
> I'm trying with other Chrome profiles and am getting the same error. Maybe this is a unique one-time use link?
> **daniela** · 2025-06-03 00:29 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1748910565578499)
> Oh interesting. It’s not working on my phone - I’ll try again when I’m back at my desk 
> **daniela** · 2025-06-03 00:29 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1748910587411239)
> Maybe see if that’s the same link as in that spreadsheet 
> **Whitney Hodges** · 2025-06-03 00:35 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1748910912818689)
> It's the same as the link in the spreadsheet. Maybe it's no longer valid since the name of the group changed?
> **Whitney Hodges** · 2025-06-03 00:53 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1748912015524249)
> Here's a new link that I just grabbed from inside the group. I did a test signup with it, and it's still working for me under different profiles. When you can, can you please test to see if this link is valid for you, too? <https://members.weddingindustryads.com/communities/groups/the-vault/home?invite=683e4564c87519b609554ac4>
> **daniela** · 2025-06-03 01:05 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1748912750604949)
> That worked! It sent me a verification code to my email, and then I was able to set up my profile with a picture - ended up here: 
> 📎 IMG_2670.png (png, saved as `files/F08UXKPRJKG-IMG_2670.png`)
> **Whitney Hodges** · 2025-06-03 01:06 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1748912804584979)
> K thanks! Link in spreadsheet has been updated

**daniela** · 2025-06-02 17:54 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1748886872821999)
@Jacqueline Hood intake questionnaire: <https://weddingindustryads.com/meta-ads-immersive-questionnaire>

**Whitney Hodges** · 2025-06-02 19:17 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1748891845648929)
@Jacqueline Hood Following up on action items from our call:

Please record a video walking through good landing pages - About Love, Exquisite Moments, The Views at Sunset Ridge

Select days/times for weekly group calls for the program. We want to put these on the calendar in the portal ASAP. Same day/time each week would be preferred, if possible.

Here's what I'm thinking for upcoming topics:
Week of June 9 - realtime landing page audits
Week of June 16 - realtime client attraction curation
Week of June 23 - direct response copy/creative workshop
Week of June 30 - nurture retargeting workshop
> **daniela** · 2025-06-02 19:31 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1748892690122289)
> I added this to the Welcome section with office hours links and scheduled calls!
> **Jacqueline Hood** · 2025-06-03 15:48 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1748965682344139)
> Let's do Thursdays 9-10am PST. This overlaps with my other monthly office hours scheduled call but there's no one in that anyway so I think this works!
> **Jacqueline Hood** · 2025-06-03 15:48 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1748965687793819)
> @Whitney Hodges
> **Whitney Hodges** · 2025-06-03 16:05 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1748966736780079)
> @Jacqueline Hood Ok, great! Can you please schedule this as a recurring meeting on your calendar, generate the Zoom link and then send that to me?
> **Jacqueline Hood** · 2025-06-04 14:10 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1749046212824439)
> Yup! just created the recurring event, can I just use this existing zoom link? <https://weddingindustryads.com/jacqueline-zoom1>
> **Whitney Hodges** · 2025-06-04 14:24 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1749047075378099)
> @Jacqueline Hood Yes, that works! Also, I wanted to throw this out there for you to think on:
> 
> If you would prefer doing the more general Weekly Office Hours and having me do the Weekly Workshops, I'm good with that. I think ideally that would be my preference because you work so much more than I do inside the Meta Ads Manager at this point.
> 
> But I didn't suggest it because of the timing. Janet (The Red Wedding) currently attends my office hours every week. She was the very first person to ever sign up for the Meta Ads Immersive Experience, and she is based in Singapore, so I scheduled office hours keeping her time zone in mind. It's 8am-10am CST on Wednesdays which is like 9pm or 10pm for her depending on daylight savings. This would be 6am-8am your time which I know is crazy early, so I don't want to ask that of you.
> 
> However, if Janet ever drops out of the program, that may be the opportunity to revisit scheduling for office hours and flip flop our responsibilities.
> 
> Or we could just make the change now, knowing that we could potentially lose Janet as a member. I want to accommodate her, but it also feels a little silly scheduling office hours based on just one person who's only paying $197/month.
> 
> @daniela Your thoughts here are welcome, too!!
> **Jacqueline Hood** · 2025-06-04 16:06 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1749053202964829)
> @Whitney Hodges Hi!
> That actually make a lot of sense to have me do the weekly office hours and you do the workshops. Especially since I'll be one of the ones actually building out their campaigns, etc., I'll have a good sense of what each client is running already :slightly_smiling_face:
> 
> I think you're right in that scheduling office hours around just Janet's schedule might be a bit limited. Maybe we reschedule the general office hours time (6-8am PST is also really early for us west coast people to attend) and offer Janet another option if the new time doesn't work for her?
> Maybe a dedicated call one a month at a time that works for her, or her own Slack channel where we can send voice notes/etc and offer personalized support that way instead?
> **Whitney Hodges** · 2025-06-04 16:18 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1749053898011349)
> @Jacqueline Hood yes, glad we're on the same page!!

**daniela** · 2025-06-02 19:29 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1748892558681339)
@Whitney Hodges got a notification from LeadLock when we created that event!
📎 Screen Shot 2025-06-02 at 2.28.49 PM.png (png, saved as `files/F08UWBNP4R4-Screen_Shot_2025-06-02_at_2.28.49_PM.png`)

**Whitney Hodges** · 2025-06-02 23:38 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1748907524843989)
@daniela I sent a membership request. Can you please approve and make me an admin? I'm not seeing a way to authorize this myself. Thank you!!
> **Whitney Hodges** · 2025-06-03 00:46 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1748911614959179)
> Nvm. I logged in as you and approved the request

**Whitney Hodges** · 2025-06-03 01:01 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1748912515484549)
@Yulia Burris @Jacqueline Hood Hi! Can you both please add bios for yourselves inside our community portal? And Jacqueline, just FYI, it will ask you to add a profile picture when you officially sign up.

Not at all urgent, but I am noticing that random numbers/letters populate at the end of our usernames. Maybe something we want to troubleshoot at a later date @daniela
> **Yulia Burris** · 2025-06-03 02:18 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1748917107450239)
> @Whitney Hodges done :white_check_mark:  
> Let me know if you want me to add another bio)
> **Jacqueline Hood** · 2025-06-03 15:52 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1748965926388139)
> @Whitney Hodges are you able to resend my invite? It says good for 30 days but when I click through, it says the invite has expired.
> **Whitney Hodges** · 2025-06-03 16:01 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1748966460126319)
> @Jacqueline Hood I think you may have already joined but just need to update your profile. Let's take a look on the team call

**Whitney Hodges** · 2025-06-03 01:02 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1748912524667809)
📎 image.png (png, saved as `files/F08UWDTMVUK-image.png`)

**daniela** · 2025-06-03 01:14 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1748913283336369)
I was able to change the path of my profile name manually inside the profile settings within the community 
> **Whitney Hodges** · 2025-06-03 01:18 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1748913533932129)
> Got it! I changed mine. I was trying to see as admin, if we had the ability to change it for other users, and we do not.
> 
> @Jacqueline Hood @Yulia Burris When you populate your profiles, please clean up your usernames, too. Thank you!

**Yulia Burris** · 2025-06-04 00:17 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1748996263315179)
@Whitney Hodges @daniela

Hi! Just wanted to follow up and share an update on LeadLock (Meta Ads Immersive Experience).
This is mainly to help us track what’s been done — let me know if you’d like any changes.
Also, please keep me posted when new videos are ready. Let me know if this format works for you, or I can add everything to a spreadsheet instead.

*Today’s updates:*
• Uploaded Welcome video + thumbnail + added the PDF
• Created a thumbnail for the “Set Up & Manage Your Account” section (<https://www.canva.com/design/DAGmI-jQjNo/3PMHYbtthwKpwZ_mLgye6Q/edit|in Canva – Cover pages>), trimmed and uploaded the video to the platform
• Trimmed the _Understanding Meta Ads Evergreen Funnel Strategy_ video, <https://drive.google.com/drive/folders/1pX2m0SxY0rQJlPxN47JfKxdmph1Y5Qwk|uploaded it to the folder> and the platform + added a cover 
• Added PDF + description section for _Understanding Meta Ads Evergreen Funnel Strategy_
• Added a thumbnail with a new title for _Understand Foundational Meta Ads Knowledge_
• Added a thumbnail with a new title for _Connect Kickoff Call & Tech Connections_
• Uploaded the video _Five Foundations for Success with Ads_
• Uploaded the video for the section _Audit & Adapt (Speed to Lead – Inquiry Follow-Up System)_ + created a thumbnail for it
> **Whitney Hodges** · 2025-06-04 00:41 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1748997713684659)
> @Yulia Burris Thank you SO much! I'm so thrilled to have you on the team. Truly grateful for you diving right in to help us get this off the ground.
> 
> One note: for PDF resources, let's add them as attachments instead of putting a link in the Description. See screenshot. I went ahead and made the change for the Welcome Guide.
> 
> Tomorrow, can you please make this update for the Understanding Meta Ads Evergreen Funnel Strategy and Five Foundations for Success with Meta Ads lessons?
> 
> @daniela @Jacqueline Hood The VAULT is now ready for us to begin welcoming members! (I turned a couple lessons into drafts for now, so we don't have anything incomplete client-facing at this time.) Tomorrow morning, I will send invites to Sully, Shelby, and Alyssa.
> 
> On my immediate to-do list is recording the video for <https://www.canva.com/design/DAGXCIvygRg/WEhzgX3M_d2rBpjM-YIJYA/edit|Understanding the Meta Ads Manager> (simplified this title btw).
> 
> The other immediate area of opportunity is enhancing the <https://members.weddingindustryads.com/courses/products/4b766a56-cd9d-4946-9812-1c4f7f936946?source=communities&amp;group_slug=the-vault|Audit &amp; Adapt course>. Any input is welcome on additional resources to share here. I think a checklist would be helpful. @Jacqueline Hood This is also where we could use your video walkthrough of strong client landing pages: <https://info.theviewsatsunsetridge.com/views1|The Views at Sunset Ridge>, <https://info.aboutlove.events/landing-page-3254|About Love>, <https://info.exquisitemomentssd.com/landing-page|Exquisite Moments>. Once we have all the resources we want members to consume for this section, we'll want to repost the Submit Your Landing Pages For Review post (I deleted it for now).
> 
> Thank you all!!!
> 📎 image.png (png, saved as `files/F08UVF39RHD-image.png`)
> 📎 image.png (png, saved as `files/F0907V3S8PK-image.png`)
> **Jacqueline Hood** · 2025-06-04 14:14 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1749046487756379)
> amazing!! I'll film that video today and send it over, and then look over the Adapt &amp; Audit section and see if I can think of anything else we can add in there :heart:
> **daniela** · 2025-06-04 16:27 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1749054431319909)
> Wonderful updates!!

**Whitney Hodges** · 2025-06-04 13:43 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1749044580944529)
@Yulia Burris Good morning! I've added the Understanding the Meta Ads Manager video and slide deck to <https://drive.google.com/drive/folders/1pX2m0SxY0rQJlPxN47JfKxdmph1Y5Qwk?usp=sharing|this folder>. Can you please add those to the Understand course and include a description for the lesson? Then change from Draft to Publish once complete. Thank you so much!
> **Yulia Burris** · 2025-06-04 14:11 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1749046292816029)
> @Whitney Hodges good morning! Will do today :dizzy: 

**Jacqueline Hood** · 2025-06-04 15:59 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1749052778588219)
Hi @Whitney Hodges :slightly_smiling_face: I put this <https://docs.google.com/document/d/1AhaconAKG7fe-DzoEwFxIJ9AOp6zCb9OzgNr8W1D2_k/edit?usp=sharing|outline> together before I record the LP video

Do you want this put into a simple slide deck first and then I can record along with the slides and then do the walkthrough of the 3 landing pages?
Maybe @Yulia Burris could help create this?

Otherwise we can just use the google doc but I'd like it to be branded properly :slightly_smiling_face: I'm not sure how to add the Lovelace font to a google doc?
> **Yulia Burris** · 2025-06-04 16:13 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1749053612668679)
> @Jacqueline Hood @Whitney Hodges :+1: ok, lmk if I should create this and what the due date is) 
> **Jacqueline Hood** · 2025-06-04 16:14 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1749053671889109)
> @Yulia Burris I'd love to get the video filmed today so if you're able to whip something up this morning, that'd be amazing! If not, we can always circle back and update it later!
> @Whitney Hodges LMK your thoughts too :slightly_smiling_face:
> **Whitney Hodges** · 2025-06-04 16:16 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1749053793944409)
> @Jacqueline Hood the outline looks amazing! @Yulia Burris are you able to prioritize this this morning?
> **Yulia Burris** · 2025-06-04 16:23 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1749054191589909)
>  @Whitney Hodges Sure, I can do it! @Jacqueline Hood, how many slides would you like me to create in Canva? Do you have any preferences? 
> **Whitney Hodges** · 2025-06-04 16:34 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1749054855816189)
> @Yulia Burris I left some comments in the doc indicating what should go on each slide. There probably needs to be some sort of final slide to wrap things up. The Canva design can be super simple. Even if it's just text that's ok. Just want it to have our brand fonts/colors. If you want to duplicate one of the other presentations and edit from there, that's great!
> **Jacqueline Hood** · 2025-06-04 16:41 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1749055273794199)
> thanks so much @Yulia Burris :slightly_smiling_face:
> **Whitney Hodges** · 2025-06-04 16:43 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1749055433761579)
> @Jacqueline Hood I don't need to approve the slides before you record. If they look good to you, go for it! I've been using Canvas's present and record feature, and it works great!
> **Jacqueline Hood** · 2025-06-04 19:35 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1749065726090309)
> Ok perfect! :slightly_smiling_face:

**daniela** · 2025-06-04 16:29 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1749054581192749)
SOOO EXCITING!! Thanks for helping us bring this to life @Yulia Burris @Jacqueline Hood!!

I was able to tuck into a coffee shop this morning to tidy up our <https://docs.google.com/spreadsheets/d/16BrqKxaaguipyaGMbj-Vr4yjL79-dkKQ95chJDbe1Xg/edit?usp=sharing|spreadsheet> a bit more @Whitney Hodges!! Looks like all the canva presentations are set up now to where "anyone with the link can edit" - but let me know if anyone runs into any access issues :heart:
📎 IMG_2692.HEIC (heic, saved as `files/F090CBD9LHF-IMG_2692.HEIC`)
> **daniela** · 2025-06-04 16:45 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1749055503021039)
> @Yulia Burris I just granted your request to edit the "speed to lead" canva file!
> 
> I'm going to put away my laptop now, but I'll keep checking in on slack - if you could, just send me a message here if you submit a request and I can go into my email on my phone to grant access to anything else you might need :relaxed:
> **Yulia Burris** · 2025-06-04 16:51 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1749055866191089)
> @daniela thank you so much:) 

**Jacqueline Hood** · 2025-06-04 19:43 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1749066228675869)
Audit &amp; Adapt Feedback:

-love the 5 foundations!
-this is where the landing page elements/audit will go, correct

The only other thing I can of to add here would be a training video on content creation. "How to create content that's perfect for ads" or something. I know we'll dive into it more when it comes to their specific client attraction and RT ads down the road, but if they can be primed to it now in terms of new content they are creating, it could help?

If they're creating organic content anyway that can easily be repurposed for ads, they'll be working smarter, not harder.

Things like adding a logo and/or CTA to the end of a reel, or making their carousels only 10 images long, or ensuring that there's some text on a reel providing some context as to who they are/what they do/who they serve so that someone completely cold seeing it - has some idea what they do. We can give the example of clients coming to us with gorgeous video content but needing to add some context because the audience has no idea if it's a venue, photographer, designer, planner, etc.

@daniela @Whitney Hodges certainly not required, but could be a good piece to add this early on in the program!
> **Whitney Hodges** · 2025-06-10 23:04 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1749596682936609)
> @Jacqueline Hood Hi! As discussed today, if you could please touch on this during office hours this Thursday, we can then trim that recording and turn it into more curriculum. Thank you!!
> 
> cc @daniela @Yulia Burris
> **Yulia Burris** · 2025-06-10 23:42 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1749598945334199)
> @Whitney Hodges  @daniela  @Jacqueline Hood 
> We could show them some simple creatives. I know a lot of people worry about running ads for themselves, especially when it comes to creating the content. It would be great to show that creatives can be simple and easy to make—just a good vibe video or photo with minimal text.
> 
> We could include examples from clients and from the Meta ad library. You can find ads for any niche using the <https://www.facebook.com/ads/library/?active_status=active&ad_type=political_and_issue_ads&country=US&is_targeted_country=false&media_type=all|Meta Ad Library> - maybe we could show that during the workshop? It might help them see what others are doing and learn how to spot what works, like strong CTAs (be unique). 
> 
> *Just an idea—it’s not necessary :) 
> 
> **Whitney Hodges** · 2025-06-10 23:45 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1749599150890249)
> Yes, clients are always so excited when we show them page they can look at a competitor's page transparency to see the exact ads they have running! I like the idea of having a quick video resource for this somewhere
> **Jacqueline Hood** · 2025-06-12 21:29 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1749763757292509)
> @Whitney Hodges we didn't get a chance to touch on client attraction ads during the call today so this will have to be a topic for another call!
> **Whitney Hodges** · 2025-06-12 21:38 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1749764320329969)
> @Jacqueline Hood thank you for the update! Im planning to make my workshop on Tuesday be supplemental client attraction curriculum. If there is anything in particular you think I should incorporate, lmk!

**Yulia Burris** · 2025-06-04 19:47 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1749066420059759)
@Jacqueline Hood
@Whitney Hodges @daniela

<https://www.canva.com/design/DAGpaRQOwVc/QIblP1JoQBoNAUfDFNmDCQ/edit?utm_content=DAGpaRQOwVc&amp;utm_campaign=designshare&amp;utm_medium=link2&amp;utm_source=sharebutton|Here’s the presentation for your review>. I edited it in my Canva account, and you can copy it to your profile.
> **Whitney Hodges** · 2025-06-05 13:26 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1749129996362049)
> @Yulia Burris This is beautiful! Excellent job!

**Yulia Burris** · 2025-06-04 21:59 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1749074388530979)
@Whitney Hodges @daniela
Hi! Quick update for the Meta Ads Immersive Experience:
• Uploaded the _Understanding the Meta Ads Manager_ video + new covers + added PDF and lesson description
• Uploaded PDFs for the _Understanding Meta Ads Evergreen Funnel Strategy_ and _Five Foundations for Success with Meta Ads_ lessons

**Jacqueline Hood** · 2025-06-04 23:45 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1749080708790249)
Recording Link for the Landing Page Presentation: <https://www.canva.com/design/DAGpaRQOwVc/zlHA17H2gnn9CXGXlsedHw/view?utm_content=DAGpaRQOwVc&amp;utm_campaign=designshare&amp;utm_medium=link2&amp;utm_source=uniquelinks&amp;utlId=h4beb85037d|https://www.canva.com/design/DAGpaRQOwVc/zlHA17H2gnn9CXGXlsedHw/view?utm_content=DA[…]hare&amp;utm_medium=link2&amp;utm_source=uniquelinks&amp;utlId=h4beb85037d>
> **Whitney Hodges** · 2025-06-05 13:41 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1749130884420169)
> @Jacqueline Hood This is excellent! Thank you so much. Can you please download the video and upload it to <https://drive.google.com/drive/folders/1CqNZX7EYQSuFCQ8usLO56qlPAHV3sCWz?usp=sharing|this folder>? @Yulia Burris You can go ahead and add the video and slide deck and a description for all of this. No need to splice it together with part two. That piece can just be added later. Jacqueline, when it's ready, you can drop it in the same folder.
> **Jacqueline Hood** · 2025-06-05 16:11 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1749139877545299)
> Part 1 is downloaded and dropped in the folder (the video and the PDF) @Yulia Burris
> **Yulia Burris** · 2025-06-05 18:10 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1749147004938009)
> @Jacqueline Hood Hi! Could you please give me access to download this 11-minute video from Canva? The one currently in the folder has an issue — it’s only 1 minute long and has no sound
> **Yulia Burris** · 2025-06-05 18:12 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1749147125333439)
> @Jacqueline Hood maybe something went wrong during the download. It happens sometimes
> **Jacqueline Hood** · 2025-06-05 18:18 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1749147484841709)
> oh shoot! Here's the link: <https://www.canva.com/design/DAGpaRQOwVc/zlHA17H2gnn9CXGXlsedHw/view?utm_content=DAGpaRQOwVc&amp;utm_campaign=designshare&amp;utm_medium=link2&amp;utm_source=uniquelinks&amp;utlId=h4beb85037d|https://www.canva.com/design/DAGpaRQOwVc/zlHA17H2gnn9CXGXlsedHw/view?utm_content=DA[…]hare&amp;utm_medium=link2&amp;utm_source=uniquelinks&amp;utlId=h4beb85037d>
> **Jacqueline Hood** · 2025-06-05 18:20 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1749147622400229)
> Hopefully you can download the entire thing! I just tried again and you're right, only 1 minute downloaded
> **Jacqueline Hood** · 2025-06-05 18:20 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1749147641445349)
> If not we can record a loom, play the video and record it that way, then just trim the ends?
> **Jacqueline Hood** · 2025-06-05 18:20 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1749147648834699)
> Part 2 of the LP training is in the folder as well :slightly_smiling_face:
> **Yulia Burris** · 2025-06-05 18:26 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1749147985361539)
> @Jacqueline Hood still don’t have access. When you downloaded the video, did it work? If you’re able to download it from your account, could you please give it a try?
> If not, just let me know :)
> **Jacqueline Hood** · 2025-06-05 18:51 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1749149472729229)
> I don't actually know how to download from Canva other than downloading the file as an MP4? is there another way?
> **Yulia Burris** · 2025-06-05 19:06 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1749150419950839)
> @Jacqueline Hood 
> Did you record it in Canva?
> 
> Try this:
> You can check the “Projects” tab in Canva → “Recordings” and download it from there.
> 
> Click the “Share” :arrow_right: Select “Download” :arrow_right: In the “File type” section, choose “MP4 Video” :arrow_right: Click “Download”. 
> 
> If that doesn’t work, we’ll find another way to save it:)
> **Jacqueline Hood** · 2025-06-05 20:12 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1749154344276619)
> Bah. I don't see a "recordings" under my project!
> But I tried downloading as MP4 but it only downloads the 1 minute version. Hmmm
> **Jacqueline Hood** · 2025-06-05 20:15 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1749154529092739)
> I'll try recording a loom and then playing the Canva presentation and recording it that way :slightly_smiling_face:
> **Whitney Hodges** · 2025-06-05 22:42 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1749163346578399)
> @Jacqueline Hood just FYI when I did Present &amp; Record in Canva, I downloaded it as soon as I was finished, right when it prompted me.
> **Jacqueline Hood** · 2025-06-05 23:54 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1749167681339519)
> I don't remember seeing that prompt ever come up when I record in Canva, just "save and exit" and then it gives me the link. Hmm
> **Jacqueline Hood** · 2025-06-06 00:24 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1749169495372999)
> Figured it out! Dropping the full video in the folder now!
> **Yulia Burris** · 2025-06-06 00:28 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1749169713448759)
> @Jacqueline Hood Thank you so much! I’ll add everything to the platform now.
> cc: @Whitney Hodges

**Jacqueline Hood** · 2025-06-04 23:45 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1749080744402979)
I couldn't figure out how to share my screen when recording in Canva so I haven't yet walked through the LP examples. I'll record a part 2 tonight with LP examples and share the video here when I'm done! @Whitney Hodges @Yulia Burris

**Jacqueline Hood** · 2025-06-04 23:46 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1749080766385129)
BTW @Yulia Burris the slides were gorgeous!!! :heart_eyes:

**Whitney Hodges** · 2025-06-04 23:53 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1749081198048839)
@Jacqueline Hood I don't think you can screen share with Canva, so it will probably need to be a loom. Totally fine if that video is separate. That may be better actually because shorter videos will be easier for members to consume

**Yulia Burris** · 2025-06-05 00:03 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1749081808164249)
@Jacqueline Hood @Whitney Hodges  
I can combine and edit them with transitions if needed — just let me know) 

**Jacqueline Hood** · 2025-06-05 02:15 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1749089729226129)
I'll work on it tonight :slightly_smiling_face:

**Whitney Hodges** · 2025-06-05 13:57 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1749131859687619)
@Jacqueline Hood I've updated The VAULT to reflect that I will now be hosting weekly workshops on Tuesdays from 11am-12pm CST, and Jacqueline will host weekly office hours on Thursdays from 11am-12pm CST.

@Yulia Burris Inside these events on the Events Calendar, there is the opportunity to add a thumbnail image. Without one, a stock image populates. Not urgent, but when you have a chance, can you please create custom images for these events and upload? Thank you!!
> **Yulia Burris** · 2025-06-05 18:19 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1749147599817559)
> Hi! @Whitney Hodges Just to clarify — do you want some stock images or your own photo, and then I’ll add graphics with text like “Whitney’s Weekly Workshop”? Or would you prefer just a slide with text like “Upcoming Event”?:)
> **Whitney Hodges** · 2025-06-05 21:39 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1749159581495979)
> I think simple designs that say Whitney's Weekly Workshop and Jacqueline's Weekly Office Hours is good! @Yulia Burris
> **Yulia Burris** · 2025-06-06 00:57 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1749171440347829)
> @Whitney Hodges @Jacqueline Hood Hi :) Do these two cover styles work for you for the calendar events?
> I’ve added them to the platform for one event — if you approve, I’ll apply them to all events.
> Just let me know :)
> 📎 1....png (png, saved as `files/F090YN9FRB2-1....png`)
> 📎 2.....png (png, saved as `files/F0901PDFRD1-2.....png`)
> **Whitney Hodges** · 2025-06-06 01:14 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1749172465983479)
> @Yulia Burris looks great!!

**Whitney Hodges** · 2025-06-05 14:13 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1749132803781449)
Invites to The VAULT have been sent to all of our Meta Ads Immersive Experience members:
• Alyssa Glorioso, Glorious Weddings
• Shelby Kenney, SK Events &amp; Design
• Sully Montero, Teach Travel Discover
If anyone sees members requests come through for them today, please go ahead and approve. Thank you!!

**Yulia Burris** · 2025-06-06 01:10 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1749172254000899)
@Whitney Hodges @daniela
Hi everyone! Just a quick update on the Meta Ads Immersive:

• I’ve uploaded the Part 1 video — _“Elements of a High-Converting Landing Page”_ to the platform, + with the description, covers, and PDF. *(in drafts)*
:interrobang: I couldn’t upload Part 2 because the platform only lets me add one video per class. Do you know if there’s a way to add a second video to the same class? (Files/description?)

• uploaded two cover options for the Events Calendar — <https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1749171440347829?thread_ts=1749131859.687619&cid=C082DURRJ2U|just waiting on approval> :slightly_smiling_face:
cc: @Jacqueline Hood

**Whitney Hodges** · 2025-06-06 01:18 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1749172689963859)
@Yulia Burris The part two video will need to be added separately, and that's totally ok. Maybe just call it Examples of High Converting Landing Pages
> **Yulia Burris** · 2025-06-06 01:20 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1749172816978139)
> Ok, thank you so much. I will upload the second part early tomorrow morning

**Whitney Hodges** · 2025-06-06 21:30 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1749245403937329)
I just published the landing page videos in the Audit &amp; Adapt course!

**Whitney Hodges** · 2025-06-09 17:37 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1749490630226809)
@Yulia Burris Hi! Daniela and I just met to talk more about curriculum for the Meta Ads Immersive Experience and have identified some things you can jump in to help with. I've included them in a list below, but I think you'll find it most helpful to <https://fathom.video/share/upWvwLX2VuxnXkFYSzXRYvNiqVDLFvcE|check out the recording of our call.>
• Turn 5 foundations and landing page training into a checklist. PDF design in Canva.
• Client attraction ads look book. I'll send you links to the ads. Then they need to be turned into a Canva presentation. Click on the link of the screenshot of the ad, then it opens the ad.
• Apply theme to all courses
• Look into editing the logo that's included in the emails (not urgent)
Please let me know if you have any questions! Thank you!
> **Yulia Burris** · 2025-06-09 17:48 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1749491319081999)
> @Whitney Hodges  ok, got it. Will do it, what is a deadline? Will start to do today, if will have some questions (i am sure will have), will tag you here:) 
> **Whitney Hodges** · 2025-06-09 18:16 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1749492970202579)
> @Yulia Burris I think we'd love to have the checklist published in the portal by tomorrow, if possible. And the client attraction workbook live by Friday. Thank you!!
> **Yulia Burris** · 2025-06-10 14:49 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1749566976993619)
> @Whitney Hodges @daniela Good morning! Here’s <https://www.canva.com/design/DAGp9b6HwNI/_NkLebcUF_n6aVE9OtdnjA/edit?utm_content=DAGp9b6HwNI&amp;utm_campaign=designshare&amp;utm_medium=link2&amp;utm_source=sharebutton|the PDF checklist for your review>. Let me know if you like this style or prefer a different text—I can make changes.
> **Yulia Burris** · 2025-06-10 19:17 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1749583052202379)
> @Whitney Hodges @daniela Hi! I <https://www.canva.com/design/DAGp-lfJcD8/O601KpCHBIuinUrNGgwd8w/edit?utm_content=DAGp-lfJcD8&amp;utm_campaign=designshare&amp;utm_medium=link2&amp;utm_source=sharebutton|just edited the PDF file> — let me know if you’d like everything on one slide or prefer each slide with screenshots/pics)
> **Whitney Hodges** · 2025-06-10 23:42 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1749598955596669)
> @Yulia Burris Thank you! I made edits, so that it lists the exact bullets that I'd like to see included. My changes messed with the formatting, sorry. Can you please adjust, so the spacing is better? Also, since it's now just three sections, I think they can each be the full width of the page instead of two columns.
> **Yulia Burris** · 2025-06-10 23:43 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1749598999101689)
> @Whitney Hodges of course! Thank you 
> **Yulia Burris** · 2025-06-11 00:09 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1749600591469189)
> @Whitney Hodges <https://www.canva.com/design/DAGp-lfJcD8/O601KpCHBIuinUrNGgwd8w/edit?utm_content=DAGp-lfJcD8&amp;utm_campaign=designshare&amp;utm_medium=link2&amp;utm_source=sharebutton|Edited> -  let me know if that works:)
> **Whitney Hodges** · 2025-06-11 00:21 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1749601318516569)
> @Yulia Burris Yes, it's great!! I added a section for this in Audit &amp; Adapt. Can you please update and publish tomorrow?
> **Yulia Burris** · 2025-06-11 00:23 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1749601386855709)
> @Whitney Hodges yes, I'll publish at 8am:)
> **Yulia Burris** · 2025-06-11 13:16 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1749647760438009)
> @Whitney Hodges Good morning! Just published it — added the cover, description, and PDF.
> **Whitney Hodges** · 2025-06-11 17:32 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1749663155565229)
> @Yulia Burris It looks great!!

**Yulia Burris** · 2025-06-10 19:32 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1749583928929149)
Hi! @Whitney Hodges.  Can you please send me the Canva presentation link for _Auditing Your Inquiry Process &amp; Optimizing for Ads Traffic_ that you used for the workshop today? I’ll upload everything to the platform. Thank you :slightly_smiling_face:
> **Whitney Hodges** · 2025-06-10 20:42 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1749588155061039)
> @Yulia Burris Hi! I uploaded the recording and the PDF slide deck to the <https://drive.google.com/drive/folders/1CqNZX7EYQSuFCQ8usLO56qlPAHV3sCWz?usp=sharing|Audit &amp; Adapt folder>. <https://www.canva.com/design/DAGp9eGlS1s/jRy9rtA82h1ZTcTI6R1pew/edit?utm_content=DAGp9eGlS1s&amp;utm_campaign=designshare&amp;utm_medium=link2&amp;utm_source=sharebutton|Here's the link to the presentation in Canva, too.> Thank you so much!!
> **Yulia Burris** · 2025-06-10 21:26 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1749590792157909)
> @daniela @Whitney Hodges Hi! The video, description, PDF, and thumbnail for the video _Auditing Your Inquiry Process &amp; Optimizing for Ads Traffic_ have been uploaded. Let me know when the new content for the platform will be ready :)
> **Yulia Burris** · 2025-06-10 21:28 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1749590889692989)
> *_The lesson is still in draft._
> **Whitney Hodges** · 2025-06-10 23:37 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1749598649893649)
> @Yulia Burris Thank you! I have published this lesson. I renamed it to match the title of the presentation, so it's more specific.
> 
> I'm realizing now that there also needs to be a short training specifically about having a thank you page, so I'll work on that

**Whitney Hodges** · 2025-06-10 21:09 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1749589792766219)
@daniela Hi! In our team call today, we discussed how Google Ads VIP Day clients could really benefit from access to the Audit &amp; Adapt course in particular. Do you know how we could go about giving someone access to just this one course? I think we can invite them to the member portal without giving them access to a community or group, but I can't figure out how to grant access to just one course or offer. Please let me know if you can point me in the right direction

**daniela** · 2025-06-10 21:15 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1749590148504859)
Since it is set up as a unique product, I'm pretty sure we can give them the "course" without adding them to the "community"
> **daniela** · 2025-06-10 21:22 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1749590531387119)
> @Whitney Hodges I think we can do this by creating a workflow triggered by a new tag, and then add that tag to whoever we want to grant access to.
> 
> Does that sound right @Christina Hill?
> 📎 Screen Shot 2025-06-10 at 4.20.21 PM.png (png, saved as `files/F090EA029MM-Screen_Shot_2025-06-10_at_4.20.21_PM.png`)
> **Whitney Hodges** · 2025-06-11 01:10 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1749604204072389)
> This worked; thanks!

**Whitney Hodges** · 2025-06-11 00:44 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1749602649967729)
@Jacqueline Hood I added <https://members.weddingindustryads.com/communities/groups/the-vault/home/posts/6848cf504eaaa6480cd5e331|a post in the VAULT> for members to share their landing pages for feedback. Can you please check this post daily for comments and respond with feedback? I think Looms would be efficient but also feel high-touch and personalized.

@Yulia Burris I created a lesson for this in Audit &amp; Adapt. Can you please add a thumbnail image?

Thank you both!!
> **Whitney Hodges** · 2025-06-11 01:12 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1749604353927099)
> @Yulia Burris Quick update here. I realized that I needed to create this as its own product instead of a lesson, so if you can please update the product to include all thumbnails needed and make sure it has the same theme as the other courses, that would be great. Thank you!
> **Whitney Hodges** · 2025-06-11 20:00 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1749672040883569)
> @Jacqueline Hood Hi! Both Elsa and Alyssa have shared their landing pages for feedback in the VAULT. Do you have the bandwidth to respond to them today? Thank you!
> **Jacqueline Hood** · 2025-06-12 01:30 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1749691835732329)
> hey @Whitney Hodges sorry! It was a very full day. I can reply to them and let them know I'll send feedback tomorrow!
> **Whitney Hodges** · 2025-06-12 01:31 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1749691884094979)
> @Jacqueline Hood That sounds great! Thank you!!
> **Yulia Burris** · 2025-06-12 02:20 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1749694811845469)
> @Whitney Hodges This morning I added a thumbnail for the product “Share Your Landing Page for Feedback” + a thumbnail for the lesson

**Jacqueline Hood** · 2025-06-12 01:32 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1749691954028929)
I love this!! :point_down: Already forming potential collaborations and connections. So awesome!
📎 Screenshot 2025-06-11 at 6.32.00 PM.png (png, saved as `files/F090W3BHWES-Screenshot_2025-06-11_at_6.32.00_PM.png`)

**Whitney Hodges** · 2025-06-12 01:48 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1749692933833849)
@Yulia Burris Hi! <https://docs.google.com/document/d/1gCGAM3fqYnrjVdrnGQxpswQ5ULjpsEc_Fi4l4yT5KFU/edit?usp=sharing|Here are the ads I've identified for the Client Attraction Campaigns Look Book>
> **Yulia Burris** · 2025-06-12 02:10 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1749694205537709)
> @Whitney Hodges  thank you :dizzy:. I’ll do it tomorrow morning 

**Whitney Hodges** · 2025-06-12 15:10 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1749741056739119)
@daniela Could you please record a quick Loom on how to update the theme for the Share Your Landing Page course and how to add it to the VAULT? Thank you!
> **daniela** · 2025-06-12 17:23 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1749749027619179)
> This theme looks like it already has been updated and applied! Here's a how-to loom on the theme, and also on adding that product to the community. I haven't added the "share your landing page" to the community yet because I believe it sends a notification email automatically to all members - wanted to make sure it's ready first.
> 
> • <https://www.loom.com/share/9cd99c27291d4d3d96343265ba7fea33?sid=8f2924f5-0bf9-4d79-b4d1-d260cf53bd76|How to update the theme on a course product>
> • <https://www.loom.com/share/fec5c5ef9e4b4bf684e428d0eceb9476?sid=1af53976-d934-4d08-8c51-4a9661d76424|Adding a course to the community>
> **Whitney Hodges** · 2025-06-12 17:42 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1749750174807319)
> @daniela Thank you! I think it's ready to be shared with the community. It's pretty straightforward. The post where they can share their landing pages already exists and has received some comments. I created this product as a separate course from Audit &amp; Adapt since we gave Jill access to that course but she doesn't have access to the community. Is there anything else that you think needs to be added before it goes live?
> **daniela** · 2025-06-12 17:51 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1749750687825779)
> I think we are good to go! I’m not at my desk this afternoon if you’re able to post it to the community - 
> (otherwise I can do that later this evening) 
> **Whitney Hodges** · 2025-06-12 18:04 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1749751445799789)
> I won't be at my desk until this evening either. And I haven't added a new product in its entirety to the community yet, so I'd love some clarity on how to do that
> **daniela** · 2025-06-13 12:35 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1749818131052869)
> That's all explained in the 2nd loom - you do it from within the community as an admin. Let me know if you still need help with that.
> **Whitney Hodges** · 2025-06-13 14:14 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1749824095741019)
> Thank you! For some reason, I didn't even see the looms yesterday

**Jacqueline Hood** · 2025-06-12 17:41 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1749750076231349)
@Whitney Hodges office hours call recording - June 12, 2025
📎 Impromptu Zoom Meeting - Jun 12 2025.mp4 (mp4, **not downloaded** — over cap (368.2 MB), [fetch it](https://files.slack.com/files-pri/T03P5A3L1DK-F091KNR6MSM/download/impromptu_zoom_meeting_-_jun_12_2025.mp4))
> **Whitney Hodges** · 2025-06-12 17:43 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1749750231454889)
> @Jenna Tria here's the recording to add you the vault
> **Whitney Hodges** · 2025-06-12 17:44 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1749750244344969)
> @Jacqueline Hood thank you!! How did it go???

**Jacqueline Hood** · 2025-06-12 17:45 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1749750306576789)
Two thoughts - I'm feeling incredibly inspired and energized being able to help clients in more of this coaching capacity. It really feels so rewarding already :face_holding_back_tears::heart_eyes:

It was so cool to see the collaboration and connection happen between Elsa and Alyssa on the call, as well, helping each other with thoughts from their own insights, their own expertise and backgrounds. It just creates such a rich collaborative environment and I think it's going to be so valuable for these women.

At the start of the call, Elsa shared some really incredible insights and testimonials of her time with us so far and really what's she's learned about how important having a strong foundation is, how ads don't work in isolation and how her work with us has really taught her that and she said explicitly a few times just how valuable this experience has been for her in learning those things. There were some great clips that we could pull for some social media content!
> **Whitney Hodges** · 2025-06-12 18:23 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1749752618979559)
> @Jacqueline Hood I love this so much! I can't wait to see you grow and thrive as a coach in our community
> **Yulia Burris** · 2025-06-12 18:52 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1749754325674299)
> @Jacqueline Hood you’re :fire:! @Whitney Hodges  @daniela You’re all doing such inspiring work :dizzy::clap: 
> 
> **Jacqueline Hood** · 2025-06-12 21:09 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1749762574505039)
> @Yulia Burris thank you! Yes huge props to @Whitney Hodges and @daniela for creating something so incredible! :slightly_smiling_face:

**Jacqueline Hood** · 2025-06-12 17:49 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1749750589825279)
📎 Screenshot 2025-06-12 at 10.47.19 AM.png (png, saved as `files/F0915PVM75K-Screenshot_2025-06-12_at_10.47.19_AM.png`)
📎 Screenshot 2025-06-12 at 10.47.46 AM.png (png, saved as `files/F090S05QPB9-Screenshot_2025-06-12_at_10.47.46_AM.png`)

**Yulia Burris** · 2025-06-12 20:14 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1749759274898529)
Hi! @Whitney Hodges @daniela <https://www.canva.com/design/DAGqKegIUMI/pCwRuuK9CUPexyVT_wyGUQ/edit?utm_content=DAGqKegIUMI&amp;utm_campaign=designshare&amp;utm_medium=link2&amp;utm_source=sharebutton|Here’s the Client Attraction Ad Creatives Look Book for your review>. Let me know if you’d like any changes — happy to make them.
> **Whitney Hodges** · 2025-06-12 20:57 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1749761871925579)
> @Yulia Burris love it! Only minor changes. Let's not use italics and justify left the headings on each page. Thank you!
> **Yulia Burris** · 2025-06-12 21:26 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1749763595152429)
> @Whitney Hodges Done:white_check_mark::blush:

**Yulia Burris** · 2025-06-13 13:52 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1749822741451239)
@Whitney Hodges @daniela Good morning! If you need me to add more lessons to the platform today, just let me know. I can do it
> **Whitney Hodges** · 2025-06-13 14:33 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1749825208886009)
> @Yulia Burris Good morning! Yes, we now need to focus on the Client Attraction course.
> 
> <https://drive.google.com/drive/folders/1ryccEqQszQ4LbCttJoOODVctY2h_naSF?usp=sharing|I've added folder called Client Attraction here.>
> 
> It has a recording from a training that I recently did internally with the team. Can you please check it out and trim/edit as you see fit?
> 
> The corresponding slide deck has been uploaded as well.
> 
> This area of the curriculum is where we'll want to include the Look Book, too. I'm thinking it may be best to share it as a Canva view only link instead of a pdf in case we make additions to it in the future. What do you think?
> 
> Open to any other thoughts y'all have on curriculum that could be useful for this section @Yulia Burris @Jacqueline Hood
> 
> We also need to formalize the process of how client attraction ads will be submitted to be turned into actual campaigns
> **Yulia Burris** · 2025-06-13 15:06 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1749827188905309)
> @Whitney Hodges Thank you! I’ll trim it. Great lesson! :heart_eyes: Should I create the lesson under the product _Curate Your Client Attraction Campaigns_?
> 
> I agree that adding a Canva link might be a better option since we can easily update it with more ad examples later. We could add the look book link into the description and highlight it. Want me to add it like that today?
> 
> If there’s time in the next workshop, I think it would be great to show them how to research businesses in their niche for inspiration, ad ideas, and competitor analysis—using tools like the Meta Ad Library. Just to get inspired, not to copy.:tada:
> 
> сс: @Jacqueline Hood
> **Whitney Hodges** · 2025-06-13 15:07 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1749827251121439)
> @Yulia Burris Yes, that all sounds great!
> **Yulia Burris** · 2025-06-13 17:13 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1749834812055369)
> @Whitney Hodges Hi! Trimming the video now — should I keep just your presentation (19 min) or include the team discussion after the workshop too?:)
> **Whitney Hodges** · 2025-06-13 17:15 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1749834920663879)
> @Yulia Burris Hmm I'm not sure. I honestly don't remember everything we talked about as a team. What do you think?
> **Yulia Burris** · 2025-06-13 17:24 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1749835468500259)
> @Whitney Hodges Jacqueline was talking with you about the importance of a clear message. The videos and photos can look beautiful, but people might not realize if it’s a photographer, wedding planner, etc.
> 
> We can keep that part in
> **Jacqueline Hood** · 2025-06-13 17:34 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1749836076569169)
> Maybe adding in a simple checklist when it comes to curating your own content.
> -look for any content that has "gone viral" or has lots of engagement/comments
> -if someone completely new to your brand saw this video - do they know who you are and what you do?
>  (we can probably add to this just brainstorming some ideas). I'm sure as clients send us their client attraction ad ideas, we'll have more thoughts!

**Whitney Hodges** · 2025-06-13 17:47 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1749836821624999)
@Yulia Burris @Jacqueline Hood Daniela and I had talked about putting the <https://docs.google.com/document/d/1kQ-Ffu_Vbd_z_n7hSUvE_cK4YFxeNVFeIPBjpDQerXM/edit?usp=sharing|messaging &amp; positioning questionnaire> into the VAULT as an exercise for members to do for themselves that they can then reference as they are curating/creating their ads. However, that may be too ambiguous. I feel like there needs to be something that connects the dots between this and then auditing their landing page and/or creating content.

Should we take what is on here and turn it into content prompts for members to use to create client attraction and/or nurture ads?
> **Yulia Burris** · 2025-06-13 18:56 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1749840978660549)
> @Whitney Hodges I like this idea! A quick guide or simple presentation could be super helpful along with the questionnaire. :tada: (Or it could even be a separate lesson.)

**Yulia Burris** · 2025-06-13 19:00 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1749841203096729)
@Whitney Hodges @daniela Hi! I just added the Client Attraction Ads lesson (trimmed video, updated description, Canva link to the Look Book + PDF + covers). The lesson is currently saved as a draft.
> **Whitney Hodges** · 2025-06-16 13:52 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1750081966456399)
> @Yulia Burris Thank you! I moved the Look Book into its own lesson. Can you please create a thumbnail for that?
> **Yulia Burris** · 2025-06-16 13:53 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1750082000803819)
> @Whitney Hodges Good morning. Of course)

**Whitney Hodges** · 2025-06-16 13:56 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1750082218954789)
@Yulia Burris I'd like for us to have slide decks very similar to the <https://www.canva.com/design/DAGlkF_VVkE/ElrD2tHpgtky1XiYOwj9Fg/edit?utm_content=DAGlkF_VVkE&amp;utm_campaign=designshare&amp;utm_medium=link2&amp;utm_source=sharebutton|Client Attraction Ads> presentation for Direct Response Ads and Nurture Retargeting Ads. Can you please take the information on <https://docs.google.com/document/d/12_x2lyBBxkie-R_fPPOxB7gw8qjP9-O5YNXTIymJ81k/edit?tab=t.0#heading=h.r5ad0em1k5z0|this strategy doc> to get started on populating information for the <https://www.canva.com/design/DAGqhRboN4E/kCGlUvfOCQNL3qru5Wkh7Q/edit?utm_content=DAGqhRboN4E&amp;utm_campaign=designshare&amp;utm_medium=link2&amp;utm_source=sharebutton|Direct Response> and <https://www.canva.com/design/DAGqhSSYPTY/qoclars8uyFxKwDVzSJWkg/edit?utm_content=DAGqhSSYPTY&amp;utm_campaign=designshare&amp;utm_medium=link2&amp;utm_source=sharebutton|Nurture Retargeting> slide decks? Thank you!

cc @daniela
> **Yulia Burris** · 2025-06-17 12:57 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1750165079826979)
> @Whitney Hodges Good morning! :dizzy: Started working on the presentations. Are they for today’s workshop?
> **Whitney Hodges** · 2025-06-17 13:01 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1750165267878499)
> @Yulia Burris No, they won't roll out until next week and the following week

**Whitney Hodges** · 2025-06-16 17:56 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1750096578234159)
<!channel> Some initial Client Attraction curriculum is now live in the VAULT! My workshop tomorrow will supplement it. Then after that workshop, I'll create a post in the Discussion where members can share Client Attraction ads for feedback.  They should be able to include a link or video attachment for us to check it out along with their message.

Then after we've given feedback, and they've made edits, the instruction will be for them to post the reel organically.

When they have three client attraction reels that have been posted that they are ready for us to turn into their campaign, we'll have a submission process where they send us the link to each reel at once, then we'll build the campaign. @daniela Can we map out exactly what this looks like on our call on Wednesday? @Jacqueline Hood Any specifics you'd like included, please let us know!

**Whitney Hodges** · 2025-06-16 20:42 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1750106540432479)
@Yulia Burris For my live workshop tomorrow, I'd like to expand upon the Client Attraction Curation Process as mentioned in the existing training video. Could you please create a workbook to support with this? I'm thinking a Google Doc or Google Slide. Members can create their own copy and then use it to start curating their client attraction ads. I'd like to see it include a table of sorts with columns for:
• Link to IG Reel
• Why does this make a good client attraction ad?
• Planning to make edits? Yes or No
• If yes, what are the edits?
@Jacqueline Hood Any thoughts on this? What do you think about members submitting this to us for review?

cc @daniela
📎 image.png (png, saved as `files/F091HPDJAA2-image.png`)
> **Yulia Burris** · 2025-06-16 21:05 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1750107946893019)
> @Whitney Hodges I’ll work on it today and send you the link as soon as it’s ready:) 

**Yulia Burris** · 2025-06-16 23:06 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1750115169889809)
@Whitney Hodges Hi! Let me know if this <https://docs.google.com/document/d/1hAWPcWni-eD_Wby2QE8W5G8KCwwERJnBXTNXjh7Jn5g/edit?usp=sharing|workbook version> works for you. I can make any changes if needed)
> **Whitney Hodges** · 2025-06-17 00:49 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1750121361973229)
> @Yulia Burris Thank you! I think this is good. Can you please move the doc to <https://drive.google.com/drive/folders/16yf0vZN7a_AzHsuoVwtZPiDSQJRQLpoK?usp=sharing|this folder>? Also, it will need to be set up to where anyone can view it, but they'll need to make a copy if they want to edit it.

**Jacqueline Hood** · 2025-06-17 00:48 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1750121330559529)
@Whitney Hodges is this workbook what they would submit to us for review?
> **Whitney Hodges** · 2025-06-17 00:49 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1750121394551769)
> @Jacqueline Hood I don't know. It could be. Or it could be something they just use for themselves. What do you think?

**Whitney Hodges** · 2025-06-17 02:54 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1750128878876549)
@Jacqueline Hood Here's a <https://www.loom.com/share/c59f5ee1092643899e62a1d932ff42a2?sid=6f438231-6c3e-40f2-a71c-20ff4903194a|loom> walking you through a Custom GPT I created for landing page audits. <https://chatgpt.com/g/g-6850bca3baec8191a724421e87621a9d-sophie|You can access Sophie here.>

I'd like to try to get her to a place where she can be client-facing at some point but am realizing she will take a lot of training to get there.

Next time you need to do a landing page audit, can you please prompt her? Then let me know if you see any errors or areas of opportunity with the feedback she provides. I can then re-configure her accordingly.

Thank you!!

cc @daniela

**Whitney Hodges** · 2025-06-17 16:43 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1750178621793129)
@Yulia Burris Here is the <https://drive.google.com/file/d/1PSGm6O4nqXH-sLHvyfKjUQuwwmUWNv-q/view?usp=drive_link|slide deck> from today's workshop, and I'll get the video to you shortly as well.
> **Whitney Hodges** · 2025-06-17 16:50 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1750179052437859)
> @Yulia Burris I've started to upload the video <https://drive.google.com/drive/folders/16yf0vZN7a_AzHsuoVwtZPiDSQJRQLpoK?usp=sharing|here>. It will need to be trimmed off the front and the back and there are probably some transitions from me sharing the presentation to sharing my screen that could be made smoother, if you please.
> 
> Please turn this into a new Client Attraction lesson once you've edited. Thank you!
> **Yulia Burris** · 2025-06-17 16:51 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1750179107296079)
> @Whitney Hodges Thank you, Will do it today :+1: 

**Yulia Burris** · 2025-06-17 22:44 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1750200275544499)
Hi! @Whitney Hodges @daniela
Quick update:
I created the lesson on the platform — _Curating Client Attraction Ads._ 
• Trimmed video (<https://drive.google.com/drive/folders/16yf0vZN7a_AzHsuoVwtZPiDSQJRQLpoK|saved in the folder> / quality looks good)
• Uploaded the video, PDF file, covers for the lesson and video
• Added the description section
Would you like me to add the links (workbook, look book, prompts) to the description, or keep them inside the presentation?
> **Whitney Hodges** · 2025-06-17 22:47 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1750200456993379)
> @Yulia Burris I think it makes sense to add the links in the description. What do you think?
> **Yulia Burris** · 2025-06-17 22:54 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1750200868646509)
> @Whitney Hodges I agree, I’ll add it now to make it easier to find)
> **Yulia Burris** · 2025-06-17 23:19 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1750202341417639)
> @Whitney Hodges added)

**Whitney Hodges** · 2025-06-18 16:53 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1750265600911009)
@Yulia Burris Hi! Daniela and I went ahead and created <https://docs.google.com/document/d/1ANd-9r-O10seAWYmq-TNcMDvXqNfwn53/edit?usp=sharing&amp;ouid=104440450174655659283&amp;rtpof=true&amp;sd=true|this doc> for members to share client attraction ads with us for feedback. Can you please please turn this into a lesson for the Client Attraction course. @Jacqueline Hood Any thoughts or edits you'd like to see?
> **Yulia Burris** · 2025-06-18 16:58 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1750265915351679)
> @Whitney Hodges I’ll add it now. Do you want it to be a separate lesson?
> **Whitney Hodges** · 2025-06-18 17:57 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1750269465827379)
> @Yulia Burris Yes, I think it makes sense for it to be its own lesson. Thank you!
> **Yulia Burris** · 2025-06-18 19:11 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1750273883593689)
> @Whitney Hodges <https://app.leadlockpro.com/v2/location/Xi40zxmRvW8Pbyk5DYHp/memberships/courses/posts/3c22e116-4891-4474-ae4a-9b71fce40211/edit|I’ve added it to the platform>.
> **Jacqueline Hood** · 2025-06-19 01:28 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1750296492287699)
> looks great! Love the colors. The only thing we could think about adding - particularly when we are receiving more of them at a time - is somewhere at the top where they can put their name and/or business name? Just to help keep it organized for the ones who are reviewing them :slightly_smiling_face:
> **Whitney Hodges** · 2025-06-19 01:58 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1750298299386139)
> @Jacqueline Hood YES! Great point. @Yulia Burris can you please add that to the doc?
> **Yulia Burris** · 2025-06-19 13:27 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1750339675105669)
> @Whitney Hodges Good morning! <https://docs.google.com/document/d/1ANd-9r-O10seAWYmq-TNcMDvXqNfwn53/edit#heading=h.3qo2mg4eyei4|Fixed>) Let me know if that works for you.
> **Whitney Hodges** · 2025-06-19 13:34 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1750340063821859)
> @Yulia Burris what do you think about the members sharing their info right after "your turn" instead?
> **Yulia Burris** · 2025-06-19 13:39 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1750340355719479)
> @Whitney Hodges will fix it. I just thought it was helpful to see who it’s from right when you open the doc, but I agree - putting it near “Your Turn” makes sense :)
> **Whitney Hodges** · 2025-06-19 13:40 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1750340450583049)
> @Yulia Burris I think it's fine either way! @Jacqueline Hood what's your preference?
> **Jacqueline Hood** · 2025-06-19 15:51 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1750348303241039)
> I think it's fine either way as well! maybe at the top of the doc so that on a quick glance we know who it's from

**daniela** · 2025-06-18 17:56 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1750269370654329)
@Whitney Hodges @Jacqueline Hood Here's a <https://api.leadconnectorhq.com/widget/form/v3Rh7dr2AYSHdOx3nOYc?notrack=true|preview of the form> for members to submit their client attraction posts for campaign buildout/launch (I still plan to make the design cuter and build a landing page to host this, and TY page - but sharing now for feedback on the questions themselves).

Do we want to include any questions about targeting, or has that already been established on their kickoff call?

And any specific directions or expectations I should include on the TY page that I haven't built yet? lol

Thanks! Happy to make any edits you guys see fit
> **Whitney Hodges** · 2025-06-18 19:05 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1750273521580699)
> @daniela they do already answer questions about targeting on their kickoff call survey. 
> 
> I think it would be good to know the url of the thank you page, so we can go ahead and install lead tracking at this point.
> 
> @Jacqueline Hood any other thoughts? As far as what our thank you page says, I'd love to set expectations on next steps. Do we want to show them the targeting we create before officially launching ads? Maybe send a video walkthrough for their review. What do you think?
> **daniela** · 2025-06-18 19:14 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1750274049930199)
> Thanks! I'll add a question for collecting the TY page URL.
> 
> Here is the first draft of the <https://weddingindustryads.com/meta-ads-immersive-submission-client-attraction|landing page with form> embedded, and our <https://weddingindustryads.com/immersive-cac-form-submitted|TY Page> upon submission.
> **daniela** · 2025-06-18 19:17 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1750274263424559)
> I'm using "MAIE Submission" for meta-ads-immersive-experience naming conventions in leadlock FYI
> **Whitney Hodges** · 2025-06-18 19:42 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1750275777222259)
> @daniela I think the landing page may still need to be published. It looks like the questionnaire to me. Thanks!!
> **daniela** · 2025-06-18 19:44 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1750275861553019)
> Oops - try this now: <https://weddingindustryads.com/meta-ads-immersive-submission-client-attraction>
> **Whitney Hodges** · 2025-06-18 19:48 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1750276138029769)
> @daniela I think the landing page design looks good. Can you update the form on the page, please?
> **daniela** · 2025-06-18 19:50 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1750276214456559)
> Can you clarify? I've added the TY page url to the form, is something else missing?
> **Whitney Hodges** · 2025-06-18 19:51 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1750276286831419)
> The form on the submission landing page looks like it's still the questionnaire form, not the ads submission form
> **daniela** · 2025-06-18 19:52 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1750276349389509)
> hmm maybe refresh - it looks correct on my end
> **daniela** · 2025-06-18 19:52 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1750276362579829)
> 📎 Screen Shot 2025-06-18 at 2.52.15 PM.png (png, saved as `files/F091WNU2KAP-Screen_Shot_2025-06-18_at_2.52.15_PM.png`)
> **Whitney Hodges** · 2025-06-18 19:54 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1750276441495709)
> Hmm I'm on mobile right now, and this is what I see. I refreshed a couple of times
> 📎 Screenshot_20250618-145308.png (png, saved as `files/F0923G50P0U-Screenshot_20250618-145308.png`)
> **daniela** · 2025-06-18 19:55 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1750276507642489)
> Ah ok! Mobile had a totally different section there - hadn't checked that yet!
> **daniela** · 2025-06-18 19:55 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1750276521390069)
> Try now
> **Whitney Hodges** · 2025-06-18 19:55 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1750276550702029)
> Got it! Looks good on mobile now
> **daniela** · 2025-06-18 19:56 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1750276586837909)
> I think next steps would be for someone to create any notification workflows and test it out - is that something Jenna can help us with?
> **Whitney Hodges** · 2025-06-18 21:10 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1750281030891669)
> @Jenna Tria Can you please create a workflow similar to the Meta Ads Immersive Kickoff Questionnaire workflow for this? There will need to be a new opportunity stage of Client Attraction Ads submitted added to the client pipeline. Thank you!
> **Whitney Hodges** · 2025-06-18 22:41 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1750286508199599)
> @Jenna Tria Just tagged you above but didn't realize you weren't in this channel. See above and lmk if you have questions
> **Jenna Tria** · 2025-06-18 22:43 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1750286606423969)
> @Whitney Hodges this is noted! 
> **Jacqueline Hood** · 2025-06-19 01:30 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1750296658009799)
> I LOVE the idea of a form to submit this! So good! I would prefer to have them include their targeting in here just so that there's one doc I am pulling from when building out their campaigns, and not having to go back and search for their onboarding questionnaire.
> **Jacqueline Hood** · 2025-06-19 01:31 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1750296691298169)
> Because most targeting is the same (the basic wedding interests) and the only change is location and age range, I don't think we need to film a walkthrough showing them?
> **Jacqueline Hood** · 2025-06-19 01:32 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1750296756134519)
> On the TY page (sorry if you've sent it and I haven't seen it yet), it could just say "great! your ads will be live within 48 business hours and we'll send you a message as soon as they're live!"
> 
> Or something. lol
> **Jacqueline Hood** · 2025-06-19 01:34 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1750296846318209)
> If this is all automated, we could trigger a "your ads are live!" email once ads go live and that email could include a link to a "bench marks and KPI's" doc in the vault that's specific to just client attraction ads so that we aren't overwhelming them with a ton of stats they don't need yet
> **Whitney Hodges** · 2025-06-19 01:50 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1750297805656279)
> @Jacqueline Hood Here are my thoughts as far as targeting: 
> 
> For these first four people in the program, we've already asked them to submit targeting details in the questionnaire, so I'm hesitant to ask them to submit the same information again. To me, it feels not great as far as user experience. But that doesn't mean that we couldn't set it up differently for future students. Instead of asking for the targeting on the kickoff call questionnaire, we could wait and ask for it when they submit ads. Another consideration though is do we need to have the targeting before the kickoff call in order to have a productive conversation? Or on the kickoff call, would we want to workshop the targeting together in real time. That may give us more direction on those calls, so it doesn't feel so custom to every member.
> 
> We could also think about creating a training in the vault that teaches them how to create and save their own interest based audience. When we build campaigns we could then tweak it if we see fit and add the custom audiences. My only hesitation with this is, does this diminish the promise of DFY campaign builds?
> 
> I definitely like the idea of some sort of message when ads are live and pointing them to training that gives them only the metrics they need to know now, so they aren't overwhelmed. What do you think about a DM in the vault instead of an email? Or we could do an email but just make it really clear replies aren't monitored or something like that lol
> 
> Cc @daniela I'd love to know what you think on all this too
> **Jacqueline Hood** · 2025-06-19 15:57 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1750348629085149)
> @Whitney Hodges such great points! I think because the targeting is fairly straight forward for most of these clients, we don't need to ask it on the kickoff call questionnaire and that detail can come later when it comes to actually building out the campaigns. We can add it as a talking point to discuss during the kick-off call as well just so that there is some conversation about it as sometimes clients have specific wishes - like targeting 18 year olds for example when they know that's their ideal demographic (which we wouldn't necessarily assume). But then they can put their actual targeting wishes on the ad submission form.
> From a build-out standpoint, it would definitely be streamlined and less chance of error having everything on one form - the ads and the targeting :slightly_smiling_face:
> 
> I like the idea of a DM within the vault instead of an email! That keeps it out of the inbox! :slightly_smiling_face:

**daniela** · 2025-06-18 20:07 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1750277242584929)
I started a <https://www.canva.com/design/DAGcMRcJ4Gs/Uj8mEZsOyK1zpFS7QgM-HQ/edit?utm_content=DAGcMRcJ4Gs&amp;utm_campaign=designshare&amp;utm_medium=link2&amp;utm_source=sharebutton|canva design file for ad creative templates> (specifically for direct response ads) - do you guys have any insights or examples of other successful ad creatives (static graphics) that I should include in addition to these? Open to any/all ideas - feel free to send post/ad links and I can work backwards to make it into a template @Jacqueline Hood @Whitney Hodges
> **Jacqueline Hood** · 2025-06-19 01:36 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1750296987615619)
> such a good start @daniela :slightly_smiling_face: Other than the collage posts for the venues, plain images - especially in black and white - seem to be working really well as conversion creatives!
> **Whitney Hodges** · 2025-06-19 22:10 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1750371035124539)
> @daniela I'll be doing an audit tomorrow of high-performing conversion ads across all of our accounts for the Direct Response Look Book. If I come across anything applicable, I'll send you the links. Thank you!!!
> **Whitney Hodges** · 2025-06-20 15:51 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1750434680765849)
> @daniela Here are static ads that have performed well. They are pretty much all collages, some with logos, some without.
> 
> @Yulia Burris Could you please incorporate what you see here (these are all inside the Direct Response Look Book doc, too) into the Canva design Daniela shared above?
> 
> Thank you!!
> 
> <https://www.facebook.com/100058870483410/posts/915139957125012/?dco_ad_token=AapfLrkX-UQZeN0HMaRQoi5irDzCZUUKVw2tN54z7TDbt1BNtJpePUpruIAbozj4H-FMDiiZyRF5P-L3&amp;dco_ad_id=120204653040850699|https://www.facebook.com/100058870483410/posts/915139957125012/?dco_ad_token=AapfLrkX[…]JpePUpruIAbozj4H-FMDiiZyRF5P-L3&amp;dco_ad_id=120204653040850699>
> 
> <https://www.facebook.com/100063580091005/posts/1063374105791916/?dco_ad_token=AapxXGdCKIYMCzA_0M41bnNLrYmQBCCXqVloV2tpYyqw2uXbo9NjZLMJCrD-ICaVrSYINPSpSyFXN_g8&amp;dco_ad_id=120212007085990650|https://www.facebook.com/100063580091005/posts/1063374105791916/?dco_ad_token=AapxXGd[…]9NjZLMJCrD-ICaVrSYINPSpSyFXN_g8&amp;dco_ad_id=120212007085990650>
> 
> <https://www.facebook.com/100063685415342/posts/1051177397015098/>
> 
> <https://www.facebook.com/100063685415342/posts/1051178010348370/>
> 
> <https://www.facebook.com/100064034590464/posts/912867704191041/>
> 
> <https://www.facebook.com/100064034590464/posts/1045112240966586/>
> 
> <https://www.facebook.com/100064034590464/posts/1126821836128959/>
> 
> <https://www.facebook.com/100039975647506/posts/1447800846562423/>
> **Yulia Burris** · 2025-06-24 14:33 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1750775617864959)
> Good morning! @Whitney Hodges @daniela I made a copy of these templates to add more slides and designs. <https://www.canva.com/design/DAGrRcIhk3w/xLWRO6sqSfPQ9TdEveNRxA/edit?utm_content=DAGrRcIhk3w&amp;utm_campaign=designshare&amp;utm_medium=link2&amp;utm_source=sharebutton|Here’s the link—you can edit it too>.

**Jacqueline Hood** · 2025-06-19 17:01 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1750352479384879)
Meta Ads Office Hours Call - June 19th

Elsa was the only one who showed up; the recorded part of the meeting is about 30 minutes long. I answered some of her questions based on your last training @Whitney Hodges and also show her how to pin different locations/venues when setting up audiences. That part maybe could get pulled out as another video for the vault - "how to select venues in your targeting".

The last half of the call wasn't recorded as we were troubleshooting her Instagram and she didn't want her passwords to be recorded and accessed by anyone else :slightly_smiling_face:
📎 Impromptu Zoom Meeting - Jun 19 2025.mp4 (mp4, **not downloaded** — over cap (181.5 MB), [fetch it](https://files.slack.com/files-pri/T03P5A3L1DK-F0926TR9XS9/download/impromptu_zoom_meeting_-_jun_19_2025.mp4))
> **Whitney Hodges** · 2025-06-19 17:03 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1750352586523569)
> @Jenna Tria Please get this added to the Office Hours section of the VAULT.
> 
> @Yulia Burris Please take a look at pulling out the portion Jacqueline mentioned to create a training on targeting.
> 
> Thank you both!!
> **Whitney Hodges** · 2025-06-19 17:03 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1750352629340119)
> @Jacqueline Hood Thank you! Was Elsa able to get her issue sorted out?
> **Jacqueline Hood** · 2025-06-19 17:07 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1750352879310469)
> Yes we did! :slightly_smiling_face:

**Whitney Hodges** · 2025-06-19 17:45 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1750355134897989)
@Jacqueline Hood @Yulia Burris @daniela We now have a lesson and post live in the VAULT that goes over the process for sharing client attraction ads for feedback. I made some additions to the <https://docs.google.com/document/d/1ANd-9r-O10seAWYmq-TNcMDvXqNfwn53/edit|doc> to make it crystal clear.

We also now have the landing page, form, and workflow ready to go for members to submit the final posts to us for building the client attraction campaigns.

@daniela What do you think about us creating a course specifically for Submitting Your Ads for Campaign Builds? I'm thinking that eventually once we get things structured the way that we want, we can remove access to this particular course for those who have graduated the program or for those who have already had all of their initial campaign builds executed by us.

**Whitney Hodges** · 2025-06-19 22:09 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1750370968159719)
@daniela I put <https://docs.google.com/document/d/1TwaljrIc1SYteQPfUzRDDsGrON8iEh0dtww6UIS0LqE/edit?usp=sharing|this doc> in the Meta Ads Immersive resources folder. It has the copywriting portion of the beta workshop we did last year

**Yulia Burris** · 2025-06-20 15:40 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1750434050894009)
@Whitney Hodges @daniela
Hi! Happy Friday! :dizzy:Here are the presentations for your review: <https://www.canva.com/design/DAGqhRboN4E/kCGlUvfOCQNL3qru5Wkh7Q/edit?utm_content=DAGqhRboN4E&amp;utm_campaign=designshare&amp;utm_medium=link2&amp;utm_source=sharebutton|Direct Response Ads> and <https://www.canva.com/design/DAGqhSSYPTY/qoclars8uyFxKwDVzSJWkg/edit?utm_content=DAGqhSSYPTY&amp;utm_campaign=designshare&amp;utm_medium=link2&amp;utm_source=sharebutton|Nurture Retargeting Ads>.
> **Whitney Hodges** · 2025-06-20 17:29 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1750440564618789)
> @Yulia Burris Thank you! Great start! I'll take it from here.

**Whitney Hodges** · 2025-06-20 15:41 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1750434086039459)
@Yulia Burris Hi! Could you please make a look book for direct response ads? All the ads to use are inside <https://docs.google.com/document/d/1ucowRpP2P47-IByej4KdcuU_f17OVh4LRuqxDr1cxSQ/edit?usp=sharing|this doc>. Please let me know if it would be doable for you to have this to me by Tuesday. Thank you!
> **Yulia Burris** · 2025-06-20 15:43 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1750434237371779)
> Yes, will do)  @Whitney Hodges

**Whitney Hodges** · 2025-06-23 15:31 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1750692663065049)
@Jacqueline Hood Hi! Elsa has shared all of her ads for feedback inside the VAULT. She created <https://docs.google.com/document/d/161JGSWkTUdd3ZPY_AYAZGgRQA4Xhjc6L/edit?tab=t.0#heading=h.art6uzfmjhq5|this doc>. I've asked her to give us edit access. Once it's granted, can you please provide her with any final feedback. I think it will also be helpful in the comments section to instruct her post organically for any of these where you want to create the ad from an existing post. Thank you!!
> **Whitney Hodges** · 2025-06-23 16:48 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1750697306510599)
> @Jacqueline Hood you should have access now!
> **Jacqueline Hood** · 2025-06-23 18:20 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1750702850883279)
> Perfect! I'll do this today :slightly_smiling_face:

**Yulia Burris** · 2025-06-23 20:47 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1750711648476599)
@Whitney Hodges @daniela
Hi! Here’s the link to the <https://www.canva.com/design/DAGrMrRP5WQ/3jkCKnykfWI_MYVET3LPyA/edit?utm_content=DAGrMrRP5WQ&amp;utm_campaign=designshare&amp;utm_medium=link2&amp;utm_source=sharebutton|Direct Response Ad Creatives Look Book>. (The Officiant link didn’t work for me, so I used stock images for now — if you have time to send me a screenshot of the ad, I can upload it!) :slightly_smiling_face:
+ here’s the updated <https://www.canva.com/design/DAGqKegIUMI/pCwRuuK9CUPexyVT_wyGUQ/edit?utm_content=DAGqKegIUMI&amp;utm_campaign=designshare&amp;utm_medium=link2&amp;utm_source=sharebutton|Client Attraction Look Book>.
> **Whitney Hodges** · 2025-07-01 12:49 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1751374155007569)
> @Yulia Burris Can you please remove the officiant ad from the direct response look book?
> **Yulia Burris** · 2025-07-01 13:09 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1751375389321699)
> @Whitney Hodges removed :heavy_check_mark:  
> **Whitney Hodges** · 2025-07-01 14:04 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1751378679285079)
> @Yulia Burris Hi! One other thing I just noticed - the links all say click to watch the full video ad, but several of them are graphics. Can you please update accordingly? Thank you!!
> **Yulia Burris** · 2025-07-01 14:07 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1751378874635579)
> @Whitney Hodges Oh, sorry! I’ll fix it now.
> **Whitney Hodges** · 2025-07-01 14:09 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1751378945204069)
> No worries, thank you!!
> **Yulia Burris** · 2025-07-01 14:42 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1751380927121229)
> @Whitney Hodges fixed it :white_check_mark:

**Jacqueline Hood** · 2025-06-24 02:41 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1750732861119259)
Hi team! For the client attraction ad feedback doc, it would be helpful to have another column specific to video feedback.
So I'm thinking the order would be video link - video feedback - caption - caption feedback

I had to lump my caption and video feedback into the same column so that could be a helpful addition for future! :slightly_smiling_face:
> **Whitney Hodges** · 2025-06-24 14:05 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1750773952996569)
> @Jacqueline Hood Great point! @Yulia Burris Can you please make this update to the doc?
> **Yulia Burris** · 2025-06-24 21:18 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1750799908189979)
> @Jacqueline Hood @Whitney Hodges <https://docs.google.com/document/d/1ANd-9r-O10seAWYmq-TNcMDvXqNfwn53/edit?usp=sharing&amp;ouid=101045703377116269548&amp;rtpof=true&amp;sd=true|updated and added>!) let me know if you want me to delete the “feedback from WIA” section to make more space for the other columns.
> **Whitney Hodges** · 2025-06-24 21:25 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1750800304026999)
> @Yulia Burris yes, let's have just 4 columns total, do you can delete the final "feedback from WIA" column. Can you please make the example table on page 1 match with the same four columns as well?
> **Jacqueline Hood** · 2025-06-26 14:24 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1750947863009439)
> that looks perfect @Yulia Burris thank you!

**Slackbot** · 2025-06-25 14:46 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1750862763308709)
> **daniela** · 2025-06-25 14:49 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1750862970689239)
> I linked our <https://docs.google.com/spreadsheets/d/16BrqKxaaguipyaGMbj-Vr4yjL79-dkKQ95chJDbe1Xg/edit?usp=sharing|spreadsheet >where I've been attempting to keep all our relevant links and raw files organized for the Meta Ads Immersive Experience (like canva links to design files and presentations, etc.).
> 
> This is a working sheet for all of us - please feel free to add to it!

**daniela** · 2025-06-25 14:46 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1750862784279549)
@Whitney Hodges thanks for your patience on this one - here is what I have going for the <https://www.canva.com/design/DAGrXV-Y-pg/98kuaqhGKj7mZiIY4acyIw/edit?utm_content=DAGrXV-Y-pg&amp;utm_campaign=designshare&amp;utm_medium=link2&amp;utm_source=sharebutton|Direct Response Ad Copy Training> (covering more specifically how to create direct response ad copy). Lmk what you think, happy to make edits if needed!

**Whitney Hodges** · 2025-06-25 15:39 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1750865978915689)
@Yulia Burris Hi! I've created a new Product called Submit Your Ads for Campaign Builds and could use your help building it out. Eventually, it will have sections for Submitting Client Attraction, Direct Response, and Nurture Retargeting Ads, but Client Attraction is what I'd like to focus on first.

Essentially, after a member has shared Client Attraction Ads for feedback, received our feedback, and them implemented that feedback, they should post the reel and caption organically. From there, they can then submit the links to those posts to us, and we will build out their campaign. <https://weddingindustryads.com/meta-ads-immersive-submission-client-attraction|This is the link they can use to submit.>

Can you help with this please? I'd love for this course to go live by the end of the week. Thank you!!
> **Yulia Burris** · 2025-06-26 19:45 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1750967118798759)
> @Whitney Hodges I added the submission form, cover, and description to the *<https://app.leadlockpro.com/v2/location/Xi40zxmRvW8Pbyk5DYHp/memberships/courses/posts/f3440a8e-2340-4676-aff8-2a889687f8a0/edit|Submit Your Client Attraction Ads>* lesson (it’s saved as a draft). Let me know if everything looks good or if you’d like me to make any edits!
> 
> + added a cover to the Submit Your Ads for Campaign Builds product.
> 
> @daniela @Whitney Hodges +Should I go ahead and create a lesson for the Direct Response Campaign submission form using <https://weddingindustryads.com/meta-ads-immersive-submission-direct-response|this link>?
> **Whitney Hodges** · 2025-06-26 20:12 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1750968749074579)
> @Yulia Burris Yes, feel free to start to build the Direct Response Submission lesson, too. Thank you!!
> **daniela** · 2025-06-26 20:31 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1750969911340099)
> @Yulia Burris The direct response submission form has already been built!
> **daniela** · 2025-06-26 20:32 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1750969922703079)
> The form exists, and so does the landing page for it
> **daniela** · 2025-06-26 20:33 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1750970010470219)
> Landing page links:
> • for CLIENT ATTRACTION: <https://weddingindustryads.com/meta-ads-immersive-submission-client-attraction>
> • for DIRECT RESPONSE: <https://weddingindustryads.com/meta-ads-immersive-submission-direct-response>
> I created a "folder" in leadlock" for all the "forms" related to the Meta Ads Immersive Experience offer so that they are all in one place and easy to find!
> **daniela** · 2025-06-26 20:33 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1750970017969279)
> @Yulia Burris @Whitney Hodges
> **daniela** · 2025-06-26 20:34 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1750970055687809)
> Hopefully that makes it easy to plug into the lesson! Thanks for all your help @Yulia Burris
> **Yulia Burris** · 2025-06-26 20:34 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1750970072295229)
> @daniela thank you so much
> **Yulia Burris** · 2025-06-26 20:57 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1750971465753519)
> @Whitney Hodges @daniela @Jacqueline Hood
> Added the lessons with submission forms for Client Attraction and Direct Response (both are saved as drafts)

**daniela** · 2025-06-25 16:53 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1750870383904449)
Hi @Jacqueline Hood - we are starting to map out a <https://docs.google.com/document/d/1_zGgjz888o8nZC_rGUBn0a5qgrenGooQ/edit?usp=sharing&amp;ouid=111573067405463038434&amp;rtpof=true&amp;sd=true|new direct response feedback document> similar to <https://docs.google.com/document/d/1ANd-9r-O10seAWYmq-TNcMDvXqNfwn53/edit?usp=sharing&amp;ouid=111573067405463038434&amp;rtpof=true&amp;sd=true|this CAC one >but geared toward the Direct Response Ads. Would love your feedback on specifically which elements we should be asking for!

For example, we are thinking they should submit 3 versions of creatives - do we want to specify that we want one video, one graphic/collage, and/or a carousel... or do we

With CAC, they had to post organically first - but with Direct Response (conversion or traffic campaigns), we can approach it differently.

Ultimately, when you're building out the campaigns, is it better for you to ask for individual elements that you can curate/arrange together, or for them to submit that they want this copy with this headline with this creative...

Would also love your feedback on how to structure the subsequent FORM they will submit when they are ready for campaigns to be built out - a few thoughts:
• X number of headlines
• X versions of creatives (3?) 
• Body copy (with multiple hooks?) 
• Landing Page URL 
• Thankyou Page URL
• Select between 2 options: 
    ◦ I want to run a Conversion Campaign for $X/day, OR 
    ◦ I want to run a Traffic Campaign for $X/day
> **Jacqueline Hood** · 2025-06-26 14:05 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1750946744399059)
> Hey!
> 
> I think it's better for them to submit individual elements and I can curate/arrange. Sometimes that's a really intuitive "in the moment" decision as to which copy/creatives pair best together and it's something that's a bit more difficult to teach/explain to them?
> 
> Most clients have a relatively small direct response ad budget, so 2 creatives and 2 versions of copy is usually all I would launch.
> 
> But if we wanted to have them create 3 of each, I can go in and choose from them?
> **Jacqueline Hood** · 2025-06-26 14:06 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1750946803478519)
> then yes, definitely LP and TY page URL's :slightly_smiling_face:
> **Jacqueline Hood** · 2025-06-26 14:06 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1750946805770239)
> @daniela
> **daniela** · 2025-06-26 15:42 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1750952533345049)
> Any thoughts on suggested budgets for these? @Whitney Hodges @Jacqueline Hood
> **Whitney Hodges** · 2025-06-26 15:58 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1750953534574579)
> @daniela @Jacqueline Hood in the first direct response training I did, I said that they need to budget a minimum of $15/day on conversion campaigns.
> 
> I'm thinking we split these into two different questions.
> 
> We can first ask if they want to run a traffic campaign or conversion campaign, noting $15/day minimum for a conversion campaign.
> 
> Then we can ask them to specify their daily budget in a separate question that is free response.
> 
> Thoughts?
> **Jacqueline Hood** · 2025-06-26 16:54 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1750956883426969)
> @Whitney Hodges @daniela will they know enough at this point to be able to determine if they want to run a conversion or traffic campaign? I feel like that question will get diverted back to us as I don't imagine they would know which they should run?
> **daniela** · 2025-06-26 17:00 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1750957205851899)
> I want to say there's at least one slide on this topic in the workshop Whitney ran earlier this week - do you think they need a deeper dive on that piece @Whitney Hodges?
> **daniela** · 2025-06-26 17:01 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1750957271428899)
> Or do you guys think we should just ask for them to provide a daily budget and we can determine the campaign objective for them (rather than leaving it up to them) ? @Jacqueline Hood
> **Jacqueline Hood** · 2025-06-26 17:10 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1750957824590749)
> I'm trying to think of scenarios in which we would run a traffic campaign instead of a conversion campaign other than budget. We are guiding them all to create/have a strong landing page to send traffic to - which can also be a reason for a traffic campaign vs. conversion
> But I think I'd rather set everyone up with a conversion campaign to start as leads just don't come in through traffic campaigns
> **Whitney Hodges** · 2025-06-26 17:50 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1750960240103299)
> @Jacqueline Hood @daniela I spoke to this in my workshop on Tuesday. I said we recommend conversion campaigns for a minimum of $15+/day. I said that a traffic campaign could be a consideration if they have less to spend than that, but that sometimes traffic campaigns can yield great results in terms of landing page views, but that doesn't mean those users will actually convert into opt-ins.
> 
> For those that are currently in the group, I don't think we're going to run into issues with them pushing back on spending $15+/day on a conversion campaign, but if someone did specify that they want to spend less than that, I feel like it would be even harder to see conversion campaign results, in which case we would say their option is a traffic campaign.
> 
> I do think we need to have a plan or some sort of communication when it comes to adjusting the client attraction budget once conversion campaigns start running. On the client attraction submission form, they are agreeing to spend $10/day on those campaigns, but I think once we launch conversion campaigns, we can back down that amount considerably.
> **daniela** · 2025-06-26 18:57 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1750964266057909)
> There are two versions:
> • for CLIENT ATTRACTION: <https://weddingindustryads.com/meta-ads-immersive-submission-client-attraction>
> • for DIRECT RESPONSE: <https://weddingindustryads.com/meta-ads-immersive-submission-direct-response> 
> I had created unique forms for each... the CAC one said that they are granting permission for $10/day.
> I had set up the direct response one to include a separate intake box where they put the budget total, indicating it can be no less than $15/day, and that's where I put the options of Traffic vs Conversion campaigns. It looks like the direct response one has been modified.
> **daniela** · 2025-06-26 18:58 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1750964318738489)
> That's why the prompt there says "please select which campaign objective you prefer" - but if you think this should be up to the ads manager based on their budget, we can update the terms to reflect that.
> **daniela** · 2025-06-26 19:00 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1750964410195679)
> The other part of the CAC one that got edited previously stated that the ad spend is paid directly to Meta from the payment method they had on file
> **Whitney Hodges** · 2025-06-26 20:10 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1750968625724339)
> @daniela I think when I updated the CAC form it automatically updated the Direct Response form because the checkboxes on each form shared the same query key. They were somehow linked. I created a new checkbox for the Direct Response form, so it should be fixed now
> **daniela** · 2025-06-26 20:32 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1750969947452659)
> Ah ok, I see!

**daniela** · 2025-06-25 19:19 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1750879163097169)
Here's the first draft version of the Direct Response Ad <https://weddingindustryads.com/meta-ads-immersive-submission-direct-response|submission form &amp; landing page>. The form still needs to be refined - happy to update it to incorporate feedback!

**Jacqueline Hood** · 2025-06-26 14:08 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1750946923579029)
@daniela on the form, is it possible for them to also include a link to their ad creatives folder?
> **Whitney Hodges** · 2025-06-26 14:21 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1750947680854779)
> good idea!
> **Jacqueline Hood** · 2025-06-26 14:23 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1750947817422319)
> Actually a link to a google doc with their ad copy and headlines would be more helpful/streamlined than pulling the copy out of the form, as well. Makes it easier to see all versions of copy together, etc. The less places we have to go to grab the content, the better! :slightly_smiling_face:
> **daniela** · 2025-06-26 15:41 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1750952485977129)
> Ah ok! That's helpful @Jacqueline Hood - do you think we can have them link to their copy of the<https://docs.google.com/document/d/1_zGgjz888o8nZC_rGUBn0a5qgrenGooQ/edit?usp=sharing&amp;ouid=111573067405463038434&amp;rtpof=true&amp;sd=true| feedback document >in the form? and then link to a folder for with the creatives. Should I include a note with a specific email address that needs to be granted access?
> **daniela** · 2025-06-26 15:48 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1750952880955839)
> Or do you think we should create a separate doc format for final versions of ad copy/headlines @Whitney Hodges
> **Whitney Hodges** · 2025-06-26 16:03 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1750953829209939)
> @daniela @Jacqueline Hood What if we update the direct response feedback doc to have a section where they include hooks, a section where they include body copy (including CTA), a section where they include headlines, and then a section where they link to their ad creatives folder?
> 
> I think the doc itself can include instructions on share permissions and sections for us to provide feedback.
> 
> Then once feedback is implemented, they could submit that same doc in the submission form 
> 
> Thoughts?
> **Jacqueline Hood** · 2025-06-26 17:10 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1750957858310319)
> yes that works!
> **Whitney Hodges** · 2025-06-26 17:34 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1750959265386529)
> @Jacqueline Hood How many hooks and headlines do you think they should create? Five and then you pick your favorites? Or is that too many?
> **Jacqueline Hood** · 2025-06-26 20:28 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1750969718851269)
> What do you mean by hooks exactly? The same version of copy just with a different intro?
> **daniela** · 2025-06-26 20:31 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1750969868275679)
> Yep! Different version of the first line
> **Jacqueline Hood** · 2025-06-27 03:20 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1750994451335409)
> Sure, they could provide a few different options! 4 or 5 works :slightly_smiling_face:

**Jacqueline Hood** · 2025-06-26 16:58 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1750957118597389)
Meta Ads Office Hours Recording - June 26th, 2025
📎 Impromptu Zoom Meeting - Jun 26 2025.mp4 (mp4, **not downloaded** — over cap (289.4 MB), [fetch it](https://files.slack.com/files-pri/T03P5A3L1DK-F0938LKMYN6/download/impromptu_zoom_meeting_-_jun_26_2025.mp4))
> **Whitney Hodges** · 2025-06-26 17:33 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1750959202225469)
> @Jenna Tria Please upload to the VAULT. Thank you!!

**Jacqueline Hood** · 2025-06-26 17:12 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1750957939315869)
@Whitney Hodges Good morning! Elsa is ready to launch her client attraction and direct response ads. I don't know if the client attraction form has been added to the vault yet but if not, is there a way to send it to just her via a DM so she can get that going? :slightly_smiling_face:
> **Whitney Hodges** · 2025-06-26 17:30 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1750959036652319)
> @Jacqueline Hood Hi! It has not yet been added to the VAULT. @Yulia Burris is still working on the course for that, but my hope is to get it up by tomorrow.
> 
> In the meantime, you can DM Elsa this link <https://weddingindustryads.com/meta-ads-immersive-submission-client-attraction>
> **Whitney Hodges** · 2025-06-26 17:32 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1750959169394429)
> @daniela Do you remember what it originally said under "By submitting below" at the bottom? When I just checked it before I sent the link to Jacqueline, there were two options: I want to run a Traffic Campaign or I want to run a Conversion Campaign. I just updated it to include one option that says "I agree" for now. I feel like you had better language there previously
> **Jacqueline Hood** · 2025-06-26 20:24 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1750969464687469)
> thanks @Whitney Hodges :slightly_smiling_face:

**Yulia Burris** · 2025-06-26 19:32 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1750966342811599)
Hi everyone! @Whitney Hodges @daniela Quick update:
• I uploaded the trimmed lesson to the <https://drive.google.com/drive/folders/12W2UU8ucS6EzjIyBl5uNeWfEtc94tgvs?usp=share_link|Direct Response Ads folder> (includes the part with Whitney + the presentation). Let me know if you’d like to include any of the conversation with Elsa in the lesson.
• Created the *Direct Response Ads* lesson — video, covers, PDF, and description are all added. It’s in “Create Direct Response Campaign”, saved as a draft.


**Jacqueline Hood** · 2025-07-01 05:09 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1751346560468249)
Launched the client attraction ads for Valley &amp; Coast tonight :slightly_smiling_face:
If I could make a request for the submission form - having them outline their targeting options (at least age range and specific locations) would be really helpful having it all in one place. With so many different clients, I can never remember where they're located and having to go back to find their initial form was a bit time consuming so having it all in one spot would be amazing!
> **Whitney Hodges** · 2025-07-01 18:25 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1751394346139609)
> @Jacqueline Hood These are the targeting-related questions we included on the kickoff call questionnaire. I think I'll remove them from that form and include them on the client attraction submission form, instead. Does that work for you? Are there any other targeting questions you'd like included?
> **Whitney Hodges** · 2025-07-01 18:25 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1751394352032369)
> 📎 image.png (png, saved as `files/F093HFRPNLX-image.png`)
> **Jacqueline Hood** · 2025-07-02 20:38 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1751488711161009)
> That's perfect!

**Whitney Hodges** · 2025-07-01 18:21 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1751394066604019)
@Yulia Burris Hi! I've uploaded today's workshop and corresponding slide deck into <https://drive.google.com/drive/folders/12W2UU8ucS6EzjIyBl5uNeWfEtc94tgvs?usp=sharing|this folder>. Can you please add it as a new direct response lesson in the VAULT? It will need to be trimmed on the front and back end. There wasn't anyone in the Zoom room a few minutes in, so I started presenting, but then Elsa joined, so I greeted her then restarted the presentation. I think the Q&amp;A section on the back end can be trimmed off because the questions/discussion felt very specific to Alyssa and Elsa. Thank you so much!!
> **Yulia Burris** · 2025-07-03 13:38 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1751549934881279)
> @Whitney Hodges @daniela
> Good morning! Yesterday, I uploaded the <https://drive.google.com/drive/folders/12W2UU8ucS6EzjIyBl5uNeWfEtc94tgvs|trimmed video to the folder> and added it to the platform — including the covers, description, PDF, and resource links in the description. The lesson is saved as a draft. Let me know if you’d like me to make any edits — I can fix it quickly:)
> **Whitney Hodges** · 2025-07-03 18:10 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1751566240331049)
> @Yulia Burris Thank you! This is now live in the VAULT!

**Jacqueline Hood** · 2025-07-03 17:26 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1751563593680339)
Meta Ads Meeting - July 3, 2025
📎 Impromptu Zoom Meeting - Jul 3 2025.mp4 (mp4, **not downloaded** — over cap (184 MB), [fetch it](https://files.slack.com/files-pri/T03P5A3L1DK-F0948A5JNLV/download/impromptu_zoom_meeting_-_jul_3_2025.mp4))
> **Whitney Hodges** · 2025-07-03 17:28 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1751563722507899)
> @Jacqueline Hood Thank you! @Jenna Tria Please add to the VAULT

**Whitney Hodges** · 2025-07-03 18:15 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1751566529534629)
@Yulia Burris Hi! Similarly to what we did inside the Client Attraction Ads course, can you please add lessons for the direct response look book and sharing direct response ads for feedback? <https://docs.google.com/document/d/1_zGgjz888o8nZC_rGUBn0a5qgrenGooQ/edit#heading=h.art6uzfmjhq5|This is the feedback doc.> Thank you!!
📎 image.png (png, saved as `files/F094XPE8TEU-image.png`)

**Whitney Hodges** · 2025-07-07 16:55 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1751907313991649)
@Yulia Burris @Jacqueline Hood @daniela Our course on <https://members.weddingindustryads.com/courses/products/1b918828-a21c-4576-a495-900b6c9cc8f9?source=communities&amp;group_slug=the-vault|Direct Response Ads> is now complete within the VAULT. There is also now a <https://members.weddingindustryads.com/communities/groups/the-vault/home/posts/686bf98ba965745ab5e57e16|post in the Discussion> for members to share their direct response ads for feedback using <https://docs.google.com/document/d/1_zGgjz888o8nZC_rGUBn0a5qgrenGooQ/edit#heading=h.art6uzfmjhq5|this doc>.

Up next, we'll make <https://weddingindustryads.com/meta-ads-immersive-submission-direct-response|this form> for submitting direct response ads for campaign builds live. @Jacqueline Hood I know you want targeting info added to the client attraction submission form. Do you need it added to the direct response form as well? Any other feedback regarding this form?
> **Yulia Burris** · 2025-07-07 17:05 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1751907950612259)
> @Whitney Hodges <https://members.weddingindustryads.com/communities/groups/the-vault/home/posts/686bf98ba965745ab5e57e16|updated the link> in the _Share Your Direct Response Ads for Feedback_ lesson for the members’ Discussion section

**Jacqueline Hood** · 2025-07-07 16:59 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1751907567244149)
that looks great! We don't need to include targeting on this one :slightly_smiling_face:

**Whitney Hodges** · 2025-07-09 15:29 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1752074995682429)
@Yulia Burris Hi! <https://drive.google.com/file/d/1nSyT_bIvVI4IuipP0S80ziNOqyz22je7/view?usp=drive_link|Here is the recording from my workshop yesterday.> Can you please trim off the front and end and upload it to the client attraction ads look book lesson? Thank you!!
> **Whitney Hodges** · 2025-07-09 21:13 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1752095590191699)
> @Yulia Burris also, you may be able to pull a couple of quotes from Shelby from the beginning of the call when she talks about everything she's been learning in the program.
> **Yulia Burris** · 2025-07-09 21:16 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1752095819248329)
> @Whitney Hodges Perfect! I was just thinking the same thing :)) It would be great to include it. I’m working on the video now
> **Yulia Burris** · 2025-07-09 23:53 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1752105181989559)
> @Whitney Hodges @daniela Hi! Trimmed video is <https://drive.google.com/drive/folders/16yf0vZN7a_AzHsuoVwtZPiDSQJRQLpoK?usp=share_link|in the folder> and uploaded to the platform with a thumbnail. Let me know if you want any edits:)

**Whitney Hodges** · 2025-07-10 17:34 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1752168897941799)
@Jacqueline Hood Hi! Do you have the recording from today's office hours? If you could please drop it here, and @Yulia Burris please upload it to the vault. Thank you!!

**Jacqueline Hood** · 2025-07-10 20:05 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1752177949244409)
📎 Impromptu Zoom Meeting - Jul 10 2025.mp4 (mp4, **not downloaded** — over cap (261.6 MB), [fetch it](https://files.slack.com/files-pri/T03P5A3L1DK-F095B6B8AJG/download/impromptu_zoom_meeting_-_jul_10_2025.mp4))
> **Yulia Burris** · 2025-07-10 20:21 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1752178877456939)
> @Whitney Hodges Hi! This video should go in the Meta Ads Office Hour Replays, right? If so, do you want me to upload the July 3rd video too? I saw the last one on the portal is from June 26. Just let me know :slightly_smiling_face:
> 
> @Jacqueline Hood @daniela
> **Whitney Hodges** · 2025-07-10 20:31 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1752179467726439)
> @Yulia Burris yes, please! Jenna was supposed to have completed that. Thank you!!
> **Yulia Burris** · 2025-07-10 20:53 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1752180826999109)
> @Whitney Hodges I added the videos <https://app.leadlockpro.com/v2/location/Xi40zxmRvW8Pbyk5DYHp/memberships/courses/products/cc19750b-8e4a-4cf2-bff9-ecd07c1ff267|to the platform for July 3 and July 10> as drafts. Do you have the Canva link for the Office Hours cover page with the dates? I didn’t see it in the Canva folder “<https://www.canva.com/design/DAGmI-jQjNo/3PMHYbtthwKpwZ_mLgye6Q/edit?utm_content=DAGmI-jQjNo&amp;utm_campaign=designshare&amp;utm_medium=link2&amp;utm_source=sharebutton|WIA Cover Pages | Meta Ads Immersive Experience>.” I can create a new one with a different picture if needed :)
> 📎 Screenshot 2025-07-10 at 4.38.53 PM.png (png, saved as `files/F0954EGTWBV-Screenshot_2025-07-10_at_4.38.53_PM.png`)
> **Whitney Hodges** · 2025-07-10 21:19 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1752182351791999)
> @Yulia Burris <https://www.canva.com/design/DAGX4XVjNUA/bI-_uQpa4jIpqyyiXBIjHQ/edit?utm_content=DAGX4XVjNUA&amp;utm_campaign=designshare&amp;utm_medium=link2&amp;utm_source=sharebutton|Here's the Canva design with those cover pages>. Thank you!!
> **Yulia Burris** · 2025-07-10 21:21 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1752182506819329)
> @Whitney Hodges thank you! Added :white_check_mark:

**Jacqueline Hood** · 2025-07-10 20:06 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1752177979674119)
Here you go :slightly_smiling_face: Sorry for the delay! @Whitney Hodges @Yulia Burris

**Whitney Hodges** · 2025-07-17 01:05 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1752714356569829)
@Yulia Burris Hi! I need some help getting the Track Your Meta Ads Metrics course in LeadLock ready to go, so it can be published and added to the VAULT.
• I believe all lessons need thumbnails
• The description of the Metrics &amp; Benchmarks Overview lesson could probably use some attention
• <https://drive.google.com/file/d/1R-CBQCja0j8c7prIuhepJg23ZRPUOk_V/view?usp=drive_link|My workshop from yesterday> needs to be trimmed on the front and back end and added to the Metrics &amp; Benchmarks: Client Attraction Ads lesson.
• My discussion with Alyssa at the end of the call which wasn't related to the workshop topic can be trimmed and turned into its own video. I'd like to see this added to the Train course. I'm thinking we should rename this course "Train | Bonus Trainings to Continue Your Ads Education" and call the video of the conversation with Alyssa something along the lines of "Understanding the Ad Strategy for a Low Ticket Wedding Planning Membership or Course"
Thank you!!
> **Yulia Burris** · 2025-07-17 21:30 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1752787811769939)
> Hi everyone!  @Whitney Hodges @daniela Just a quick update for the Meta Ads Immersive:
> – Trimmed the workshop video, added it <https://drive.google.com/drive/folders/1SS5J7PSpfbq7P1mkXboTqb_7cgWX-3ui?usp=sharing|to the folder>, and uploaded it to the Metrics &amp; Benchmarks: Client Attraction Ads lesson, + added the description and thumbnail.
> – Uploaded thumbnails for each lesson in the Track Your Meta Ads Metrics product.
> – Updated the description in the _Metrics &amp; Benchmarks Overview_ lesson.(let me know if you'd like me to make any edits).
> – Renamed and updated the cover for the Train | Bonus Trainings to Continue Your Ads Education product.
> – Uploaded the bonus lesson with Alyssa to the <http://Updated%20the%20description%20in%20the%20Metrics%20&amp;%20Benchmarks%20Overview%20lesson.|folder> and added it to the platform with a cover.
> Hope I didn’t miss anything. I double-checked everything! Let me know if you’d like any changes:)
> **Whitney Hodges** · 2025-07-17 22:18 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1752790680919879)
> @Yulia Burris Hi! Thank you! I think the thumbnails may be off. I'd like to see one that aligns with the "Congrats" title. Then shift the "Meta Ads Metrics &amp; Benchmarks" to the overview lesson. Tysm!!!
> **Whitney Hodges** · 2025-07-22 14:49 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1753195753558059)
> @Yulia Burris Hi! Could you please customize the theme of the Train course to match our other products? Thank you!!

**Whitney Hodges** · 2025-07-17 14:07 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1752761255140889)
@Jacqueline Hood Good morning! Hope you're having a great week! I just posted a reminder about your office hours this morning inside the VAULT. I'm trying to encourage attendance because I want Sully to get whatever payment issue is going on sorted out, and I want you to be able to give Elsa some clear action items since her conversion campaign isn't generating leads. I think letting her know to change the CTA language on her landing page buttons is the best place to start if you haven't communicated that to her already. Let me know how it goes. And thank you so much as always!!

**Jacqueline Hood** · 2025-07-17 16:58 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1752771506167489)
Had a great call with Elsa! She's going to change the CTA on the buttons and we're going to launch RT ads :slightly_smiling_face:
My internet is a bit slow here so I'll download and share the call recording as soon as I can!
> **Whitney Hodges** · 2025-07-17 17:18 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1752772699371329)
> Amazing, thanks!
> **Jacqueline Hood** · 2025-07-18 15:34 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1752852884732939)
> The lead she got looks promising, too! It was actually a wedding planner booking on behalf of her client and they're getting married at one of the locations that Elsa designs for and we included in our targeting! She's meeting with her on Tuesday!

**Jacqueline Hood** · 2025-07-18 15:38 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1752853139826499)
Here's the call recording from yesterday! Sorry it's so delayed
📎 Impromptu Zoom Meeting - Jul 17 2025.mp4 (mp4, **not downloaded** — over cap (133.3 MB), [fetch it](https://files.slack.com/files-pri/T03P5A3L1DK-F096HJXGSRJ/download/impromptu_zoom_meeting_-_jul_17_2025.mp4))
> **Whitney Hodges** · 2025-07-18 15:43 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1752853388355689)
> @Yulia Burris can you please get this added to the vault?
> **Yulia Burris** · 2025-07-19 16:14 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1752941664636859)
> @Whitney Hodges Hi! I’ve added it and saved it as a draft)

**Whitney Hodges** · 2025-07-22 16:42 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1753202557916269)
@Jacqueline Hood Hi! Sully came to my workshop today. After I got through my presentation, she asked if we could look at her Client Attraction Ads. She had previously added a method of payment and thought everything was resolved. She didn't realize that one of her ads still had an error and that another was turned off.

We turned on the one that was off. For the one that had an error, I duplicated the ad set, the error went away, and I published that one. I deleted the ad/ad set with an error.

I think we need to formalize at what point in the process we pixel members' websites/landing pages. I'm not seeing a pixel installed on <http://teachtraveldiscover.com|teachtraveldiscover.com>, and the pixel attached to each of her ads is showing an inactive error.

What do you think about having some sort of internal checklist to make sure the pixel is installed before we launch Client Attraction Ads? That way we can be sure there is an exclusion for Website Visitors, and we don't have to add it in later

**Jacqueline Hood** · 2025-07-24 17:05 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1753376715148489)
Meta Ads Meeting July 24,2025
📎 Impromptu Zoom Meeting - Jul 24 2025.mp4 (mp4, **not downloaded** — over cap (316.2 MB), [fetch it](https://files.slack.com/files-pri/T03P5A3L1DK-F097RBD7YRF/download/impromptu_zoom_meeting_-_jul_24_2025.mp4))
> **Whitney Hodges** · 2025-07-24 18:49 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1753382991969829)
> @Yulia Burris Could you please add this to the VAULT? Thank you!
> **Yulia Burris** · 2025-07-24 18:57 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1753383434727259)
> @Whitney Hodges added :white_check_mark::blush:

**Gisselle Jiménez** · 2025-07-28 14:56 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1753714611936139)
:mega: *MAIE Submission Notice*
 @Jacqueline Hood — Submission received from *Shelby Kenney* on *July 24* for Client Attraction Ads. Just flagging here for visibility!

**Yulia Burris** · 2025-07-28 16:30 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1753720205465329)
@Whitney Hodges @daniela
Hi! I added a new lesson to the platform as a draft _*Understanding Nurture Retargeting Ads*_. (trimmed the video, added covers, pdf,  and a description) + uploaded the new version to the <https://drive.google.com/drive/folders/1xE2VF5QEOVj2C89x9t7ROyc46huhQK5r?usp=share_link|folder>.
> **Whitney Hodges** · 2025-07-28 18:11 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1753726268531339)
> @Yulia Burris Thank you! This has been published and added to the VAULT

**Jacqueline Hood** · 2025-07-28 19:05 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1753729533509759)
I'll launch Shelby's client attraction ads today, thanks for the reminder @Gisselle Jiménez :slightly_smiling_face:
> **Gisselle Jiménez** · 2025-07-28 19:11 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1753729902695499)
> Thank you! Let me know when this is done so I can check it off. :heart_hands:

**Gisselle Jiménez** · 2025-07-30 14:40 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1753886454175359)
@Whitney Hodges @Yulia Burris This week's workshop about *<https://drive.google.com/file/d/1U3ynEGmmqerj8nZ_ca2YaMLtw-fAEO7W/view?usp=drive_link|Short-term Promotions>* has been uploaded to the drive under _Resources_! :white_check_mark:
> **Whitney Hodges** · 2025-07-30 15:10 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1753888200329939)
> @Yulia Burris Can you please trim off basically the whole conversation with Elsa at the end? Then add this training as a new lesson for the Train course. Thank you!!
> **Yulia Burris** · 2025-07-30 15:19 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1753888773205299)
> @Gisselle Jiménez thank you) 
> @Whitney Hodges I’ll add it today! :blush:
> **Yulia Burris** · 2025-07-30 18:24 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1753899860880589)
> @Whitney Hodges I added the lesson to the platform.:heavy_check_mark: I didn’t include the part about the 15X return in less than 3 weeks in the description (just the real client example). Let me know if you’d like me to add that info. <https://drive.google.com/drive/folders/1ryccEqQszQ4LbCttJoOODVctY2h_naSF?usp=sharing|Here’s the trimmed video>.

**Jacqueline Hood** · 2025-07-31 17:07 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1753981620085489)
Meta Ads Call - July 31, 2025
📎 Impromptu Zoom Meeting - Jul 31 2025 (1).mp4 (mp4, **not downloaded** — over cap (117.9 MB), [fetch it](https://files.slack.com/files-pri/T03P5A3L1DK-F098AK05ELW/download/impromptu_zoom_meeting_-_jul_31_2025__1_.mp4))
> **Whitney Hodges** · 2025-07-31 18:19 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1753985953372949)
> @Gisselle Jiménez I'd like for you to add this to our Office Hours recordings inside the VAULT. I can show you how on our call tomorrow
> **Gisselle Jiménez** · 2025-07-31 18:42 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1753987343784309)
> Noted! I'll add it to the agenda.

**Gisselle Jiménez** · 2025-08-05 18:16 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1754417772075969)
@Yulia Burris This week’s workshop on *<https://drive.google.com/file/d/1vOB_xv4mPo9iq0QUaGqyoNkvLqhddKYQ/view?usp=drive_link|Meta Ad Campaign Performance &amp; Optimization>* has been uploaded to the Drive under _Resources_ and is ready for you to edit.
 @Whitney Hodges Let us know if you'd prefer a different title or if it should be moved to a specific folder. Thanks!
> **Whitney Hodges** · 2025-08-05 18:17 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1754417875840949)
> It should go in the "Track" folder and have a name similar to the video for Client Attraction metrics, but in this case, it's about Direct Response metrics. Thank you!!
> **Gisselle Jiménez** · 2025-08-05 18:22 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1754418154746309)
> Done!
> 📎 image.png (png, saved as `files/F098Z01FD43-image.png`)
> **Yulia Burris** · 2025-08-06 17:55 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1754502911228699)
> @Whitney Hodges Hi!) I uploaded the new lesson version to the <https://drive.google.com/drive/folders/1SS5J7PSpfbq7P1mkXboTqb_7cgWX-3ui?usp=sharing|folder> + added the lesson to the platform as a draft.

**Gisselle Jiménez** · 2025-08-07 18:42 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1754592144159739)
@Whitney Hodges Today's MAIE <https://app.leadlockpro.com/v2/location/Xi40zxmRvW8Pbyk5DYHp/memberships/courses/posts/1ab28ffc-b22d-474c-9700-6a518710f023/edit|Office Hours> meeting has been published. :raised_hands:

**Jacqueline Hood** · 2025-08-08 01:25 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1754616354552849)
Thanks again so much for covering the call this morning @Whitney Hodges :two_hearts:

**Gisselle Jiménez** · 2025-08-12 20:06 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1755029209340479)
@Yulia Burris This week’s workshop on <https://drive.google.com/file/d/1X3Wd9g4jwb-BtXwlvSciEXxfC0_eH2Q1/view?usp=drive_link|Driving Instagram Growth &amp; High-Quality Leads> has been uploaded to the Drive under _Resources_ and is ready for you to edit.
 @Whitney Hodges Let me know if you'd prefer a different title or if it should be moved to a specific folder. Thanks!:revolving_hearts:
> **Whitney Hodges** · 2025-08-12 20:19 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1755029955489019)
> @Gisselle Jiménez @Yulia Burris I'd like this to be part of the Train course. Editing should be really minimal, just see if anything needs to be trimmed off the front or back.
> 
> Is there a transcript from this recording? I think I'd like to incorporate some of what I was saying into our weekly marketing email
> **Gisselle Jiménez** · 2025-08-12 20:38 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1755031085386919)
> *<https://docs.google.com/document/d/1hPYBDVSd7Jc5T9br2lbujdE2VJPtOOT2z-ABeRJaB-Y/edit?usp=drive_link|Here>* is the transcript extracted from Zoom! @Whitney Hodges
> **Yulia Burris** · 2025-08-14 23:13 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1755213185650519)
> @Whitney Hodges @Gisselle Jiménez Hi!:) I’ve uploaded the <https://app.leadlockpro.com/v2/location/Xi40zxmRvW8Pbyk5DYHp/memberships/courses/posts/41de0968-7358-4335-950f-e06a47412c27/edit|lesson> to the platform. Here’s the video in the <https://drive.google.com/drive/folders/1soAt8Ro0HtWaHD6UktvwfCgQEkaewc3w?usp=share_link|WIA folder>.

**Whitney Hodges** · 2025-08-13 17:26 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1755106014708899)
Whitney to record: <https://www.canva.com/design/DAGXkIfbIC0/cZSjvmbo_AD45aZUxEXAaA/edit>

**Jacqueline Hood** · 2025-08-14 18:46 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1755197191191669)
Meta Ads Call - Aug 14, 2025

**Jacqueline Hood** · 2025-08-14 18:50 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1755197440641719)
📎 Impromptu Zoom Meeting - Aug 14 2025.mp4 (mp4, **not downloaded** — over cap (132.1 MB), [fetch it](https://files.slack.com/files-pri/T03P5A3L1DK-F09A9J97JLT/download/impromptu_zoom_meeting_-_aug_14_2025.mp4))
> **Gisselle Jiménez** · 2025-08-14 20:35 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1755203722565399)
> @Whitney Hodges This has been uploaded to <https://members.weddingindustryads.com/courses/products/cc19750b-8e4a-4cf2-bff9-ecd07c1ff267/categories/7f052005-653e-497d-9608-ef93400c4d52/posts/c52c00a4-46e2-40ed-8ad7-2f5f8ada6632?source=communities&amp;group_slug=the-vault|The Vault>. :raised_hands:

**Gisselle Jiménez** · 2025-08-19 19:40 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1755632458715199)
Hi, @Whitney Hodges Did you record today's workshop? I was only able to find a 45-second recording.:face_holding_back_tears:
> **Whitney Hodges** · 2025-08-19 19:42 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1755632570202889)
> No, I didn't have a workshop today. Daniela did a momentum call instead, but no one showed up. She said she was going to record some sort of short motivational video instead. Can you follow up with her on that?
> **Gisselle Jiménez** · 2025-08-19 19:44 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1755632662267269)
> Got it! I'll follow-up with her

**Jacqueline Hood** · 2025-08-21 17:36 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1755797793784849)
Hey @Gisselle Jiménez :slightly_smiling_face: Here's the recording from today - are you able to cut out the first 30 minutes? I was on another call with someone else and then our clients hopped in so it's all in one recording :slightly_smiling_face:

**Jacqueline Hood** · 2025-08-21 17:40 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1755798059151619)
📎 Impromptu Zoom Meeting - Aug 21 2025 (1).mp4 (mp4, **not downloaded** — over cap (365 MB), [fetch it](https://files.slack.com/files-pri/T03P5A3L1DK-F09BAP12SGK/download/impromptu_zoom_meeting_-_aug_21_2025__1_.mp4))
> **Gisselle Jiménez** · 2025-08-21 18:39 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1755801580798199)
> No problem! Working on it.:heart_hands:
> **Gisselle Jiménez** · 2025-08-21 19:26 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1755804394517719)
> @Jacqueline Hood @Whitney Hodges Video was trimmed and is now <https://members.weddingindustryads.com/courses/products/cc19750b-8e4a-4cf2-bff9-ecd07c1ff267/categories/7f052005-653e-497d-9608-ef93400c4d52/posts/1b36ce67-16fc-462f-867f-93aba801f4de?source=communities&amp;group_slug=the-vault|published>!
> **Jacqueline Hood** · 2025-08-21 22:56 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1755816987638759)
> I see the transcript thinks I dropped the F-bomb but I swear I didn't! haha
> **Jacqueline Hood** · 2025-08-21 22:56 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1755816999311769)
> thank you @Gisselle Jiménez :slightly_smiling_face:

**Whitney Hodges** · 2025-08-26 14:05 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1756217108145399)
@Jacqueline Hood Hi! I didn't realize the link to submit direct response ads wasn't live in the Vault yet, but it is now! <https://weddingindustryads.com/meta-ads-immersive-submission-direct-response|Please check it out>, and let me know if you want any edits made. I think this should match up with what we previously discussed, but I know it's been awhile.

**Jacqueline Hood** · 2025-08-26 14:06 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1756217182501459)
that looks perfect, thank you!
> **Whitney Hodges** · 2025-08-26 14:06 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1756217218138549)
> Great! I expect Shelby will submit soon!

**Whitney Hodges** · 2025-08-26 16:38 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1756226293815509)
@Gisselle Jiménez Today's Meta Ads workshop was a bust. Nobody showed, and I kept coughing and running into errors in the ads manager, so we're not going to use that recording. I'll need to re-record.

@Jacqueline Hood For the workshop, I was going over the material in <https://www.canva.com/design/DAGXkIfbIC0/cZSjvmbo_AD45aZUxEXAaA/edit?utm_content=DAGXkIfbIC0&amp;utm_campaign=designshare&amp;utm_medium=link2&amp;utm_source=sharebutton|this presentation>, but I was sharing my screen inside the Ads Manager giving real examples. Honestly, I meant to ask you to look at this content last week, but I totally forgot. Can you please review it and let me know if there's anything you'd change or add?

@Yulia Burris Based on Jacqueline's feedback, I'd like for you to then update the presentation. Instead of photos throughout, I think screenshot examples from inside the Meta Ads Manager would be much more helpful. The text on each slide is dense, so if it needs to be broken up into more slides that is totally fine. I'd love to have a revised version by the end of the week, so I can re-record.

Thank you all!!!
> **Yulia Burris** · 2025-08-29 20:45 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1756500358190799)
> @Jacqueline Hood Hi Jacqueline, do you have any preferences or suggestions you’d like us to add to the presentation? Please let us know when you have a moment to take a look:) 
> Thank you so much!
> 
> cc: @Whitney Hodges 

**Gisselle Jiménez** · 2025-08-27 14:45 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1756305912699219)
:mega: *MAIE Submission Notice*

 @Jacqueline Hood — Submission received from *Shelby Kenney* on August 26 for *Direct Response Ads.* Just flagging here for visibility!
> **Jacqueline Hood** · 2025-08-28 19:42 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1756410175140709)
> Ads are launched :slightly_smiling_face:

**Jacqueline Hood** · 2025-08-28 01:17 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1756343847681309)
thanks!!

**Jacqueline Hood** · 2025-08-28 16:58 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1756400335230359)
Meta Ads Office Hours - Aug 28, 2025
📎 Impromptu Zoom Meeting - Aug 28 2025.mp4 (mp4, **not downloaded** — over cap (145.3 MB), [fetch it](https://files.slack.com/files-pri/T03P5A3L1DK-F09DB9REFJL/download/impromptu_zoom_meeting_-_aug_28_2025.mp4))
> **Gisselle Jiménez** · 2025-08-28 17:23 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1756401809916059)
> Uploaded!

**Gisselle Jiménez** · 2025-09-02 18:12 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1756836778408899)
@Yulia Burris, This week’s workshop on <https://drive.google.com/file/d/1BKlHLEEgxQL_X1YSp0YaxxkRh1u-l64-/view?usp=drive_link|What you need to know to run your own campaigns successfully> has been uploaded to the Drive under _Resources_.

@Whitney Hodges , let us know if you'd prefer a different title or if it should be moved to a specific folder. Thanks!:dizzy:
> **Whitney Hodges** · 2025-09-02 18:29 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1756837779972959)
> @Yulia Burris Can you please edit the video? There was a part in the middle where something weird happened with my screenshare, and it took me a second to get back to full screen.
> 
> I moved it to the folder Tweak. There is a course for this, but it isn't published yet.
> 
> Thank you!!
> **Yulia Burris** · 2025-09-02 21:09 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1756847395183459)
> @Whitney Hodges Hi! I’ve uploaded a draft <https://app.leadlockpro.com/v2/location/Xi40zxmRvW8Pbyk5DYHp/memberships/courses/products/4ea38074-ddf1-4ea0-89a8-d5d049daa143|lesson> to the _Tweak Campaigns to Optimize Performance_ product. I also added covers and a description, and the trimmed video is in the Tweak <https://drive.google.com/drive/folders/1oOOWEGEYbyMsT216BvKqO6G6B-ff1A_j?usp=share_link|folder>. Let me know if you’d like any changes.
> 
> 
> cc: @Gisselle Jiménez
> **Whitney Hodges** · 2025-09-08 16:25 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1757348712441489)
> @Yulia Burris Looks good! Can you please create lessons for the two other videos in <https://drive.google.com/drive/folders/1oOOWEGEYbyMsT216BvKqO6G6B-ff1A_j|this folder>?
> **Whitney Hodges** · 2025-09-16 15:42 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1758037346375449)
> @Yulia Burris Hi! I saw that you created lessons and uploaded the videos and thumbnails. Thank you!
> 
> Can you please add in descriptions for each as well?
> **Yulia Burris** · 2025-09-16 15:44 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1758037444904429)
> @Whitney Hodges Of course! I’ll do it now.
> **Yulia Burris** · 2025-09-16 16:07 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1758038836131589)
> @Whitney Hodges I’ve added the <https://app.leadlockpro.com/v2/location/Xi40zxmRvW8Pbyk5DYHp/memberships/courses/products/4ea38074-ddf1-4ea0-89a8-d5d049daa143|descriptions>. Please let me know if that works
> **Whitney Hodges** · 2025-09-16 16:10 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1758039054361879)
> Perfect! Published!

**Jacqueline Hood** · 2025-09-04 17:14 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1757006098989279)
Meta Ads Call - Sept 4/2025

Updates - Shelby is getting leads but her LP conversion rate was really low, so we changed the funnel slightly so the form is now a pop-up, not on its own page. And Elsa got her first paid project from the ads!!

It was a full hour and I totally forgot to mention the change in time for next week. LOL sorry! @Whitney Hodges
📎 Impromptu Zoom Meeting - Sep 4 2025 (1).mp4 (mp4, **not downloaded** — over cap (335 MB), [fetch it](https://files.slack.com/files-pri/T03P5A3L1DK-F09DL296XFU/download/impromptu_zoom_meeting_-_sep_4_2025__1_.mp4))
> **Gisselle Jiménez** · 2025-09-04 17:50 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1757008201569859)
> <https://members.weddingindustryads.com/courses/products/cc19750b-8e4a-4cf2-bff9-ecd07c1ff267/categories/7f052005-653e-497d-9608-ef93400c4d52/posts/a684ecab-0602-4ba7-bb16-25114fc1cee3?source=communities&amp;group_slug=the-vault|Uploaded>!

**Whitney Hodges** · 2025-09-08 16:01 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1757347271305739)
@Yulia Burris Hi! I created a new recurring event for Jacqueline's office hours because we changed the time. Can you please go into the VAULT and add a thumbnail image for this?
> **Yulia Burris** · 2025-09-08 16:40 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1757349650703819)
> @Whitney Hodges updated :white_check_mark:

**Gisselle Jiménez** · 2025-09-08 17:54 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1757354047231249)
:inbox_tray: New Retargeting Campaign Form Submission from Gisselle TEST!

**Gisselle Jiménez** · 2025-09-10 21:25 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1757539535975159)
:inbox_tray: New Retargeting Campaign Form Submission from Sullienid Montero!
> **Jacqueline Hood** · 2025-09-12 00:52 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1757638333594579)
> Ads are launched!

**Jacqueline Hood** · 2025-09-11 21:09 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1757624969504789)
Something to add to the agenda for Monday's meeting:
-Elsa is considering layering Google ads into her strategy so I said we'd discuss how that could look :slightly_smiling_face:

**Jacqueline Hood** · 2025-09-11 23:27 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1757633225103389)
Meta Ads Immersive Call - Sept 11, 2025
📎 Impromptu Zoom Meeting - Sep 11 2025 (1).mp4 (mp4, **not downloaded** — over cap (196.9 MB), [fetch it](https://files.slack.com/files-pri/T03P5A3L1DK-F09EZ53U8GL/download/impromptu_zoom_meeting_-_sep_11_2025__1_.mp4))
> **Gisselle Jiménez** · 2025-09-12 15:17 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1757690273694979)
> Uploaded!

**Whitney Hodges** · 2025-09-16 16:08 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1758038926399459)
@Yulia Burris Hi! I've added a lesson for Submit Your Nurture Retargeting Ads. Can you please add a thumbnail and then publish? Thank you!
> **Yulia Burris** · 2025-09-16 16:12 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1758039173953229)
> @Whitney Hodges Added the <https://app.leadlockpro.com/v2/location/Xi40zxmRvW8Pbyk5DYHp/memberships/courses/posts/3625be5d-545d-42b7-bac3-e506cf282ecb/edit|thumbnail> and published.

**Whitney Hodges** · 2025-09-16 16:22 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1758039729372229)
@Gisselle Jiménez Hi! There should be two recordings from my workshop today. The first one can be disregarded. I started recording, but then ended up working on other things. The second recording is what we'll want to add to the VAIULT. Thank you!
> **Gisselle Jiménez** · 2025-09-16 17:17 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1758043065911409)
> Hey, @Whitney Hodges! Only one recording has come through so far. I checked Zoom, and it also only shows that one. If you recorded a longer session, it may still be processing. I’ll keep you updated.
> 📎 image.png (png, saved as `files/F09FY4BHLGH-image.png`)
> **Whitney Hodges** · 2025-09-16 17:19 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1758043147180639)
> Okay, maybe it automatically combined the two recordings or something. Can you take a look and see if I am speaking or sharing anything at all within the recording? @Gisselle Jiménez
> **Gisselle Jiménez** · 2025-09-16 17:25 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1758043538659229)
> @Whitney Hodges I did, and you never spoke or shared screen:slightly_frowning_face: You were just working on other things.
> **Whitney Hodges** · 2025-09-16 17:28 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1758043710248679)
> @Gisselle Jiménez ok thank you for checking! If it doesn't ever come through, let me know. And I'll re-record
> **Gisselle Jiménez** · 2025-09-16 17:35 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1758044119773449)
> Will do!
> **Whitney Hodges** · 2025-09-18 22:35 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1758234911473959)
> @Gisselle Jiménez did the recording ever come through?
> **Gisselle Jiménez** · 2025-09-19 13:19 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1758287941563519)
> @Whitney Hodges It didn't :smiling_face_with_tear:

**Jacqueline Hood** · 2025-09-18 22:14 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1758233653872499)
Office Hours Sept 18/25:
📎 Impromptu Zoom Meeting - Sep 18 2025.mp4 (mp4, **not downloaded** — over cap (387.4 MB), [fetch it](https://files.slack.com/files-pri/T03P5A3L1DK-F09G0F72RDG/download/impromptu_zoom_meeting_-_sep_18_2025.mp4))
> **Gisselle Jiménez** · 2025-09-19 14:11 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1758291073546639)
> Published!

**Gisselle Jiménez** · 2025-09-20 15:17 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1758381433140959)
:inbox_tray: New Retargeting Campaign Form Submission from Sullienid Montero!

**Jacqueline Hood** · 2025-09-25 20:57 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1758833854937189)
Huge win today for Shelby!! Last Thursday we went over some recommended changes to her landing page. She made the changes last Friday and has generated 2 leads since then; CPL went from $178 to $60 and the landing page conversion rate went from 0.99% to 3.22% - with the same ads! :partying_face: AND she got her first wedding booked from the ads!
Such an important reminder of how important not just the ads are, but the entire journey.

@Whitney Hodges I wonder if we could pull some screen recordings or screenshots of her original LP and compare it to the new one to somehow include in the vault as a training?
> **Whitney Hodges** · 2025-09-25 21:12 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1758834773627589)
> @Jacqueline Hood Amazing results! Such an exciting update. Does the previous version of the landing page still exist? Or would we have to dig into your previous video walkthrough/office hours recordings for that?
> **Whitney Hodges** · 2025-09-25 21:13 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1758834812639969)
> @Jacqueline Hood Do you know what the value of the wedding Shelby booked from ads is?
> **Jacqueline Hood** · 2025-09-25 21:14 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1758834898936329)
> The previous version doesn't exist, she just edited what she had, so we'd have to dig through the previous office hours. But last week's recording we did a deep dive on it!
> **Jacqueline Hood** · 2025-09-25 21:15 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1758834912060869)
> I don't know the value - I can ask her next week!
> **Jacqueline Hood** · 2025-09-25 21:22 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1758835367708259)
> Office Hours - Sept 25/25
> 📎 Impromptu Zoom Meeting - Sep 25 2025.mp4 (mp4, **not downloaded** — over cap (174.1 MB), [fetch it](https://files.slack.com/files-pri/T03P5A3L1DK-F09H45Z522H/download/impromptu_zoom_meeting_-_sep_25_2025.mp4))
> **Whitney Hodges** · 2025-09-25 21:24 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1758835463848639)
> @Gisselle Jiménez ^
> **Gisselle Jiménez** · 2025-09-26 18:07 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1758910059496589)
> Office hours published! :done:

**Gisselle Jiménez** · 2025-09-29 21:22 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1759180971091519)
:bell:Gisselle TEST has requested to join The VAULT!
> **Gisselle Jiménez** · 2025-09-29 21:25 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1759181134373649)
> @Whitney Hodges LeadLock only has the option to trigger when a request has been accepted or denied, so I created this as a zap. I also noticed the previous alert went to the sales-opportunities channel, so I've moved it to this channel now.

**Gisselle Jiménez** · 2025-09-29 21:25 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1759181158148809)

**Gisselle Jiménez** · 2025-09-30 13:55 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1759240551765539)
Hi, @Jacqueline Hood! Just flagging Elsa's email here in case you missed it:

&gt; Oh man, I totally spaced the office hours today!
&gt; One thing I did want to bring up in our time today was that previously we had discussed that the follow up email should have more of a look book or an orientation video of some sort... that folks might need more info about my services before committing to booking. Thats why I created the video and the link to my website. Whitney mentioned that booking a call was a pretty big ask, so we need to give them more info first...

**Gisselle Jiménez** · 2025-09-30 18:59 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1759258752087049)
@Yulia Burris @Whitney Hodges I've uploaded today's workshop to the<https://drive.google.com/drive/folders/1gOcS0SDYnf3khcZFpjXCTndqBGe4ZGCk?usp=drive_link| retargeting folder>, titled <https://drive.google.com/file/d/1S11uBm1BjQNZ1TH9HR30Cio3UYw-WXR_/view?usp=drive_link|Metrics and Benchmarks for Nurture Retargeting Ads>. Let me know if anything needs to be modified!
> **Whitney Hodges** · 2025-09-30 19:02 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1759258965401799)
> @Gisselle Jiménez thank you! @Yulia Burris there was a part kind of near the beginning when I tripped over my words a couple of times trying to say "9 times out of 10". Can you please edit that out before you post to the Vault?
> **Yulia Burris** · 2025-10-01 19:53 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1759348390060159)
> @Whitney Hodges Hi! I uploaded a new trimmed video to the <https://drive.google.com/drive/folders/1gOcS0SDYnf3khcZFpjXCTndqBGe4ZGCk?usp=share_link|folder> and also uploaded the <https://app.leadlockpro.com/v2/location/Xi40zxmRvW8Pbyk5DYHp/memberships/courses/posts/3ef663cf-75d4-4fb7-a31b-fd3ef843e8a9/edit|lesson and thumbnails>. I added the lesson to the product _Track Your Meta Ads Metrics_. Let me know if it needs to be moved to a different one)
> 
> cc: @Gisselle Jiménez

**Jacqueline Hood** · 2025-10-02 21:31 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1759440662028269)
Meta Ads Office Hours - Oct 2/25
📎 Impromptu Zoom Meeting - Oct 2 2025.mp4 (mp4, **not downloaded** — over cap (316.3 MB), [fetch it](https://files.slack.com/files-pri/T03P5A3L1DK-F09JKSS21T6/download/impromptu_zoom_meeting_-_oct_2_2025.mp4))
> **Gisselle Jiménez** · 2025-10-03 14:29 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1759501756352709)
> Uploaded!

**Gisselle Jiménez** · 2025-10-08 22:24 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1759962278042239)
:checkered_flag: Katie Logan scheduled a Meta Ads Immersive Experience Kickoff Call with Whitney!

Appointment Date &amp; Time: Tuesday, October 21, 2025 10:30 AM EDT

**Jacqueline Hood** · 2025-10-09 21:32 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1760045566937509)
Meta Ads Office Hours - Oct 9, 2025
📎 Impromptu Zoom Meeting - Oct 9 2025.mp4 (mp4, **not downloaded** — over cap (165.9 MB), [fetch it](https://files.slack.com/files-pri/T03P5A3L1DK-F09KR59PA02/download/impromptu_zoom_meeting_-_oct_9_2025.mp4))
> **Gisselle Jiménez** · 2025-10-10 13:55 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1760104540196549)
> Uploaded!

**Gisselle Jiménez** · 2025-10-17 14:12 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1760710361380399)
Hi, @Jacqueline Hood! Just for visibility, wanted to let you know that there’s a <https://members.weddingindustryads.com/communities/groups/the-vault/home/posts/6848cf504eaaa6480cd5e331?commentId=68f168786389de3dcbec7abd&amp;parentId=6848cf504eaaa6480cd5e331|new comment> from Katie Logan in The Vault asking for feedback on her landing page. :raised_hands:
> **Jacqueline Hood** · 2025-10-20 14:32 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1760970737427399)
> Reviewed and sent feedback!

**Jacqueline Hood** · 2025-10-17 18:01 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1760724084936269)
ohh thank you!

**Gisselle Jiménez** · 2025-10-20 00:57 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1760921828003219)
:memo: Katie Logan completed their onboarding questionnaire!
> **Gisselle Jiménez** · 2025-10-20 19:50 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1760989847570819)
> @Whitney Hodges Here is Katie's questionnaire. Also uploaded to <https://drive.google.com/file/d/1HzQAUlLveZSI4N5DFwLSNxt0zjQsBL6T/view?usp=drive_link|Drive>.
> 📎 Katie Logan - MAIE Onboarding Questionnaire.pdf (pdf, saved as `files/F09MKA8075Y-Katie_Logan_-_MAIE_Onboarding_Questionnaire.pdf`)

**Jacqueline Hood** · 2025-10-23 23:27 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1761262023166029)
(No one showed last week so no recording)

**Jacqueline Hood** · 2025-10-23 23:29 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1761262181822149)
Meta Ads Office Hours - Oct 23/25
📎 Impromptu Zoom Meeting - Oct 23 2025.mp4 (mp4, **not downloaded** — over cap (256.9 MB), [fetch it](https://files.slack.com/files-pri/T03P5A3L1DK-F09P5MGSZL0/download/impromptu_zoom_meeting_-_oct_23_2025.mp4))
> **Whitney Hodges** · 2025-10-23 23:37 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1761262638209619)
> @Jacqueline Hood Hi! Was Elsa at office hours today?
> **Gisselle Jiménez** · 2025-10-24 14:03 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1761314607653689)
> @Whitney Hodges @Jacqueline Hood Published!
> **Jacqueline Hood** · 2025-10-28 21:56 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1761688595377619)
> @Whitney Hodges sorry I missed that question! Yes she was there last week!

**Gisselle Jiménez** · 2025-10-28 20:14 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1761682468225949)
@Whitney Hodges Today's <https://drive.google.com/file/d/1mY1yvGQj1kEASM-2DFjgFiEv5UzSpskV/view?usp=drive_link|workshop recording> has been uploaded to the _Resources_ folder. Let me know if you want this moved to any specific folder!

cc: @Yulia Burris
> **Whitney Hodges** · 2025-10-28 20:17 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1761682662421919)
> @Yulia Burris Hi! If you could check this out when you have some time and let me know if you think we should edit into curriculum, that would be great.
> 
> I didn't have any planned content for this session. But Katie was there and we audited some of her content to repurpose for ads. 
> 
> If you think this would be helpful for anyone else in the program to watch, please let me know. But it may only be helpful for Katie in particular, in which case, I don't know that we need to upload it anywhere
> **Yulia Burris** · 2025-10-28 21:23 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1761686616890239)
> @Whitney Hodges I think we can add it! We can edit the video and cut some parts. Maybe call it _“Content Audit for Ads: Micro Wedding &amp; Elopement Planner,”_ or something else. Let me know what you prefer cc: @Gisselle Jiménez
> **Whitney Hodges** · 2025-10-28 21:28 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1761686934974339)
> @Yulia Burris ok if you think it would be valuable to include l, that sounds great!

**Jacqueline Hood** · 2025-10-30 21:24 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1761859497707939)
Meta Ads Immersive Office Hours - Oct 30
📎 Impromptu Zoom Meeting - Oct 30 2025.mp4 (mp4, **not downloaded** — over cap (175.6 MB), [fetch it](https://files.slack.com/files-pri/T03P5A3L1DK-F09PMDENTMZ/download/impromptu_zoom_meeting_-_oct_30_2025.mp4))
> **Gisselle Jiménez** · 2025-10-31 14:44 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1761921898080439)
> Published!

**Gisselle Jiménez** · 2025-11-03 19:56 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1762199819273689)
Hi, @Jacqueline Hood! Just for visibility, I wanted to let you know that there’s a <https://email.reply.weddingindustryads.com/c/eJyElM1yozgQgJ9G3JICCRA-cIhNsIO9s0lm7Di-uEBqgzBIWAhi_PRb4DnOZG_dqq-6P_202FHwcHjDEewJLYfPmy_XX8ybLSwe8gyfKLa4qlMhQw1NNTx-AedC5kLyrjV6SHn7yFT9mzmqLwm6LURzNEMDYaVYaoS6r3MLQof62Jn5xPUtqFNRHWto2zSHUQJvCzULFqsi3hx0fUnefy5eflNTMWUK0BbIXmgla5AmbLTiHRsbWEVIPD8IUjyzKSPEdU6EA3AGHkBKSOBQS4TYxp7j2MQJvJntP2ZAHWZTzyYcOwR85Nrf7rEKC2OaFpEnhGOE4xrqDHT7F3xkSDz5IxIVUFUKufbfWL9SuZALxQGRCGHX8fYIO1t8RtjXwIUGZrZ6qjQ5YG-08EYP7_9NPBwzVdedFEZAO-W5Vl1zD00BD33aVWbKClXDFDSqNXfADzzXTX3uBIyeKM9oSk4-BHS0mAqDNC98zCJ_ZgenjLo2YJw5sxTbdupzyKyKHe93KaQBLdMq3OK45cvdee_Mfg6mDPrz7qO8rJpu1TKEY8N_ZMsS1NtSbg7_rhZLuJ2qG-TN52L7-aygR3jusjnCsdOSPT-UCMdJVcRUJ3sj6RtbRZWI1gjHu7P9fFu7uJxf6HO-y_xl-ZoMa5HMEI51nOXzzRCnbcGumWLuZntpVgjPC_qqdoaqzfqJ7vVAb7vuKUd4Hm-97WH1qy9ect5pLxl2L7qJ4g1eCHb91RDtXRLZjXamePsn-rFI3m_zffAx5Ncmx-X1kDTlvEUksio1Dd9euPbtWr_3H8FrNpy96HPVWDWYQvEwbYTVaNULDjqsIOVMSQnMKG3p8Ps3ZbWq0wzC6dQfRNs_fCl9Bm2ZcSyPf-xqQqbq4x9_AxOCOd5HsA_xfwEAAP__jPJtqQ|new comment> from Katie Logan in The Vault asking for feedback on some existing reels for client Attraction Ads! :raised_hands:

**Jacqueline Hood** · 2025-11-03 23:33 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1762212795816059)
thank you!!

**Gisselle Jiménez** · 2025-11-05 13:45 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1762350353460939)
:bell:Diana Leimbach has requested to join The VAULT!
> **Whitney Hodges** · 2025-11-05 14:06 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1762351592118919)
> @Gisselle Jiménez Can you please create a channel called the VAULT and move these alerts there? Thank you!!
> **Gisselle Jiménez** · 2025-11-06 18:44 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1762454666291369)
> @Whitney Hodges Notifications have been moved to the channel!

**Gisselle Jiménez** · 2025-11-05 15:17 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1762355863376599)
:gem: Diana Leimbach joined The VAULT!


**Gisselle Jiménez** · 2025-11-05 15:23 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1762356189504319)
:gem: Christina HIll joined The VAULT!


**Gisselle Jiménez** · 2025-11-05 15:54 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1762358074117219)
:bell:Erin Smith has requested to join The VAULT!

**Gisselle Jiménez** · 2025-11-05 17:30 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1762363832910239)
:gem: Erin Smith joined The VAULT!


**Gisselle Jiménez** · 2025-11-06 17:59 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1762451952775059)
:bell:Fernanda Ruiz has requested to join The VAULT!

**Gisselle Jiménez** · 2025-11-06 18:31 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1762453880726519)
:gem: Fernanda Ruiz joined The VAULT!

> **Gisselle Jiménez** · 2025-11-06 18:52 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1762455163213669)
> @Whitney Hodges It seems that only channel managers within the channel can add new members. I was able to add Fernanda to the GSA channel, but only Daniela is a channel manager in MAIE.
> 
> @daniela Could you grant us access in the MAIE channel so we can add members?
> 
> Thanks!:heart_hands:
> 📎 image.png (png, saved as `files/F09QUQ4RRMM-image.png`)
> **daniela** · 2025-11-06 19:39 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1762457952845799)
> Absolutely! Thanks for bringing this up @Gisselle Jiménez - let me know who in addition to you should be channel managers as well
> 
> cc: @Whitney Hodges - should all of the WIA team members be designated as "channel managers"? Looks like there can be more than one!
> **daniela** · 2025-11-06 19:43 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1762458232242489)
> Side note - let's invite Carmen to add her photo and a quick bio showing her role at WIA
> 📎 Screenshot 2025-11-06 at 1.43.02 PM.png (png, saved as `files/F09QV7L2YUX-Screenshot_2025-11-06_at_1.43.02_PM.png`)
> **Whitney Hodges** · 2025-11-06 20:10 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1762459852743379)
> @daniela Yes, can you please make everyone on the team channel managers?
> 
> @Gisselle Jiménez Please reach out to Carmen regarding adding a profile pic and short bio in the vault.
> 
> Thank you both!
> **Gisselle Jiménez** · 2025-11-06 20:14 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1762460081960319)
> @daniela Thank you!:heart_hands:
> 
> @Whitney Hodges I've reached out to Carmen:raised_hands:
> 
> Fernanda has been added to both channels!
> **daniela** · 2025-11-06 22:26 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1762467988491259)
> Done!

**Jacqueline Hood** · 2025-11-08 16:39 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1762619954544689)
Good morning! Apologies for the delay - I was travelling yesterday! Here's the call recording from Thursday's office hours!
📎 Impromptu Zoom Meeting - Nov 6 2025 (1).mp4 (mp4, **not downloaded** — over cap (230.6 MB), [fetch it](https://files.slack.com/files-pri/T03P5A3L1DK-F09S2A8PLG1/download/impromptu_zoom_meeting_-_nov_6_2025__1_.mp4))
> **Gisselle Jiménez** · 2025-11-10 14:05 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1762783503819499)
> Published!

**Whitney Hodges** · 2025-11-10 17:21 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1762795314579649)
@Jacqueline Hood Hi! I just updated your weekly office hours in the vault, so they are only visible to meta ads immersive members. I'm noticing that there isn't an office hours call on the calendar this Thursday, November 13. I'm not sure if I removed it by accident or it intentionally isn't there. Are you holding office hours this Thursday? Thank you!
> **Jacqueline Hood** · 2025-11-12 23:00 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1762988439116799)
> Yes I am! I'm not sure why it was removed!

**Gisselle Jiménez** · 2025-11-12 14:02 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1762956134751759)
@Whitney Hodges @Yulia Burris Yesterday's workshop has been uploaded to the Audit and Adapt folder! Let me know if you need anything else.

<https://drive.google.com/file/d/1mfnasX60W6Un8jWlWTRU0omvoWRHNP5n/view?usp=drive_link>
> **Whitney Hodges** · 2025-11-12 14:05 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1762956318604959)
> @Gisselle Jiménez Can you please take the lead on adding this to the vault? It should be pretty easy to edit. You'll just need to trim my conversations with Katie off the front and back ends
> **Gisselle Jiménez** · 2025-11-12 14:24 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1762957482427479)
> @Whitney Hodges Sure! Will do
> **Gisselle Jiménez** · 2025-11-12 20:44 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1762980255699189)
> @Whitney Hodges Should this be in its own category in Audit and Adapt or bonus trainings? And this will also need to go in Elevate: Audit & Adapt, right?
> 📎 image.png (png, saved as `files/F09SGMEFZEJ-image.png`)
> **Whitney Hodges** · 2025-11-17 20:21 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1763410907423089)
> @Gisselle Jiménez It should go in the Foundations section. And yes, we'll want to include it in the Elevate: Audit &amp; Adapt section, too.
> **Gisselle Jiménez** · 2025-11-18 20:00 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1763496043163969)
> @Whitney Hodges This has been published!
> 
> I have trimmed <https://drive.google.com/file/d/1Sff1RsIqGYciXgH3OAgMo9pVbE56_N-y/view?usp=drive_link|today's workshop> and added it to the Audit &amp; Adapt folder. I have it drafted under the Foundations section in the VAULT. Let me know if it's good to be published as well!
> **Whitney Hodges** · 2025-11-20 18:46 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1763664419316519)
> @Gisselle Jiménez Can you please move the spam across all channels workshop recording to a new category I just created within the lesson? Note: this does NOT need to be added to Elevate
> **Whitney Hodges** · 2025-11-20 18:48 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1763664508227229)
> @Gisselle Jiménez Nvm; I was able to just drag and drop it :joy:

**Gisselle Jiménez** · 2025-11-13 20:17 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1763065057192949)
@Whitney Hodges Meta Ads Immersive Experience feedback survey for your review!

<https://app.leadlockpro.com/v2/preview/9wibhOgmU95u2Ap9psX2>

**Gisselle Jiménez** · 2025-11-17 15:35 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1763393742499609)
Hi, @Jacqueline Hood! Katie Logan posted a comment in #Community Discussion:

> *Can Carousels be Effective as Client Attraction Ads?*
> I know the focus is on reels, and that those typically get more traffic organically. Could carousels be effective too for client Attraction? I had a carousel do well organically lately and the message is great (I think!) for client Attraction. I'm wondering if I should run the carousel as an ad or if I should turn the message into a reel. Here is the carousel I'm talking about: <https://www.instagram.com/p/DRBOCzUjWIA/?utm_source=ig_web_copy_link&igsh=MzRlODBiNWFlZA==>
> 
> Thank you!!
cc: @Whitney Hodges

**Jacqueline Hood** · 2025-11-17 16:17 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1763396241754289)
@Gisselle Jiménez replied, thank you!

**Gisselle Jiménez** · 2025-11-17 16:51 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1763398273420039)
:inbox_tray: New Client Attraction Campaign Form Submission from Katie Logan!

**Jacqueline Hood** · 2025-11-17 16:52 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1763398347641889)
thank you!

**Jacqueline Hood** · 2025-11-18 15:24 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1763479447617019)
Katie's client attraction ads are live :smile:
> **Whitney Hodges** · 2025-11-18 15:28 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1763479724234489)
> Amazing! Can you post in the Vault and tag her to build some excitement/engagement? @Jacqueline Hood
> **Jacqueline Hood** · 2025-11-18 15:30 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1763479818097659)
> Yup!
> **Whitney Hodges** · 2025-11-18 17:40 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1763487647490209)
> @Jacqueline Hood Thank you! Katie just came to my training about preventing spam leads.
> 
> One of the suggestions inside the training was to make sure that the audience network placement is off for all ads running to cold traffic.
> 
> She took a look at the carousel ad and noticed Advantage+ placements are on and is wondering if it needs to be adjusted. I told her I would check with you in case it was intentional, and that we would fix it if not.
> 
> Thank you!!

**Jacqueline Hood** · 2025-11-21 03:14 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1763694847460159)
Meta Ads Office Hours - Nov 20/25
📎 Impromptu Zoom Meeting - Nov 20 2025.mp4 (mp4, **not downloaded** — over cap (168 MB), [fetch it](https://files.slack.com/files-pri/T03P5A3L1DK-F09US5GDXJM/download/impromptu_zoom_meeting_-_nov_20_2025.mp4))
> **Gisselle Jiménez** · 2025-11-21 15:36 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1763739393724149)
> Published!

**Gisselle Jiménez** · 2025-11-25 18:29 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1764095382202609)
@Jacqueline Hood

<https://email.reply.weddingindustryads.com/c/eJyElM-SojoUh58m7KYLEhJgwUKby7TjpbXbEbU3VkiOkhYIHYKKT39LnOXM3N051FeHL39-EXsl4-ENJ7Alweewu7FmfhE0enZkLAt8CLAjdc1VExtoq-HpAlKq5qga2XfWDFx2T0LXv5i9vjRgulK1ezu0EFdacKv047t0IPYC5rthRHzfgZqral9D1_Ej3CWSiopTNz954RfbmgmfVpn4RY3DtC3BONCcldFNDY2NW6NlL-4_cMq4IMyjoXc4eC4JZFG4hHPB3EByFtKCh46KsYup52HqMT9yyRNlpAg9FvlSCEJ8H_nuX9dYxaW1bYfIBOEU4bSGugDT_QG_MyQd_RFJSqgqjXz3Tyyr9FE1z1oCIgnCvke3CHtrfEKYGZDKgLBrM04aHTC9W9C7B_1_E4pToeu6b5RV0I390ei-fZS2hG9n3ld27Epdw1i0urMPgIWsOERhwSNGA5_yggINwGN3i3EwNHYm713CIkylPBQCAkKCgy-AEkEC7lRi_zhL1VgwDa_iNU47-T0_bb0Q4entzcu3N5Xv6rlM_l23CE8v4fvQ59-zt_y5z1R6zaPFDl6zCuF0uBU0XGG2RThdvrJgdVyIa-nnq1BY6S0222U9W2x_IJy-I5xmecK4mfiyzVxhEZ66aaZmZt26avFRZ-1tXk0u5vML4XR2_dxcZ5N8sVivbfTe8Q2fljoYXo6nPNl1eJKEF4TTYMWfdz_zeTH5elGL4bAk7YKtiybrTivvAB8_b0NvXpqPXZBMqXh9jf6ZbHa3VHs_suWJsI2LSOJUegzfVvnu7Vq_nzfhshhONNm9tE4NttQy5q1yWqPPSoKJK-BS6KYBYbVxTPz3O-V0ujcC4nHXv6nu_O2izQmMY2Ow-0eY7D2h-98K2Fjoev_bh-Ec4_8CAAD__wn-ayQ|New comment >from Katie in the VAULT! :star2:

&gt; Here are my direct response ads, ready for feedback!! Thank you!!
&gt; <https://docs.google.com/document/d/1Viuc6Cdtgx-wEPRYhYCFBnvMWecmN5bb/edit?usp=sharing&amp;ouid=103575049963786056829&amp;rtpof=true&amp;sd=true>

**Notification Bot** · 2025-11-30 07:57 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1764489458396059)
Diana Leimbach has joined on for the Meta Ads Immersive Experience!:partying_face:

**Gisselle Jiménez** · 2025-12-01 18:00 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1764612041539829)
:inbox_tray: New Direct Response Campaign Form Submission from Katie Logan!

**Jacqueline Hood** · 2025-12-02 04:02 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1764648138325659)
@Whitney Hodges I have Katie's conversion ads ready to turn on but I don't have proper permissions to add the Lead event to her TY page: <https://www.loganplanningsolutions.com/thankyou>
> **Whitney Hodges** · 2025-12-02 15:26 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1764689179445759)
> @Jacqueline Hood Hi! You have full control of the ad account, but for Katie's FB page, you and I only have partial control. Is that what the issue is?
> 
> @Christina Hill Are you able to add a Meta Lead event to Katie's TY page via GTM?
> 📎 image.png (png, saved as `files/F0A1F152D33-image.png`)
> **Jacqueline Hood** · 2025-12-02 16:58 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1764694691057139)
> I just don't have access to the dataset to be able to add it through the events manager
> **Whitney Hodges** · 2025-12-02 17:06 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1764695218652319)
> @Jacqueline Hood We don't have a dataset for her in our business manager at all. When I did the tech connections with her, I granted us partner access to everything available. There's a chance I missed it, but I don't remember seeing a dataset inside her business manager.
> 
> If she shows up to my workshop today, I'll see if I can get her to share her screen and give us access.
> 
> But I believe if we install through GTM, it shouldn't matter if we don't have access to her Events Manager.
> 
> @Christina Hill What would you need on your end in order to install a lead event on Katie's TY page? We should have admin access to her GTM and I remember connecting it to her website on our kickoff call.
> 
> Jacqueline, let's see if we can accomplish this through GTM and if not, have Katie come to office hours. Does that sound ok?
> **Whitney Hodges** · 2025-12-02 18:01 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1764698510428239)
> @Jacqueline Hood Hi! I just ended my workshop, and Katie was there. We reviewed her client attraction campaign results. I had her try to give us access to the dataset, and for some reason, she doesn't have permission to do so. Instead, I walked her through adding the lead event live on the call. Everything looks good from what I can see on my end. Can you please doublecheck?
> 
> @Christina Hill I don't think we need any GTM assistance at this time. Thank you!!
> **Jacqueline Hood** · 2025-12-02 21:06 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1764709582594889)
> oh perfect! thanks @Whitney Hodges :slightly_smiling_face: I'll get her ads turned on and post in the Vault!

**Gisselle Jiménez** · 2025-12-02 19:49 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1764704963476349)
@Whitney Hodges @Yulia Burris

Today's <https://drive.google.com/file/d/1s3HlOHkaB4sWSI9L9ToO-qbzo7trEKle/view?usp=drive_link|workshop> has been uploaded to the Resources folder. :white_check_mark:
> **Yulia Burris** · 2025-12-03 14:31 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1764772306112429)
> @Whitney Hodges @Gisselle Jiménez Good morning! Should I edit this video?
> **Whitney Hodges** · 2025-12-03 14:34 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1764772441155949)
> @Yulia Burris I don't think this needs to be turned into a training video. @Gisselle Jiménez When a workshop doesn't have a set topic and we're just reviewing ad results for members, we can add the video to the office hours recording. Thank you!!

**Jacqueline Hood** · 2025-12-05 18:58 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1764961132270289)
Call recording with Fernanda today:
📎 Impromptu Zoom Meeting - Dec 5 2025.mp4 (mp4, **not downloaded** — over cap (77 MB), [fetch it](https://files.slack.com/files-pri/T03P5A3L1DK-F0A1ED9R8MD/download/impromptu_zoom_meeting_-_dec_5_2025.mp4))
> **Gisselle Jiménez** · 2025-12-05 19:48 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1764964132341749)
> Published!

**Jacqueline Hood** · 2025-12-06 04:28 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1764995331476769)
thank you! @Whitney Hodges Fernanda is going to update the photo in the hero section of her landing page to look like a more traditional wedding and she's also going to look into adding a pop-up to the site with the form (similar to Adriana's). Just some context if she comes to your office hours this week!

I spoke with Katie and she didn't need a 1:1 just yet, but she'll try to come to office hours this week to review her campaigns.

**Gisselle Jiménez** · 2025-12-11 20:39 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1765485563247719)
<!channel> Meta Ads Immersive Feedback Survey from Shelby!:star2:
📎 Meta Ads Immersive Experience Feedback Survey _ SK Design & Events.pdf (pdf, saved as `files/F0A3FSC4T09-Meta_Ads_Immersive_Experience_Feedback_Survey___SK_Design_Events.pdf`)

**Gisselle Jiménez** · 2025-12-18 15:40 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1766072417889509)
has renamed the channel from "metaadsimmersive" to "metaadsaccelerator"

**Gisselle Jiménez** · 2025-12-18 17:34 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1766079268255569)
:memo: Diana Leimbach completed their onboarding questionnaire!

**Gisselle Jiménez** · 2025-12-18 17:34 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1766079268629719)
Diana Leimbach scheduled a Meta Ads Accelerator Kickoff Call with Whitney :checkered_flag:

Appointment Date &amp; Time: Tuesday, December 23, 2025 7:45 AM PST

**Jacqueline Hood** · 2025-12-18 22:30 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1766097016806189)
@Gisselle Jiménez office hours recording - Dec 18, 2025
📎 video1242634249.mp4 (mp4, **not downloaded** — over cap (52.2 MB), [fetch it](https://files.slack.com/files-pri/T03P5A3L1DK-F0A4EF7GAAZ/download/video1242634249.mp4))
> **Gisselle Jiménez** · 2025-12-22 15:16 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1766416588702379)
> Published!

**Whitney Hodges** · 2025-12-23 16:46 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1766508405247149)
@Carmen Cruickshank @Christina Hill Hi! I just created a pixel for LUXE Whitening Lounge. Can you please install it on their website via GTM? Meta Pixel ID: <https://business.facebook.com/latest/settings/events_dataset_and_pixel?business_id=543099017224748&amp;selected_asset_id=2361757284255433&amp;selected_asset_type=events-dataset-new#|1508906153521316>
> **Christina Hill** · 2025-12-23 20:09 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1766520560206639)
> Hi @Whitney Hodges! The Meta Pixel is installed on all pages. Please let me know if you would like additional events set up. :slightly_smiling_face:
> **Whitney Hodges** · 2025-12-23 20:09 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1766520595789469)
> @Christina Hill Thank you!

**Gisselle Jiménez** · 2025-12-23 19:07 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1766516828488739)
:inbox_tray: New Retargeting Campaign Form Submission from Katie Logan!
> **Whitney Hodges** · 2025-12-24 14:11 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1766585467190469)
> @Jacqueline Hood let us know what support you need to get these published. Thank you!!
> **Jacqueline Hood** · 2025-12-24 14:12 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1766585574367629)
> @Whitney Hodges thank you! Is someone able to hop in and get those launched for Katie?
> I could also co-work with someone on Monday and we could do it together through their access :slightly_smiling_face:
> **Whitney Hodges** · 2025-12-24 14:14 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1766585676005139)
> @Jacqueline Hood I'll handle it the day after Christmas!

**Gisselle Jiménez** · 2025-12-23 19:15 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1766517347838819)
Hi, @Jacqueline Hood! Kindly find below recordings of _Diana's Meta Ads Kickoff Call with Whitney (LUXE Whitening Lounge)_ &amp; _Whitney's workshop_ from today, where she discussed landing page optimization and conversion campaign performance with Katie Logan.

• <https://drive.google.com/file/d/1imuirTPd0nQ2oGDl5H82qx7xWjBwWaSS/view?usp=drive_link|Diana's Meta Ads Kickoff Call>
• <https://drive.google.com/file/d/1hyuoQJ6chBUm_WSG86Qc2ZqYLMQ6Xdyg/view?usp=drive_link|Whitney's Weekly Workshop>
cc: @Whitney Hodges

**Jacqueline Hood** · 2025-12-23 22:10 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1766527840964629)
@Gisselle Jiménez office hours recording today :slightly_smiling_face:
📎 video1466989976.mp4 (mp4, **not downloaded** — over cap (99.4 MB), [fetch it](https://files.slack.com/files-pri/T03P5A3L1DK-F0A59B689B8/download/video1466989976.mp4))
> **Gisselle Jiménez** · 2025-12-29 13:44 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1767015845235319)
> Published!

**Jacqueline Hood** · 2025-12-24 14:17 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1766585870105189)
@Whitney Hodges Shelby also has some new ads she'd like launched; one new client attraction ad and some holiday focused ads for her conversion campaign.

I just reminded her in the Vault to submit them via the form so we can keep track of them. We decided yesterday to launch the new conversion creatives next week on Jan 30th so no rush for those!

*Fingers crossed I have access back by next week!

**Jacqueline Hood** · 2025-12-31 03:13 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1767150829923749)
@Whitney Hodges Shelby's new ads have been launched :slightly_smiling_face:

**Jacqueline Hood** · 2025-12-31 03:14 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1767150845182169)
@Gisselle Jiménez no one showed up for office hours today so no call recording to upload

**Jacqueline Hood** · 2026-01-08 23:54 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1767916452371659)
Meta Ads Office Hours - Jan 8/26
📎 Impromptu Zoom Meeting - Jan 8 2026.mp4 (mp4, **not downloaded** — over cap (193.6 MB), [fetch it](https://files.slack.com/files-pri/T03P5A3L1DK-F0A7NRHKPU2/download/impromptu_zoom_meeting_-_jan_8_2026.mp4))
> **Gisselle Jiménez** · 2026-01-09 13:38 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1767965913438999)
> Posted!

**Jacqueline Hood** · 2026-01-15 22:47 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1768517276216699)
Meta Ads Office Hours - Jan 15/26
📎 Impromptu Zoom Meeting - Jan 15 2026.mp4 (mp4, **not downloaded** — over cap (226.7 MB), [fetch it](https://files.slack.com/files-pri/T03P5A3L1DK-F0A91PL1W1Y/download/impromptu_zoom_meeting_-_jan_15_2026.mp4))

**Notification Bot** · 2026-01-21 14:53 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1769007189777239)
Michelle Chriqui Hidalgo has joined on for the Meta Ads Immersive Experience!:partying_face:

**Whitney Hodges** · 2026-01-22 21:38 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1769117891883259)
<!channel> I just posted a welcome announcement for Michelle in the VAULT. Please help me welcome her in the comments

**Whitney Hodges** · 2026-01-23 16:11 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1769184692539909)
@Jacqueline Hood Good morning! Was everything ok with office hours yesterday? I just saw Katie's comment in the vault

**Jacqueline Hood** · 2026-01-23 18:16 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1769192199336979)
I'll go check the comments now - but nobody showed up for office hours yesterday. I stayed on until around 2:25pm
> **Whitney Hodges** · 2026-01-23 18:31 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1769193118402509)
> @Jacqueline Hood Katie was trying to get into the zoom room but couldn't because there was a passcode. Can you please reach out to her?
> 
> As a best practice moving forward, can you please be logged into the vault while office hours is happening?
> 
> Also, the way I usually describe office hours is that people can join anytime within the one hour window, so if you could stay on zoom the full duration just in case, I would appreciate it so much
> **Jacqueline Hood** · 2026-01-23 18:52 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1769194369214309)
> Yes I will. I messaged her back; I have no idea why it suddenly required a passcode. 
> **Jacqueline Hood** · 2026-01-23 18:56 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1769194599030079)
> I replied and sent her a DM inviting her to schedule some 1:1 time with me if she needs anything.
> 
> I'm so sorry for the mix-up

**Gisselle Jiménez** · 2026-01-24 23:05 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1769295909604889)
Michelle Chriqui Hidalgo scheduled a Meta Ads Accelerator Kickoff Call with Whitney :checkered_flag:

Appointment Date &amp; Time: Tuesday, January 27, 2026 12:30 PM EST

**Gisselle Jiménez** · 2026-01-24 23:05 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1769295910551279)
:memo: Michelle Chriqui Hidalgo completed their onboarding questionnaire!

**Gisselle Jiménez** · 2026-01-28 21:03 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1769634214033299)
:inbox_tray: New Retargeting Campaign Form Submission from Katie Logan!
> **Whitney Hodges** · 2026-01-28 21:14 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1769634845339949)
> @Jacqueline Hood

**Gisselle Jiménez** · 2026-01-28 21:10 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1769634639072479)
:inbox_tray: New Client Attraction Campaign Form Submission from Katie Logan!
> **Whitney Hodges** · 2026-01-28 21:14 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1769634856865849)
> @Jacqueline Hood

**Jacqueline Hood** · 2026-01-29 03:55 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1769658929318399)
thanks! I'll work on these in the morning!

**Jacqueline Hood** · 2026-01-29 22:31 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1769725868829949)
All ads for Katie are launched and live :slightly_smiling_face:

**Jacqueline Hood** · 2026-01-29 22:31 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1769725882414019)
No attendees for the Meta ads office hours today so no recording @Gisselle Jiménez :slightly_smiling_face:

**Whitney Hodges** · 2026-01-30 01:21 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1769736115145939)
@Gisselle Jiménez can you please drop the recording from my kickoff call with Michelle here so @Jacqueline Hood can catch up on it

**Gisselle Jiménez** · 2026-01-30 18:36 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1769798191091929)
Apologies for the delay here! @Jacqueline Hood Here is the recording:

<https://drive.google.com/file/d/1cWvzj9lnMjnGI1pDYd2v2u27iyyCK64E/view?usp=sharing>

**Whitney Hodges** · 2026-02-04 14:01 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1770213693738909)
@Gisselle Jiménez Good morning! Let's extend Michelle's time in MAA by a month please since she didn't initially have access to all of the curriculum.
📎 image.png (png, saved as `files/F0ACY8EA3RQ-image.png`)

**Gisselle Jiménez** · 2026-02-04 16:08 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1770221288979819)
@Whitney Hodges Oki, noted!

**Jacqueline Hood** · 2026-02-06 00:13 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1770336825415799)
Meta Ads Office Hours - Feb 5/26

*<https://fathom.video/share/R-mLPrK8x2iaNtickaPJN1uz7HftpA8D|VIEW RECORDING - 60 mins (No highlights)>*
<https://fathom.video/share/R-mLPrK8x2iaNtickaPJN1uz7HftpA8D?tab=summary&amp;timestamp=0|Landing page review and feedback @ 0:00>
Jacqueline and Michelle reviewed Michelle's new landing page design. Jacqueline provided positive feedback, noting that the page looks great and she wouldn't change anything. They discussed the mobile-optimized layout and the overall style and approach, which focuses on capturing candid, documentary-style wedding photos rather than posed shots.
<https://fathom.video/share/R-mLPrK8x2iaNtickaPJN1uz7HftpA8D?tab=summary&amp;timestamp=219|Form functionality and customization @ 3:39>
Michelle raised an issue with the form functionality on the landing page, where the form title was duplicating when she tried to customize it. Jacqueline and Michelle troubleshooted the issue, determining that Michelle would need to manually edit the form title after duplicating it to avoid the duplication.
<https://fathom.video/share/R-mLPrK8x2iaNtickaPJN1uz7HftpA8D?tab=summary&amp;timestamp=988|Privacy policy and compliance @ 16:28>
Jacqueline noted that the landing page should include a link to a privacy policy at the bottom, as this is required for running ads. They discussed how Michelle could add a simple privacy policy link to the existing website footer and link it from the landing page.
<https://fathom.video/share/R-mLPrK8x2iaNtickaPJN1uz7HftpA8D?tab=summary&amp;timestamp=1162|Next steps and wrap-up @ 19:22>
Jacqueline said she would do a deeper review of the landing page copy and provide any additional feedback. They agreed the page looks great overall and Jacqueline commended Michelle on the work she had done.
> **Gisselle Jiménez** · 2026-02-06 20:30 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1770409843291669)
> Hi, @Jacqueline Hood! Are you able to share the recording? I can't download it from fathom. Thanks!!
> **Jacqueline Hood** · 2026-02-06 20:31 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1770409873101949)
> yup!
> **Jacqueline Hood** · 2026-02-06 20:35 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1770410136497829)
> Here you go @Gisselle Jiménez :slightly_smiling_face:
> 📎 Impromptu Zoom Meeting - Feb 5 2026.mp4 (mp4, **not downloaded** — over cap (211.3 MB), [fetch it](https://files.slack.com/files-pri/T03P5A3L1DK-F0ADXQ86T7B/download/impromptu_zoom_meeting_-_feb_5_2026.mp4))
> **Gisselle Jiménez** · 2026-02-06 20:41 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1770410464085159)
> Thank youu!
> **Gisselle Jiménez** · 2026-02-06 21:07 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1770412025899239)
> Published!

**Whitney Hodges** · 2026-02-06 17:49 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1770400157173009)
@Jacqueline Hood I got this DM in the VAULT from Michelle. Has she been DMing you?

We've realized that unfortunately we do not receive email alerts for DMs, only if we're tagged.
📎 image.png (png, saved as `files/F0ADE983LLD-image.png`)

**Jacqueline Hood** · 2026-02-06 18:35 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1770402911891999)
Yes, she had just asked if she could come to office hours to discuss her landing page! Which we did :slightly_smiling_face:

But no, I don't receive alerts for DM's

**Gisselle Jiménez** · 2026-02-06 19:03 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1770404605303679)
Hi, @Jacqueline Hood! I believe that was a comment. Are you able to check your DMs here? :
📎 image.png (png, saved as `files/F0ADBST2D27-image.png`)

**Jacqueline Hood** · 2026-02-06 20:18 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1770409117844409)
Yes, I saw the comment and the DM :slightly_smiling_face: We chatted about in during office hours; I will review her landing page this weekend and send her my feedback!

**Gisselle Jiménez** · 2026-02-07 01:17 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1770427071950099)
:inbox_tray: New Client Attraction Campaign Form Submission from Katie Logan!

Reminder: Check tracking first!

**Gisselle Jiménez** · 2026-02-08 20:28 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1770582530926109)
:inbox_tray: New Retargeting Campaign Form Submission from Katie Logan!

**Gisselle Jiménez** · 2026-02-09 19:40 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1770666013978829)
Hi, @Jacqueline Hood! Just making sure you saw Katie's new campaign submissions!:raised_hands:

**Jacqueline Hood** · 2026-02-09 19:54 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1770666879261489)
Yes! I have launched her new ads as well :slightly_smiling_face:

**Whitney Hodges** · 2026-02-09 20:00 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1770667212379489)
@Jacqueline Hood @Carmen Cruickshank Hi! Michelle's website has the Meta pixel installed, but she needs a Lead pixel on her confirmation page. <https://www.wandermorephotography.com/confirmation>

Carmen, are you able to add this via GTM? Or is it just easiest for you to add this through the Events Manager, Jacqueline?
📎 image.png (png, saved as `files/F0ADHB0Q2J3-image.png`)

**Jacqueline Hood** · 2026-02-09 21:45 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1770673555900099)
I should be able to add it using the event manager @Whitney Hodges

**Carmen Cruickshank** · 2026-02-09 22:02 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1770674520002189)
im able to add on GTM @Whitney Hodges

**Carmen Cruickshank** · 2026-02-09 22:02 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1770674525447909)
whatever works best

**Whitney Hodges** · 2026-02-09 22:18 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1770675538366859)
@Carmen Cruickshank go head and do it through gtm and just let me and @Jacqueline Hood know if you run into any issues

**Carmen Cruickshank** · 2026-02-09 22:25 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1770675949770939)
okay sounds good

**Carmen Cruickshank** · 2026-02-10 16:26 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1770740792965309)
@Whitney Hodges @Jacqueline Hood ok i added it in, let me know if it works, i don't see it on my end yet when testing it with the meta pixel helper but ill check again soon
> **Whitney Hodges** · 2026-02-10 17:54 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1770746042024439)
> I'm also only seeing the Meta Pixel page view. @Jacqueline Hood Do you want to try installing from events manager?
> **Jacqueline Hood** · 2026-02-10 23:23 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1770765794651249)
> Yup!
> **Jacqueline Hood** · 2026-02-10 23:26 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1770766013408349)
> @Whitney Hodges Done!

**Jacqueline Hood** · 2026-02-12 22:39 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1770935960073319)
Meta Ad Office Hours - Feb 11/26
📎 Impromptu Zoom Meeting - Feb 12 2026.mp4 (mp4, **not downloaded** — over cap (413.1 MB), [fetch it](https://files.slack.com/files-pri/T03P5A3L1DK-F0AEK5L5NFM/download/impromptu_zoom_meeting_-_feb_12_2026.mp4))

**Gisselle Jiménez** · 2026-02-13 15:12 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1770995521364359)
Thank you, @Jacqueline Hood! We want to now post a very brief call recap in The VAULT. Are you able to share a brief recap of the call or share your fathom summary notes, please? As an example, this is what we shared for the Google ads office hours:

&gt; Carmen worked with <https://members.weddingindustryads.com/communities/users/jillian-dalu-ford?groupId=672cf7741753dbd4f482d49f|@Jillian Dalu-Ford> on prepping for her upcoming VIP Day, helped <https://members.weddingindustryads.com/communities/users/erin-smith-NYC?groupId=672cf7741753dbd4f482d49f|@Erin Smith> explore A/B testing a shorter form to improve conversion rates, and guided <https://members.weddingindustryads.com/communities/users/diana-leimbach-5aO6HM?groupId=672cf7741753dbd4f482d49f|@Diana Leimbach> on switching from Maximize Clicks to Conversions while ensuring proper maintenance on her ads.
Thank you!

**Jacqueline Hood** · 2026-02-14 03:56 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1771041388655209)
Yes absolutely!
Here's the summary @Gisselle Jiménez

Jacqueline met with Diana to learn more about their luxury teeth whitening business and what sets their spa-like experience apart in their local market. They reviewed existing Instagram content and identified strong opportunities to leverage their current videos for client attraction ads, rather than creating everything from scratch. Jacqueline provided high-level guidance on building a cohesive ad strategy, including clarifying messaging around the luxury experience, addressing common objections, incorporating social proof, and using clear calls to action. She also walked through the structure of an ads funnel—explaining how to nurture cold, warm, and retargeting audiences strategically to move prospects toward booking.

**Gisselle Jiménez** · 2026-02-16 18:54 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1771268082985489)
:inbox_tray: New Client Attraction Campaign Form Submission from Katie Logan!

Reminder: Check tracking first!

**Jacqueline Hood** · 2026-02-16 22:17 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1771280222685629)
I'm out of office so I sent her a message that I received the submission and will get them up asap when I'm back! :slightly_smiling_face:

**Gisselle Jiménez** · 2026-02-17 19:42 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1771357343533199)
Hi, team! Just a reminder that Michelle submitted her client attraction ad for feedback!
<https://members.weddingindustryads.com/communities/groups/the-vault/home/posts/68544a6d18c7f7db7a3f6e87?commentId=6993a46d47fd40aed2261d0d>

Here is the link to the post:
<https://members.weddingindustryads.com/communities/groups/the-vault/home/posts/68544a6d18c7f7db7a3f6e87?commentId=6993a46d47fd40aed2261d0d>

**Jacqueline Hood** · 2026-02-17 20:30 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1771360202038459)
Left her comments on her doc. Thanks!

**Gisselle Jiménez** · 2026-02-19 15:56 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1771516605523029)
Katie Logan completed the Meta Ads Accelerator Feedback Survey!:star2: 


> **Gisselle Jiménez** · 2026-02-19 18:45 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1771526725125559)
> Katie Logan's submission!
> 📎 f193ef94-e879-4912-8c42-0436a2168961.pdf (pdf, saved as `files/F0AGD9DGF17-f193ef94-e879-4912-8c42-0436a2168961.pdf`)

**Jacqueline Hood** · 2026-02-20 02:54 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1771556040742839)
@Gisselle Jiménez no one showed up for Meta ads office hours today so no recording

**Gisselle Jiménez** · 2026-02-25 19:39 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1772048362341579)
:inbox_tray: New Client Attraction Campaign Form Submission from Michelle Chriqui Hidalgo!

Reminder: Check tracking first!
> **Gisselle Jiménez** · 2026-02-26 17:07 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1772125650203649)
> Hi, @Jacqueline Hood! Just making sure you saw this. Thansk!
> **Jacqueline Hood** · 2026-02-26 17:26 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1772126783872649)
> Yes I did, thank you for the reminder! :slightly_smiling_face:

**Gisselle Jiménez** · 2026-02-26 17:48 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1772128114775539)
:inbox_tray: New Direct Response Campaign Form Submission from Michelle Chriqui Hidalgo!

**Gisselle Jiménez** · 2026-02-26 17:53 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1772128412522449)
:inbox_tray: New Retargeting Campaign Form Submission from Michelle Chriqui Hidalgo!

**Jacqueline Hood** · 2026-02-26 20:29 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1772137753035489)
Working on them all now!

**Jacqueline Hood** · 2026-02-26 20:31 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1772137884806139)
@Whitney Hodges @Gisselle Jiménez something that has come up with regards to Michelle's retargeting ads. Some of her carousels have more than 10 images, which is too many for ads, so we are unable to use them.
We are also unable to use any existing content that is done in partnership with another business - unless we request specific permissions from that owner.

It might be worth adding a section to the vault for selecting pre-existing content that it shouldn't have anyone else tagged as a partner in the post, and a carousel can have a max of 10 slides.

I messaged Michelle with some options to still use this content (either edit the existing posts or she can send me the copy and creatives and we launch as ads instead of boosting her existing content). But moving forward it might be helpful for everyone to know this ahead of time when selecting their content!

**Gisselle Jiménez** · 2026-02-27 04:39 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1772167193802229)
:memo: Teresa Moody completed their onboarding questionnaire!

**Gisselle Jiménez** · 2026-02-27 04:39 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1772167194135449)
Teresa Moody scheduled a Meta Ads Accelerator Kickoff Call with Jacqueline :checkered_flag:

Appointment Date &amp; Time: Thursday, March 5, 2026 4:30 PM CST

**Jacqueline Hood** · 2026-02-27 16:48 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1772210912717809)
No one showed up for Office Hours yesterday so no recording @Gisselle Jiménez
> **Gisselle Jiménez** · 2026-02-27 17:18 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1772212713437509)
> Got it!

**Jacqueline Hood** · 2026-03-05 04:03 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1772683396158549)
Hey @Whitney Hodges - for my onboarding call tomorrow, is there a brief presentation that we typically go through with them before we do the tech connections? If so, can you please share where I can find it :slightly_smiling_face: @Gisselle Jiménez or if you could point me in the right direction, that'd be great! This is my first Meta Ads Accelerator onboarding call so I want to be prepared :slightly_smiling_face: thanks!
> **Whitney Hodges** · 2026-03-05 15:14 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1772723660426609)
> @Jacqueline Hood Here's how I've been structuring the kickoff calls:
> • Getting a feel for how much time they've spent in the VAULT so far and what curriculum they've consumed
> • Showing them around the VAULT to make sure everything is clear to them as far as the curriculum and support provided.
> • Encouraging them to create an ads traffic landing page if they don't already have one / giving feedback on existing website and what can be repurposed into the landing page
> • Gaining access to their Meta Business Manager and Ad Account. Assessing if they already have the pixel installed or if we're starting from scratch
> • If they have ads inside their ad account, doing a mini audit on the spot
> • At that point, if there's still time remaining, looking at some of their existing IG content with them to see if we can identify some reels/posts to be repurposed into ads.
> @Gisselle Jiménez should be able to drop some of my recordings here for you to check out if it's helpful.
> 
> Also, Gisselle, should we create a doc with an outline of what I've listed above and/or a ClickUp task?
> 
> Thank you both!!
> **Jacqueline Hood** · 2026-03-05 15:44 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1772725489301119)
> perfect!  thank you so much!
> **Gisselle Jiménez** · 2026-03-05 16:30 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1772728248211789)
> @Whitney Hodges Since we don't do ClickUp folders for accelerator clients, we can do a kickoff call worksheet that I duplicate for each new client, as we have for the LeadLock kickoff call. Let me know if this works!
> 
> <https://docs.google.com/document/d/1SI88MSzrXUeBLGFfj0kPO2GfyTD9YQsZ1gtzScVOlWk/edit?tab=t.0>
> 
> cc: @Jacqueline Hood
> **Whitney Hodges** · 2026-03-05 16:31 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1772728314872099)
> @Gisselle Jiménez Thanks! I'm not sure it needs to be duplicated. I think just having one copy that can be referenced is fine
> **Gisselle Jiménez** · 2026-03-05 16:50 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1772729418991189)
> @Whitney Hodges Sounds good! It has been saved in the MAA drive folder.
> **Jacqueline Hood** · 2026-03-05 17:12 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1772730752945549)
> this is perfect, thank you!

**Gisselle Jiménez** · 2026-03-05 20:53 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1772743985697389)
:checkered_flag:Teresa Moody booked their Meta Ads Accelerator Kickoff Call!

Booked with: Whitney Hodges
Appointment Date &amp; Time: Thursday, March 12, 2026 4:30 PM 
 CST

**Jacqueline Hood** · 2026-03-05 20:54 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1772744072976249)
@Whitney Hodges Teresa emailed to say she wasn't feeling well so we rescheduled her call to next week at the same time

**Jacqueline Hood** · 2026-03-05 22:39 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1772750341478269)
Meta Ads Recording and Summary @Gisselle Jiménez

Michelle and Jacqueline reviewed the performance of Michelle's Meta ads campaign, which launched about a week ago. They discussed key metrics like cost per click, click-through rate, landing page views, and lead generation. Overall, the campaign is performing well with a 3% click-through rate and two leads generated so far, though the landing page conversion rate could be improved. Jacqueline explained how to interpret the Meta ads reporting, noting that the platform's data may not always be fully accurate or up-to-date. They discussed potential ways to optimize the ads and landing page, such as testing different ad creative, headlines, and calls-to-action.
📎 Impromptu Zoom Meeting - Mar 5 2026.mp4 (mp4, **not downloaded** — over cap (178.2 MB), [fetch it](https://files.slack.com/files-pri/T03P5A3L1DK-F0AJE8U45TR/download/impromptu_zoom_meeting_-_mar_5_2026.mp4))
> **Gisselle Jiménez** · 2026-03-06 15:17 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1772810278352739)
> Thank you!! Published:white_check_mark:

**Jacqueline Hood** · 2026-03-06 18:53 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1772823231156589)
Hey @Carmen Cruickshank :slightly_smiling_face: I got this message from Michelle:

Hi! I was running a speed check on the landing page and it seems im getting a Uses deprecated APIs warning. This is the info: Deprecation / Warning
Source
Google Tag Manager
tag-manager
AttributionReporting
<https://www.googletagmanager.com/gtag/js?id=G-JTJWR6RJMR|/gtag/js?id=G-JTJWR6RJMR:738:235>
(<http://www.googletagmanager.com|www.googletagmanager.com>) Is there a way you can check on this? I dont want to delete anything that you may be using for the campaigns. Thank you!

**Jacqueline Hood** · 2026-03-06 18:53 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1772823239024229)
Any ideas? This is all Greek to me. lol

**Carmen Cruickshank** · 2026-03-09 17:19 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1773076748948819)
@Jacqueline Hood Hi! Yes ill check it out

**Jacqueline Hood** · 2026-03-12 17:30 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1773336630480719)
Hey @Carmen Cruickshank any updates on this? Just in case she comes to Office Hours today I'd like to give her an update if possible. thanks!
> **Carmen Cruickshank** · 2026-03-12 18:17 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1773339455426219)
> hi @Jacqueline Hood looking into this again now
> **Carmen Cruickshank** · 2026-03-12 18:17 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1773339461316949)
> ill update you in 15-30 min

**Carmen Cruickshank** · 2026-03-12 18:45 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1773341108555039)
@Jacqueline Hood Hi! I checked the page in Google Tag Assistant and everything is firing correctly. The GA4 tag and Google Ads tag are both loading and sending events like page views and conversions. The deprecated API warning appears to be coming from Google’s own script (gtag.js) that loads through Google Tag Manager. Sometimes tools like PageSpeed or browser dev tools flag these scripts because Google is updating how certain browser APIs work, but it doesn’t affect how the tags function. It’s essentially just a notice from the browser about Google’s internal script and not something we should remove, since it powers analytics and campaign tracking. Everything looks good on the tracking side and nothing needs to be done.

**Carmen Cruickshank** · 2026-03-12 18:45 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1773341120118439)
let me know if that makes sense, or any questions you have

**Whitney Hodges** · 2026-03-12 20:42 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1773348155420639)
@Jacqueline Hood Hi! Not sure if you saw the email too, but Teresa reached out and said she's still sick, so she needs to reschedule the kickoff call

**Jacqueline Hood** · 2026-03-12 20:57 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1773349024967849)
Yes I did see that, thank you!

**Jacqueline Hood** · 2026-03-12 21:36 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1773351394648229)
@Gisselle Jiménez no attendees for office hours today :slightly_smiling_face:
> **Gisselle Jiménez** · 2026-03-13 13:21 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1773408069868859)
> noted!

**Jacqueline Hood** · 2026-03-20 02:37 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1773974273060429)
@Gisselle Jiménez no attendees again today for office hours :disappointed:
> **Gisselle Jiménez** · 2026-03-20 13:37 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1774013833811139)
> Got it:')

**Gisselle Jiménez** · 2026-03-24 15:32 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1774366350625669)
Hi, @Jacqueline Hood! I'm going to share some DMs between Michelle and Whitney so you're in the loop!
📎 image.png (png, saved as `files/F0ANNE4FCDS-image.png`)
📎 image.png (png, saved as `files/F0APD4ZLX32-image.png`)
📎 image.png (png, saved as `files/F0ANCF0S31R-image.png`)
📎 image.png (png, saved as `files/F0ANGQQNCES-image.png`)
📎 image.png (png, saved as `files/F0ANJSGCFSN-image.png`)
📎 image.png (png, saved as `files/F0ANGQV0SP8-image.png`)
📎 image.png (png, saved as `files/F0ANFE87KGD-image.png`)
📎 image.png (png, saved as `files/F0APD59MRAL-image.png`)
📎 image.png (png, saved as `files/F0APD5A72QY-image.png`)
📎 image.png (png, saved as `files/F0AN3DGHQBH-image.png`)

**Gisselle Jiménez** · 2026-03-24 15:33 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1774366399981969)
📎 image.png (png, saved as `files/F0AN3DSCU95-image.png`)
📎 image.png (png, saved as `files/F0ANNEX2012-image.png`)
📎 image.png (png, saved as `files/F0ANGRE7XRC-image.png`)

**Jacqueline Hood** · 2026-03-26 21:31 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1774560662851859)
No attendees for office hours today but I filmed a little walkthrough of Michelle's account and posted in the vault :slightly_smiling_face:
> **Gisselle Jiménez** · 2026-03-27 13:30 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1774618245050519)
> Thank you, @Jacqueline Hood!
> 
> @Whitney Hodges Should I still upload it to office hours in The VAULT?
> **Whitney Hodges** · 2026-03-27 13:39 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1774618751241579)
> @Gisselle Jiménez yes wouldn't hurt!
> **Jacqueline Hood** · 2026-03-27 15:44 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1774626256685389)
> @Gisselle Jiménez let me know if you need me to download the loom!
> **Gisselle Jiménez** · 2026-03-27 15:48 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1774626501565599)
> I was able to download it. Thank you! It has been uploaded.:white_check_mark:

**Jacqueline Hood** · 2026-04-02 21:04 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1775163869015039)
@Whitney Hodges is Katie no longer part of the vault?
I just did a walkthrough of her account and then went to post and tag her and I don't see her in there anymore!
> **Whitney Hodges** · 2026-04-02 21:05 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1775163958429329)
> @Jacqueline Hood No, she's not. Her membership ended about a month ago and she didn't feel like she needed to renew. Sorry for the confusion. I'll make sure you're updated next time
> **Jacqueline Hood** · 2026-04-02 21:13 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1775164391033729)
> No worries! :slightly_smiling_face:

**Jacqueline Hood** · 2026-04-06 23:54 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1775519689929169)
@Whitney Hodges Hi! I had a great call with Teresa today; got her up to speed on the vault, walked through some examples and suggestions for good client attraction ads and chatted about ads-traffic landing pages. She was having some technical issues with her computer so we weren't able to get the tech connections completed; she's going to try to come to office hours this week to get that part done!

**Gisselle Jiménez** · 2026-04-08 15:47 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1775663270300149)
Hi, @Jacqueline Hood! I had forgotten to send this your way. Could you please take a look at this lesson on *<https://xi40zxmrvw8pbyk5dyhp.memberships.msgsndr.com/products/0ef89da0-841f-4a3e-b703-5a8de177a67a/categories/f3fbf401-79fd-4dd7-bd1c-3c8853c2ad97/posts/e66f98b7-7cbb-409f-8588-6e4b625b8ccc?token=eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJhdXRoQ2xhc3MiOiJVc2VyIiwiYXV0aENsYXNzSWQiOiJDa0dNQUpRMDdobmI4UWVLdUdPZyIsImNoYW5uZWwiOiJBUFAiLCJzb3VyY2UiOiJXRUJfVVNFUiIsInNvdXJjZUlkIjoiQ2tHTUFKUTA3aG5iOFFlS3VHT2ciLCJwcmltYXJ5QXV0aENsYXNzSWQiOiJDa0dNQUpRMDdobmI4UWVLdUdPZyIsImFwcE1ldGEiOnt9LCJqdGkiOiI2OWQ2NzA0MzhlOGQyY2NiOGNiNThlMzEiLCJpYXQiOjE3NzU2NjExMjMuMTIzLCJleHAiOjE3NzU2NjQ3MjMuMTIzfQ.ZkigKo-ANwxMKxuSwJKizyIduvTn5RIRl-sPXTxWsc8_Esj-SNAO2QrbTRdt0Tt41S43q6VOVwsGSugMlIf_Mp-DlclIwmjZda2O2rCKD4ytSCnQKVbuTfLg0_jcOjThG76DTN2XMm2f4_Z8Lks037TD0kJ-3LDqd409jd0K77Uc4xitHPnZi-XGxDNPXywsM6Jz69X_BuwNeOz76RRhmWIA8VevrPpFGlTyQasAhmSXpYplHxcg-o66i0-0qLD57yZgNirEV1I6V3pZ7R8O_ZcXetuRch3_jOYSCW-Rjgyh0lSuzUGLHjb3mCm7HkhXUV9RxUemh31mSaHMmHsuNsj5GMiFOsUg6KIO_hsPh3OG4wp4R5Dya4yQbccEluPf0AIkeoBTxH_g0grBjDFidwbEF0oGShwkyOAUUMgwKWk4uvbtxN-HDOjWPYYUkj3_YLYhLka7pLgdy96I4eYl80BjZ_LwOm4CafqjJJ4LdPk_kTPVSYKrXHlGZ0fdMyRBvZ0w_tkczaGgjdG8p9atc9QgkhhoYzDMw4Ti1KfeTem8gQIzRpel52Z1qFjb86yCZDH9IpzxzkEZLUa2bNPiU5pDNoBCZ-kJU0c7gtbZ7_BYspCgDNkOhMVg4z-HQBvPPwHNygq3ZvVLcagVxhbrs2P8N65ky1pMSBSqAkx4oQY&amp;location_id=Xi40zxmRvW8Pbyk5DYHp&amp;is_preview=true|Selecting Content Without Partnership or Collaboration Tags>*? Let me know if anything needs to be updated before we publish. Thanks!

**Jacqueline Hood** · 2026-04-09 18:50 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1775760617940819)
Yes absolutely! Nothing comes up when I click that link though

**Gisselle Jiménez** · 2026-04-09 18:52 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1775760755538619)
@Jacqueline Hood Sorry, I think the previews expire. Can you please try this one: <https://xi40zxmrvw8pbyk5dyhp.memberships.msgsndr.com/products/0ef89da0-841f-4a3e-b703-5a8de177a67a/categories/f3fbf401-79fd-4dd7-bd1c-3c8853c2ad97/posts/e66f98b7-7cbb-409f-8588-6e4b625b8ccc?token=eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJhdXRoQ2xhc3MiOiJVc2VyIiwiYXV0aENsYXNzSWQiOiJDa0dNQUpRMDdobmI4UWVLdUdPZyIsImNoYW5uZWwiOiJBUFAiLCJzb3VyY2UiOiJXRUJfVVNFUiIsInNvdXJjZUlkIjoiQ2tHTUFKUTA3aG5iOFFlS3VHT2ciLCJwcmltYXJ5QXV0aENsYXNzSWQiOiJDa0dNQUpRMDdobmI4UWVLdUdPZyIsImFwcE1ldGEiOnt9LCJqdGkiOiI2OWQ3ZjE3NWFhZWFlODczOTk1NjFjMjEiLCJpYXQiOjE3NzU3NTk3MzMuOTY1LCJleHAiOjE3NzU3NjMzMzMuOTY1fQ.lqfrR4zzQibAnWgrnSTFkL0JVIU5NGE57MmPZrmrtZlDE_b7rBSOyYU2kYJcP-X0LT5-RiNFYbbdncKQ1GwFsuefJRA7ZOZnLZ0H-6xJhdL5SrGY3ObAOZssshTNwN8lTSgRk10aWJ6qT6RUBZgrhXtrtjaWj5quq9aWQQelzCP5EawHHz-hPIhDIRovHIdFM7FxbGvajIW7Zu1e-KHNIjmAFPHhbWQJ8GNlh9Cwforjrz7If5CEfGHU9CnZ2-GicfCQYbmGJNwZ5_PVieKEXcEKuxqjGy0m4zxc4Hio4p-z7UC6dnu-T_7Ar6XGFIykrNLUIQts7OgV3ypoI51w-2K3UMwHFXntawApB8RraE_HHfFvrcQcai6fo-jcHz48LA7r6YI6ZOiZ0mFLWVMVR4NmGnOadejg5Q1q0nCLBuiXf45HrkfJNItOQZ1gowNbru8Uf8bpB0GRpKiDQNLevP4WtzjWvENTNlHc4LkCgj-MSamMijEkenOLQeYIU3R9dBsWOPhnmv86XAafczyIotO0HrJr-98IfDavCG5AXFjARJ1gRsPM5N2Cf7reVFmc17R1u45PLyHo0VdCmIk6XPFPFkQ9jpklyoOwle76lECR6938SRiJQpYOBP2IdBftuU_mIR3fBlhA_OnEciM2nTscYxr5CNzyJgreA9krlw4&amp;location_id=Xi40zxmRvW8Pbyk5DYHp&amp;is_preview=true|https://xi40zxmrvw8pbyk5dyhp.memberships.msgsndr.com/products/0ef89da0-841f-4a3e-b703-5a8de177a67a/[…]cation_id=Xi40zxmRvW8Pbyk5DYHp&amp;is_preview=true>

**Jacqueline Hood** · 2026-04-09 19:05 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1775761502847319)
the lesson looks great, thank you!
> **Gisselle Jiménez** · 2026-04-09 20:28 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1775766525700689)
> Awesome. We will publish it now. Thanks!

**Whitney Hodges** · 2026-04-22 17:23 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1776878592975239)
@Jacqueline Hood Hi! Diana is planning to attend your office hours tomorrow for some guidance on her ads. She's ready to get everything submitted for launch!

**Jacqueline Hood** · 2026-04-22 23:21 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1776900061039289)
Sounds great! I'll be there :slightly_smiling_face:
> **Whitney Hodges** · 2026-04-23 00:07 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1776902832558439)
> Glad you're back but hope you had an amazing trip!!!
> **Jacqueline Hood** · 2026-04-23 21:54 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1776981253315279)
> Thank you!! :slightly_smiling_face:

**Jacqueline Hood** · 2026-04-23 21:55 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1776981333274899)
Meta Ads Office Hours - April 23/26

Not much to say in terms of a summary for the call; it was mostly logistics just showing Diana how to submit her content for review and getting Teresa's accounts connected. I did touch base with Felipe about the upcoming landing page A/B split test they want to run and best practice around that as well
📎 Impromptu Zoom Meeting - Apr 23 2026.mp4 (mp4, **not downloaded** — over cap (240.9 MB), [fetch it](https://files.slack.com/files-pri/T03P5A3L1DK-F0AUS0BTDMZ/download/impromptu_zoom_meeting_-_apr_23_2026.mp4))
> **Gisselle Jiménez** · 2026-04-24 17:09 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1777050570748819)
> Thank you! Posted

**Gisselle Jiménez** · 2026-04-28 06:11 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1777356683356349)
:inbox_tray: New Client Attraction Campaign Form Submission from Diana Leimbach!

Reminder: Check tracking first!

**Gisselle Jiménez** · 2026-04-28 06:15 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1777356914390919)
:inbox_tray: New Client Attraction Campaign Form Submission from Diana Leimbach!

Reminder: Check tracking first!
> **Gisselle Jiménez** · 2026-04-28 20:42 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1777408949263099)
> Hi, @Jacqueline Hood! Tagging you here! Just a heads up that Diana submitted the Meta Ads content form twice. Two of the Google Drive picture links were different between the submissions, so wanted to make sure you saw both. Feel free to reach out to her in the VAULT if you have any questions!
> **Jacqueline Hood** · 2026-04-28 23:26 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1777418793365849)
> thank you!!
> **Jacqueline Hood** · 2026-04-28 23:39 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1777419596843579)
> Feedback sent via the chat in the vault!

**Whitney Hodges** · 2026-04-29 15:12 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1777475561565179)
@Jacqueline Hood Just got this DM from Michelle! :tada:
📎 image.png (png, saved as `files/F0B06MBAYBZ-image.png`)

**Gisselle Jiménez** · 2026-04-30 05:23 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1777526609300589)
:inbox_tray: New Client Attraction Campaign Form Submission from Diana Leimbach!

Reminder: Check tracking first!
> **Gisselle Jiménez** · 2026-05-01 20:12 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1777666373416179)
> @Jacqueline Hood Making sure you got this! Thanks!
> **Jacqueline Hood** · 2026-05-02 00:25 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1777681522814229)
> I did, yes! thank you! Ads are ready to go live, just waiting on her payment method

**Jacqueline Hood** · 2026-05-07 22:17 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1778192244998549)
*Meta Ads Office Hours: May7/26*

@Gisselle Jiménez can we maybe cut out or blur the part in the middle of the video where Diana inputs her CC info? She was sharing her screen and I don't want her CC info on the public video recording. Thanks!

This call covered two main topics: landing page messaging feedback and Facebook ad account setup/troubleshooting.
In the first portion of the call, the group discussed feedback on the current landing page messaging and positioning. The conversation focused heavily on how the page currently communicates the company’s value, with discussion around shifting messaging from being more process/service-focused to more emotionally focused on the couple’s experience, challenges, and desired outcomes. There was also conversation around how brides typically feel when arriving on a landing page, what messaging helps create trust and connection quickly, and the importance of testing different messaging approaches with real traffic data rather than relying solely on personal preference. The group also discussed the reasoning behind the current headline structure and overall positioning strategy.
The second half of the call focused on Facebook ad account setup for Diana. This included navigating Business Manager, troubleshooting access and billing setup issues, reviewing payment settings and Facebook billing thresholds, and attempting to publish the ads that were still in draft mode. During setup, an unexpected GST/tax issue appeared despite the account being US-based. The group investigated possible causes, including account settings and connected users, but no clear resolution was identified during the call. Jacqueline will continue researching the issue, consult Whitney for additional insight, and follow up with Michael & Diana via email with next steps and a resolution plan.

Full Summary:

*<https://fathom.video/share/sv3eBUMGMBi8WjRG3ZKVUDx1EgWossz5|VIEW RECORDING - 49 mins (No highlights)>*
<https://fathom.video/share/sv3eBUMGMBi8WjRG3ZKVUDx1EgWossz5?tab=summary&timestamp=173|Landing page feedback and messaging strategy @ 2:53>
Felipe thanks Jacqueline for her feedback and requests a detailed review of her comments on the landing page. Jacqueline provides specific feedback that the current page is too process-focused ("this is what we do") rather than couple-focused ("this is how we help you"). She explains that prospective brides arriving at the page feel overwhelmed and confused, and want to immediately sense that the company understands their struggles and can solve their problems. The current header ("signature destination weddings, hand-selected venues, elevated guest experiences, expertly designed at no additional cost") feels too generic and broad. Felipe defends the current approach, explaining that the header is designed to address the four major concerns couples bring (venue selection, guest experience, wedding design, no additional cost) in 15 words or less, with additional detail provided in videos and further down the page. He also clarifies that they intentionally avoid claiming the process is "stress-free" because that would be dishonest—the real value is having someone guide couples through the inherent stress of planning. Jacqueline acknowledges her feedback is one person's perspective and emphasizes that split testing with actual traffic data will be the true determinant of what messaging converts best. She requests to see the alternative landing page version they plan to test against the current one.
<https://fathom.video/share/sv3eBUMGMBi8WjRG3ZKVUDx1EgWossz5?tab=summary&timestamp=1246|Facebook ad account setup and configuration @ 20:46>
Michael & Diana joins the call late and Jacqueline explains she remains available throughout the hour for anyone to pop in. They proceed to set up Michael & Diana's Facebook ad account by navigating to <http://Business.facebook.com|Business.facebook.com>. After multiple technical difficulties with screen sharing, authentication, and password resets, they successfully access the billing and payments section. Jacqueline explains the payment structure: Facebook charges in $2 increments, and Visa may flag these as suspicious activity and place a hold on the card—this is common with new ad accounts, so Michael & Diana should not be alarmed if it happens and should simply contact Visa to confirm the charges are legitimate. They confirm the daily spending limit is $98 and discuss that once a few charges have gone through successfully, Michael & Diana will be able to adjust the payment threshold. Jacqueline attempts to publish the ads, which are currently in draft status.
<https://fathom.video/share/sv3eBUMGMBi8WjRG3ZKVUDx1EgWossz5?tab=summary&timestamp=1861|GST location issue and resolution plan @ 31:01>
While attempting to publish the ads, the system unexpectedly requires a Canadian GST (Goods and Services Tax) number, despite the account being US-based and all connected accounts being from the United States. Jacqueline investigates the ad account settings and discovers that a previous social media manager is still connected to the account, though this doesn't fully explain the Canadian location requirement. The system is pulling "wedding industry ads" (which is American) but continues to demand Canadian tax information. Neither Jacqueline nor Michael & Diana can determine why the system is behaving this way. Jacqueline decides to consult with Whitney (a colleague) and conduct additional research before proceeding, as she has not encountered this issue before. She notes that the GST requirement shouldn't result in additional charges since Michael & Diana is in America and shouldn't be charged GST anyway. The plan is for Jacqueline to research the issue, consult Whitney, and email Michael & Diana with her findings. As a worst-case scenario, they can input the information and potentially change it later if needed.
📎 Impromptu Zoom Meeting - May 7 2026.mp4 (mp4, **not downloaded** — over cap (189.7 MB), [fetch it](https://files.slack.com/files-pri/T03P5A3L1DK-F0B2DF6MH4J/download/impromptu_zoom_meeting_-_may_7_2026.mp4))
> **Whitney Hodges** · 2026-05-08 00:51 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1778201481847899)
> @Jacqueline Hood Hi! I looked into this for Diana. I found where the issue is in the billing information in her ad account. Her country is Canada but currency is USD. I tried to change the country to US, but then I got this popup that she's going to need a whole new ad account.
> 
> I was worried I had missed something on the call or set up her ad account incorrectly. So I went back to my kickoff call recording with her and discovered that this ad account already existed. She just granted us access on the call. She was also on the call on her phone but on her laptop simultaneously, so she wasn't actually screensharing. I was verbally walking her through it.
> 
> So the solution is that she's going to have to set up a new ad account, unfortunately.
> 
> Could you record a video walkthrough of how she can do this, post it in the vault, and tag her, please?
> 📎 image.png (png, saved as `files/F0B2HQ595DJ-image.png`)
> 📎 image.png (png, saved as `files/F0B1YNB6AET-image.png`)
> **Jacqueline Hood** · 2026-05-08 05:03 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1778216630974279)
> ahh thank you for looking into this! Yes, I will do that

**Gisselle Jiménez** · 2026-05-08 16:37 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1778258229832109)
@Jacqueline Hood Thank you, published! I cut the entire section where she was on her account and billing settings. :white_check_mark:

**Jacqueline Hood** · 2026-05-14 22:03 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1778796201730709)
Meta Ad Office Hours:

Honestly, only Diana showed up and we quickly tried to solve her ad account issue, and then Fallon and I spent the remainder of the hour catching up and troubleshooting the issue.

@Whitney Hodges we tried to edit the settings in her ad account and ran into the same error on her end. We tried to create a new ad account and she has a limit of 1 so can't do that either. I have been on with Meta chat support and Diana will need to deactivate her existing ad account and create a new one.
I made sure to ask if this would be flagged as suspicious activity at all, and I was reassured that it wouldn't.

@Fallon Looney pulled up these instructions. Can I email them directly to Diana with an invite to book a 10 min call with me if she runs into any issues? Actually, she'll have to share this ad account with WIA after she creates it, so maybe we should just do it together regardless.


*How to Deactivate a Meta Ad Account (Desktop Only)*
1. Go to *Business Settings* in Meta Business Suite.
2. 
3. Navigate to *Accounts* &gt; *Ad Accounts* in the left menu.
4. 
5. Select the ad account you want to deactivate.
6. 
7. Click the dropdown menu or settings icon and select *Deactivate Ad Account*.
8. 
9. If you have an outstanding balance, you will be prompted to pay it before the account is deactivated.
10. 
11. Confirm the deactivation in the popup window.
12. 


*How to Create a New Meta Ad Account*
1. Go to *Business Settings*.
2. 
3. Click *Accounts* &gt; *Ad Accounts*.
4. 
5. Click the blue *Add* dropdown button.
6. 
7. Select *Create a New Ad Account*.
8. 
9. Follow the prompts to name the account, select your timezone and currency, and associate it with your business.
10. 

> **Whitney Hodges** · 2026-05-14 22:38 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1778798331019329)
> @Jacqueline Hood yes, please invite her to book a call with you. Thank you!
> **Jacqueline Hood** · 2026-05-14 23:02 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1778799777785689)
> Will do, thanks!
> **Jacqueline Hood** · 2026-05-20 01:54 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1779242066400309)
> @Whitney Hodges hi! just following up here - met with Diana today. We were able to deactivate her ad account, which takes up to 3 business days. We can't create a new one until that happens so we'll try again on office hours Thursday! :zany_face:
> **Fallon Looney** · 2026-05-20 12:18 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1779279492610139)
> @Jacqueline Hood Yay for progress! I'm so invested in this now:joy:
> **Gisselle Jiménez** · 2026-05-22 14:35 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1779460531475959)
> Hi, @Jacqueline Hood! Diana didn't end up joining office hours? @Whitney Hodges I believe we will wait until this is resolve to follow up on her access?
> **Whitney Hodges** · 2026-05-22 14:40 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1779460844036639)
> @Gisselle Jiménez yes, that works
> **Jacqueline Hood** · 2026-05-22 16:36 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1779467781275359)
> Correct, she didn't join office hours this week

**Jacqueline Hood** · 2026-05-21 22:12 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1779401557530129)
No one was there for office hours today @Gisselle Jiménez
> **Gisselle Jiménez** · 2026-05-22 14:34 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1779460463726049)
> Noted!

**Jacqueline Hood** · 2026-05-28 21:36 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1780004184693669)
Meta Ads Office Hours - May 28/26

Jacqueline walked Felipe (Luxe Travel Boutique) through an analysis of his ad performance, then they launched a new campaign together in real time to give an underperforming promo ad its own runway before the offer expires in July.
📎 Impromptu Zoom Meeting - May 28 2026.mp4 (mp4, **not downloaded** — over cap (186.1 MB), [fetch it](https://files.slack.com/files-pri/T03P5A3L1DK-F0B6YR4RXFW/download/impromptu_zoom_meeting_-_may_28_2026.mp4))
> **Gisselle Jiménez** · 2026-05-29 15:11 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1780067487354249)
> Thank you! Posted

**Jacqueline Hood** · 2026-05-29 17:30 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1780075812594919)
@Whitney Hodges I just CC'ed you in a thread between me and Diana if you wanted to chime in any thoughts regarding her spot in the program and setting up an ad account

**Jacqueline Hood** · 2026-06-03 02:56 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1780455416019419)
What a process! Happy to report that Diana's client attraction ads are finally live!! Got a new business manager, ad account and pixel set up :slightly_smiling_face: :partying_face:

**Jacqueline Hood** · 2026-06-03 03:08 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1780456099076469)
@Whitney Hodges curious your thoughts on strategy for Diana's conversion campaign.
She has a "contact us" section on the page where they can request more information (many other CTA's on that page as well though, like text us, for example). Or you can book a service directly on the page. Looks like you can book the service and pay after the service has been done, which removes one barrier.

On the one hand, list building through the contact form could be strategic long-term but I'm not sure how well it'll work given the current set up. Ideally we would be optimizing for booked appointments, but I'm not sure how well a $500 budget would support that, either.

Did you chat with her about strategy at all? If she's not doing any email marketing, then building an email list is sort of irrelevant as well.

We could always start with optimizing for booked appointments (visits to the confirmation page) and see how it goes!
I wonder if a 10% off FB lead form ad could work well (if this doesn't) - and then direct them straight to the booking page to claim their discount.
> **Whitney Hodges** · 2026-06-03 08:52 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1780476770035999)
> @Jacqueline Hood I would definitely suggest lead form ads that promote a special first-time offer
> **Jacqueline Hood** · 2026-06-04 22:41 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1780612900237519)
> Perfect. Update here: She sent me a message telling me that her account was hacked last night, so she spent hours with Meta getting everything sorted :disappointed:
> Super weird timing with what happened to Michelle's account, so I've changed all of my passwords just as a precaution.
> 
> But in all of that, it looks like she removed WIA from her new ad account. I've emailed her again to see if she can re-add us so I can get her conversion campaigns finally launched! @Whitney Hodges
> **Whitney Hodges** · 2026-06-04 22:43 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1780612994010559)
> @Jacqueline Hood ok! Maybe the hacker removed us?? Can you please take a look inside all the other WIA ad accounts you're connected to and make sure nothing looks weird?
> **Jacqueline Hood** · 2026-06-04 22:50 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1780613423811529)
> @Whitney Hodges just checked -all of my client accounts look fine. Maybe @Fallon Looney and @Carmen Cruickshank can take a peek at theirs, too, just in case?

**Jacqueline Hood** · 2026-06-04 22:41 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1780612910372369)
No attendees for office hours today

**Jacqueline Hood** · 2026-06-11 21:41 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1781214074201579)
Office Hours Call June 11/26:

Jacqueline and Felipe reviewed performance of the updated landing page in terms of conversion rates from Meta ads, and reviewed performance of the $1000 promo ads we launched last week!
📎 Impromptu Zoom Meeting - Jun 11 2026.mp4 (mp4, **not downloaded** — over cap (114.3 MB), [fetch it](https://files.slack.com/files-pri/T03P5A3L1DK-F0B9XJ69DK7/download/impromptu_zoom_meeting_-_jun_11_2026.mp4))
> **Gisselle Jiménez** · 2026-06-12 14:52 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1781275923169359)
> Awesome, published!

**Jacqueline Hood** · 2026-06-16 19:31 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1781638264003419)
Another update regarding Diana/Luxe Whitening:

We had everything set to go with her new business manager/ad account. Client attraction ads were launched and then she got hacked so everything got deleted.
I just met with her again to get a new ad account created and WIA added back in. It's giving us an error when we try to input the payment method so I asked her to try again in a few hours. Once that's done, I can relaunch all of her campaigns again. @Whitney Hodges

**Jacqueline Hood** · 2026-06-18 21:55 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1781819707723789)
Meta Ads Office Hours - June 18/26

Jacqueline &amp; Felipe reviewed the performance of their $1000 promo campaign and their ongoing conversion campaigns. We decided to just run the conversion campaigns to our cold audiences right now, as they're outperforming the warm, and we think the retargeting window on the warm campaign might be too large and possibly reaching women who have already chosen their venue/planner.
📎 Impromptu Zoom Meeting - Jun 18 2026.mp4 (mp4, **not downloaded** — over cap (116.2 MB), [fetch it](https://files.slack.com/files-pri/T03P5A3L1DK-F0BBQC9PL1F/download/impromptu_zoom_meeting_-_jun_18_2026.mp4))
> **Gisselle Jiménez** · 2026-06-19 15:30 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1781883018504769)
> Thank you, posted!!

**Jacqueline Hood** · 2026-06-26 06:29 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1782455347260949)
No attendees for office hours today

**Gisselle Jiménez** · 2026-06-28 22:58 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1782687515014389)
:checkered_flag:Shannon Lee booked their Meta Ads Accelerator Kickoff Call!

Booked with: Whitney Hodges
Appointment Date &amp; Time: Monday, July 20, 2026 2:00 PM 
 EDT
> **Gisselle Jiménez** · 2026-07-06 19:34 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1783366478859799)
> @Whitney Hodges Here is Shannon's questionnaire!
> 📎 form_submission_ea29c9b4-88e7-4658-a175-bed5a5373573.pdf (pdf, saved as `files/F0BGBMZ8F7S-form_submission_ea29c9b4-88e7-4658-a175-bed5a5373573.pdf`)

**Jacqueline Hood** · 2026-07-03 14:57 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1783090663214739)
No attendees for office hours yesterday

**Gisselle Jiménez** · 2026-07-08 22:35 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1783550105988649)
:inbox_tray: New Client Attraction Campaign Form Submission from Teresa Moody!

Reminder: Check tracking first!

**Jacqueline Hood** · 2026-07-09 17:47 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1783619220522459)
I tried launching Teresa's ads and I'm not seeing her ad account anywhere. I reviewed our last call together and it looks like it was there, so not sure what happened.  @Whitney Hodges let me know if you see it on your end at all.

I just emailed her and asked if we could get on a quick 5 min zoom just to reconnect the ad account :slightly_smiling_face:
📎 Screenshot 2026-07-09 at 10.38.19 AM.png (png, saved as `files/F0BGAUNB2NN-Screenshot_2026-07-09_at_10.38.19_AM.png`)

**Whitney Hodges** · 2026-07-09 17:55 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1783619727620239)
@Jacqueline Hood Her ad account is no longer assigned to us, but we're still connected as partners with access to her FB and IG pages. I also went to the Meta Ads Library, and it's showing that Evergreen doesn't have any active ads. Thank you for offering her a call to reconnect!

**Jacqueline Hood** · 2026-07-09 18:54 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1783623276784139)
No problem. Looks like she'll try to hop in at the end of office hours today :slightly_smiling_face: No idea why the ad account is no longer connected!

**Jacqueline Hood** · 2026-07-09 22:03 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1783634611560039)
Is mercury in retrograde or something? Things are so bizarre today!!

You can watch the last 30 minutes of this call if you want - on her end, WIA has full access to the ad account. I removed our access and re-added us, requested access to the page from my end with her ad account ID and even tried adding myself as. "person" rather than a partner. Everything shows that we have full access to the ad account on her end, yet I'm still not seeing anything on our end. I'm at a loss - any thoughts @Whitney Hodges @Fallon Looney?

**Jacqueline Hood** · 2026-07-09 22:05 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1783634715908989)
Impromptu Zoom Meeting - July 09

*<https://fathom.video/share/eBenbndoHWuzqqTshy_napoRyLhuJHwm|VIEW RECORDING - 72 mins (No highlights)>*
Meeting Purpose
<https://fathom.video/share/eBenbndoHWuzqqTshy_napoRyLhuJHwm?tab=summary&amp;timestamp=48.0|Troubleshoot Meta ad account access and payment issues for two clients.>
Key Takeaways
• *<https://fathom.video/share/eBenbndoHWuzqqTshy_napoRyLhuJHwm?tab=summary&amp;timestamp=253.0|Ridgefield:>*<https://fathom.video/share/eBenbndoHWuzqqTshy_napoRyLhuJHwm?tab=summary&amp;timestamp=253.0| Ads were reactivated by adding a new Coast Central Visa (7976), which resolved a payment failure with the old Chase card.>
• *<https://fathom.video/share/eBenbndoHWuzqqTshy_napoRyLhuJHwm?tab=summary&amp;timestamp=3199.0|Evergreen Weddings:>*<https://fathom.video/share/eBenbndoHWuzqqTshy_napoRyLhuJHwm?tab=summary&amp;timestamp=3199.0| A persistent Meta glitch blocks partner access to the ad account, despite all permissions being correctly assigned by the client.>
• *<https://fathom.video/share/eBenbndoHWuzqqTshy_napoRyLhuJHwm?tab=summary&amp;timestamp=3870.0|Evergreen Solution:>*<https://fathom.video/share/eBenbndoHWuzqqTshy_napoRyLhuJHwm?tab=summary&amp;timestamp=3870.0| The team will investigate creating a new ad account, as the existing one appears inaccessible to the partner agency.>
• *<https://fathom.video/share/eBenbndoHWuzqqTshy_napoRyLhuJHwm?tab=summary&amp;timestamp=705.0|Communication:>*<https://fathom.video/share/eBenbndoHWuzqqTshy_napoRyLhuJHwm?tab=summary&amp;timestamp=705.0| Scott (Ridgefield) requested text as the fastest contact method for urgent issues.>
Topics
Ridgefield Ad Account: Payment Failure Resolution
• *<https://fathom.video/share/eBenbndoHWuzqqTshy_napoRyLhuJHwm?tab=summary&amp;timestamp=242.0|Problem:>*<https://fathom.video/share/eBenbndoHWuzqqTshy_napoRyLhuJHwm?tab=summary&amp;timestamp=242.0| Ads were paused due to a payment failure with the existing Chase card.>
• *<https://fathom.video/share/eBenbndoHWuzqqTshy_napoRyLhuJHwm?tab=summary&amp;timestamp=253.0|Solution:>*<https://fathom.video/share/eBenbndoHWuzqqTshy_napoRyLhuJHwm?tab=summary&amp;timestamp=253.0| Added a new Coast Central Visa (7976) as the default payment method.>
• *<https://fathom.video/share/eBenbndoHWuzqqTshy_napoRyLhuJHwm?tab=summary&amp;timestamp=360.0|Unexpected Verification:>*<https://fathom.video/share/eBenbndoHWuzqqTshy_napoRyLhuJHwm?tab=summary&amp;timestamp=360.0| Meta required a novel bank-level verification, asking for a code from a temporary $1 charge on the card statement.>
    ◦ *<https://fathom.video/share/eBenbndoHWuzqqTshy_napoRyLhuJHwm?tab=summary&amp;timestamp=547.0|Code:>*<https://fathom.video/share/eBenbndoHWuzqqTshy_napoRyLhuJHwm?tab=summary&amp;timestamp=547.0| >`N-Q-V-V`
• *<https://fathom.video/share/eBenbndoHWuzqqTshy_napoRyLhuJHwm?tab=summary&amp;timestamp=642.0|Result:>*<https://fathom.video/share/eBenbndoHWuzqqTshy_napoRyLhuJHwm?tab=summary&amp;timestamp=642.0| The payment processed successfully, and ads were reactivated immediately.>
Evergreen Weddings: Partner Access Glitch
• *<https://fathom.video/share/eBenbndoHWuzqqTshy_napoRyLhuJHwm?tab=summary&amp;timestamp=2658.0|Problem:>*<https://fathom.video/share/eBenbndoHWuzqqTshy_napoRyLhuJHwm?tab=summary&amp;timestamp=2658.0| Evergreen Weddings' ad account is inaccessible to the partner agency, blocking ad management.>
• *<https://fathom.video/share/eBenbndoHWuzqqTshy_napoRyLhuJHwm?tab=summary&amp;timestamp=2658.0|Troubleshooting Steps:>*
    ◦ *<https://fathom.video/share/eBenbndoHWuzqqTshy_napoRyLhuJHwm?tab=summary&amp;timestamp=3374.0|Re-assigning Permissions:>*<https://fathom.video/share/eBenbndoHWuzqqTshy_napoRyLhuJHwm?tab=summary&amp;timestamp=3374.0| Removed and re-added the partner agency in Business Settings.>
    ◦ *<https://fathom.video/share/eBenbndoHWuzqqTshy_napoRyLhuJHwm?tab=summary&amp;timestamp=3681.0|Direct Invite:>*<https://fathom.video/share/eBenbndoHWuzqqTshy_napoRyLhuJHwm?tab=summary&amp;timestamp=3681.0| Invited Jacqueline Hood as an individual user.>
• *<https://fathom.video/share/eBenbndoHWuzqqTshy_napoRyLhuJHwm?tab=summary&amp;timestamp=3199.0|Outcome:>*<https://fathom.video/share/eBenbndoHWuzqqTshy_napoRyLhuJHwm?tab=summary&amp;timestamp=3199.0| Both attempts failed. The client's view confirms all permissions are assigned, but the ad account remains invisible to the partner.>
• *<https://fathom.video/share/eBenbndoHWuzqqTshy_napoRyLhuJHwm?tab=summary&amp;timestamp=3199.0|Hypothesis:>*<https://fathom.video/share/eBenbndoHWuzqqTshy_napoRyLhuJHwm?tab=summary&amp;timestamp=3199.0| The issue is a Meta glitch, not a configuration error.>
Next Steps
• *<https://fathom.video/share/eBenbndoHWuzqqTshy_napoRyLhuJHwm?tab=summary&amp;timestamp=4071.0|Jacqueline Hood:>*
    ◦ <https://fathom.video/share/eBenbndoHWuzqqTshy_napoRyLhuJHwm?tab=summary&amp;timestamp=4071.0|Consult the team on the Evergreen Weddings access issue.>
    ◦ <https://fathom.video/share/eBenbndoHWuzqqTshy_napoRyLhuJHwm?tab=summary&amp;timestamp=4087.0|Send Teresa instructions for creating a new ad account if it's the agreed-upon solution.>
    ◦ <https://fathom.video/share/eBenbndoHWuzqqTshy_napoRyLhuJHwm?tab=summary&amp;timestamp=705.0|Use text for urgent communication with Scott (Ridgefield).>


**Fallon Looney** · 2026-07-10 14:18 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1783693115971129)
@Jacqueline Hood I'm big on astrology &amp; things &amp; I can confirm Mercury is in fact in retrograde until July 23rd:zany_face:

**Jacqueline Hood** · 2026-07-10 15:38 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1783697921607799)
things are seriously wacky right now! haha

**Jacqueline Hood** · 2026-07-16 21:53 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1784238818938859)
No one at office hours today.

Update on Teresa - her client attraction campaigns are in draft mode and ready to turn on, but she didn't actually add the payment method (she thought she did). I emailed her with more instructions/invite to do it together :slightly_smiling_face: @Whitney Hodges

**Jacqueline Hood** · 2026-07-17 18:00 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1784311219678119)
Teresa's ads are live :slightly_smiling_face:

**Gisselle Jiménez** · 2026-07-20 16:06 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1784563565252489)
:checkered_flag:Shannon Lee booked their Meta Ads Accelerator Kickoff Call!

Booked with: Whitney Hodges
Appointment Date &amp; Time: Wednesday, July 22, 2026 2:00 PM 
 EDT

**Whitney Hodges** · 2026-07-22 18:51 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1784746282656869)
@Jacqueline Hood Hi! I just had the Meta Ads Kickoff Call with Shannon from Love Like Wild. We have partner access to her Meta Business Portfolio, so you should be able to grant yourself access to her FB page, ad account, and pixel. Her previous campaigns that she ran earlier this year actually performed really well for awhile then suddenly stopped performing. I'm not quite sure how the leads from those campaigns were being tracked because I don't see a lead pixel on her TY page. Just a page view. <https://lovelikewild.com/thank-you|lovelikewild.com/thank-you>

Her pixel was installed via GTM which we do have access to and @Carmen Cruickshank should be able to help you with or you can try installing through Events Manager.

@Gisselle Jiménez Can you please drop the recording from the call here, so Jacqueline can catch up.

Thank you!

**Gisselle Jiménez** · 2026-07-22 19:47 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1784749675519109)
@Jacqueline Hood Here is the <https://drive.google.com/file/d/1tg8sT6ApQ0oRUcTgJMGJf-sY6C-hRudw/view?usp=drive_link|recording> and <https://docs.google.com/document/d/1PipVocOGidty-XLyjnOzwA39pfyT2vRehwji6XbzRaA/edit?usp=drive_link|summary>

Here's also the zoom shareable link so you have access to the chat since she was still sick and just typing. You'll also find summary and action items, if needed. Let me know if you need anything else!

Shareable link: <https://zoom.us/rec/share/9gmxFJqE2c7FAswVtAAMeVcUa6bAlTY7koUSra59i2Wc2qdXLlKQjnKBsg9DEovU.hBtP5Py5izaeH-pw|zoom.us/rec/share/9gmxFJqE2c7F…>
Passcode: x7X+NM=d

**Gisselle Jiménez** · 2026-07-22 20:06 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1784750802488829)
Hi, @Jacqueline Hood! I'm still working on the attendance flow and automating the reminders, but for tomorrow if you could just check off who attended, then I'll monitor for now. Thanks!

<https://docs.google.com/spreadsheets/d/16XQJvz1GIgpJwjAagBaNXKAoJhtn1Bv1YoI1YjRepkE/edit?gid=13791412#gid=13791412|docs.google.com/spreadsheets/d/16XQJvz1GIgp…/edit?gid=13791412#gid=13791412>
> **Gisselle Jiménez** · 2026-07-22 20:08 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1784750924228899)
> I have added it to clickup as well!
> 📎 image.png (png, saved as `files/F0BK39ZPADU-image.png`)
> **Jacqueline Hood** · 2026-07-23 23:51 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1784850691242689)
> thank you! No attendees today @Gisselle Jiménez

**Gisselle Jiménez** · 2026-07-27 22:09 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1785190172152299)
:inbox_tray: New Direct Response Campaign Form Submission from Shannon Lee!

**Whitney Hodges** · 2026-07-28 16:05 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1785254714270619)
@Carmen Cruickshank Hi! Shannon from Love Like Wild submitted her conversion ads for us to launch. Before I do that, we need to add Meta conversion tracking to her thank you page <https://lovelikewild.com/thank-you|lovelikewild.com/thank-you>. I believe her pixel was installed via GTM and that we already have access to her GTM account. Could you please add a Meta Lead event to the thank you page via GTM? If it's possible for you to prioritize this to be complete by tomorrow morning, I would appreciate it so much. Please let me know. Thanks!

cc @Gisselle Jiménez
> **Carmen Cruickshank** · 2026-07-28 16:15 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1785255313935809)
> looking at it now @Whitney Hodges
> **Whitney Hodges** · 2026-07-28 16:15 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1785255348910219)
> @Carmen Cruickshank Thank you! FYI I did try setting it up through the setup tool in Meta Events Manager, but it doesn't seem to be working
> **Carmen Cruickshank** · 2026-07-28 18:12 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1785262330273649)
> good to know
> **Carmen Cruickshank** · 2026-07-28 19:33 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1785267236025579)
> @Whitney Hodges tested it and now its firing correctly on Meta!
> **Whitney Hodges** · 2026-07-28 19:34 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1785267259842429)
> @Carmen Cruickshank tysm!!!!
> **Whitney Hodges** · 2026-07-30 00:10 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1785370220297549)
> @Carmen Cruickshank Hi! I'm taking a look in Events Manager, and it looks like the Lead event is firing twice on the Thank You page. Not sure if the Lead event I set up with the Events Manager ended up sticking? I tried to delete via Events Manager, but it's still there. I'll take a look again in the morning, but we may need to delete the Lead event via GTM. I don't want her leads to get counted twice!
> 📎 image.png (png, saved as `files/F0BLALKHK4P-image.png`)
> **Carmen Cruickshank** · 2026-07-30 18:22 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1785435763007519)
> checking this out now
> **Carmen Cruickshank** · 2026-07-30 18:29 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1785436190746329)
> i cant pause the one on GTM and we can test it out again @Whitney Hodges

**Whitney Hodges** · 2026-07-30 16:54 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1785430469114039)
@Fallon Looney Hi! Thanks again for covering Jacqueline's office hours this afternoon. The two potential attendees are Teresa with Evergreen Venue and Shannon with Love Like Wild Photography. I just launched Shannon's ads last night and posted a video walkthrough in the Meta Ads Accelerator if you want to check it out

**Carmen Cruickshank** · 2026-07-30 18:46 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1785437202883979)
@Whitney Hodges Hi! just tested in events manager for Shannon after i paused the leads meta tag and its only firing once!
📎 Screenshot 2026-07-30 at 2.45.23 PM.png (png, saved as `files/F0BM1K87RGR-Screenshot_2026-07-30_at_2.45.23_PM.png`)
> **Whitney Hodges** · 2026-07-30 19:01 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1785438119734529)
> Tysm!!

**Gisselle Jiménez** · 2026-07-31 16:11 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1785514318864669)
Hi, @Fallon Looney! Were there any attendees for Meta ads office hours yesterday?

**Fallon Looney** · 2026-07-31 16:20 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1785514852115729)
@Gisselle Jiménez Hi yes! Felipe was the only attendee. I think the recording may have glitched because nothing downloaded for me. We just looked at his ad account performance over the last 7-14 days and he was happy with CPL etc.

**Whitney Hodges** · 2026-08-06 17:01 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1786035717178489)
@Jacqueline Hood Hi! Even if she doesn't attend today, could you please take a look at Shannon's ads and give your insights and make suggestions if needed? Thank you!!
> **Jacqueline Hood** · 2026-08-06 20:53 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1786049615863839)
> I just filmed a loom for her! Want me to put it right in the main chat of the Vault, or as a DM to her?
> **Whitney Hodges** · 2026-08-06 20:54 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1786049660413529)
> @Jacqueline Hood you can put it in the meta channel and tag her please
> **Jacqueline Hood** · 2026-08-06 21:09 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1786050575697269)
> she showed up just as I finished recording it haha
> **Jacqueline Hood** · 2026-08-06 21:09 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1786050579542439)
> I'll still share it!

**Jacqueline Hood** · 2026-08-06 17:11 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1786036304493419)
Yup definitely!

**Jacqueline Hood** · 2026-08-07 14:45 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1786113950731899)
Meta Ads Office Hours: Aug 6th

Jacqueline and Shannon reviewed her recently launched conversion campaigns; metrics all look strong except for landing page conversion rate, so we disabled the "pricing guide opt-in" popup on the landing page and we'll analyze again in a week's time. We also looked at how different angles of messaging are performing in terms of conversion rates.

@Gisselle Jiménez the first part of the video likely recorded me recording a loom for Shannon before she hopped on. You can delete that part of the recording, please! Thank you!
📎 Impromptu Zoom Meeting - Aug 6 2026.mp4 (mp4, **not downloaded** — over cap (147.9 MB), [fetch it](https://files.slack.com/files-pri/T03P5A3L1DK-F0BNW9PMBK6/download/impromptu_zoom_meeting_-_aug_6_2026.mp4))
> **Gisselle Jiménez** · 2026-08-07 19:26 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1786130809791829)
> @Jacqueline Hood thank you! edited and posted

**Gisselle Jiménez** · 2026-08-11 20:08 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1786478898225699)
:inbox_tray: New Client Attraction Campaign Form Submission from Shannon Lee!

Reminder: Check tracking first!
> **Gisselle Jiménez** · 2026-08-12 16:54 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1786553645929529)
> @Jacqueline Hood Clickup task has been created and here is the form for reference! It's also in the task description
> 📎 889e8528-7287-4c84-9ff1-c68c2cd85224.pdf (pdf, saved as `files/F0BPV5YH0Q1-889e8528-7287-4c84-9ff1-c68c2cd85224.pdf`)
> **Jacqueline Hood** · 2026-08-12 17:12 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1786554762930649)
> thank you!!
> **Jacqueline Hood** · 2026-08-12 17:28 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1786555695269089)
> Campaign is launched!

**Jacqueline Hood** · 2026-08-13 20:42 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1786653742170789)
Huge win for Shannon!! Last week she came to office hours and we looked at her initial conversion campaign results; decent at $58 CPL. We were brainstorming and she mentioned that she has the contact form on the landing page AND a pop-up for people to get the pricing guide (which isn't tracked). So I suggested removing the pop-up so there's just one CTA on the page.

CPL since doing so has dropped to $24! :partying_face:
📎 Screenshot 2026-08-13 at 1.40.24 PM.png (png, saved as `files/F0BPY43HGUB-Screenshot_2026-08-13_at_1.40.24_PM.png`)
📎 Screenshot 2026-08-13 at 1.40.43 PM.png (png, saved as `files/F0BQ2C16BSA-Screenshot_2026-08-13_at_1.40.43_PM.png`)
> **Whitney Hodges** · 2026-08-13 20:43 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1786653793614729)
> Amazing!!!
> **Jacqueline Hood** · 2026-08-13 21:23 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1786656191644079)
> I mentioned to her that next steps are really letting the leads come in and then starting to analyze the quality of the leads, and then using that data to tweak things higher in the funnel.
> 
> I wonder if something like that could make a good upcoming training? Like the leads are coming in...now what? Looking at open rates, how many are booking calls/tours, and how we can use the actual data from the leads to tweak either what we need to say TOF or how we need to connect with the leads that are coming in&gt;
> 
> Moreso I was thinking though how using the information from the leads to then influence the messaging/positioning of the ads themselves
> **Whitney Hodges** · 2026-08-13 21:27 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1786656446678229)
> @Jacqueline Hood Yes, love that thought! Could you please take a look at this training and let me know if it encompasses any of what you have in mind? <https://members.weddingindustryads.com/courses/products/4b766a56-cd9d-4946-9812-1c4f7f936946/categories/703d664b-bc59-4182-89a5-1b94a35a0803/posts/55832c35-d0be-46f0-92db-fb5d33a6a268?source=communities&amp;group_slug=the-vault|members.weddingindustryads.com/courses/…/…?source=communities&amp;group_slug=the-vault> If you could let me know what areas of opportunity you see beyond this, I'd love to use it for an upcoming workshop. Thank you!!
> **Gisselle Jiménez** · 2026-08-24 18:12 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1787595156324949)
> Hi, @Jacqueline Hood! Just wanted to follow up on this above whenever you get a chance to review. Thanks!!

**Gisselle Jiménez** · 2026-08-20 21:47 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1787262457587069)
:inbox_tray: New Retargeting Campaign Form Submission from Shannon Lee!
> **Jacqueline Hood** · 2026-08-21 17:06 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1787331968542739)
> launched! one of her retargeting ads was a carousel but it had over 10 slides, so I asked her to repost with just 10 slides

**Jacqueline Hood** · 2026-08-20 22:06 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1787263570644489)
*Meta Ads Office Hours - Aug 20/26*

Shannon and I reviewed her conversion ads and did some troubleshooting since we hadn't seen any leads come through in the last 7 days, even though Shannon said she has still been getting leads on the backend (Meta wasn't tracking them).  We tested the funnel and confirmed that "Lead" was no longer firing, so we installed the event on the thank-you page using the Event Set up Tool.

We also discussed ideas for retargeting ads; essentially answering the question "If you could get back in front of a potential client you just spoke with, what would you want them to know/see/hear that would get them to book with you?'
📎 Impromptu Zoom Meeting - Aug 20 2026.mp4 (mp4, **not downloaded** — over cap (195 MB), [fetch it](https://files.slack.com/files-pri/T03P5A3L1DK-F0BR7PJHLJK/download/impromptu_zoom_meeting_-_aug_20_2026.mp4))
> **Gisselle Jiménez** · 2026-08-21 16:09 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1787328586672879)
> Posted!! thank you

**Gisselle Jiménez** · 2026-08-26 15:58 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1787759911337879)
Hi, @Jacqueline Hood! Quick reminder to reply to Shannon on her RT ads:
<https://members.weddingindustryads.com/communities/groups/the-vault/channels/Announcements-6nWm7z/posts/6a88848d56dc05a84852bc58?commentId=6a8c74acd03324353d6fb786&amp;parentId=6a88848d56dc05a84852bc58|members.weddingindustryads.com/communities/…/…?commentId=…&amp;parentId=…>

She asked if the videos work in the retargeting ad or if she should remove those slides?

**Jacqueline Hood** · 2026-08-26 22:08 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1787782130574069)
I replied via DM but I'll reply there as well!

**Jacqueline Hood** · 2026-08-27 21:34 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1787866484506339)
Meta Ads Office Hours: Aug 27/26

Shannon and I reviewed her ads and I helped her launch another new retargeting ad that she was getting an error on - quick fix, it just needed the website URL put in. Otherwise things are looking great! Lots of leads and great lead quality!

Impromptu Zoom Meeting - August 27

*<https://fathom.video/share/goyj9P2PbULRVh-8Pxyzt3yqxspGnZbv|VIEW RECORDING - 49 mins (No highlights)>*
Meeting Purpose
<https://fathom.video/share/goyj9P2PbULRVh-8Pxyzt3yqxspGnZbv?tab=summary&amp;timestamp=4.0|Troubleshoot a Meta ad error and review campaign performance.>
Key Takeaways
• *<https://fathom.video/share/goyj9P2PbULRVh-8Pxyzt3yqxspGnZbv?tab=summary&amp;timestamp=198.0|Ad Error Resolved:>*<https://fathom.video/share/goyj9P2PbULRVh-8Pxyzt3yqxspGnZbv?tab=summary&amp;timestamp=198.0| A Meta ad failed because the URL field was missing after a post edit. The fix was a simple re-duplication, which correctly populated the URL.>
• *<https://fathom.video/share/goyj9P2PbULRVh-8Pxyzt3yqxspGnZbv?tab=summary&amp;timestamp=209.0|Campaign Performance Strong:>*<https://fathom.video/share/goyj9P2PbULRVh-8Pxyzt3yqxspGnZbv?tab=summary&amp;timestamp=209.0| Meta ads are generating daily, high-quality leads with an 80% response rate, leading to calls. Actual CPL is estimated to be lower than reported due to untracked direct Instagram profile visits.>
• *<https://fathom.video/share/goyj9P2PbULRVh-8Pxyzt3yqxspGnZbv?tab=summary&amp;timestamp=379.0|Google Ads Relaunched:>*<https://fathom.video/share/goyj9P2PbULRVh-8Pxyzt3yqxspGnZbv?tab=summary&amp;timestamp=379.0| Google ads were pivoted to target only "elopement" keywords after poor performance on "wedding" terms. This new strategy is now successfully generating leads.>
Topics
Meta Ad Troubleshooting
• *<https://fathom.video/share/goyj9P2PbULRVh-8Pxyzt3yqxspGnZbv?tab=summary&amp;timestamp=120.0|Problem:>*<https://fathom.video/share/goyj9P2PbULRVh-8Pxyzt3yqxspGnZbv?tab=summary&amp;timestamp=120.0| A new Meta ad failed to publish, showing an error: "A call to action is required. Your campaign objective requires an external website URL.">
• *<https://fathom.video/share/goyj9P2PbULRVh-8Pxyzt3yqxspGnZbv?tab=summary&amp;timestamp=122.0|Cause:>*<https://fathom.video/share/goyj9P2PbULRVh-8Pxyzt3yqxspGnZbv?tab=summary&amp;timestamp=122.0| The URL field was missing in the ad setup. This likely occurred after Shannon edited the source Instagram post (reducing it to 10 slides) and then duplicated an existing ad.>
• *<https://fathom.video/share/goyj9P2PbULRVh-8Pxyzt3yqxspGnZbv?tab=summary&amp;timestamp=198.0|Solution:>*<https://fathom.video/share/goyj9P2PbULRVh-8Pxyzt3yqxspGnZbv?tab=summary&amp;timestamp=198.0| Jacqueline guided a re-duplication of a working ad. This process correctly pulled the URL from the source post, allowing the new ad to publish.>
• *<https://fathom.video/share/goyj9P2PbULRVh-8Pxyzt3yqxspGnZbv?tab=summary&amp;timestamp=350.0|Action:>*<https://fathom.video/share/goyj9P2PbULRVh-8Pxyzt3yqxspGnZbv?tab=summary&amp;timestamp=350.0| Shannon will rename the new ad for clarity and delete the failed draft.>
Campaign Performance &amp; Strategy
• *<https://fathom.video/share/goyj9P2PbULRVh-8Pxyzt3yqxspGnZbv?tab=summary&amp;timestamp=209.0|Meta Ads:>*
    ◦ *<https://fathom.video/share/goyj9P2PbULRVh-8Pxyzt3yqxspGnZbv?tab=summary&amp;timestamp=209.0|Leads:>*<https://fathom.video/share/goyj9P2PbULRVh-8Pxyzt3yqxspGnZbv?tab=summary&amp;timestamp=209.0| Generating daily, high-quality leads.>
    ◦ *<https://fathom.video/share/goyj9P2PbULRVh-8Pxyzt3yqxspGnZbv?tab=summary&amp;timestamp=514.0|Response Rate:>*<https://fathom.video/share/goyj9P2PbULRVh-8Pxyzt3yqxspGnZbv?tab=summary&amp;timestamp=514.0| 80%, leading to calls.>
    ◦ *<https://fathom.video/share/goyj9P2PbULRVh-8Pxyzt3yqxspGnZbv?tab=summary&amp;timestamp=434.0|CPL:>*<https://fathom.video/share/goyj9P2PbULRVh-8Pxyzt3yqxspGnZbv?tab=summary&amp;timestamp=434.0| Actual cost per lead is likely lower than reported.>
        ▪︎ *<https://fathom.video/share/goyj9P2PbULRVh-8Pxyzt3yqxspGnZbv?tab=summary&amp;timestamp=448.0|Reason:>*<https://fathom.video/share/goyj9P2PbULRVh-8Pxyzt3yqxspGnZbv?tab=summary&amp;timestamp=448.0| Many leads find the Instagram profile via ads and then navigate directly to the website, bypassing tracking.>
• *<https://fathom.video/share/goyj9P2PbULRVh-8Pxyzt3yqxspGnZbv?tab=summary&amp;timestamp=379.0|Google Ads:>*
    ◦ *<https://fathom.video/share/goyj9P2PbULRVh-8Pxyzt3yqxspGnZbv?tab=summary&amp;timestamp=379.0|Strategy Pivot:>*<https://fathom.video/share/goyj9P2PbULRVh-8Pxyzt3yqxspGnZbv?tab=summary&amp;timestamp=379.0| Relaunched to target only "elopement" keywords.>
        ▪︎ *<https://fathom.video/share/goyj9P2PbULRVh-8Pxyzt3yqxspGnZbv?tab=summary&amp;timestamp=379.0|Rationale:>*<https://fathom.video/share/goyj9P2PbULRVh-8Pxyzt3yqxspGnZbv?tab=summary&amp;timestamp=379.0| "Wedding" keywords had poor conversion rates, while search data showed high volume for "elopement" terms.>
    ◦ *<https://fathom.video/share/goyj9P2PbULRVh-8Pxyzt3yqxspGnZbv?tab=summary&amp;timestamp=379.0|Result:>*<https://fathom.video/share/goyj9P2PbULRVh-8Pxyzt3yqxspGnZbv?tab=summary&amp;timestamp=379.0| The new elopement-focused ads are now successfully generating leads.>
• *<https://fathom.video/share/goyj9P2PbULRVh-8Pxyzt3yqxspGnZbv?tab=summary&amp;timestamp=484.0|Lead Quality Monitoring:>*
    ◦ *<https://fathom.video/share/goyj9P2PbULRVh-8Pxyzt3yqxspGnZbv?tab=summary&amp;timestamp=484.0|Threshold for Concern:>*<https://fathom.video/share/goyj9P2PbULRVh-8Pxyzt3yqxspGnZbv?tab=summary&amp;timestamp=484.0| A significant drop in quality (e.g., majority of leads are unresponsive or a poor fit).>
    ◦ *<https://fathom.video/share/goyj9P2PbULRVh-8Pxyzt3yqxspGnZbv?tab=summary&amp;timestamp=484.0|Current Status:>*<https://fathom.video/share/goyj9P2PbULRVh-8Pxyzt3yqxspGnZbv?tab=summary&amp;timestamp=484.0| Quality is high; a few bad leads are normal and not a cause for concern.>
Next Steps
• *<https://fathom.video/share/goyj9P2PbULRVh-8Pxyzt3yqxspGnZbv?tab=summary&amp;timestamp=350.0|Shannon:>*
    ◦ <https://fathom.video/share/goyj9P2PbULRVh-8Pxyzt3yqxspGnZbv?tab=summary&amp;timestamp=350.0|Rename the new, published Meta ad.>
    ◦ <https://fathom.video/share/goyj9P2PbULRVh-8Pxyzt3yqxspGnZbv?tab=summary&amp;timestamp=350.0|Delete the failed ad draft.>
    ◦ <https://fathom.video/share/goyj9P2PbULRVh-8Pxyzt3yqxspGnZbv?tab=summary&amp;timestamp=484.0|Monitor lead quality and report any significant decline.>

> **Gisselle Jiménez** · 2026-08-28 16:59 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1787936382683509)
> Hi, @Jacqueline Hood! Could you please share the recording? I'm not able to download it from Fathom:face_holding_back_tears: Thanks!
> **Jacqueline Hood** · 2026-09-06 01:35 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1788658502236669)
> You bet! @Gisselle Jiménez sorry for the delay!
> 📎 Impromptu Zoom Meeting - Aug 27 2026.mp4 (mp4, **not downloaded** — over cap (111.6 MB), [fetch it](https://files.slack.com/files-pri/T03P5A3L1DK-F0BV7JV5JBY/download/impromptu_zoom_meeting_-_aug_27_2026.mp4))

**Jacqueline Hood** · 2026-09-03 22:12 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1788473529567169)
No attendees for office hours today @Gisselle Jiménez

**Notification Bot** · 2026-09-10 18:01 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1789063272434269)
Myla Garlitz has joined on for the Meta Ads Immersive Experience!:partying_face:
> **Gisselle Jiménez** · 2026-09-10 18:09 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1789063764964489)
> @Whitney Hodges I have changed this to Meta Ads Acelerator in Zapier now! Also, I saw the welcome email error in Dubsado and it's because it got disconnected when the password was changed. I'm reconnecting it now and sending it manually:)
> **Gisselle Jiménez** · 2026-09-10 18:11 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1789063867138369)
> Reconnected and welcome email sent!

**Jacqueline Hood** · 2026-09-10 21:48 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1789076891432479)
No attendees for office hours today @Gisselle Jiménez

**Gisselle Jiménez** · 2026-09-15 15:41 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1789486909600819)
@Jacqueline Hood @Whitney Hodges Office hours have been changed to Wednesdays 12pm PST (2pm CST) starting tomorrow! Announcement has been posted
> **Whitney Hodges** · 2026-09-15 16:15 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1789488904195369)
> @Gisselle Jiménez Can we send out an email too please?
> **Gisselle Jiménez** · 2026-09-15 16:22 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1789489357313629)
> @Whitney Hodges Absolutely! I can send this from LeadLock as Jacqueline to Myla, Shannon, Samantha, Teresa. Would that work?
> 
> &gt; *Subject:* Meta Ads Office Hours Moving to Wednesdays
> &gt; Hi client name,
> &gt; Starting tomorrow, Meta Ads Weekly Office Hours is moving to a new time.
> &gt; *New Schedule:*
> &gt; Wednesdays at 12pm PST / 2pm CST / 3pm EST
> &gt; Please update your calendar so you don't miss our sessions!
> &gt; Zoom link: <https://weddingindustryads.com/jacqueline-zoom1|weddingindustryads.com/jacqueline-zoom1>
> &gt; If you have any questions, let us know!
> &gt; Best,
> &gt; Jacqueline
> **Jacqueline Hood** · 2026-09-15 16:51 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1789491060648029)
> Thank you!!
> **Whitney Hodges** · 2026-09-15 17:28 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1789493302301099)
> @Gisselle Jiménez Yes, please!!
> **Gisselle Jiménez** · 2026-09-15 18:07 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1789495653539789)
> Email sent!

**Jacqueline Hood** · 2026-09-16 20:01 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1789588887132869)
No attendees for office hours today @Gisselle Jiménez

**Jacqueline Hood** · 2026-09-23 20:03 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1790193788919069)
No attendees for office hours today @Gisselle Jiménez

**Gisselle Jiménez** · 2026-09-24 22:22 · [link](https://weddingindustryads.slack.com/archives/C082DURRJ2U/p1790288535167929)
:checkered_flag:Myla Garlitz booked their Meta Ads Accelerator Kickoff Call!

Booked with: Whitney Hodges
Appointment Date &amp; Time: Tuesday, September 29, 2026 2:00 PM 
 PDT
