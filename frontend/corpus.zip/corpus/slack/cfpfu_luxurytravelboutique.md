# #cfpfu_luxurytravelboutique

Private channel · `C08QU9K31KN`
Pulled 2026-09-25 by `corpus/fetch-slack.mjs`.

188 parent messages · 245 thread replies · 32 files downloaded.
Covers 2025-05-14 → 2026-09-04.

Thread replies are indented with `>`. Every message links back to Slack, so a
candidate drawn from here carries its source the way a transcript quote carries
a timecode.

---

**Nicole Bautista** · 2025-05-14 16:16 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1747239398686589)
@Whitney Hodges @Carmen Cruickshank Hi! Here is Beth’s <https://portal.dubsado.com/public/form/view/6813c321e03a2f003ac2d906|onboarding questionnaire>. Her <https://drive.google.com/drive/folders/1ZRsLGPhS8wyHRVXizGiwlSiAIzQz1m-b?usp=sharing|Google Drive Folder> and <https://docs.google.com/document/d/16Fe9DMyBhawQpHlPP_yoF9-1SwlM-FQurV_ocSwOStw/edit?usp=drive_link|Onboarding Checklist> are also pinned as bookmarks at the top of this channel.

**Carmen Cruickshank** · 2025-05-14 16:55 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1747241731731039)
thank you @Nicole Bautista!

**Nicole Bautista** · 2025-05-15 17:37 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1747330652061599)
@Carmen Cruickshank @Whitney Hodges, Here’s the draft email for Beth. Let me know if there are any action items you'd like to include.

_Hi Beth,_ 

_We want to again extend a heartfelt welcome to Wedding Industry Ads! It was a pleasure meeting with you on the call, and we are so excited to get started!_

_For your reference, I wanted to share the recording of the call and the presentation we reviewed. You can access them through the links below:_

• _<https://drive.google.com/file/d/1L2oVDtBLGwEeedOmVzMhKIZr645F1GWR/view?usp=drive_link|Onboarding Guide Presentation>_
• _<https://drive.google.com/drive/folders/1T0pqcZ_4LNZv2Zfg20Cu9u1CW4diFVcp?usp=sharing|Call Recording>_
_Please reach out if you have any questions or concerns!_

_Thank you,_
_Whitney_
> **Whitney Hodges** · 2025-05-15 17:57 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1747331860401219)
> @Nicole Bautista We had another call with her today, too, and there is even more info I owe her, so no need to send this email. I plan to email her tomorrow. Thank you!!

**Whitney Hodges** · 2025-05-19 19:12 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1747681978984129)
@Carmen Cruickshank Hi! I've invited you to be an admin on the Luxury Travel Boutique FB page. If you visit <https://www.facebook.com/experienceluxetravel>, you should be able to view and accept the request. This should suffice until we are able to move the page from the Beth Rasor Meta Business Portfolio to the Luxury Travel Boutique Business Portfolio and connect FB &amp; IG. Beth and I now have access to everything that we need, but we have to wait a week before making any changes since we are new admins on the account.

I met with Felipe a couple of times today to troubleshoot all of this and let him know that he needs to prioritize the Thank You page(s) in order for us to get Google Ads running

**Carmen Cruickshank** · 2025-05-19 20:13 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1747685606585839)
Sounds good! Thank @Whitney Hodges  I will check to make sure I have access tomorrow

**Carmen Cruickshank** · 2025-05-21 14:20 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1747837229887329)
@Whitney Hodges Hi! So I'm creating their Google Ads right now and noticed I couldn't put the code in for Google Tag Manager because I see with all other websites we have permission with on Squarespace as an Admin but only with Luxury Travel Boutique we only have Website Editor and Reporting permissions. Should I just email Beth about this?
> **Whitney Hodges** · 2025-05-21 14:21 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1747837278972839)
> @Carmen Cruickshank Yes, please send an email requesting Admin permission. I'm sure they can get it taken care of ASAP. Thank you!
> **Carmen Cruickshank** · 2025-05-21 14:28 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1747837710663799)
> Of course!

**Carmen Cruickshank** · 2025-05-23 18:46 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1748026004019359)
Creatives Doc: <https://docs.google.com/document/d/1R4vu8eBhRGavWOeylHjBVI13E5ZCbvju8ZnQ40ZmK2w/edit?usp=sharing> @Whitney Hodges

**Whitney Hodges** · 2025-05-24 00:42 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1748047322333539)
@Carmen Cruickshank I just saw Beth's email with feedback on the Google Ads. After you've implemented the changes she has requested, I think it will be best for you to get on a call with her to present everything, so that if she wants changes they can be made in real time. We'll work on getting a scheduler for client calls created for you, so she can easily book a time on  your calendar. Also, @Christina Hill may have some good insights to share with you during your next Google Ads meeting on how she uses the existing copy on a client's website to craft the copy for their Google Ads. Thank you!!

**Carmen Cruickshank** · 2025-05-24 01:19 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1748049587108779)
Sounds good! Love it!

**Whitney Hodges** · 2025-05-27 13:37 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1748353059228599)
@Carmen Cruickshank Great meeting this morning! To recap, please go through Luxury Travel Boutique's website very closely and consume all the info. Use that to fill in the <https://docs.google.com/document/d/1QiuKFN87rF6xYfvVukk3rg_RHGgxZoPppUyuhDwFym8/edit?usp=sharing|Messaging &amp; Positioning Questionnaire> to the best of your ability. If there is anything that remains unclear, then share the doc with Beth &amp; Felipe and ask for their specific insights.

Once you have that foundation, it's going to give you a jumping off point for writing strong copy to include as text overlays for existing reels for client attraction ads. <https://docs.google.com/document/d/1gtMp5MAkrff50Qp4EQobF5jTMT74fWZxFoJwC27Zq8k/edit?usp=sharing|Here is a copywriting resource you may find helpful.>

Let's use these existing reels for the client attraction ads:
<https://www.instagram.com/p/DJuzxObRxOm/>
<https://www.instagram.com/p/DJpaHb4xCfJ/>

Focus on all of the above first. Then we can work together, on a creative brief for Felipe with some totally fresh ideas including a reel that introduces Beth and features all the locations where she helps couples book their destination weddings.

Thank you!

**Whitney Hodges** · 2025-05-27 14:27 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1748356034645999)
@Carmen Cruickshank Hi! I just had a call with Felipe. We were finally able to get the Luxury Travel Boutique FB &amp; IG pages connected. Also, instead of moving these assets from the Beth Rasor business portfolio into the Luxury Travel Boutique business portfolio, we created a new ad account in the Beth Rasor business portfolio and deactivated the ad account we originally created. Beth needs to add a method of payment to this new ad account, but Felipe is planning to work with her on that.

**Carmen Cruickshank** · 2025-05-28 14:47 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1748443641293929)
@Whitney Hodges This all sounds good, I will be sure to complete the questionnaire, as well as letting felipe know about the multiple location reel. Thank you for the pdate with the IG and FB accounts. I will be sure to get on it!
> **Whitney Hodges** · 2025-05-28 14:55 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1748444157053569)
> @Carmen Cruickshank You can hold off on letting Felipe now about that reel idea until we've had the opportunity to collaborate on a full creative brief for him
> **Carmen Cruickshank** · 2025-05-28 15:36 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1748446603411359)
> Okay sounds good @Whitney Hodges

**Whitney Hodges** · 2025-05-29 17:06 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1748538398855019)
@Megan Jivraj Recurring invoice needs to be created for this client with a monthly due date of the 14th
> **Megan Jivraj** · 2025-05-30 13:41 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1748612466655429)
> @Whitney Hodges This has been created with the first payment due on June 14.

**Carmen Cruickshank** · 2025-06-02 20:51 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1748897460833229)
@Whitney Hodges @Christina Hill Today's meeting with Beth went well in reviewing the messaging for the Google Ads. I'm not starting her campaigns yet because when someone fills in the form, they aren't redirected to the thank you page yet. I also still need to get beth to fill in the messaging and positioning questionare. @Jacqueline Hood I'm getting started on the creatives and brief and curating copy for the text overlay
> **Whitney Hodges** · 2025-06-02 20:53 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1748897596911929)
> @Carmen Cruickshank how much of the interview questionnaire were you able to complete on your own just from doing a deep dive on her website?
> **Carmen Cruickshank** · 2025-06-02 20:56 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1748897765433399)
> I'd say 50% of it.

**Carmen Cruickshank** · 2025-06-02 20:57 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1748897852822109)
Also Beth mentioned to me today that a client found her from ChatGPT. She said she would ask the client how that specifically came about and Beth assumes its because of al the pages on the site and keywords that made chatgpt see her business as relevant to what the client was looking for.
> **Whitney Hodges** · 2025-06-03 15:59 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1748966392674209)
> We've had a couple of leads find us through ChaptGPT recently, too!

**Carmen Cruickshank** · 2025-06-02 20:58 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1748897888829089)
I heard of chatgpt ads existing in the future but this was cool to hear, seems like "chatgpt SEO"

**Jacqueline Hood** · 2025-06-03 15:50 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1748965801628869)
that is so interesting! I wonder if ChatGPT will have its own ads soon lol

**Megan Jivraj** · 2025-06-03 20:54 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1748984097560559)
Hey team! Here are the follow-ups from the June 3 Team Meeting:
1. @Carmen Cruickshank to provide status on ad creative

**Carmen Cruickshank** · 2025-06-05 21:25 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1749158714236489)
Hi @Whitney Hodges! I'm working on the Ads Creative brief and I know we discussed 2 solid ones for me to curate the copy and overall idea, but we mentioned Felipe putting together clips of different locations for the 3rd ad creative. Should I email him now to start creating that or should we present the client attraction ads to Beth and Felipe and then ask for the 3rd reel to be created?
> **Whitney Hodges** · 2025-06-05 21:33 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1749159206614919)
> I'd like us to present client attraction ads first. Then give Felipe a creative brief with a few different ideas
> **Carmen Cruickshank** · 2025-06-05 23:19 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1749165567773689)
> okay sounds good

**Megan Jivraj** · 2025-06-10 20:47 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1749588476764199)
Hey team! Here are the follow-ups from the June 10 Team Meeting:
1. @Carmen Cruickshank to send email with mobile optimization suggestions for landing their landing page (more contact us buttons)

**Carmen Cruickshank** · 2025-06-11 17:26 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1749662793429689)
@Ivy Ayala Hi! Here is the creative brief for the client attraction ads for Luxury Travel Boutique: <https://docs.google.com/document/d/1KhQ_hZ80xXW7oRhgvFLT_v-twzmJ-FhcghlsiktTvsE/edit?tab=t.0> It has only 2 creatives, the third will be coming soon but for now thats all we need.
> **Jacqueline Hood** · 2025-06-12 21:10 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1749762615145319)
> @Carmen Cruickshank I just requested access!
> **Carmen Cruickshank** · 2025-06-13 00:04 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1749773073478669)
> just allowed it let me know if it doesnt

**Carmen Cruickshank** · 2025-06-11 17:26 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1749662815586059)
@Jacqueline Hood I'd love to hear your comments on these! ^ :slightly_smiling_face:

**Carmen Cruickshank** · 2025-06-12 15:39 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1749742793389179)
@Ivy Ayala Hi! If you could give me the first draft of the client attraction ad creatives within the next 24-48 hours that'd be helpful because the client would love to see the ads as soon as possible! Let me know, thank you :blush:
> **Ivy Ayala** · 2025-06-12 22:55 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1749768902019579)
> just requested access
> **Ivy Ayala** · 2025-06-12 23:18 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1749770282013529)
> QQ: do you have content from this client? Or should I take it from socials 
> **Ivy Ayala** · 2025-06-12 23:18 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1749770329045509)
> @Carmen Cruickshank if so, can you please also share it with me? Thanks! 

**Carmen Cruickshank** · 2025-06-13 00:05 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1749773110508319)
@Ivy Ayala im sorry it was the wrong document

**Carmen Cruickshank** · 2025-06-13 00:05 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1749773114450369)
i will resend here

**Carmen Cruickshank** · 2025-06-13 00:25 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1749774333898919)
<https://docs.google.com/document/d/1R4vu8eBhRGavWOeylHjBVI13E5ZCbvju8ZnQ40ZmK2w/edit?tab=t.0#heading=h.svnk6mynj7bw>
> **Ivy Ayala** · 2025-06-13 16:21 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1749831697065329)
> Good morning! Here are the creatives <https://drive.google.com/drive/folders/1aaABtN6n3poanSCQFPqmPxEoFwkNBqTN?usp=sharing>
> **Ivy Ayala** · 2025-06-13 16:22 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1749831740466859)
> @Carmen Cruickshank
> **Carmen Cruickshank** · 2025-06-13 16:29 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1749832190236319)
> @Ivy Ayala Thank you! Those look great! For creative 1 if you could take out the inbox green sticker at the end inferring to private messages to prevent DMS and encourage more website visits.
> **Carmen Cruickshank** · 2025-06-13 16:30 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1749832240559049)
> @Whitney Hodges @Jacqueline Hood What are you're thoughts? I want these to informational but i know since creative 1 is 20 seconds should we take some more copy out of creative one so its not so overwhelming with the words and all the short video clips?
> **Whitney Hodges** · 2025-06-13 16:47 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1749833265541919)
> @Carmen Cruickshank I don't think it's too overwhelming. I think the quick movement will keep attention. I would like to see some minor copy edits. There's nuance with this client because she's technically not a wedding planner yet she does support with wedding planning. I can tell that Beth is sensitive to this distinction. I made copy suggestions in the <https://docs.google.com/document/d/1R4vu8eBhRGavWOeylHjBVI13E5ZCbvju8ZnQ40ZmK2w/edit?tab=t.0|doc>. Sorry, I don't know that I saw this before it was sent over to Ivy but hopefully they are quick edits.
> 
> What's the plan for audio for these?
> 
> cc @Jacqueline Hood @Ivy Ayala
> **Whitney Hodges** · 2025-06-13 16:50 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1749833405840129)
> Nvm about the audio, my sound was muted and I didn't know it :joy:
> **Carmen Cruickshank** · 2025-06-13 16:56 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1749833761537119)
> @Whitney Hodges Okay sounds good for creative 1! I remember in her emails and when speaking on the phone that she is a wedding planner and would rather put herself out there as a wedding planner than a travel agent. These are some snippets of her email when she responded to my first draft of Google Ad Copy: "_We aren't just travel agents that book rooms for wedding groups. We are a full service destination wedding planners that assist with both travel accommodations for guests AND wedding planning. Couples have full support on both the travel side and wedding side of planning."_  and "_Your Luxury Wedding Planner - Change to Destination Wedding Planner (Luxury Wedding can mean anything)"_
> **Carmen Cruickshank** · 2025-06-13 16:56 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1749833815010359)
> If she said something else to you let me know but from what Ive seen and heard it sounds that she wants to market herself and services from that angle. But I can definitely make those edits to get these meta ads running as soon as possible.
> **Whitney Hodges** · 2025-06-13 16:58 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1749833926940609)
> @Carmen Cruickshank Thank you for this!!! I must be getting her mixed up with another client. Go ahead and keep the text in the creatives as is!!
> **Whitney Hodges** · 2025-06-13 16:59 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1749833941811389)
> I think they look really good. Great job!!
> **Carmen Cruickshank** · 2025-06-13 17:00 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1749834055110759)
> ok perfect! @Whitney Hodges thanks and thank you @Ivy Ayala!
> **Jacqueline Hood** · 2025-06-13 17:42 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1749836524283279)
> The creatives are beautiful! My only feedback is that it would be nice to show some clips of couples in there, brides, grooms, the party, the wedding party, etc. There's some shots of tables etc but actually seeing the bride/groom would be nice too!
> **Carmen Cruickshank** · 2025-06-16 14:28 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1750084128991909)
> thats helpful thank you @Jacqueline Hood

**Whitney Hodges** · 2025-06-13 15:32 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1749828742518599)
@Carmen Cruickshank Hi! I've forwarded you a few emails over the last few days that Beth has been forwarding to me from Google. Do any of these require action on our part? cc @Christina Hill
📎 image.png (png, saved as `files/F09167V3GQK-image.png`)
📎 image.png (png, saved as `files/F090XF8AJ7R-image.png`)
📎 image.png (png, saved as `files/F09167BS3RU-image.png`)

**Carmen Cruickshank** · 2025-06-13 15:50 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1749829817778409)
Hi @Whitney Hodges! Yes i just saw the email aobut those and her question. Those don't require any action because i since i have the conversion tracking in place the "objective" is set. Christina and I talked about this that if a campaign objective is set like "leads" it can take the CPC up a lot which isn't good for low budget ads.
> **Carmen Cruickshank** · 2025-06-13 15:54 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1749830093386199)
> also i'll be sure to have more of a mental timeline in the future when it comes to meta ads with FS clients to ensure everything stays within the contract, expectations and is timely

**Carmen Cruickshank** · 2025-06-13 17:01 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1749834082263499)
@Ivy Ayala here is the updated creatives breif: <https://docs.google.com/document/d/1R4vu8eBhRGavWOeylHjBVI13E5ZCbvju8ZnQ40ZmK2w/edit?tab=t.0> Whitney made some edits to the copy to make it better but other than that its great
> **Ivy Ayala** · 2025-06-13 19:53 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1749844391085189)
> I already edited them! they are in the folder I shared with you, I saw some comments from Jacqueline to add some brides, do you have any content of brides I can add here?
> **Ivy Ayala** · 2025-06-13 19:53 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1749844403698369)
> @Carmen Cruickshank
> **Carmen Cruickshank** · 2025-06-13 22:53 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1749855219308209)
> @Ivy Ayala I didn’t see the brides comment yet but I will get back to you on that
> **Carmen Cruickshank** · 2025-06-13 22:53 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1749855237653779)
> Thank you for those edits I’ll check em out and let you know what I think

**Carmen Cruickshank** · 2025-06-13 19:06 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1749841594677899)
updated client attraction ads headline &amp; primary text copy: <https://docs.google.com/document/d/1KhQ_hZ80xXW7oRhgvFLT_v-twzmJ-FhcghlsiktTvsE/edit?tab=t.0> @Whitney Hodges @Jacqueline Hood if you want to check it out before I make the client attraction ads early next week, thank you for the initial comments Jacqueline, very helpful!

**Carmen Cruickshank** · 2025-06-16 14:32 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1750084365237199)
@Whitney Hodges i'll send beth the 2 client attraction ads we have so far, here is the doc: <https://docs.google.com/document/d/1KhQ_hZ80xXW7oRhgvFLT_v-twzmJ-FhcghlsiktTvsE/edit?tab=t.0>
> **Whitney Hodges** · 2025-06-16 15:01 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1750086081128499)
> @Carmen Cruickshank Ok, I made some minor copy edits.
> 
> Along with sending her these for review/approval, I'm thinking we should send concepts for additional ad creatives.
> 
> I've started working with Lily on this this morning.
> 
> <https://chatgpt.com/g/g-6849fc80c4d881919d517caff6a68f35-lily|Here's the link for her.> Does it let you see my chat history with her?
> **Whitney Hodges** · 2025-06-16 15:06 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1750086381030409)
> Can you download everything Luxury Travel Boutique has in the Google Photos folder they shared with us and upload it to a Google Drive folder with "Anyone with the link can view" permissions? Then Lily will be able to see the contents and can incorporate that footage into storyboards
> **Carmen Cruickshank** · 2025-06-16 15:20 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1750087208395459)
> Okay thank you! I will make a document of how many concepts of additional ad creatives? 3?
> **Carmen Cruickshank** · 2025-06-16 15:20 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1750087213804479)
> and yes i will try that
> **Whitney Hodges** · 2025-06-16 15:24 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1750087445091259)
> However many you think. We can send them several and ask them to pick their favorites. Any chance you are available at 3pm CST to review together today? Or we could do tomorrow morning at 8am or 9am CST?
> 
> As long as we send Beth an email by mid-day tomorrow, we should be in good shape.
> 
> Since Meta Ads are delayed for her, I'd rather send over more than less at this point, to make it apparent that we've been hard at work behind the scenes, if that makes sense.
> **Carmen Cruickshank** · 2025-06-16 15:27 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1750087669792069)
> that makes sense, i was thinking 3-5 ill take some concepts from lily, and im available tomorrow 8am CST
> **Carmen Cruickshank** · 2025-06-16 15:28 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1750087732700849)
> i was thinking of making the concepts today and attaching that to the doc and emailing her by the end of the day, does that sound good or would you like to go over it in the call tommorow?
> **Whitney Hodges** · 2025-06-16 15:30 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1750087818507389)
> Ok, sounds good. I think the only way you'll be able to see my conversation history with Lily is if you log into ChatGPT using the hello@weddingindustryads gmail account. Let's review together on the call tomorrow and then email Beth
> **Carmen Cruickshank** · 2025-06-16 15:31 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1750087867606279)
> okay ill try that, and sounds good!!
> **Carmen Cruickshank** · 2025-06-16 17:10 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1750093818659939)
> hey @Whitney Hodges i tried to get all the videos and photos from the google ads photo folder and upload it and it wasnt working with lily. I even took it out of the whole wedding industry ads folder and everytime made sure there was access to anyone with the link, that its unrestricted and lily was still asking me to describe whats in there, still wasnt abel to access it but i still have the concepts from lily just not the full storyboards
> **Whitney Hodges** · 2025-06-16 17:15 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1750094138420889)
> @Carmen Cruickshank Aw man, that's annoying. I went ahead and asked her for voiceover scripts and audio pairings for each reel idea if you want to check those out
> **Carmen Cruickshank** · 2025-06-16 17:16 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1750094198526069)
> yea ill check it out

**Megan Jivraj** · 2025-06-16 14:42 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1750084978552519)
Hey @Carmen Cruickshank Beth received an email from Google suggesting adding negative keywords. She has provided a list of negative keywords (destinations they don't plan) that she thinks would be good examples. What are your thoughts on this?
Additionally, they received a notification that someone from EmailMeForm had been added to their Google Drive folder. Was this done on our end? They have removed the person. Thanks!
cc: @Whitney Hodges

**Carmen Cruickshank** · 2025-06-16 14:49 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1750085355787069)
@Megan Jivraj I sent them a performance review 5 days ago about their account and already went over the negative keywords that i added from irrelevant searches, they never responded but i hope she saw it. I didn't add the emailmeform to the google ads account but thats good she removed it. cc:@Whitney Hodges

**Megan Jivraj** · 2025-06-17 20:55 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1750193749378529)
Hey team! Here are the follow-ups from the June 17 Team Meeting:
1. @Megan Jivraj to adjust the renewal date on the recurring invoice to November 27
> **Megan Jivraj** · 2025-06-18 20:47 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1750279659571089)
> @Whitney Hodges I've updated this to start on November 27 and every 27th of the month thereafter.

**Carmen Cruickshank** · 2025-06-18 15:54 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1750262047321959)
hey @Whitney Hodges! Did you see Felipe's email response to the ads? I can book a call tomorrow or Friday morning to discuss the meta ads but what are your thoughts?
> **Whitney Hodges** · 2025-06-18 15:57 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1750262257838049)
> just sent you a dm

**Megan Jivraj** · 2025-06-26 17:41 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1750959692684839)
Hey team! Here are the follow-ups from the June 24 Team Meeting:
1. @Carmen Cruickshank to provide an audit
2. @Carmen Cruickshank to look at providing Felipe with more direction for the videos paired with the scripts

**Carmen Cruickshank** · 2025-07-07 15:43 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1751902995435059)
@Jenna Tria Just curious the progress on the monthly report slides, let me know how its going or if i can help in any way:blush:

**Jenna Tria** · 2025-07-07 15:48 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1751903283043749)
@Carmen Cruickshank Hi! I just gained access to Google Ads today!

**Carmen Cruickshank** · 2025-07-07 15:48 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1751903313256709)
No worries, thank you for letting me know! @Jenna Tria

**Jenna Tria** · 2025-07-07 16:48 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1751906927697979)
@Christina Hill @Carmen Cruickshank Here's the monthly report for <https://www.canva.com/design/DAGsgHySLdA/LihrQl5NdqObfqCKFv2Q1A/edit?utm_content=DAGsgHySLdA&amp;utm_campaign=designshare&amp;utm_medium=link2&amp;utm_source=sharebutton|Luxury Travel Boutique>, ready for your review. Let me know if you need any changes or further adjustments. Thank you!

**Megan Jivraj** · 2025-07-08 19:30 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1752003037248899)
Hey team! Here are the follow-ups from the July 8 Team Meeting:
1. @Carmen Cruickshank to include a strategy call link with Whitney in monthly report email (push the call and communicate area of opportunity for the landing page, mention we understand it’s a busy time and we want to help with ad creatives we just need access)

**Carmen Cruickshank** · 2025-07-13 23:36 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1752449817238389)
@Ivy Ayala Here is the client attraction creatives brief for luxury travel boutique! ideally the client wants this done within 48 hours but i get back on Thursday so no pressure: <https://docs.google.com/document/d/1cfzYFJMn-EcL9huD8l34340SiRHpaZI9Ng-CuPtGl1w/edit?usp=sharing>
> **Ivy Ayala** · 2025-07-14 15:17 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1752506223636919)
> perfect! working on it tomorrow :heart:
> **Whitney Hodges** · 2025-07-17 18:54 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1752778442175319)
> @Carmen Cruickshank @Ivy Ayala any update on these? I'd really like to have something over to them for review before the weekend
> **Ivy Ayala** · 2025-07-17 19:38 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1752781100132439)
> working on it! sorry I have been a lit bit sick but feeling better now
> **Whitney Hodges** · 2025-07-17 19:50 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1752781844833669)
> Sorry to hear you were sick! Glad you're feeling better!!
> **Carmen Cruickshank** · 2025-07-17 19:55 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1752782148937819)
> Glad you’re better as well @Ivy Ayala 
> **Ivy Ayala** · 2025-07-17 21:27 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1752787675721699)
> <https://www.canva.com/design/DAGtc57e34Y/XulyjEFCK-ItwvmOnvYDGg/edit?utm_content=DAGtc57e34Y&amp;utm_campaign=designshare&amp;utm_medium=link2&amp;utm_source=sharebutton|Creative 1> <https://www.canva.com/design/DAGtc9t5E04/WFV_bLfOqUJN1hDOXoieng/edit?utm_content=DAGtc9t5E04&amp;utm_campaign=designshare&amp;utm_medium=link2&amp;utm_source=sharebutton|C2> <https://www.canva.com/design/DAGtdJwuaAY/khoEz3qUibGI8xrpdEcaLA/edit?utm_content=DAGtdJwuaAY&amp;utm_campaign=designshare&amp;utm_medium=link2&amp;utm_source=sharebutton|C3>
> **Ivy Ayala** · 2025-07-17 21:28 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1752787684095319)
> @Carmen Cruickshank
> **Ivy Ayala** · 2025-07-17 21:28 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1752787690329529)
> Hey! here's the content
> **Whitney Hodges** · 2025-07-17 22:54 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1752792841685699)
> @Ivy Ayala Thank you! Carmen will send over some edit requests. Also, just FYI we're going to looping in Yulia on some additional video creatives for this client because we're needing a super fast 24 hour turnaround time. Normally, we love to send everything your way, but didn't want to dump a ton on you so last minute.
> **Ivy Ayala** · 2025-07-18 15:03 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1752850997168119)
> Thanks for the heads-up! I totally understand the quick turnaround needs. I apologize for the delay this week, I’ll make sure to stay on top of deadlines moving forward and get content to you on time.  @Whitney Hodges :heart:

**Carmen Cruickshank** · 2025-07-14 14:55 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1752504949588709)
update for tommorow's meeting: Google Ads - Still no conversions, have yet to hear from them on what they think of my comments on their landing page, good click through rate, search terms though

**Carmen Cruickshank** · 2025-07-14 14:56 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1752504988306659)
Meta Ads - Their Clients attraction ads were submitted to ivy, using the comments and their input on what they think works for ads, we just want to get things rolling

**Whitney Hodges** · 2025-07-17 23:09 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1752793762783229)
@Carmen Cruickshank @Yulia Burris Hi! I put a call on the calendar for us for 9am EST tomorrow.

Yulia, I forwarded you a lot of email correspondence with the client, so you can bring yourself fully up to speed. Please watch <https://zoom.us/rec/share/fRmKhyesXI7iHsexyY-PapJ8UCAG09HvRGebjlj0oVR_byKGUWhaWSnjszvrEp0_.PCIWo_t81tBpUrtQ?startTime=1750448016000|this call recording>, too.

Essentially, what we need for tomorrow is for you to bring the <https://docs.google.com/document/d/1WzAt3kJPlP35XFaMioVnfXL2QT8IcaIn_R4e3vjXnc8/edit?tab=t.bbiuq5hbmu00#heading=h.sajyxk5ywqos|Additional Ad Concepts (second tab) on this doc> to life using any of <https://photos.google.com/share/AF1QipOgB3N-pzIoC-0oumR_rSfAplnrjFYWrG2pQUBHAg3pIh-sm1FsY72Vw5vU5ZRIdg?key=V293dUV3YVZNa1U3SmZOTW9CWjBvZ0EweENSZmdR|this photo and video footage> provided by the client.

Not at all expected, but depending on how fast you work, there's also a third tab called Scripts you could create reels for. We still need voiceovers from the client, but you could just use the scripts as text overlays in the meantime.

Thank you so much! We appreciate you!!!
> **Yulia Burris** · 2025-07-18 17:56 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1752861379522019)
> @Carmen Cruickshank @Ivy Ayala  Hi! <https://docs.google.com/document/d/1WzAt3kJPlP35XFaMioVnfXL2QT8IcaIn_R4e3vjXnc8/edit?usp=sharing|In Reel #3>, they added a link, but I’m getting an error when I try to open it. Do you have the right one? Or is it the same link with all the photos and videos? It seems like it could be a different one.
> 📎 Screenshot 2025-07-18 at 1.48.29 PM.png (png, saved as `files/F0962LC3LNB-Screenshot_2025-07-18_at_1.48.29_PM.png`)
> **Carmen Cruickshank** · 2025-07-18 18:51 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1752864678179019)
> I'm looking into it right now
> **Carmen Cruickshank** · 2025-07-18 18:53 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1752864812693459)
> not sure why its the 404 error message, but any emotional looking videos of couples would work
> **Carmen Cruickshank** · 2025-07-18 18:53 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1752864816839229)
> @Yulia Burris

**Carmen Cruickshank** · 2025-07-18 00:16 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1752797767136939)
@Ivy Ayala Thank you for the creatives! They loook great! Here is the updated ad creative brief: <https://docs.google.com/document/d/1cfzYFJMn-EcL9huD8l34340SiRHpaZI9Ng-CuPtGl1w/edit?pli=1&amp;tab=t.0> very similar but I highlighted the changes I suggest being made to the creatives befoer it's sent to the client. @Whitney Hodges add anything that i might have missed to add to the doc

**Whitney Hodges** · 2025-07-18 12:39 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1752842374563629)
@Carmen Cruickshank @Ivy Ayala I'd make POV too more about the bride than the wedding planner. Something like POV: You had the most epic destination wedding to your forever love with all your favorite people by your side because you hired the right wedding planner

@Ivy Ayala any chance you can make these edits today, please? :grin:
> **Ivy Ayala** · 2025-07-18 15:01 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1752850865749889)
> <https://www.canva.com/design/DAGtc57e34Y/XulyjEFCK-ItwvmOnvYDGg/edit?utm_content=DAGtc57e34Y&amp;utm_campaign=designshare&amp;utm_medium=link2&amp;utm_source=sharebutton|creative 1> <https://www.canva.com/design/DAGtc9t5E04/WFV_bLfOqUJN1hDOXoieng/edit?utm_content=DAGtc9t5E04&amp;utm_campaign=designshare&amp;utm_medium=link2&amp;utm_source=sharebutton|Creative 2> <https://www.canva.com/design/DAGtdJwuaAY/khoEz3qUibGI8xrpdEcaLA/edit?utm_content=DAGtdJwuaAY&amp;utm_campaign=designshare&amp;utm_medium=link2&amp;utm_source=sharebutton|Creative 3>
> **Ivy Ayala** · 2025-07-18 15:01 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1752850873698759)
> @Carmen Cruickshank @Whitney Hodges
> **Ivy Ayala** · 2025-07-18 15:01 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1752850886928489)
> I remain attentive to your comments :slightly_smiling_face:
> **Whitney Hodges** · 2025-07-18 15:05 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1752851126953289)
> @Carmen Cruickshank @Ivy Ayala I think these look great!!
> **Carmen Cruickshank** · 2025-07-18 15:48 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1752853704898289)
> @Ivy Ayala @Whitney Hodges Yes! I think these look great! Amazing job Ivy!! I'll organize these on a doc Whitney to be ready to present to beth as well as yulias additional concept ad creations too

**Ivy Ayala** · 2025-07-18 14:54 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1752850469236279)
yes! working on it

**Ivy Ayala** · 2025-07-18 14:54 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1752850476203109)
@Whitney Hodges

**Carmen Cruickshank** · 2025-07-18 21:20 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1752873604027979)
@Yulia Burris How are you on ad creation? Let me know if there's any way I can support you!
> **Yulia Burris** · 2025-07-18 21:23 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1752873781006589)
> @Carmen Cruickshank Everything’s good! I’ll let you know when I’m finished. I’m trying to be creative:grinning:..they don’t have many videos with couples, but I’m doing my best))
> **Carmen Cruickshank** · 2025-07-18 21:39 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1752874743811769)
> @Yulia Burris Yea i know what you mean, i can send you something i found

**Yulia Burris** · 2025-07-19 00:52 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1752886326003019)
@Whitney Hodges @Carmen Cruickshank
<https://drive.google.com/drive/folders/1RDAEyDLA5B-vUH3Wxy8nxG-_sqlOyhHt?usp=share_link|Videos are all ready>! Let me know if you’d like any changes.

**Carmen Cruickshank** · 2025-07-19 01:01 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1752886887481199)
great job @Yulia Burris! THESE LOOK AMAZING! some quick fixes could be: just take out all dashes, i think it was on the 3rd reel and change the word travel planning in the 2nd reel to planning your travel, the client got really picky with that
> **Yulia Burris** · 2025-07-19 01:10 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1752887419721319)
> @Carmen Cruickshank All fixed! Lmk if you need any more edits)
> **Carmen Cruickshank** · 2025-07-19 01:12 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1752887568941539)
> thank you Yulia! ill let you know @Yulia Burris
> **Carmen Cruickshank** · 2025-07-19 01:13 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1752887596052379)
> its good as it right now though, have a great weekend
> **Yulia Burris** · 2025-07-19 01:15 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1752887708704049)
> @Carmen Cruickshank thank you!! You too :dizzy: :cherry_blossom: 

**Whitney Hodges** · 2025-07-22 13:59 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1753192753821729)
@Carmen Cruickshank Hi! I know you've said we aren't seeing conversions on Google. Do we have any tracking in place to tell us what visitors are doing when they get to the page? Like how much time they are spending, what buttons (if any) are they clicking? If tracking for any of this isn't set up, @Christina Hill should be able to walk you through what to do.

At this point, I think we've reached out multiple times to ask them to get on a strategy call with us, and they haven't. We need to formally tell them what they need to do to improve the destination weddings landing page. If I'm remembering correctly, the biggest areas of opportunity are adding more CTA buttons and mentioning on the page the actual destination locations people are searching/clicking on, but I'm sure there are more.

I'd like to see you record a video walkthrough detailing this but also provide them with a bulleted list of the changes we're suggesting and put that in the body of the email, so it's very apparent. Please prioritize this for this week.

In response to Beth's most recent email requesting edits, can you please send something along these lines? Reply all and also copy @Yulia Burris

_Thank you so much for your notes! I'm looping in Yulia from our team. She'll be making these edits and supporting with your Meta ad campaigns. As she's working through these changes, she'll reach out if she comes across any questions for you._

**Carmen Cruickshank** · 2025-07-22 15:05 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1753196759688969)
@Whitney Hodges Yes I will check and get back to you on visitor behavior! I will re-email them on what they can improve in their landing page and yes those are the main improvements that need to be made. And I will reply with that message

**Carmen Cruickshank** · 2025-07-22 15:52 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1753199537823969)
@Whitney Hodges checking squarespace for LTB, wondering if you could verify for me getting in through hello@

**Carmen Cruickshank** · 2025-07-22 15:52 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1753199565943259)
thank you!

**Whitney Hodges** · 2025-07-25 04:13 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1753416837074659)
@Yulia Burris Here is some <https://docs.google.com/document/d/1xYyHTh8iqNHaTrmyYWlcZgEDVsz8l4dKPNYy-UgmMLA/edit?usp=sharing|ad copy for LTB.> When you have the creatives revised can you please email this to them as well? Thank you so much!!

**Gisselle Jiménez** · 2025-07-28 16:05 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1753718752163649)
Hey @Carmen Cruickshank! Beth just forwarded another email regarding the _Google Ads Smart Bidding credit_. Based on your last feedback, I went ahead and drafted the response below — but I know you were planning to check in with Christina about it.
Let me know your thoughts or if this is good to go so we can send a reply to the client. Thanks!

Hi Beth,

Thanks for forwarding this over!

We did take a closer look, and while switching to a Smart Bidding strategy like _Maximize Conversions_ would unlock the $100 Google Ads credit, we're currently seeing some issues with the landing page that could affect performance.

Our concern is that moving to Smart Bidding too soon—especially with a daily budget around $16.66—might lead to higher cost-per-click (we've seen CPCs spike up to $18) without generating the results you're looking for. In some cases, Smart Bidding can burn through the budget quickly if the campaign isn’t set up strategically.

For now, we recommend holding off on switching bidding strategies until the landing page is better optimized. That way, any investment (including the ad credit) can work more efficiently toward conversions.

Best,
Whitney
> **Gisselle Jiménez** · 2025-07-28 16:05 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1753718759114119)
> cc: @Whitney Hodges
> **Whitney Hodges** · 2025-07-28 17:24 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1753723452514159)
> @Gisselle Jiménez Thank you so much! I made some minor tweaks to the draft and sent it over and cc'ed Carmen

**Carmen Cruickshank** · 2025-07-28 16:22 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1753719773131299)
@Gisselle Jiménez Hi! Yes i don't believe smart bidding would be good for this campaign in Google Ads simply because their landing page isn't working for any conversions right now. That's a good email draft. cc: @Whitney Hodges @Christina Hill

**Ivy Ayala** · 2025-08-05 15:00 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1754406040754799)
Good morning! Here's the <https://www.canva.com/design/DAGvNldrLgY/yOL_KnV2z1-ZvJ7SKgr8FQ/edit?utm_content=DAGvNldrLgY&utm_campaign=designshare&utm_medium=link2&utm_source=sharebutton|Monthly report July> let me know your comments! @Yulia Burris @Carmen Cruickshank

**Carmen Cruickshank** · 2025-08-05 15:13 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1754406835521209)
thank you @Ivy Ayala

**Carmen Cruickshank** · 2025-08-07 17:51 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1754589061201739)
hey @Whitney Hodges @Yulia Burris ! Beth responded to my email aobut shortnering the form with this:
_Thank you for your email!_  

_Can you please clarify what an impression is?_ 

_I reviewed the planning form to consider if there are any questions being asked that would cause a prospective client to have to leave and come back to the form to finish it. One question was, when are you available to meet - which was an open ended text box question. For some, answering that question may prove to be difficult. Therefore, I changed it to a multi-choice_

_The rest of the questions are pretty straight forward and involve just a click and the form can be completed in under 60 seconds._  

_If there are additional questions that you think can be removed to make the form more straightforward, please let me know your thoughts : )_ 

**Carmen Cruickshank** · 2025-08-07 17:53 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1754589231027189)
i was thinking the name of the other couple, their email, if they want an all-inclusive resort, and maybe more can be taken off, want to hear your guys' thoughts
> **Whitney Hodges** · 2025-08-08 16:40 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1754671247348989)
> @Carmen Cruickshank yes, I agree. I think the deeper issue could be asking people to inquire solely to get on a call. It may be different once Meta Ads start running, but what we're starting to see across the industry is that couples aren't ready to go straight to getting on a call, especially if it's cold traffic. They want more information first.
> 
> In the meantime, there could be the opportunity to include on the page where the form is embedded more context as to why they should schedule a call and what to expect. Basically, what's in it for them. Maybe even referring to it differently as a "complimentary destination wedding planning session".  I'd love to know from Beth three to five bullet points of what couples walk away with after the call. This could even be a video Beth records to try to get them on a call.
> 
> There could be a very simple lead capture form for name and email. Then they could get an email about scheduling a call. Then she could send them the lengthy form to fill out prior to the call.
> 
> I think she just needs to be open to restructuring things and having an actual conversation with us instead of email dialogue.
> 
> Let's see how things go once Meta Ads start running next week, then go from there.
> **Carmen Cruickshank** · 2025-08-08 17:29 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1754674185776699)
> @Whitney Hodges make sense, i completely agree and believe that'd a better way to do it. Yes, we can let Meta Ads run and then give her this further feedback soon. i did get back to her saying some few things she can remove but it was wasnt the full picture
> **Whitney Hodges** · 2025-08-08 17:31 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1754674304795849)
> @Carmen Cruickshank yes, I saw that, and she pushed back and basically said no
> **Carmen Cruickshank** · 2025-08-11 14:12 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1754921549716099)
> @Whitney Hodges yea, i think after the meta ads i can get back to her on this thought

**Whitney Hodges** · 2025-08-08 14:42 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1754664144771689)
@Christina Hill @Carmen Cruickshank Good morning! Yulia and I just worked on creating a Meta pixel for Luxury Travel Boutique and updating their <https://docs.google.com/spreadsheets/d/11J90zuJB-1QITX0euC8unptDkHbRUwkjRM4hMSIxBqg/edit?gid=0#gid=0|funnel map>.

The Meta Pixel ID is 1422249285647563. Beyond creating the pixel, we haven't done anything as far as set up inside the Ads Manager. Does anything need to happen there to connect it to GTM?

Carmen, can you please fill in what the thank you page URL is on the funnel map? I didn't want to have to do a test inquiry.

Christina, does this give you what you need to install tracking?
> **Christina Hill** · 2025-08-08 15:22 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1754666532035809)
> :+1::skin-tone-4:  Yes. 
> **Carmen Cruickshank** · 2025-08-08 16:23 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1754670194751019)
> @Whitney Hodges yes i will fill it in!
> **Christina Hill** · 2025-08-08 16:35 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1754670918734459)
> All done. :white_check_mark: PV, ViewContent, and Lead Events should now be firing for Meta. Please let me know what you see on your end.
> 
> Carmen, for the Lead event, I used the Page URL that was being used to track leads on Google. I hope that is okay. I went ahead and added it to the funnel map since I was testing all of the other events. :slightly_smiling_face:
> 
> @Carmen Cruickshank @Whitney Hodges @Yulia Burris
> **Carmen Cruickshank** · 2025-08-08 17:27 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1754674026883689)
> @Christina Hill thank you! thats helpful because for some reason after filling on the form it redirected me to squarespace

**Carmen Cruickshank** · 2025-08-22 14:54 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1755874484733229)
@Whitney Hodges Curious what your thoughts are on adding a meta event for Beth's ads that show how many people who click on the ad are going to the destination wedding. Just like were doing on Google so that way if it shows if the form is too extensive or not.
> **Whitney Hodges** · 2025-08-27 13:04 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1756299877290249)
> @Carmen Cruickshank @Yulia Burris Hi! Sorry I totally missed this. We should be able to see on the Meta site how many visits we're getting to the destination wedding landing page and subsequently the form.
> 
> Beth emailed me yesterday, so I'm drafting a reply to her this morning.
> 
> Carmen, can you remind me what the Conversions are that I'm seeing in her Google Ads account. Are those people who have visited the form?
> **Carmen Cruickshank** · 2025-08-27 17:13 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1756314801203809)
> No worries, yea now i can see the amount of people who have seen the form from meta ads. and yes
> **Carmen Cruickshank** · 2025-08-27 17:13 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1756314821214349)
> yes, the conversions are people who visited the form.

**Whitney Hodges** · 2025-08-27 13:09 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1756300160555939)
@Yulia Burris hi! I just saw one of Beth's ads. There are a lot of CTA options at the bottom I've never seen before. Just FYI this may be a new setting of Meta's that we need to turn off next time we launch ads
📎 Screenshot_20250827-080741.png (png, saved as `files/F09C7LQ6D9T-Screenshot_20250827-080741.png`)
> **Yulia Burris** · 2025-08-27 14:06 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1756303609734639)
> @Whitney Hodges Hi! It’s from Meta Advantage+ creative enhancements. It’s turned off. I’ve now duplicated 2 ad creatives with shorter copies and CTAs. We’ll see how it works.

**Carmen Cruickshank** · 2025-08-27 17:15 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1756314945445619)
@Whitney Hodges ill be getting you the stats very soon if you want to include that in the draft email

**Carmen Cruickshank** · 2025-08-27 17:43 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1756316632776109)
@Whitney Hodges Here is the performance summary, let me know if there any other info you want me to look into: *Performance Summary*
*Google Ads (Past 30 Days)*
• Strong Click-Through Rate: *5.78% CTR* (well above industry averages).
• Quality Traffic: *510 clicks* to the website.
• Strong Engagement: *8.24%* of visitors (42 people) reached the destination form.
• Conversion Block: *0 form submissions* despite consistent form views.
• This indicates that the form itself is the barrier. Visitors are relevant and engaged but are not completing the step due to friction in the form.
*Meta Ads (Conversions Campaign)*
• Healthy Click-Through Rate: *2.01% CTR* (benchmark is 1–2%).
• Traffic Quality: *53 link clicks*, with *47 landing page views* (*88.86% view rate* per click).
• High Intent: Out of those landing page views, *12 visitors* went to the form.
• Conversion Block: *0 submissions*, mirroring the same barrier seen on Google Ads.
*Conclusion*
Both Google and Meta are driving qualified, interested visitors all the way to the form. The consistent drop-off shows that the form is the obstacle preventing conversions. The data supports adjusting the form strategy:
• Shorten the form.
• Shift focus from booking a call upfront to a simpler inquiry form.
• Use email follow-up to nurture leads toward booking a call.

**Whitney Hodges** · 2025-08-27 20:57 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1756328238941359)
@Carmen Cruickshank @Yulia Burris FYI
📎 image.png (png, saved as `files/F09CDKC7SJJ-image.png`)
> **Carmen Cruickshank** · 2025-08-28 13:12 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1756386760117959)
> looks good! @Whitney Hodges

**Yulia Burris** · 2025-08-28 18:14 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1756404885728799)
Hi! I saw the first lead for LTB. Could we get the details about who booked, please? I just want to make sure it came from the ads. Thank you! :) @Whitney Hodges @Christina Hill @Carmen Cruickshank
> **Whitney Hodges** · 2025-08-29 14:41 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1756478479001669)
> @Yulia Burris That's amazing news! We'll definitely want to bring this up on the call with Beth today. Since the attribution is showing inside the Meta Ads Manager, the lead is definitely from ads, but based on what we have access to, I don't think we have details on who it is. We'll need to confirm with Beth on the call if she got a form submission yesterday and what she is seeing in terms of quality.
> **Yulia Burris** · 2025-08-29 21:43 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1756503789261729)
> @Whitney Hodges It shows 2 leads for LTB now.
> 📎 Screenshot 2025-08-29 at 5.41.34 PM.png (png, saved as `files/F09DK4RGUN4-Screenshot_2025-08-29_at_5.41.34_PM.png`)

**Whitney Hodges** · 2025-08-29 16:54 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1756486498200709)
@Yulia Burris @Carmen Cruickshank Are y'all available to hop into the call 10 minutes early, so we can all touch base before Beth and/or Felipe join?

**Carmen Cruickshank** · 2025-08-29 17:05 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1756487136570129)
Yes, im able to even 30 minutes before if needed @Whitney Hodges

**Yulia Burris** · 2025-08-29 17:20 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1756488011482249)
@Whitney Hodges  yes!! 2:10 or 2:20 Est? @Carmen Cruickshank 

**Whitney Hodges** · 2025-08-29 17:21 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1756488079211939)
Let's say 2:15!!
> **Yulia Burris** · 2025-08-29 17:21 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1756488091590499)
> @Whitney Hodges perfect! Thank you 
> **Carmen Cruickshank** · 2025-08-29 17:26 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1756488415036269)
> sounds good! @Whitney Hodges @Yulia Burris

**Yulia Burris** · 2025-08-29 19:40 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1756496441415779)
@Whitney Hodges Hi! Here’s the <https://drive.google.com/drive/folders/1DLqtaeGFqVzEVW6YYyTehazg6mAqpKcd?usp=sharing|link with the content> Beth can post for LTB :slightly_smiling_face:

**Gisselle Jiménez** · 2025-08-29 21:16 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1756502204165409)
@Whitney Hodges Here's the email recap draft for Beth on today's call. :raised_hands:
cc: @Yulia Burris @Carmen Cruickshank

Hi Beth and Felipe,

Thank you for taking the time to meet today!

I’ve uploaded the recording of our call, and you can access it here:
:open_file_folder: *<https://drive.google.com/file/d/1gMQ5XQRxItGeAJd0T6y-sHQEReX_9AA2/view?usp=drive_link|Call Recording>*

Our team is working diligently on the following items, and we will keep you in the loop as we move forward:
• Continuing ads management with monthly reports and video walkthroughs.
• Supporting organic content strategy questions during monthly strategy calls as needed.
• Providing guidance on using Meta Business Suite for Facebook content scheduling and the option to backdate posts to build up page history
• Outlining the option for additional services should you want to explore full-service social media management in the future.
Thanks again for your time — we’re excited to keep the momentum going!

Sincerely,
Whitney
> **Yulia Burris** · 2025-08-29 21:21 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1756502494945829)
> @Gisselle Jiménez  We can also send them a link with the ad creatives so they can post these videos organically. I’ve just created a new folder for this, and they can easily download everything from <https://drive.google.com/drive/folders/1DLqtaeGFqVzEVW6YYyTehazg6mAqpKcd|there>. Thank you!) 
> 
> cc: @Whitney Hodges 
> **Whitney Hodges** · 2025-09-02 12:55 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1756817718516189)
> @Gisselle Jiménez @Yulia Burris Thank you! I made several edits because there were action items for the client. This has been sent!

**Ivy Ayala** · 2025-09-03 22:38 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1756939083639699)
Hey there! Here's the <https://www.canva.com/design/DAGx9vtXI2I/lntrMfH-yw8XAOaaF_8YDg/edit?utm_content=DAGx9vtXI2I&amp;utm_campaign=designshare&amp;utm_medium=link2&amp;utm_source=sharebutton|monthly report>

**Ivy Ayala** · 2025-09-03 22:38 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1756939118503699)
@Carmen Cruickshank @Yulia Burris let me know your comments ! :heart:

**Ivy Ayala** · 2025-09-03 22:42 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1756939332501909)
I used the july template but I think we started meta ads in august, should I add that info too?
> **Whitney Hodges** · 2025-09-03 22:48 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1756939711034379)
> @Ivy Ayala Yes, please!!
> **Ivy Ayala** · 2025-09-04 16:09 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1757002150348399)
> Done! @Whitney Hodges
> **Carmen Cruickshank** · 2025-09-04 17:24 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1757006657822339)
> Thank you @Ivy Ayala 

**Carmen Cruickshank** · 2025-09-05 17:08 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1757092124366399)
@Yulia Burris im working on the monthly reports right now and am going to film the google ads one, i dont mind doing the meta ads one too and sending it, did you want to film the meta ads walkthrough and let me know when its done and i can send it all in the monthly report to beth?
> **Yulia Burris** · 2025-09-05 17:17 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1757092656546469)
> @Carmen Cruickshank That would be amazing if you could also film the Meta Ads one for this month’s report. Please let me know if you have any questions. Thank you so much! :blush:  
> **Carmen Cruickshank** · 2025-09-05 17:27 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1757093245607579)
> of course! @Yulia Burris

**Whitney Hodges** · 2025-09-18 12:27 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1758198451197469)
@Yulia Burris @Carmen Cruickshank good morning! I need to respond to Beth's email. Can y'all give me some insights to share on how things are looking this month? How many leads from Google and Meta? How does it compare to last month? Also, if you could pull a screenshot from Google Analytics that shows how website traffic looks now compared to before ads were running? Maybe a date range of the year so far? Or early spring until now? Thank you so much!!
> **Yulia Burris** · 2025-09-18 15:43 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1758210180302739)
> @Whitney Hodges Hi! We started running Meta Ads on August 16.
> From August 16 to September 18, we got 4 leads in total. So far this September, we’ve had 2 leads.
> **Carmen Cruickshank** · 2025-09-18 15:45 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1758210337709849)
> @Whitney Hodges Last month in august on google we had no leads, just people viewing the form. This month we have 2 leads from google ads
> **Whitney Hodges** · 2025-09-18 17:48 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1758217715304749)
> @Yulia Burris @Carmen Cruickshank thank you both! Please pause Google ad spend for now
> **Carmen Cruickshank** · 2025-09-18 18:15 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1758219355800739)
> okay got it @Whitney Hodges
> **Yulia Burris** · 2025-09-18 22:45 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1758235542836239)
> @Whitney Hodges Hi! I wanted to let you know that the LTB ad account has a payment issue. The last payment couldn’t be processed, so the ads have stopped running. Should we reach out to Beth now, or would you prefer to wait a little bit?
> 📎 Screenshot 2025-09-18 at 6.29.35 PM.png (png, saved as `files/F09GU32B01W-Screenshot_2025-09-18_at_6.29.35_PM.png`)
> 📎 Screenshot 2025-09-18 at 6.41.19 PM.png (png, saved as `files/F09G0JUF4QJ-Screenshot_2025-09-18_at_6.41.19_PM.png`)
> 📎 undefined (undefined, not downloaded)
> **Whitney Hodges** · 2025-09-18 22:47 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1758235669555919)
> @Yulia Burris you can try to push the payment through manually, and if that doesn't work, please do reach out to her to make her aware and let her know next steps on updating her payment method with Meta, if needed
> **Yulia Burris** · 2025-09-18 23:03 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1758236600463239)
> @Whitney Hodges Looks like a card issue. The payment was declined by the provider. Tried, but it didn’t go through. We’ll wait a couple of hours and then reach out to Beth if it’s still not resolved. I’ll keep you posted.
> 📎 Screenshot 2025-09-18 at 6.54.08 PM.png (png, saved as `files/F09G0L7B002-Screenshot_2025-09-18_at_6.54.08_PM.png`)
> 📎 Screenshot 2025-09-18 at 6.58.56 PM.png (png, saved as `files/F09FYJN0HRT-Screenshot_2025-09-18_at_6.58.56_PM.png`)
> **Yulia Burris** · 2025-09-19 16:27 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1758299272476849)
> @Whitney Hodges Hi! Update on Beth’s account: her card was hacked, and she’ll reach out once the new one is set up.
> 
> cc: @Carmen Cruickshank 

**Carmen Cruickshank** · 2025-09-18 15:40 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1758210015857399)
hi @Whitney Hodges here are the screen shots:

**Carmen Cruickshank** · 2025-09-18 15:40 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1758210040368339)
this month so far:
📎 Screenshot 2025-09-18 at 11.39.30 AM.png (png, saved as `files/F09G2VC0HJ8-Screenshot_2025-09-18_at_11.39.30_AM.png`)

**Carmen Cruickshank** · 2025-09-18 15:40 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1758210055504519)
last month on google;
📎 Screenshot 2025-09-18 at 11.39.57 AM.png (png, saved as `files/F09G2VDL7EY-Screenshot_2025-09-18_at_11.39.57_AM.png`)

**Carmen Cruickshank** · 2025-09-18 15:44 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1758210282548279)
meta for this month:
📎 Screenshot 2025-09-18 at 11.44.30 AM.png (png, saved as `files/F09FW2XBM53-Screenshot_2025-09-18_at_11.44.30_AM.png`)

**Carmen Cruickshank** · 2025-09-18 16:32 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1758213120351789)
now for google analytics, this is what i have: I cant see any data before we worked with her
📎 Screenshot 2025-09-18 at 12.20.43 PM.png (png, saved as `files/F09G3BCUL0L-Screenshot_2025-09-18_at_12.20.43_PM.png`)

**Whitney Hodges** · 2025-09-26 17:01 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1758906102871849)
@Yulia Burris Hi! Please check out email correspondence with Beth. We need to bring down the Meta Ads budget to $250 and try a messenger campaign while they work on updating the funnel. Also, Beth sent over their doc with video ideas. Please take a look and we can compile feedback on our team call if needed. @Gisselle Jiménez make sure Carmen and Yulia have access if they don't already. Cc @Carmen Cruickshank
> **Gisselle Jiménez** · 2025-09-26 17:06 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1758906385586609)
> Access has been requested for Carmen and Yulia!
> **Yulia Burris** · 2025-09-26 18:41 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1758912070882669)
> @Whitney Hodges Hi! Sounds great!  thank you for sharing this. I love these video ideas and will start working on a new messenger campaign.
> **Whitney Hodges** · 2025-09-26 18:42 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1758912155306149)
> @Yulia Burris Thank you! Beth will want to see what we have in mind for the messenger auto response options before we publish
> **Yulia Burris** · 2025-09-26 22:58 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1758927515854459)
> @Whitney Hodges I’ll prepare this first and send it to you for review)

**Ivy Ayala** · 2025-10-07 14:41 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1759848066542769)
<https://www.canva.com/design/DAG0-I-qbcc/WOt5PtDuI5T8bE4b6riVuA/edit?utm_content=DAG0-I-qbcc&amp;utm_campaign=designshare&amp;utm_medium=link2&amp;utm_source=sharebutton|Monthly report- September 2025> @Carmen Cruickshank @Yulia Burris :heart:

**Carmen Cruickshank** · 2025-10-07 16:36 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1759855017447529)
thank you @Ivy Ayala

**Carmen Cruickshank** · 2025-10-07 16:46 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1759855618140009)
@Whitney Hodges should i just keep sending the email and make sure @Yulia Burris has the meta ads reporting video within the canva?

**Carmen Cruickshank** · 2025-10-07 17:37 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1759858661267109)
or should i just not report anything and let yulia send it for this month since they didnt do google ads? @Whitney Hodges

**Whitney Hodges** · 2025-10-07 17:38 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1759858708702089)
@Carmen Cruickshank Were their Google Ads off the whole month of September?

**Carmen Cruickshank** · 2025-10-07 17:50 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1759859455417189)
no they got 2 leads aparently

**Carmen Cruickshank** · 2025-10-07 17:51 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1759859504264929)
so i can report google and meta to make it more seamless and help yulia

**Carmen Cruickshank** · 2025-10-07 17:51 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1759859508653939)
@Whitney Hodges

**Whitney Hodges** · 2025-10-07 17:52 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1759859550685779)
@Carmen Cruickshank that sounds good, thank you!

**Gisselle Jiménez** · 2025-10-30 13:43 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1761831794249579)
Hi, @Yulia Burris! Flagging Beth’s note from yesterday about the typo fix, the embedded form handoff to Felipe, and timing for Google Ads around engagement season. I drafted a quick reply below for convenience!

&gt; Hi Beth,
&gt; 
&gt; Thank you for the quick update! I’m glad the typo is resolved, and I appreciate you coordinating with Felipe on embedding the form on the site.
&gt; 
&gt; For Google Ads, we can plan around engagement season. I can check in mid-November, so everything is ready for late November through early January.
&gt; 
&gt; Please don’t hesitate to reach out if you need anything in the meantime.
&gt; 
&gt; Best,
&gt; Yulia
> **Yulia Burris** · 2025-10-30 14:16 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1761833796315749)
> @Gisselle Jiménez Thank you! @Whitney Hodges Should we skip the part about planning with Google Ads for engagement season? I’m not sure when their contract ends, just wanted to double-check
> **Whitney Hodges** · 2025-10-30 14:21 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1761834090576969)
> @Yulia Burris Hi! Thanks for checking! Her initial contract ends in mid-November. I need to have a conversation with her around that time about renewing for another six months or just going month to month.
> 
> @Carmen Cruickshank Could you do some research about search volume for destination wedding keywords and if volume increasing during engagement season (Nov-Jan)? Thank you!
> **Carmen Cruickshank** · 2025-10-30 18:29 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1761848973126159)
> @Whitney Hodges Hi! Here is the data I've gathered from my research: Destination wedding keywords tied to *Mexico and the Caribbean* show clear seasonal increases after engagement season begins.
> • *Top risers:* Jamaica wedding packages (+172%), Cabo wedding packages (+140%), and location-specific terms like destination wedding Cancun, Tulum, and St. Lucia (+80–90%).
> • Broader intent terms like destination wedding packages and beach destination weddings each rose around +50% from baseline.
> • The consistent January peak confirms couples begin researching and booking destination weddings right after the holidays, aligning with engagement season trends. 
> **Carmen Cruickshank** · 2025-10-30 18:29 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1761848994145969)
> Here is the spreadsheet: <https://docs.google.com/spreadsheets/d/1A_qYKTEt33Hcvx0LMd3tFEd5mcoJDV8Gf6bcOzHrMmM/edit?gid=0#gid=0> Let me know anything else needed!
> **Whitney Hodges** · 2025-10-30 18:32 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1761849133054429)
> @Carmen Cruickshank Thank you so much! @Yulia Burris If you'd like to work this into your reply, that would be amazing!!

**Yulia Burris** · 2025-10-31 16:20 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1761927612480429)
@Christina Hill @Carmen Cruickshank Hi! Beth just sent us the link to the <https://www.experienceluxetravel.com/destination-wedding-venue-selection|Inquiry landing page> with the new embedded form and <https://luxury-travel-boutique.squarespace.com/request-for-wedding-inquiry-successful|thank-you page>. She mentioned that these pages are now integrated into her website.

However, if we open the link directly from her website and submit the form, it still shows the old form, not the new one.

I just wanted to clarify if everything will track correctly with the new links and if we’ll still see leads coming through. @Christina Hill I’d really appreciate it if you have time to double-check these new links in GTM.

Thank you so much! :pray:
> **Whitney Hodges** · 2025-10-31 16:25 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1761927952823759)
> @Yulia Burris The pages she shared will be used for ads traffic only. That's why the website itself is still as is for organic traffic. Thank you!!
> **Carmen Cruickshank** · 2025-10-31 17:23 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1761931430455859)
> Thank you @Yulia Burris I'll be sure to update it!
> **Yulia Burris** · 2025-10-31 17:36 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1761932201682949)
> @Whitney Hodges  @Carmen Cruickshank Thank you :pray:
> **Yulia Burris** · 2025-10-31 17:43 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1761932610007929)
> @Whitney Hodges I forwarded to Beth the keywords that Carmen prepared, and she replied asking if we’d like her to do something with those terms, such as SEO.
> 
> Do you have any recommendations for her? Carmen doesn’t recommend this, but we’re curious to hear your thoughts as well.
> 
> Thank you so much! :pray:
> 
> Cc: @Carmen Cruickshank 
> **Whitney Hodges** · 2025-10-31 17:56 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1761933367266219)
> @Yulia Burris I don't know enough about SEO to make SEO recommendations. If her we designer handled SEO for her, she might forward it on to her and get her advice. By sending the spreadsheet to her, I just wanted to convey the point that search volume for destination wedding related keywords does increase during engagement season, and therefore, it would be in her best interest to run Google Ads during that timeframe
> **Carmen Cruickshank** · 2025-10-31 18:14 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1761934482846489)
> I think Beth got confused, I'll clarify the higher peak volume on Google in January @Whitney Hodges @Yulia Burris
> **Christina Hill** · 2025-11-03 17:53 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1762192384421089)
> Hi @Yulia Burris, thank you for updating the funnel map with her new links. Conversion tracking is updated for Meta and Google :white_check_mark: . Please check to ensure the events are firing on your end. It may take a few minutes to sync. :slightly_smiling_face:
> 
> cc:@Carmen Cruickshank @Whitney Hodges
> **Yulia Burris** · 2025-11-03 17:53 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1762192425302469)
> @Christina Hill thank you so much:)
> **Christina Hill** · 2025-11-03 17:54 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1762192459121269)
> @Yulia Burris You're welcome. :slightly_smiling_face:

**Gisselle Jiménez** · 2025-11-04 20:36 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1762288561222659)
Hi @Yulia Burris! For visibility, here is Beth’s latest email!

&gt; I think for now I would like to keep the budget where it is and then ramp up the budget in a few weeks closer to Thanksgiving when we tend to see more engagements.

**Ivy Ayala** · 2025-11-06 17:57 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1762451843583279)
<https://www.canva.com/design/DAG38QaGocw/qkgimtXQN-O0qXd8l7ygQQ/edit?utm_content=DAG38QaGocw&amp;utm_campaign=designshare&amp;utm_medium=link2&amp;utm_source=sharebutton|Monthly report October 2025> @Carmen Cruickshank @Yulia Burris
> **Yulia Burris** · 2025-11-07 13:28 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1762522139573569)
> @Ivy Ayala Good morning! thank you so much. 
> 
> @Carmen Cruickshank Just to clarify, was the Google Ads campaign launched in early October?
> 
> 
> сс: @Whitney Hodges 
> **Carmen Cruickshank** · 2025-11-07 16:29 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1762532962743739)
> @Yulia Burris No, google ads havent ran at all in october

**Gisselle Jiménez** · 2025-11-13 14:58 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1763045898349489)
Hi @Yulia Burris! Just a gentle nudge that Beth sent an email with some questions about the venue selection video. Whenever you have a chance to reply to her, that would be great! Thank you!
> **Yulia Burris** · 2025-11-13 14:59 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1763045959664499)
> @Gisselle Jiménez Thank you! I already wrote the email and will send it to her now.

**Gisselle Jiménez** · 2025-11-25 14:01 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1764079319555319)
Hi @Yulia Burris! Also, for visibility, there's a new email from Beth about removing an extra period in her ad copy. Thanks!

**Gisselle Jiménez** · 2025-12-02 14:15 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1764684916805019)
Hi, @Carmen Cruickshank! New email from Beth! Yulia is OOO so if you're able to chime in here, that would be great! Thank you!

&gt; Hello, 
&gt; 
&gt; Thank you for your email and the updates - they look great! 
&gt; 
&gt; To clarify - what is my current budget per month per platform?

**Whitney Hodges** · 2025-12-04 22:05 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1764885948969119)
@Carmen Cruickshank @Yulia Burris Hi! I want to make sure you both saw Beth's emails.

She has requested to spend $250/month per platform. I don't care to argue with her. Carmen, please make sure Google Ads are running ASAP.

Yulia, given her feedback on lead volume and the minimal budget, we may want to revisit the strategy for Meta Ads. I'm thinking we could just run client attraction and retargeting. Let me know your thoughts. Can you please address her request about the autoresponses?
📎 image.png (png, saved as `files/F0A1GBKPAUT-image.png`)
> **Yulia Burris** · 2025-12-05 01:57 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1764899824108989)
> @Whitney Hodges Thank you! I was thinking about this today too. We can see how the new creatives perform in the conversion campaign with her $8 daily budget through Monday. Then on Monday/Tuesday, we can set up the new campaigns.
> **Carmen Cruickshank** · 2025-12-05 17:17 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1764955064662619)
> @Whitney Hodges yes i'll turn her ads back on at $8.33/day

**Ivy Ayala** · 2025-12-08 14:23 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1765203788960499)
Morning! Here's the <https://www.canva.com/design/DAG67rbFS1s/kWOzg8FlUxDohV2DncqqOQ/edit?utm_content=DAG67rbFS1s&amp;utm_campaign=designshare&amp;utm_medium=link2&amp;utm_source=sharebutton|Monthly Report Nov 2025> @Yulia Burris

**Yulia Burris** · 2025-12-29 22:15 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1767046514502869)
@Carmen Cruickshank Hi!:)  Here are the links to the creatives that Beth has already approved. You can use them for your new or current campaign.

<https://drive.google.com/file/d/1MdKViGuswtWyjQl-097KA5aV-17oxGu3/view?usp=share_link|Ad Creative #1>
<https://drive.google.com/file/d/11ckE_IhAtNAaKUDIGN1mJJPcpyasagkX/view|Ad Creative #2>
<https://www.canva.com/design/DAG2dbukeOM/jfVgKi0wNsT1nk9Mv9RCcQ/edit?utm_content=DAG2dbukeOM&amp;utm_campaign=designshare&amp;utm_medium=link2&amp;utm_source=sharebutton|Ad Creative #3>
<https://www.canva.com/design/DAG5vHEMuqQ/8ec4JqP0BliSLNl7lO60UA/edit?utm_content=DAG5vHEMuqQ&amp;utm_campaign=designshare&amp;utm_medium=link2&amp;utm_source=sharebutton|Ad Creative #4>


cc: @Whitney Hodges
> **Carmen Cruickshank** · 2026-01-05 16:31 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1767630707601979)
> thank you @Yulia Burris! I'll add these

**Ivy Ayala** · 2026-01-06 16:12 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1767715943231789)
Morning! here's the <https://www.canva.com/design/DAG9qFLRs4o/-lVaelXx6A8W3YI5UNAXLQ/edit?utm_content=DAG9qFLRs4o&amp;utm_campaign=designshare&amp;utm_medium=link2&amp;utm_source=sharebutton|monthly report DEC 2025> @Carmen Cruickshank @YO

**Ivy Ayala** · 2026-01-06 16:12 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1767715948895499)
@Yulia Burris

**Carmen Cruickshank** · 2026-01-08 22:44 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1767912293339249)
@Carmen Cruickshank @Ivy Ayala Hi! how do i add google stats to this? i'll try to figure this out tommorow morning

**Ivy Ayala** · 2026-01-09 14:27 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1767968867279619)
Hi! I just added them! @Carmen Cruickshank

**Carmen Cruickshank** · 2026-01-09 14:29 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1767968976689099)
Thank you @Ivy Ayala !

**Carmen Cruickshank** · 2026-01-22 16:26 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1769099218047479)
hey @Whitney Hodges I saw Beth wanted to reschedule, should i follow up with the book a call link?
> **Whitney Hodges** · 2026-01-22 16:29 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1769099354703789)
> @Carmen Cruickshank yes, please. If you could just send her the link to book the strategy call with both of us, that's great. Thanks!

**Whitney Hodges** · 2026-01-28 19:59 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1769630353111799)
@Gisselle Jiménez Hi! Beth will most likely be moving forward with the Foolproof Follow Up Advantage. I quoted her $1697 because I know how she is lol. Can you please put together a proposal, contract, and invoice for her? And also draft the email

In the email, please include details on joining the Accelerator Bundle for $497 per month spelling out the support that's included.

Thank you!
> **Gisselle Jiménez** · 2026-01-28 20:27 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1769632059121879)
> @Whitney Hodges Email with proposal is ready! I set due date for 1 week, let me know if this needs adjusting and if you want an expiry date as well
> **Whitney Hodges** · 2026-01-28 20:36 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1769632612963959)
> @Gisselle Jiménez no need for a expiration date on this one, thank you!
> **Whitney Hodges** · 2026-01-28 21:18 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1769635090587469)
> @Gisselle Jiménez can we give ourselves 4 weeks for all FPFUA proposals moving forward, please? Please make sure the contract reflects this too. Thank you!!
> 📎 Screenshot_20260128-151606.png (png, saved as `files/F0ABDUY8H43-Screenshot_20260128-151606.png`)
> **Gisselle Jiménez** · 2026-01-29 16:18 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1769703491557069)
> @Whitney Hodges This has been modified. :raised_hands:
> **Gisselle Jiménez** · 2026-01-29 16:19 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1769703561328479)
> I didn't find anything about timeline in the contract!
> **Whitney Hodges** · 2026-01-29 17:26 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1769707571434289)
> @Gisselle Jiménez For the email to Beth, can you please adjust the language about what the accelerator programs include? They already have ads running, so it's a downsell from full-service to being inside the VAULT. I need them to understand the ongoing support that is included and the curriculum and also to make sure that it's clear that if they want to launch new Meta ads, they need to come up with the copy + creative and submit them to us for launch. Thank you!!
> **Gisselle Jiménez** · 2026-01-29 17:41 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1769708482600709)
> @Whitney Hodges Got itt, email has been updated!

**Carmen Cruickshank** · 2026-01-30 18:46 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1769798772859719)
Hi @Whitney Hodges! I'm looking for the folder with shared content from Beth and Felipe and I'm wondering if it's this one here (Nov 2025 Videos). I only see two videos and I think Yulia created/edited them.
📎 Screenshot 2026-01-30 at 1.44.24 PM.png (png, saved as `files/F0ABM4D9ZJT-Screenshot_2026-01-30_at_1.44.24_PM.png`)
> **Whitney Hodges** · 2026-01-30 18:49 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1769798982799049)
> @Gisselle Jiménez can you please help Carmen track this down? It's likely a link that Beth/Felipe shared with us via email early on in the onboarding process. I believe they created Google photo and/or video albums that they gave us access to
> **Gisselle Jiménez** · 2026-01-30 18:59 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1769799545089729)
> @Whitney Hodges @Carmen Cruickshank I found this! Let me know if it's what you need.
> 
> <https://photos.google.com/share/AF1QipOgB3N-pzIoC-0oumR_rSfAplnrjFYWrG2pQUBHAg3pIh-sm1FsY72Vw5vU5ZRIdg?pli=1&amp;key=V293dUV3YVZNa1U3SmZOTW9CWjBvZ0EweENSZmdR|https://photos.google.com/share/AF1QipOgB3N-pzIoC-0oumR_rSfAplnrjFYWrG2pQUBHAg3pIh-sm[…]5vU5ZRIdg?pli=1&amp;key=V293dUV3YVZNa1U3SmZOTW9CWjBvZ0EweENSZmdR>

**Carmen Cruickshank** · 2026-02-02 15:47 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1770047254020159)
@Gisselle Jiménez yes that's it, thank you!!

**Carmen Cruickshank** · 2026-02-04 19:28 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1770233313309879)
@Whitney Hodges @Jacqueline Hood Hi! I was uploading 2 new creatives directly from LTB's organic content to their conversion campaign running at $8.33/day. Before it was just 1 ad running in that 1 campaign. With these 2 new ads i saw this message and was wondering your guys' thoughts on if i should just have 1 new ad instead of 2.
📎 Screenshot 2026-02-04 at 2.20.20 PM.png (png, saved as `files/F0ADE0P7YF3-Screenshot_2026-02-04_at_2.20.20_PM.png`)

**Jacqueline Hood** · 2026-02-04 23:17 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1770247068249799)
@Carmen Cruickshank I would still launch both of the new ads; it's just possible that at that ad spend, Meta won't put any $ towards the new ones so I'd keep an eye on it and then we can adjust if we need to!
> **Carmen Cruickshank** · 2026-02-05 15:57 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1770307027584669)
> thank you @Jacqueline Hood!! makes sense

**Ivy Ayala** · 2026-02-05 15:47 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1770306450603039)
Morning! Here's the monthly report <https://www.canva.com/design/DAHAd8AOBWY/XpHZIUTLbk_fB0Z-zbJl0Q/edit?utm_content=DAHAd8AOBWY&utm_campaign=designshare&utm_medium=link2&utm_source=sharebutton|JAN 2026> @Carmen Cruickshank  @Yulia Burris

**Gisselle Jiménez** · 2026-02-17 17:57 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1771351047458469)
@Whitney Hodges Beth's invoice for the Accelerator bundle has been scheduled, and it's due on March 1st. After she pays that, we can schedule the orientation call. :raised_hands:

**Carmen Cruickshank** · 2026-02-17 18:07 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1771351647586859)
@Whitney Hodges Hi! So i'm looking through the heatmap and its actually glitching and i can't see the content on the website to thoroughly look at what's working and what's not but the only thing i can find that is that loading time looks slow, more on mobile and a lot of people bounce off after 3-15 seconds and their page speed is really low on the test i run it through: <https://pagespeed.web.dev/analysis/https-www-experienceluxetravel-com-destination-wedding-venue-selection/03rdkjwkc4?form_factor=mobile> I'm not sure if on an email i should reccomend someone from fiver (it really is that easy, anyone on fiverr can improve site speed for $15). I know I told them i would follow up, but since i can't see full data i know that i should at least give this reccomendation
> **Whitney Hodges** · 2026-02-17 19:21 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1771356071680099)
> @Carmen Cruickshank I would probably encourage them to share this information with their web designer since the site was built pretty recently

**Gisselle Jiménez** · 2026-02-18 17:51 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1771437071223379)
has renamed the channel from "c_luxurytravelboutique" to "cfpfu_luxurytravelboutique"

**Gisselle Jiménez** · 2026-02-18 20:49 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1771447742404319)
@Whitney Hodges @Danielle McGinnis Here is Beth's *<https://drive.google.com/file/d/1PLUL8eM-kihQZ2dPu54wMEY7u-GHhZvv/view?usp=drive_link|onboarding questionnaire>*! It has been added to her <https://drive.google.com/drive/folders/1ZRsLGPhS8wyHRVXizGiwlSiAIzQz1m-b?usp=drive_link|folder> along with all brand assets.

She needs clarification on the following:
• Specifications for email Subdomain
• Brand/Origin Story
• Brand Voice
Also, you can find her *<https://app.clickup.com/9011165651/v/li/901113171140|onboarding checklist >*in the Bookmarks section of this channel. Let me know if you need anything else!
> **Whitney Hodges** · 2026-02-18 20:52 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1771447933682929)
> @Gisselle Jiménez can you please draft an email for her with the clarifications she's looking for?
> **Gisselle Jiménez** · 2026-02-18 21:04 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1771448669179139)
> @Whitney Hodges Done!

**Gisselle Jiménez** · 2026-02-18 20:49 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1771447757748699)
Here is her Kickoff Call Worksheet:
<https://docs.google.com/document/d/1uV-h_6wtHfdcsO7c6R2itRGgbngLCGYei5s98dmY6hQ/edit?tab=t.0>

**Gisselle Jiménez** · 2026-02-18 21:20 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1771449625718139)
@Whitney Hodges We have an internal subaccount for LTB. Will we use this one, or do we need to create a new one?
> **Whitney Hodges** · 2026-02-18 21:57 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1771451837331849)
> @Gisselle Jiménez I think we can use that one

**Danielle McGinnis** · 2026-02-19 23:30 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1771543840126179)
@Whitney Hodges I see Beth's call is Wed at 9am EST. Im planning to attend and have marked this as a hold on my calendar.

**Gisselle Jiménez** · 2026-02-25 21:02 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1772053376584129)
@Whitney Hodges I believe post-kickoff call email will come from you this time? I have drafted it in the LeadLock account, but I'm waiting for the meeting recording to process!
> **Whitney Hodges** · 2026-02-25 21:04 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1772053460197799)
> @Gisselle Jiménez thanks for checking in! @Danielle McGinnis is going to draft the email this time and send it after I approve. She should have the recording from her fathom notetaker
> **Gisselle Jiménez** · 2026-02-25 21:10 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1772053823706729)
> @Whitney Hodges Okay, perfect!
> 
> @Danielle McGinnis I'm having trouble downloading the recording from Zoom as it's quite heavy. Once you download it from Fathom, you can upload it to the<https://drive.google.com/file/d/1PL2lTIuWX8M1smJtXjzDIL6t67Iv-XJ5/view?usp=drive_link| client drive >and include the link. Thank you!
> 
> Here is also the <https://docs.google.com/document/d/1uVo3XwAFCvto18d_7PPAQwj1cPqCJ1FrVqUSGVWkQNU/edit?usp=drive_link|email template> if you need a base. :raised_hands:
> **Danielle McGinnis** · 2026-02-26 13:24 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1772112287575989)
> Thank you so much @Gisselle Jiménez for the template. I've uploaded the recording to the client folder and drafted the email for your review @Whitney Hodges and it's in the support inbox!
> 
> Quick FYI @Whitney Hodges, I figured out the issue with the phone number. Lead Connector wasn't connected yet. I'll add that to the onboarding checklist for future reference to make sure we do this before hopping on the kickoff call moving forward.
> **Whitney Hodges** · 2026-02-26 16:27 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1772123240157129)
> @Danielle McGinnis Thank you!! I don't think I have the password for the support email account since I gave you access. Would you like to drop the draft here for me to review?
> **Danielle McGinnis** · 2026-02-26 19:33 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1772134403724049)
> Oh sure @Whitney Hodges so sorry! Here's the draft. Also where should I share the password?
> 
> Subject: Next Steps After Your LeadLock Kickoff Call
> 
> Hi Beth,
> 
> It was great meeting you yesterday! We're excited to get started on building out your LeadLock system. For your reference, here are the links from today's call:
> 
> • *<https://drive.google.com/file/d/14p1SoHOaJtyFFo2FbzwdYeDcuzbtc9it/view?usp=sharing|Call Recording>*
> • *<https://drive.google.com/drive/folders/10qsISk_BPciQalOp9xjYYGMXYfRezgJm?usp=sharing|Google Drive Folder>*
> Now that we have your account connected, our team will be working behind the scenes on the technical setup, including DNS records, A2P registration, and building out your inquiry forms, funnels, and email templates. This process typically takes 4 weeks.
> 
> In the meantime, we'll still need you to purchase your phone number when you get a moment so we can proceed with the A2P registration process. As a refresher, navigate to the lefthand navigation bar in your LeadLock account, scroll to the bottom, click Settings, then Billing.
> 
> I also want to confirm that we received your overview video, and we'll add it to your inquiry workflows as discussed on yesterday's call.
> 
> Lastly, just a quick reminder to not forget to add your personal Gmail calendar to the conflicts calendar in your profile to avoid double-booking yourself once your account is live and running.
> 
> We'll keep you updated on progress and reach out if we need anything from you. Please let us know if you have any questions!
> 
> Best,
> Danielle
> 
> --
> 
> _Funnel Strategist_
> *<https://leadlockpro.com/|LeadLock Pro>*
> **Whitney Hodges** · 2026-02-26 20:20 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1772137200770759)
> @Danielle McGinnis Thank you! Do you use LastPass? You can share it with me there through the email address <mailto:hello@weddingindustryads.com|hello@weddingindustryads.com>.
> 
> As for the draft, I think the paragraph below could be clearer. Let's just ask her to add her billing information. On the call, it sounded like she was fine with us selecting her LeadLock phone number on her behalf.
> 
> _In the meantime, we'll still need you to purchase your phone number when you get a moment so we can proceed with the A2P registration process. As a refresher, navigate to the lefthand navigation bar in your LeadLock account, scroll to the bottom, click Settings, then Billing._
> **Danielle McGinnis** · 2026-02-26 21:37 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1772141837368239)
> @Whitney Hodges how's this:
> _In the meantime, please add your billing information to allow us to purchase your phone number and proceed with the A2P registration process. As a refresher, navigate to the lefthand navigation bar in your LeadLock account, scroll to the bottom, click Settings, then Billing._
> **Danielle McGinnis** · 2026-02-26 21:44 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1772142247080149)
> Also @Whitney Hodges I just shared the support login info with you!
> **Whitney Hodges** · 2026-02-26 22:14 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1772144056927549)
> @Danielle McGinnis that's perfect!
> **Danielle McGinnis** · 2026-02-26 23:25 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1772148310933269)
> Email sent @Whitney Hodges !

**Danielle McGinnis** · 2026-02-26 13:34 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1772112885829559)
Hi @Tina Henares! Me again! haha. We have another client ready to onboard in LeadLock. Here's the info from the kickoff call:

• <https://drive.google.com/drive/folders/1VWH3wOdO1-CPdGW2N3_Xln8h_A8wdr9Q?usp=drive_link|Brand Assets>
• <https://www.experienceluxetravel.com/|Website>
Forms:
• Website Inquiry Form (Re-Create <https://www.experienceluxetravel.com/destination-weddings-form|this form> in LeadLock)
• Ads Inquiry Form (Create a new one that captures the 3 "What best describes you" options below)
Emails:
Inquiry Nurture Sequence - "I'm ready to get started"
• Include <https://photos.app.goo.gl/7SjBFA42ZzXQK8M56|overview video> in 1st email in sequence
    ◦ CTA - Book a Consultation
• Inquiry Nurture Sequence - "My destination wedding is booked. I just need help with rooming."
    ◦ CTA - Book a Consult
• Inquiry Nurture Sequence - "I'm not ready to start planning"
    ◦ CTA - Tips on destination weddings, planning process
• Consult Reminder Sequence
• Cancellation & No Show Emails
Funnels:
• Zoom Room (1)
• Calendar Funnel (1)
    ◦ 60 minute consult page
    ◦ 30 minute consult page
• Website TY Page
• Ads TY Page
• Preferences Funnel
Please let me know if you have any questions.

I know that I also just sent you The email for The Colonial at Sunset today as well. Do you think you can aim to have this one done by the week of March 9th?

Please let me know if this is doable with your schedule and how I can support you.

@Whitney Hodges please let me know if I'm missing anything or if anything needs tweaked based on our call.

Thank you both!

**Whitney Hodges** · 2026-02-26 21:06 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1772139985509279)
@Danielle McGinnis thank you! @Carmen Cruickshank can you please drop here the link to their ads traffic landing page? @Tina Henares that is the form we'll need to recreate for their LeadLock build plus the addition of "What best describes you" categories Danielle mentioned above. Thank you!!

**Carmen Cruickshank** · 2026-03-02 15:56 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1772466981556819)
@Whitney Hodges Here's the ads traffic landing page: <https://www.experienceluxetravel.com/destination-wedding-venue-selection> im sorry. I thought I sent this on Friday

**Whitney Hodges** · 2026-03-02 15:59 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1772467148592419)
@Tina Henares Hi! We've been tagging you in this channel, but just realized you weren't in it! So sorry! Please see messages above. Thank you!!

**Danielle McGinnis** · 2026-03-03 13:21 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1772544080191499)
Good morning @Whitney Hodges! I just skimmed through our call with Beth last week. Did we get access to her DNS records? I don't think we did, but am I missing it? I just want to be sure before I reach out to her. Thanks!
> **Whitney Hodges** · 2026-03-03 17:14 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1772558097488229)
> @Danielle McGinnis I might have missed that on the call, but I checked and luckily we already have access via WIA, so I just sent a contributor invite to you. If that doesn't work, let me know!
> **Danielle McGinnis** · 2026-03-03 19:19 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1772565569799689)
> @Whitney Hodges received! Thank you!

**Ivy Ayala** · 2026-03-08 00:00 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1772928041060069)
Hi team! here's the <https://www.canva.com/design/DAHDTxIZQJc/LjqBhmAh05zcIEGolhcPnA/edit?utm_content=DAHDTxIZQJc&amp;utm_campaign=designshare&amp;utm_medium=link2&amp;utm_source=sharebutton|monthly report FEB 2026> @Carmen Cruickshank

**Danielle McGinnis** · 2026-03-23 18:07 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1774289246899059)
@Whitney Hodges Great news! It looks like the third time is the charm for Beth! Was just about to contact GHL Support but I refreshed her account one last time and see that her phone number purchase was FINALLY successful!:raised_hands::skin-tone-4:
> **Whitney Hodges** · 2026-03-23 18:07 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1774289271528269)
> Great to hear!!!

**Danielle McGinnis** · 2026-04-02 19:36 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1775158600256969)
@Whitney Hodges quick update. Testing in place for all workflows. I intend to send over the asset review email to Beth tomorrow!

**Danielle McGinnis** · 2026-04-03 14:59 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1775228397624479)
Morning @Whitney Hodges heads up that I sent you the draft I plan to send to Beth for your review!
> **Whitney Hodges** · 2026-04-03 15:35 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1775230534955079)
> @Danielle McGinnis Thank you! Similarly to Diamond A Ranch, this client will need an Ads Inquiry Form as well. For some clients, this is just a duplicate of the Website Inquiry Form, but in Beth's case, I believe the form for ads traffic shorter.
> 
> @Carmen Cruickshank should be able to share Beth's existing ads landing page with you if you need the link to reference those inquiry questions. (This page is built on Beth's existing website, not LeadLock, so as part of onboarding, you'll need to be sure the website form and ads form get embedded in the proper spots)
> 
> As for the virtual meeting room, landing page, we've found that this is only usable if the client has a Zoom personal meeting room. That way the button on the page goes to the same URL every time. When a client uses Google Meet, I believe a unique meeting link is created for each appointment booking. I believe About Love and Funktastic use Google Meet for their consultations if you need a point of reference for how we've set this up for other clients 
> 
> I'll review all the other assets in the email later today but wanted to share all of this info with you in the meantime
> **Danielle McGinnis** · 2026-04-03 18:43 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1775241797355599)
> @Whitney Hodges I'm so sorry for the confusion. There's already an <https://link.experienceluxetravel.com/widget/form/WWdy4gjl5aB15O911MlY|Ads Inquiry form>. I just didn't link it in the email to Beth, but I will add it to her email. Noted about the Zoom versus Google Meet page. I'm not too familiar with Google Meet so I wasn't sure if there was a link to a personal Google Meet room similar to Zoom.
> **Carmen Cruickshank** · 2026-04-03 19:52 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1775245949615879)
> @Danielle McGinnis here is the landing page: <https://www.experienceluxetravel.com/destination-wedding-venue-selection?fbclid=fbclid>

**Danielle McGinnis** · 2026-04-03 20:35 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1775248509316159)
@Whitney Hodges I'm going to ping @Tina Henares here to update the Set Preferences Page to reflect the LTB brand fonts and to update it to match the other pages.

Are you ok if I send this to Beth for review now or do you want me to wait until the page is updated?

**Danielle McGinnis** · 2026-04-03 22:32 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1775255537596619)
@Whitney Hodges just wanted to make sure you saw this. Was hoping to het Beth's email out today if possible. :-) 

**Whitney Hodges** · 2026-04-03 22:46 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1775256369662309)
@Danielle McGinnis yes, I think it's ok to send now. Thanks!!

**Danielle McGinnis** · 2026-04-07 19:05 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1775588742992619)
@Whitney Hodges can you perhaps weigh in on the message from Beth please?:pray::skin-tone-4:
> **Whitney Hodges** · 2026-04-07 19:13 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1775589229367869)
> @Danielle McGinnis Ok, I just took a look!
> 
> For the inquiry forms, I like her idea of removing "Other" and using the same short form questions for both the website form and the ads form. I agree that it makes sense to ask the more detailed questions as part of the form to book their consultation.
> 
> Do we need to include the marketing SMS checkbox for A2P approval, or can it be removed? I can't keep up with the requirements :melting_face:
> 
> Is there any issue with making the phone number mandatory in order to book a consultation?
> **Danielle McGinnis** · 2026-04-07 19:17 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1775589435300619)
> Thank you @Whitney Hodges! Ok cool, I'll make those changes with the forms. It's a simple swap.
> 
> I can also take the marketing checkboxes off according to the new  A2P process)
> 
> Im most concerned about taking the phone number mandatory. I really dont think we should do that at all. Its too risky to do that on any of the forms in my opinion.
> **Whitney Hodges** · 2026-04-07 19:18 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1775589530514459)
> @Danielle McGinnis Ok, I think I understand. Is the concern that if the phone number is mandatory on the consultation form, she won't be approved for A2P? Or that even if we push her approval through now that she could be rejected retroactively in the future?
> **Danielle McGinnis** · 2026-04-07 19:23 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1775589801941579)
> @Whitney Hodges Yep, I'm concerned for A2P purposes only. Part of the A2P process is automated, driven by AI, but the second part is a live person clicking around on the site, through the forms etc. I'd rather not have any of the forms that are clickable or visible on her site to the public to have a mandatory phone number on them.
> **Whitney Hodges** · 2026-04-07 19:32 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1775590323006819)
> @Danielle McGinnis I think if you explain that to her, she'll understand. You can let her know that after she is approved for A2P, we can make the phone number for the consultation mandatory, but that will expose her to the risk of being rejected after the fact and having to start the whole process over. What do you think?
> **Danielle McGinnis** · 2026-04-07 19:41 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1775590905302999)
> @Whitney Hodges That's exactly right! I'll let her know! Thank you!

**Danielle McGinnis** · 2026-04-15 18:22 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1776277334841169)
@Whitney Hodges Tina has made the updates to the nurture email copy with her edits in green. FYI - The inquiry sequence for room blocks is only 4 emails instead of 5.
<https://docs.google.com/document/d/14qLqmAaO1lOgH9ewCJu-eSghV9AHyNw1xjqFMLXAy3g/edit?tab=t.0>

Please let me know once you reviewed so I can send along to Beth.
> **Whitney Hodges** · 2026-04-15 19:38 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1776281933188099)
> @Danielle McGinnis @Tina Henares Thank you both so much for all of your work on LTB so far!
> 
> I've reviewed the emails, and I want to jump in here for a couple of reasons.
> 
> 1. I know from experience that Beth is not easy to please. Edits requests from here are likely unavoidable, but I want to do what I can to help us get there sooner than later
> 2. The requests for "room block only" and "not ready to book yet" email sequences aren't typical, so I'd love to provide some additional guidance
> What Beth is looking for is for these two sequences to be fundamentally different than the general inquiry sequence because the goal of each is very different.
> 
> For room blocks only, it's much more straightforward support.
> 
> For those who aren't ready to plan, it's about educating over a longer time frame. These emails should probably spaced out about a week apart. (FYI @Danielle McGinnis)
> 
> <https://docs.google.com/document/d/18DM0cyuSXMq28VUEK4KGqk2a0JRBXjK1fJzgGz2Canc/edit?tab=t.jpqgowaof6ly|In this doc, I've put together suggestions that I believe are closer to what Beth is looking for. >
> 
> Please note: I didn't spend a ton of time on this. I'm not saying these are fully ready to go. Full transparency, I used one of my Custom GPTs to help with this. I think they're pretty strong as is, but there's always room for improvement @Tina Henares can you please take a closer look? If anything sounds like AI, Beth will be sensitive to it, so feel free to edit, customize, and/or make additions based on what you know about Beth and her brand.
> 
> From there, please put these new versions into the <https://docs.google.com/document/d/14qLqmAaO1lOgH9ewCJu-eSghV9AHyNw1xjqFMLXAy3g/edit?tab=t.0#heading=h.uncxsciw5hhx|Nurture Email Copy doc> instead of what's currently there.
> 
> Thank you both so much for your support and collaboration!
> **Danielle McGinnis** · 2026-04-15 19:41 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1776282066116639)
> Thanks so much for jumping in here @Whitney Hodges ! @Tina Henares we told Beth we’ll have something for her review but end of this week so let me know if you need more time and I’ll update her. 
> **Tina Henares** · 2026-04-16 04:17 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1776313064341479)
> Thanks for your input @Whitney Hodges! I reviewed the new versions of the emails and moved them to the Nurture Email Copy Doc <https://docs.google.com/document/d/14qLqmAaO1lOgH9ewCJu-eSghV9AHyNw1xjqFMLXAy3g/edit?tab=t.0#heading=h.uncxsciw5hhx|here>. They should be ready for review @Danielle McGinnis
> **Danielle McGinnis** · 2026-04-16 17:58 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1776362298820639)
> @Tina Henares thank you so much! @Whitney Hodges do you need to review again or am I good to send to Beth?
> **Whitney Hodges** · 2026-04-16 18:45 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1776365107818399)
> @Danielle McGinnis Feel free to send and we'll see what Beth says!! :crossed_fingers:
> **Danielle McGinnis** · 2026-04-16 18:51 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1776365468830829)
> Sending now :face_with_peeking_eye:

**Danielle McGinnis** · 2026-04-15 18:22 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1776277339591909)
Thank you!!

**Danielle McGinnis** · 2026-04-24 12:45 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1777034700342589)
Hi @Tina Henares me again!

Beth hasn't yet reviewed the actual email copy yet, but sent along sent some feedback regarding the landing pages, forms, etc. Here's <https://docs.google.com/document/d/1vx5OeBejR9IJFrcdN7U9bTo-M0JBgM7jVVV_wpxbB4U/edit?tab=t.0|the copy doc link> again with her feedback highlighted in yellow.

Please let me know if you have any changes.

Thank you!

**Danielle McGinnis** · 2026-04-27 19:25 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1777317908687809)
Hi @Tina Henares and Happy Monday! just wanted to make sure you saw these edits from Beth. Thank you!
> **Tina Henares** · 2026-04-28 02:18 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1777342712561939)
> Hi @Danielle McGinnis! Finished the edits. Beth wants to ask more questions when they book a consultation call and less when they initially inquire. So I created two separate calendar submission forms and attached them to the appropriate calendars, and also shortened the inquiry forms. Also, in the Set Preferences Page, she had a question about when that email is used. Could you respond to that one? Thank you!
> **Danielle McGinnis** · 2026-04-28 11:45 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1777376700579599)
> Thanks so much @Tina Henares! I'll notify Beth that we've made changes and provided a response re: the Set Preferences page. Just a quick heads up that I noticed she's made changes in the email copy doc, so I'm going to ask her if those updates are ready to be made as well. Will let you know what she says. Thanks!

**Danielle McGinnis** · 2026-05-04 12:07 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1777896445622999)
Morning @Tina Henares! I've forwarded you an email from Beth with more <https://docs.google.com/document/d/1vx5OeBejR9IJFrcdN7U9bTo-M0JBgM7jVVV_wpxbB4U/edit?tab=t.0|landing page> and <https://docs.google.com/document/d/14qLqmAaO1lOgH9ewCJu-eSghV9AHyNw1xjqFMLXAy3g/edit?tab=t.0|email copy updates>. Can you assist with those and let us know if you have any questions?

@Whitney Hodges this makes me think that we may want to put a limit on the number of copy edits/tweaks that can be be made. I know some copywriters actually tell you that you get a certain number of edits, then afterwards there is an additional fee.

Also @Whitney Hodges Beth is possibly asking for another landing page.  Not exactly sure what she's referencing. Can you take a look at <https://docs.google.com/document/d/1vx5OeBejR9IJFrcdN7U9bTo-M0JBgM7jVVV_wpxbB4U/edit?tab=t.0|the copy doc>/the email she sent and let me know what you think she's referring to?

Thanks!

**Whitney Hodges** · 2026-05-04 19:44 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1777923891027849)
@Danielle McGinnis Hi! I looked through the doc Beth provided and saw the part at the very end where she's asking for feedback on the ads traffic landing page they created on their website. I don't think she's asking for us to create this in LeadLock. I believe Felipe has already shared this with Jacqueline and Carmen in the VAULT. I think Beth may just be out of the loop on who to ask for what. I think she sees us as all intertwined instead of the LeadLock build being separate with a very defined scope, so if you're going to leave her comments in the doc or however you plan to get back to her. I would say something along the lines of - "Great job on the ads traffic landing page! Felipe is welcome to share this inside The VAULT for a thorough review and detailed feedback from our ads team if he hasn't already."

Daniela and I will talk through how we can set better expectations during the sales process and better define scope when it comes to email copy, including potential upgrades for custom emails written from scratch.

Thank you!

cc @Tina Henares @daniela
📎 image.png (png, saved as `files/F0B14G0D0DD-image.png`)

**Danielle McGinnis** · 2026-05-05 18:52 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1778007121645319)
@Tina Henares would you be able to assist me with an A2P compliance page for Luxury Travel Boutique? The funnel is called A2P Compliance Website. You can use <https://info.theeliawilmington.com/home|The Elia's site> as an example. I know this is our first time with you working on this different funnel for A2P so please let me know if you have questions! The site should be extremely basic and I still info directly from the main website to create the A2P one.

**Danielle McGinnis** · 2026-05-11 19:34 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1778528060502619)
@Whitney Hodges Luxury Travel Boutique has been submitted for A2P compliance!

**Danielle McGinnis** · 2026-05-12 16:55 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1778604956830949)
@Whitney Hodges Tina has completed the <https://docs.google.com/document/d/1vx5OeBejR9IJFrcdN7U9bTo-M0JBgM7jVVV_wpxbB4U/edit?tab=t.0|landing page> and <https://docs.google.com/document/d/14qLqmAaO1lOgH9ewCJu-eSghV9AHyNw1xjqFMLXAy3g/edit?tab=t.0|email copy updates> for Beth. Would you like to review everything before I send it back to Beth?

**Danielle McGinnis** · 2026-05-14 12:54 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1778763273703929)
@Whitney Hodges Luxury Travel Boutique is now A2P compliant! Also just wanted to circle back on the emails for Beth. Would you like to review prior to my sending them back to Beth? Thanks so much!
> **Whitney Hodges** · 2026-05-14 13:30 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1778765425961579)
> @Danielle McGinnis Thank you! Yes, I'll review today. When you send this, what do you think about positioning this to Beth as "Here are our final edits. If you'd like any other changes, please make them inside the doc."?
> **Danielle McGinnis** · 2026-05-14 21:09 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1778792954846669)
> @Whitney Hodges I think that makes perfect sense to position it that way!
> **Whitney Hodges** · 2026-05-18 12:16 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1779106600790519)
> @Danielle McGinnis Hi! Sorry for the delay. I think the emails are fine to send, but on the landing page doc, it looks like most of Beth's questions are still unanswered

**Danielle McGinnis** · 2026-05-29 20:18 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1780085923559949)
@Whitney Hodges soooooo Beth just responded.

The first bullet is doable.  She made more <https://docs.google.com/document/d/1vx5OeBejR9IJFrcdN7U9bTo-M0JBgM7jVVV_wpxbB4U/edit?tab=t.0|landing page edits> to the copy doc. :woman-facepalming::skin-tone-4:

*Landing Page Designs*
• I added a note regarding potentially adding a notification on the scheduler page to inform prospective clients that a fee will be charged for cancellations made after the deadline and for no-shows. Since the client will receive periodic reminders, I believe this information can be included in those messages as well. I set the cancellation deadline at 48 hours prior but am open to 24 hours prior as well. For people serious about meeting with me, this won't be an issue.  Hopefully, people who are just late-night clicking and not serious won't schedule. What are your thoughts here?  
• *Landing Page*-<https://docs.google.com/document/d/1-maKoB7iMRbtgNEfMhqqEX9R32ERBiy7KqFfd4Xq8SA/edit?tab=t.0|LINK to dialog> - I feel that we're not receiving the requested support for landing page suggestions. Some of the suggestions provided were very generic and didn't apply to our agency's operations. Some pretty specific questions were highlighted but not acknowledged.  
The <https://docs.google.com/document/d/14qLqmAaO1lOgH9ewCJu-eSghV9AHyNw1xjqFMLXAy3g/edit?tab=t.0|copy updates she made for the emails> is more doable.

Please let me know what you think about next steps bc I'm slightly stumped on moving forward with the landing page edits. :woozy_face:
> **Whitney Hodges** · 2026-05-29 21:34 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1780090486401549)
> @Danielle McGinnis Thanks for this! I'll chime in on the email thread as I think it would be helpful to gently clarify with Beth that your role is overseeing her LeadLock build.
> 
> The landing page in question is their asset that they have built on their own website for ads traffic and really doesn't have anything to do with LeadLock. We're happy to continue consulting with her on this, but based on her current level of support, that should be happening inside the VAULT.
> 
> @Jacqueline Hood Have you seen <https://docs.google.com/document/d/1-maKoB7iMRbtgNEfMhqqEX9R32ERBiy7KqFfd4Xq8SA/edit?tab=t.0|this version of the doc> with the things Beth has highlighted?
> I'm not sure what she means about specific questions not being acknowledged. It more so sounds likes she's just rejecting some of our suggestions.
> 
> Do you have any insight on this? I'm not really seeing much in the Discussion area. Have they been chatting you in the vault about this?
> 
> Given that she sounds unhappy, how would you feel about offering her and Felipe a complimentary 1:1 strategy call with you to talk about the landing page in more detail?
> 
> Please let me know what you think, so I can respond to her accordingly?
> 
> cc @Gisselle Jiménez
> **Jacqueline Hood** · 2026-05-30 00:45 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1780101954861259)
> Hi!
> 
> If you look in the doc, basically everything in the yellow is Beth's "rebuttal" to the suggestions I had made.
> 
> We did chat about this in depth on an office hours call a few weeks ago, as well, where she basically argued every point I was trying to make and the suggestions I was making.
> 
> For example, I suggested mentioning how many years they have been in business as a form of social proof, and her rebuttal was that it may come across as though if they have too many years experience, couples will think they are "burned out". She sort of had an excuse or rebuttal to nearly everything - so in the end of our conversation, I basically said "these are just my suggestions and thoughts, we won't know anything until we start testing and running traffic to the page.
> 
> It wasn't a very productive conversation because it felt like she was very much playing defense of the page and just didn't appear too receptive to any suggestions or considerations. In my opinion.
> 
> Felipe just emailed again late Wednesday sharing their original landing page and I said I would take another look.
> 
> I can definitely go back through the doc and reply specifically to any questions she has, but I honestly don't know that a 1:1 to talk about the LP would be that productive :woman-shrugging:
> **Whitney Hodges** · 2026-05-30 00:49 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1780102159108289)
> @Jacqueline Hood Got it! That context is very helpful. Thank you. I didn't remember that she had attended an office hours with you. I thought it was just Felipe. I agree that offering a 1:1 call doesn't make sense
> **Jacqueline Hood** · 2026-05-30 00:49 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1780102185971469)
> Side caveat:
> 
> As an engaged woman who is literally planning a destination wedding right now, the page did nothing to evoke feelings of "ahhh they know exactly what I want, they know what my worries are and they will handle it" at least in my opinion, which is what I was trying to convey to them in that the page talks a lot about Luxe and what they do, but I wish it was more centered around the couple and what THEY will experience in working with them
> **Jacqueline Hood** · 2026-05-30 00:50 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1780102222398269)
> But I also mentioned to Beth that I'm not the end all be all in LP copy, and it's just my opinion as someone who has seen a lot of LP's and also as someone in their target audience right now.
> 
> ok I'll stop rambling. lol
> **Whitney Hodges** · 2026-05-30 00:51 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1780102281983599)
> Totally makes sense
> **Jacqueline Hood** · 2026-05-31 20:05 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1780257935136149)
> @Whitney Hodges how is this for a response to Beth?
> 
> Hi Beth,
> 
> Thank you so much for taking the time to walk through my landing page feedback in such detail.
> Before I dig into specifics, I just want to say that my recommendations or suggestions are just that and are drawn from general landing page best practices (and my own personal opinion as an engaged woman planning a destination wedding in Mexico, someone in your target audience).
> 
> Ultimately, you know your business and your couples better than we do so your expertise absolutely should be acknowledged here.
> 
> A few thoughts on what you raised:
> 
> On the couple fears section: you asked where those concerns came from; they were drawn from general destination-wedding industry pain points, not from your specific couples. That said, what you actually hear from your brides is more accurate and powerful so feel free to lean into the top concerns you do hear from your brides here.
> 
> On the "stress-free" language - fair point. Weddings do involve emotional and financial complexity, and over-promising "stress-free" can be misleading. Maybe the reframe is that you offer expert guidance and support _when_ stress happens.
> 
> On trust signals (years/wedding count) - I see your point, but I’d argue that the benefit of “20 years experience” (for example) outweighs the potential assumption that you’re “burned out”. This isn’t a make or break point on the page, I don’t think, so if it doesn’t feel aligned, feel free to leave it out!
> 
> On reviews - yes, I saw the love stories and they're really strong. My one specific suggestion would be to move one short, punchy testimonial above the fold (right alongside or just under the inquiry CTA). That builds trust before the scroll, which matters because most visitors decide whether to engage within the first few seconds of landing. The deeper testimonials and love stories can stay exactly where they are as they do a great job.
> 
> Ultimately, we need to let the data decide as we can speculate all day long :slightly_smiling_face:
> 
> Thank you again for the care you've put into this. We want to ensure we are being a useful resource on the marketing side of things, but we also want to respect that this is your business, your brand, and your couples and you're the experts there.
> 
> Would love to hear your thoughts.
> **Whitney Hodges** · 2026-05-31 20:33 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1780259581374469)
> @Jacqueline Hood I think this is great, but I wonder if you should close with encouraging them to make the changes/additions that align with them and leave out what doesn't. I think the goal here is getting a new landing page live and seeing how that impacts results as opposed to continuing to debate back and forth on this. 
> 
> For what it's worth, my plan for my next live workshop is to teach how our clients can/should be conducting market research, so they have a clearer idea of what to say in their ads/landing page based on their own real data
> 
> Cc @Gisselle Jiménez
> **Jacqueline Hood** · 2026-05-31 20:59 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1780261172276139)
> Love that idea!!
> **Jacqueline Hood** · 2026-05-31 21:11 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1780261879240779)
> How's this @Whitney Hodges?
> 
> Hi Beth,
> 
> Thank you so much for taking the time to walk through my landing page feedback in such detail.
> Before I dig into specifics, I just want to say that my recommendations or suggestions are just that and are drawn from general landing page best practices (and my own personal opinion as an engaged woman planning a destination wedding in Mexico, someone in your target audience).
> 
> Ultimately, you know your business and your couples better than we do so your expertise absolutely should be acknowledged here.
> 
> A few thoughts on what you raised:
> 
> On the couple fears section: you asked where those concerns came from; they were drawn from general destination-wedding industry pain points, not from your specific couples. That said, what you actually hear from your brides is more accurate and powerful so feel free to lean into the top concerns you do hear from your brides here.
> 
> On the "stress-free" language - fair point. Weddings do involve emotional and financial complexity, and over-promising "stress-free" can be misleading. Maybe the reframe is that you offer expert guidance and support _when_ stress happens.
> 
> On trust signals (years/wedding count) - I see your point, but I’d argue that the benefit of “20 years experience” (for example) outweighs the potential assumption that you’re “burned out”. This isn’t a make or break point on the page, I don’t think, so if it doesn’t feel aligned, feel free to leave it out!
> 
> On reviews - yes, I saw the love stories and they're really strong. My one specific suggestion would be to move one short, punchy testimonial above the fold (right alongside or just under the inquiry CTA). That builds trust before the scroll, which matters because most visitors decide whether to engage within the first few seconds of landing. The deeper testimonials and love stories can stay exactly where they are as they do a great job.
> 
> All in all, you know your brand and your audience more closely than we do. I'd recommend making any changes/additions that align with you and leave out what doesn't. Once we start sending traffic to the page, we'll be able to get a sense of how things are performing!
> **Whitney Hodges** · 2026-05-31 21:14 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1780262045442949)
> @Jacqueline Hood
> 📎 audio_clip_2026-05-31_16-13-11-570.m4a (m4a, saved as `files/F0B7AGXPXUJ-audio_clip_2026-05-31_16-13-11-570.m4a`)
> **Jacqueline Hood** · 2026-05-31 21:20 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1780262433260349)
> Done and sent! Sorry for bugging you on the weekend :slightly_smiling_face:

**Danielle McGinnis** · 2026-06-10 11:30 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1781091001322469)
Good morning @Tina Henares! I wanted to ask a favor with <https://docs.google.com/document/d/14qLqmAaO1lOgH9ewCJu-eSghV9AHyNw1xjqFMLXAy3g/edit?tab=t.0|Luxury Travel Boutique's email copy>. I've make all of the tweaks to the emails Beth requested, except for one. She is suggesting Email #4 of the Room Block Only Sequence Be sent earlier in the sequence. Can you make a recommendation on where that email needs to be moved to in the sequence? Also, I'm thinking she wants the email rewritten based on the image she pasted so can you tweak the copy on the document as well? Once this piece is finished I'll reach out to Beth for her final review.

Als @Whitney Hodges Beth is asking about including photos in the emails. I'd like it if she would provide the photos and specify which emails she wants them added to, but let me know your thoughts.

Thank you both!
> **Tina Henares** · 2026-06-10 18:14 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1781115282132499)
> Hi @Danielle McGinnis! I'd suggest moving it up to be Email #2 in that sequence now. Should I make that change in the doc? I also tweaked the copy to specifically cite the Tailored Advantages she listed. Thanks!
> **Danielle McGinnis** · 2026-06-10 20:34 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1781123695453179)
> @Tina Henares Beth is in the inbox as we speak and so yes let's make that change in the doc as soon as possible as I'm about to reach out to respond to her now. Thank you so much!
> **Tina Henares** · 2026-06-10 20:38 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1781123926606649)
> @Danielle McGinnis done!
> **Danielle McGinnis** · 2026-06-10 20:39 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1781123950841299)
> Thank you so much!

**Whitney Hodges** · 2026-06-10 13:10 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1781097024213729)
@Danielle McGinnis I think it's important for her to be aware that photos in emails can impact deliverability. I would avoid using them in the initial emails, but subsequent ones should be ok, as long as it's a single optimized photo, not multiple images. The image will need to be compressed, so that they're as small as possible. cc @Tina Henares

**Danielle McGinnis** · 2026-06-10 20:57 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1781125066497889)
@Gisselle Jiménez just wanted to circle back to confirm you're able to update the Onboarding scheduler to include Whitney as I just responded to Beth with the link to book her onboarding call pending review/testing. Thanks!
> **Gisselle Jiménez** · 2026-06-10 21:09 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1781125798720379)
> Hi @Danielle McGinnis! I did add Whitney, but the calendar is set as a service calendar, not a collective calendar, so I'm not sure if it will actually create a meeting with both of you:slightly_frowning_face:
> **Danielle McGinnis** · 2026-06-10 21:13 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1781125987878569)
> UGH @Gisselle Jiménez! I can see the availability is now not correct bc I'm not working a full week next week and it's showing availability all week. :face_with_peeking_eye:
> **Gisselle Jiménez** · 2026-06-11 13:42 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1781185362167009)
> @Danielle McGinnis Ah, then yes, it's showing availability for both of you:') I'll remove Whitney for now.
> 
> Do you want me to create a collective calendar you can resend to Beth?
> **Gisselle Jiménez** · 2026-06-11 13:43 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1781185401273859)
> Actually, let me create the collective calendar and just update it in the page!
> **Danielle McGinnis** · 2026-06-11 13:44 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1781185440558869)
> Omg that woulw be great! Thank you so much!
> **Gisselle Jiménez** · 2026-06-11 13:51 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1781185891154599)
> @Danielle McGinnis Calendar has been switched in the page, but when checking the email you sent to Beth, I see you sent her the link to the actual calendar, not the scheduler page:face_holding_back_tears:
> **Gisselle Jiménez** · 2026-06-11 13:51 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1781185918977999)
> You can resend her this link: <https://support.leadlockpro.com/onboarding-call>

**Danielle McGinnis** · 2026-06-10 21:36 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1781127382213339)
@Tina Henares Beth responded already. :grimacing:

Edit #1 image below. Can you get this updated for us? :pray::skin-tone-4:
📎 IMG_1871.jpg (jpg, saved as `files/F0B9P2S4Y5C-IMG_1871.jpg`)
> **Tina Henares** · 2026-06-10 22:09 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1781129367071389)
> @Danielle McGinnis I added a gray color to the background and bolded the green text to make it easier to read.
> Could you help me find their Landing Page link since it's not with us in LeadLock?
> 📎 Screenshot 2026-06-10 170129.png (png, saved as `files/F0B9UU2KNMS-Screenshot_2026-06-10_170129.png`)
> **Tina Henares** · 2026-06-10 22:44 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1781131462551429)
> @Danielle McGinnis Never mind, I found the landing page link in one of her emails!

**Danielle McGinnis** · 2026-06-10 21:48 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1781128099836199)
@Tina Henares Edit #2 

Beth requested language re: a cancellation be to added to all appointment confirmations and reminders and to the scheduler page. I email forwarded you the email. 

**Danielle McGinnis** · 2026-06-11 11:27 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1781177238953409)
Morning @Tina Henares just a quick heads up regarding edit #2, I added this languge to the appointment confirmations and reminders and Beth's scheduler pages: _*Note: A fee will be charged for cancellations made after the deadline and for no-shows."_ Feel free to tweak it. I am about to send an email back to Beth to start testing LeadLock again and I didn't want her to not see any updates and ping us again. ha ha
> **Tina Henares** · 2026-06-11 14:42 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1781188951715799)
> @Danielle McGinnis thank you!
> **Tina Henares** · 2026-06-11 15:02 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1781190139685219)
> @Danielle McGinnis Looks great! The only thing I was thinking is should we say in the message that the deadline is 48 hours prior - to make sure the leads are aware? Or is that information somewhere else?
> **Danielle McGinnis** · 2026-06-11 15:22 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1781191371140349)
> @Tina Henares Beth came back with more edits and I think this will also clarify your question. I forwarded you her email. :face_with_peeking_eye:
> **Tina Henares** · 2026-06-11 16:55 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1781196945784819)
> @Danielle McGinnis Thanks for sending that over - I've been working on her edits and wanted to check with you about some things.
> • She does not currently have an SMS sequence in LeadLock. Should I create a quick sequence for her?
> • She says she can't see the full emails on her phone because they're shifted right . I can go in to each email and change the padding to shift email content left - please let me know if there's a better way to do this. I don't think it's usually an issue?
> • I added the cancellation policy acknowledgement as a required checkbox to both booking pages.
> • She wants to change the email address in the footer to be <mailto:destinationweddings@experienceluxetravel.com|destinationweddings@experienceluxetravel.com> instead of coming from her email. It's a custom value so I wanted to check with you before changing it!
> • I'll go through and update her email signatures shortly. 
> • And the last edits are finished!
> **Danielle McGinnis** · 2026-06-11 16:59 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1781197185444919)
> @Whitney Hodges will defer to you on the SMS question 
> 
> I was thinking the same thing about the emails. I’ve never known for this to be an issue before. Definitely try adjusting the padding and send yourself a test to see if that helps?
> 
> Re: the cancellation policy, thank you!
> 
> Regarding changing the email address. Let's go ahead and just manually type it in (without updating the actual custom value) so as not to interrupt anywhere else thar custom value is listed 
> 
> That's it for now. Thank u so much!
> **Danielle McGinnis** · 2026-06-11 16:59 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1781197198062899)
> @Tina Henares sorry forgot to tag u. Haha
> **Tina Henares** · 2026-06-11 17:23 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1781198602141969)
> @Danielle McGinnis no worries and sounds good, thank you!
> 
> Since I'll be updating all the email templates with these details, I'll go ahead and update the copy as well. Where did Beth land on having images in emails?
> 
> Also, I can set up a personal email signature for her so its on all her outgoing emails like the one we did for Catherine. It'll be easier since there are no pictures :slightly_smiling_face:
> **Danielle McGinnis** · 2026-06-11 20:50 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1781211047406059)
> @Tina Henares Beth never came back with anything regarding the pictures. 
> 
> Sounds good about the email signature. Thank you!
> **Tina Henares** · 2026-06-12 18:43 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1781289836675369)
> @Danielle McGinnis Emails have been updated! Also, she's not doing a post-consult email sequence with us, correct?
> **Danielle McGinnis** · 2026-06-12 18:45 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1781289949933709)
> @Tina Henares Thank you!! I don't think the post consult sequence was offered initially when Beth signed on. 
> 
> @Whitney Hodges thoughts? 
> **Tina Henares** · 2026-06-12 18:48 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1781290137484779)
> @Danielle McGinnis I don't believe so either just wanted to make sure :slightly_smiling_face: thanks!
> **Danielle McGinnis** · 2026-06-12 18:49 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1781290177680849)
> You're welcome!

**Gisselle Jiménez** · 2026-06-11 14:48 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1781189338263289)
@Whitney Hodges Beth tagged you in one of the emails in case you wanted to chime in, but Danielle has been addressing her edits
📎 image.png (png, saved as `files/F0B9R71GNCB-image.png`)

**Jacqueline Hood** · 2026-06-11 20:49 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1781210951811719)
Just met with Felipe and wanted to share a quick update!
We're now sending all ads traffic to this updated landing page: <https://www.experienceluxetravel.com/destination-wedding-venue-selection?fbclid=IwY2xjawSX_AlleHRuA2FlbQIxMABicmlkETFhdU1ycTRiWmk5cFJrTlZrc3J0YwZhcHBfaWQQMjIyMDM5MTc4ODIwMDg5MgABHs75SR55wEqMPNhuyd_-c3Ri8-btA6hZDWy5BMVY84MddaSplzfAbuz9n36-_aem_WKyIUGSGM1P4c2es5e1m_Q|https://www.experienceluxetravel.com/destination-wedding-venue-selection?fbclid=IwY2xjawSX_[…]Wy5BMVY84MddaSplzfAbuz9n36-_aem_WKyIUGSGM1P4c2es5e1m_Q>
It went live on Monday. Since then, it's generated 3 leads on Meta for *$11 each*.

LP conversion rate prior (for the same ads) was around 21%; it's sitting at *37.5%* currently this week :slightly_smiling_face: Looks like the recommendations/changes to the page and new copy that we've been doing for them is off to a good start!
> **Whitney Hodges** · 2026-06-11 22:34 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1781217287316449)
> @Jacqueline Hood Incredible!!

**Danielle McGinnis** · 2026-06-16 13:20 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1781616027247599)
@Whitney Hodges good morning! Would love to know your thoughts on Beth's message re: the email formatting issue for Android....
> **Whitney Hodges** · 2026-06-16 13:27 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1781616424498479)
> @Danielle McGinnis I have an android, and haven't noticed any formatting issues with our emails on mobile. Can you please send test emails from Beth's sequence to me at <mailto:whitneymichellehodges@gmail.com|whitneymichellehodges@gmail.com>, and I'll take a look?
> **Danielle McGinnis** · 2026-06-16 13:29 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1781616541156649)
> @Whitney Hodges just sent over a test!
> **Whitney Hodges** · 2026-06-16 13:33 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1781616832090189)
> @Danielle McGinnis ok, the email looks great to me! Screenshot attached. I've never had to adjust the settings on my phone for our emails to be formatted properly.
> 
> @Danielle McGinnis @Tina Henares in doing a bit of research, I learned that there are specific mobile formatting settings for emails in GHL. See below. Maybe this would fix what Beth is experiencing 
> 
> Configure Mobile Formatting Settings
> GoHighLevel features specific settings dedicated to how your emails render on mobile screens.Open your Email template, navigate to the Appearance tab, and click Mobile Formatting.Ensure your font heights, button alignments, and paddings are explicitly toggled and set for mobile clients.Pro-tip: Avoid using overly complex multi-column blocks (like 3 or 4 columns) in your templates, as these often force content off-screen on smaller Android devices.
> 📎 Screenshot_20260616-082945.png (png, saved as `files/F0BAY2YSJSE-Screenshot_20260616-082945.png`)
> **Danielle McGinnis** · 2026-06-17 19:45 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1781725542109379)
> Hey @Tina Henares , Beth is in the inbox again. I forwarded you her message. Dis you have a chance to update the padding on the emails? She's still saying it's not viewing properly. :expressionless:
> 
> She is also now requesting the initial inquiry text message be reworded. Can you assist?
> 
> Also she's asking if we can update the send email address on all email templates. Can you assist with that also?:pray::skin-tone-4:
> 
> @Whitney Hodges I just want to be clear. Beth is back on copy edits. What is our maximum when it comes to making copy edits with Beth? I just feel like she's about to send us down another rabbit hole:sob:
> **Tina Henares** · 2026-06-18 12:58 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1781787482259209)
> Hi @Danielle McGinnis , yes I used updated padding in all the emails already and took a look at the mobile formatting settings Whitney shared above. I'll shift the text over more but besides that I'm not sure what else to do.
> 
> Regarding the inquiry text message, I don't see any snippets in LeadLock for her. Is the inquiry text message housed somewhere else?
> **Tina Henares** · 2026-06-18 13:07 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1781788034308349)
> @Danielle McGinnis I updated her emails to be sent from Luxury Travel Boutique and the destination weddings in settings on the workflow level here.
> 📎 Screenshot 2026-06-18 080308.png (png, saved as `files/F0BBFU00Z9U-Screenshot_2026-06-18_080308.png`)

**Gisselle Jiménez** · 2026-06-18 20:00 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1781812807877829)
Hi, @Danielle McGinnis! Here is the link for the joint onboarding scheduler that includes you and Whitney
<https://support.leadlockpro.com/onboarding-call-joint>

**Danielle McGinnis** · 2026-06-24 01:51 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1782265918820949)
@Whitney Hodges here's my email draft to Beth:

Good morning Beth,

I hope you're doing well. I wanted to follow up on the remaining edits you requested in your LeadLock account.

1. Welcome email not formatted properly - We updated the padding in all emails, adjusted the mobile formatting settings and attempted to shift the text over more in the email template. Hopefully that does the trick for when you view it from your phone.
2. Change all emails and communications to send from <mailto:destinationweddings@experienceluxetravel.com|destinationweddings@experienceluxetravel.com> instead of <mailto:beth@experienceluxetravel.com|beth@experienceluxetravel.com> - we've made this change on all of your email templates.
3. Text message does not convey a warm welcome or excitement - we're currently working to update this text to make it sound more welcoming. Just a quick note: all of the email and text copy will be fully customizable once your account is live. You'll have full access to tweak the sms messages and emails to enhance them however you'd like. I hope this is helpful to know that the information we've added in can be replaced at any time. :-)

I've removed all of your tags from your test contact in LeadLock so you can run another test whenever you're ready. (Just a quick note that the text message is the last piece that hasn't been updated as of yet.)

Please let me know if you have any questions.

Thank and chat soon!

**Danielle McGinnis** · 2026-06-24 14:19 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1782310789090259)
@Whitney Hodges hi! Following up on this as Beth is in the inbox again. Thanks!

**Whitney Hodges** · 2026-06-24 15:01 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1782313269953559)
@Danielle McGinnis I sent a test of the "I'm ready" welcome email to myself, and it did not look great on mobile. There was zero padding on the left, and the thumbnail for the video was distorted. I added 20 px padding on the left and set the video height and width to auto. For me, it now looks much better on my Android. But I'm not sure what these settings were previously.

I think we should ask Beth is this first email now looks better for her on her device, and if so, we make sure the mobile padding for all other emails matches it.

Also, I don't think it's acceptable at this point to let her know that the text has not yet been revised when that request came through a week ago. I went ahead and updated the snippet. See attached.

I think it would also be good in this email to go ahead and include the link for the onboarding call. If there are still issues. We can hash it out live on a call rather than have this extended email dialogue back and forth.

Thank you!
📎 image.png (png, saved as `files/F0BDQB19R5W-image.png`)

**Danielle McGinnis** · 2026-06-24 15:31 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1782315065869629)
@Whitney Hodges noted. 

**Whitney Hodges** · 2026-06-24 15:32 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1782315161799659)
@Danielle McGinnis I just emailed her, so if you could please chime in with the specifics on the edits and the onboarding link today, I would appreciate it. Thank you so much! Very excited to get this one launched!!!

**Danielle McGinnis** · 2026-06-24 15:33 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1782315224659949)
@Whitney Hodges I she she requested a call with you. Should I still proceed with the onboarding scheduling link or wait until after you meet with her?

**Whitney Hodges** · 2026-06-24 15:34 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1782315298064239)
@Danielle McGinnis I think you can go ahead and include the link. I mentioned in my email to her that I'd like to go ahead and get this scheduled but in the meantime that I can give her a phone call. I'm hoping to connect with her tomorrow morning. I'll update you once I meet with her. Thank you!

**Tina Henares** · 2026-06-24 15:35 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1782315346030689)
@Whitney Hodges The text padding was at 20px on the left and 40px on the right when Beth sent her last response with the edits. I just shifted it over more now since she said it still wasn't formatting correctly and I thought her concern was the text was too far right. I'll go in and make sure all the padding for the emails is consistent with the new welcome email. Thank you!!

**Danielle McGinnis** · 2026-06-24 15:36 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1782315409168799)
@Whitney Hodges @Tina Henares this was my concern, that that's where the settings were initially :weary:

**Whitney Hodges** · 2026-06-24 15:38 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1782315530730659)
@Tina Henares @Danielle McGinnis Thank you for letting me know! Maybe we try for padding of 5px or 10px at the left, and see if we can get Beth's approval on that? When it was 0px on the left, it looked odd on mobile, and I bet Beth would have complained about that too :joy:

**Tina Henares** · 2026-06-24 15:39 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1782315573591709)
@Whitney Hodges @Danielle McGinnis Since in the more recent email with edits she only cited the welcome email not formatting correctly, hopefully the auto video formatting helps :crossed_fingers::skin-tone-3::crossed_fingers::skin-tone-3:

**Whitney Hodges** · 2026-06-24 15:39 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1782315574678149)
@Tina Henares But before you edit all of the emails, let's get her approval on this first one...

**Tina Henares** · 2026-06-24 15:41 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1782315666173859)
@Whitney Hodges Yes, I was planning to wait until she approves before editing them again. Thank you!

**Whitney Hodges** · 2026-06-24 15:41 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1782315685111059)
If I need to get on a working Zoom session with her where I play around with padding in real time and send her test emails along the way, I will!

**Danielle McGinnis** · 2026-06-24 15:43 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1782315784478009)
Email sent :face_with_peeking_eye:

**Whitney Hodges** · 2026-06-25 14:19 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1782397164970619)
@Danielle McGinnis @Tina Henares I have a phone call with Beth this morning at 10am CST. I'll keep y'all posted
> **Whitney Hodges** · 2026-06-25 15:42 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1782402179802709)
> @Danielle McGinnis @Tina Henares The call with Beth was good overall. What needs to happen at this point is that we prioritize/expedite any final requests from her to finally get this launched.
> 
> I will meet with her 1:1 next week to get the email formatting worked out in real time (I'll let you know once this is scheduled). I explained to her that we hadn't adjusted formatting in all emails yet because we wanted to get the first one right first then we will adjust all others accordingly.
> 
> Can you please work on/respond to her other requests today? If you have questions on any of these for me, please let me know
> 
> Thank you!
> **Danielle McGinnis** · 2026-06-25 15:44 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1782402279746519)
> I plan to work on her requests today. Does she intend to book her onboarding call?
> **Whitney Hodges** · 2026-06-25 15:46 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1782402386281929)
> Probably not until she meets with me first
> **Danielle McGinnis** · 2026-06-25 15:54 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1782402842703579)
> So she's asking for the email address to be updated from the sender. Things like that require her to reconnect the new email address which we would do in the call
> **Whitney Hodges** · 2026-06-25 15:55 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1782402949036529)
> I think if you just explain that in your reply, it will be fine
> **Danielle McGinnis** · 2026-06-25 15:55 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1782402957877919)
> Ok:weary:
> **Whitney Hodges** · 2026-06-25 19:21 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1782415262999299)
> @Danielle McGinnis I meet with her Monday morning. On that call, I can add a user for that email address and have her connect the email address
> **Danielle McGinnis** · 2026-06-25 19:21 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1782415309067779)
> @Whitney Hodges I just changed the business email address as well. That may do the trick

**Danielle McGinnis** · 2026-06-25 20:11 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1782418274485599)
@Whitney Hodges Beth is wanting to remove one of the unsubscribe links from the emails. So there are two because the one  at the very bottom is the legal requirement.
Per GHL, "Beyond best practices, unsubscribe links are a legal requirement under multiple international regulations. Failing to include them can lead to serious financial penalties."

The second one is the one we added in as the set references page. Can you please advise on how you want me to respond about this? I would like to tell her, no, we can't remove them but would like to know your thoughts.

Thanks
📎 image (16).png (png, saved as `files/F0BD2DU3ZEX-image_16_.png`)
> **Whitney Hodges** · 2026-06-25 20:38 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1782419915964449)
> @Danielle McGinnis I was going to say that I'd let her know that the one at the very bottom is legally required but that we can remove the one in the footer itself
> **Danielle McGinnis** · 2026-06-25 20:43 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1782420226929319)
> If we remove the one in the footer, it eliminates the set preferences page @Whitney Hodges. Is that ok?
> **Whitney Hodges** · 2026-06-25 20:46 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1782420413660399)
> @Danielle McGinnis It's definitely not ideal. I think your response to her was fine. We'll see what she says.

**Danielle McGinnis** · 2026-06-25 20:37 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1782419879694349)
@Whitney Hodges I went ahead and responded to her because I did not want it to get too late and her to ping us again. I hope my response was ok. I am about to send her all of the test emails now.

**Whitney Hodges** · 2026-06-29 15:47 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1782748022366589)
@Danielle McGinnis Hi! Just got off of the call with Beth. It was good! I'll bring you up to speed on the team call. In the meantime, can you please book her for a joint onboarding call with us on Monday, July 6 at 12pm EST? Thank you!

**Gisselle Jiménez** · 2026-06-30 19:27 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1782847631126649)
Hi, @Tina Henares! Here's a link to the <https://drive.google.com/file/d/16F6TjNV4jz6itCFOonbegQOgvvebtCcP/view?usp=drive_link|recording >and <https://docs.google.com/document/d/1lL96JezGFn26gOxCEOWSlehycPlhzsnAd8bAuZvEYxg/edit?usp=drive_link|summary> of Whitney and Beth's call from yesterday, where they made formatting changes to one of the inquiry emails (Track B?) that need to be applied across all of her other emails.

Could you please watch the recording to see exactly what was changed? A few key updates include making hyperlinks bold, sage colored, and underlined, updating the signature, and adjusting padding to 20 pixels on each side.

Once you've reviewed it, please go through each of Beth's remaining emails and apply the same changes. Whitney also mentioned it would be good to send yourself test emails on mobile to double-check everything renders correctly. Let us know if you have any questions!

cc: @Whitney Hodges
> **Whitney Hodges** · 2026-07-02 23:05 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1783033529148289)
> @Tina Henares Hi! Just checking in on this. I want to make sure you're aware that @Danielle McGinnis and I are scheduled to meet with Beth for her onboarding on Monday
> **Tina Henares** · 2026-07-02 23:13 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1783034038118209)
> @Whitney Hodges Yes thanks for checking in, it's next on my to do list! I'll have it done by Monday
> **Tina Henares** · 2026-07-03 23:03 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1783119814198059)
> @Whitney Hodges @Danielle McGinnis just finished editing all of Beth's emails! I test sent them to myself while working on them and made my email inbox dark on my phone so I could see that view as well. Hopefully we're all set now! :crossed_fingers::skin-tone-3:

**Whitney Hodges** · 2026-07-06 16:00 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1783353623616969)
@Danielle McGinnis Hi! What is the link for the onboarding call with Beth?

**Danielle McGinnis** · 2026-07-06 16:01 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1783353685409079)
It's my Zoom room

**Danielle McGinnis** · 2026-07-06 16:01 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1783353687726809)
Just a sec

**Gisselle Jiménez** · 2026-07-06 16:02 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1783353720348099)
I've added it! Here it is: <https://support.leadlockpro.com/zoom|support.leadlockpro.com/zoom>

**Danielle McGinnis** · 2026-07-06 22:15 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1783376126633959)
@Tina Henares just received updates from Beth and forwarded the email to you. 
> **Tina Henares** · 2026-07-07 03:14 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1783394062616449)
> Hi @Danielle McGinnis! Just looked at Beth's email and I'm wondering if we might be experiencing a glitch in LeadLock where the email templates are not updating/syncing to workflows?
> 
> The first image here is the one she emailed us and the second is from my test email to myself on
> Friday (I tested it again just now to confirm it's still showing up the same and it is).
> 📎 image.png (png, saved as `files/F0BFPCV9XV2-image.png`)
> 📎 Screenshot 2026-07-06 220548.png (png, saved as `files/F0BFKM7MFGA-Screenshot_2026-07-06_220548.png`)
> **Tina Henares** · 2026-07-07 03:22 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1783394538926189)
> @Danielle McGinnis I looked into it more and found this! Continuous sync for this template (and probably others too) was disabled so the changes I was making to the template were not syncing to the workflow email. Could you help me look into this further tomorrow?
> 📎 Screenshot 2026-07-06 221856.png (png, saved as `files/F0BFKNBKVUJ-Screenshot_2026-07-06_221856.png`)
> **Danielle McGinnis** · 2026-07-07 11:20 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1783423227993689)
> @Tina Henares hmm ok I thought that was turned on for all templates. Let me check 
> **Whitney Hodges** · 2026-07-07 22:02 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1783461753719079)
> @Gisselle Jiménez can you please look into this since Danielle is OOO tomorrow? We need to get this project wrapped up once and for all
> **Danielle McGinnis** · 2026-07-07 22:49 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1783464597553069)
> @Whitney Hodges Im about to look into it right now
> **Danielle McGinnis** · 2026-07-08 00:30 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1783470617007059)
> @Whitney Hodges @Tina Henares I just sent tests to Beth. Not sure what happened in the workflows bc the template sync was turned on in the workflows but Im not sure why they didnt sync properly. To be safe I readded all of the templates in the workflows so the templates with the most recent changes are synced. Let's see what Beth says. :face_with_peeking_eye::pray::skin-tone-4:

**Danielle McGinnis** · 2026-07-09 17:14 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1783617253622289)
@Tina Henares additional updates requested from Beth


📎 IMG_2059.png (png, saved as `files/F0BGCJL6N2D-IMG_2059.png`)
> **Tina Henares** · 2026-07-09 18:22 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1783621376930589)
> @Danielle McGinnis Done! All words in email subject lines have been capitalized
> **Danielle McGinnis** · 2026-07-09 18:25 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1783621539317729)
> @Tina Henares thank you so much! I will let her know!

**Danielle McGinnis** · 2026-08-04 17:52 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1785865924815789)
<!channel> quick update. Sent Beth a follow up email regarding her changes. Hopefully she[ in a better position to get those back to us so we can finalize her account.

**Whitney Hodges** · 2026-09-04 16:56 · [link](https://weddingindustryads.slack.com/archives/C08QU9K31KN/p1788540990668769)
Nothing here that LTB's time zone at a subaccount level will need to be changed, but also something to keep in mind and get in front of is Beth's frequent travel schedule/changing time zones. Not sure how that may affect her bookings
