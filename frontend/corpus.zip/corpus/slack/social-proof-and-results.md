# #social-proof-and-results

Private channel · `C091CPQD8L9`
Pulled 2026-09-25 by `corpus/fetch-slack.mjs`.

32 parent messages · 35 thread replies · 32 files downloaded.
Covers 2025-06-11 → 2026-08-14.

Thread replies are indented with `>`. Every message links back to Slack, so a
candidate drawn from here carries its source the way a transcript quote carries
a timecode.

---

**Whitney Hodges** · 2025-06-11 15:47 · [link](https://weddingindustryads.slack.com/archives/C091CPQD8L9/p1749656843312629)
<!channel> Hi! Moving forward, if you have great results, feedback, screenshots, etc. pertaining to our clients or members, please drop it here. The goal is to work more social proof and results into our IG and email marketing content. Thank you!!

**Whitney Hodges** · 2025-06-20 12:36 · [link](https://weddingindustryads.slack.com/archives/C091CPQD8L9/p1750422960425199)
@Yulia Burris Here's a great testimonial sent via email re: the Meta Ads Immersive Experience. I'd love to see this worked into our content
📎 image.png (png, saved as `files/F091X5BKUJ3-image.png`)

**Christina Hill** · 2025-06-24 16:32 · [link](https://weddingindustryads.slack.com/archives/C091CPQD8L9/p1750782735277589)
@Yulia Burris @Whitney Hodges The Weinberg at Wixon Valley | Meta Ads YOY :tada:
📎 Screenshot 2025-06-24 at 12.29.57 PM.png (png, saved as `files/F093HD51W6L-Screenshot_2025-06-24_at_12.29.57_PM.png`)
📎 Screenshot 2025-06-24 at 12.28.03 PM.png (png, saved as `files/F092EJQUG5V-Screenshot_2025-06-24_at_12.28.03_PM.png`)
> **Whitney Hodges** · 2025-06-24 16:34 · [link](https://weddingindustryads.slack.com/archives/C091CPQD8L9/p1750782875314219)
> That's cool! I didn't even know we could look at it year over year like that

**Megan Jivraj** · 2025-07-09 16:03 · [link](https://weddingindustryads.slack.com/archives/C091CPQD8L9/p1752077011980059)
Hey Team! I am popping Courtney's <https://portal.dubsado.com/public/form/view/68093cce04ce62003a6d07bb?|feedback survey> from Aisle Planner in this channel.

**Whitney Hodges** · 2025-07-10 17:39 · [link](https://weddingindustryads.slack.com/archives/C091CPQD8L9/p1752169172617459)
Some LeadLock social proof from Mike! @daniela this could be good to incorporate into the investment guide and/or LeadLock landing page
📎 Screenshot_20250710-123117.png (png, saved as `files/F0953DTUL6P-Screenshot_20250710-123117.png`)

**Whitney Hodges** · 2025-07-17 21:25 · [link](https://weddingindustryads.slack.com/archives/C091CPQD8L9/p1752787505056609)
@Yulia Burris
📎 image.png (png, saved as `files/F096RPNQW81-image.png`)

**Whitney Hodges** · 2025-07-31 19:35 · [link](https://weddingindustryads.slack.com/archives/C091CPQD8L9/p1753990518026609)
@Yulia Burris Hi! We just got off a call with one of our venue clients The Views at Sunset Ridge. They had been receiving about one lead a day through their Google Ads. We switched them to Google Performance Max, and it's more than doubled their Google lead volume (70 leads in July) without compromising quality (tour volume is up too) and while simultaneously reducing their cost per lead by more than half.

I think I'll probably use this story for my weekly marketing email next week.

@Christina Hill Are there any screenshots you can send me for support?
> **Whitney Hodges** · 2025-08-04 20:04 · [link](https://weddingindustryads.slack.com/archives/C091CPQD8L9/p1754337850377329)
> @Christina Hill circling back on this. I'd like to be able to write this email tomorrow, so it can go live Wednesday. Let me know if there are any screenshots that would be good to incorporate. Thank you!!
> **Christina Hill** · 2025-08-05 15:37 · [link](https://weddingindustryads.slack.com/archives/C091CPQD8L9/p1754408256219639)
> @Whitney Hodges yes. I will pull some screenshots for you now.
> **Christina Hill** · 2025-08-05 15:46 · [link](https://weddingindustryads.slack.com/archives/C091CPQD8L9/p1754408802291899)
> P.Max Campaign was enabled May 22, 2025.
> Here is a screenshot of April 2025 (Search Campaigns only) and July 2025 (P.Max Campaign only) Same budget, lower cost per lead, higher conversions. @Whitney Hodges
> 📎 Screenshot 2025-08-05 at 11.41.30 AM.png (png, saved as `files/F098Y0SQHGB-Screenshot_2025-08-05_at_11.41.30_AM.png`)
> 📎 Screenshot 2025-08-05 at 11.43.06 AM.png (png, saved as `files/F099HMHAZ6D-Screenshot_2025-08-05_at_11.43.06_AM.png`)
> **Whitney Hodges** · 2025-08-05 15:50 · [link](https://weddingindustryads.slack.com/archives/C091CPQD8L9/p1754409011530319)
> @Christina Hill Thank you! Is there any way to exclude CTR since that went down?
> 
> Also, anything from LeadLock that we could pull that shows an increase in tour volume?
> **Christina Hill** · 2025-08-07 15:34 · [link](https://weddingindustryads.slack.com/archives/C091CPQD8L9/p1754580877643759)
> Hi @Whitney Hodges I apologize that I missed this message. I saw that the email went out yesterday (and it looked great)! Did you still want me to pull this info for you?
> **Whitney Hodges** · 2025-08-07 15:37 · [link](https://weddingindustryads.slack.com/archives/C091CPQD8L9/p1754581035044529)
> @Christina Hill No worries! Nothing else needed. Your screenshots gave me a jumpstart. Thank you for those!!

**Christina Hill** · 2025-08-19 19:47 · [link](https://weddingindustryads.slack.com/archives/C091CPQD8L9/p1755632874462599)
*About Love (Oct 1, 2024 - July 31, 2025):*

Google Leads = 125 (screenshot)
Google Ads Impressions = 31,376

I don't have access to see her Meta metrics. Let me know if there is anything else you need me to pull :slightly_smiling_face:

@Whitney Hodges
📎 Screenshot 2025-08-19 at 3.37.48 PM.png (png, saved as `files/F09B22CSX0V-Screenshot_2025-08-19_at_3.37.48_PM.png`)
📎 Screenshot 2025-08-19 at 3.46.44 PM.png (png, saved as `files/F09B5JW752S-Screenshot_2025-08-19_at_3.46.44_PM.png`)

**Carmen Cruickshank** · 2025-08-19 20:15 · [link](https://weddingindustryads.slack.com/archives/C091CPQD8L9/p1755634504141289)
*Miss Lyss Planning (Dec 1 2024 - July 31 2025)*

Google Leads = 85 (screenshot)
Google Ads Impressions = 25,898

Meta Impressions =343,487

**Carmen Cruickshank** · 2025-08-19 20:15 · [link](https://weddingindustryads.slack.com/archives/C091CPQD8L9/p1755634522859249)
📎 Screenshot 2025-08-19 at 4.12.09 PM.png (png, saved as `files/F09AY3VAGBD-Screenshot_2025-08-19_at_4.12.09_PM.png`)
📎 Screenshot 2025-08-19 at 4.14.13 PM.png (png, saved as `files/F09B3MH90EN-Screenshot_2025-08-19_at_4.14.13_PM.png`)

**Whitney Hodges** · 2025-08-20 19:09 · [link](https://weddingindustryads.slack.com/archives/C091CPQD8L9/p1755716977341229)
@Christina Hill @Carmen Cruickshank Thank you for sharing those stats! I ended up pulling lead totals for the full duration these clients have worked with us.

@daniela I decided to turn it into a more <https://www.canva.com/design/DAGwoVzCmqY/eVqPy8xuCyH6r2D17UUYhA/edit?utm_content=DAGwoVzCmqY&amp;utm_campaign=designshare&amp;utm_medium=link2&amp;utm_source=sharebutton|formal case study> because I think this has a lot of potential to be shared beyond just this one potential client and we have really great social proof from Alyssa and Adriana. I'll definitely still record a video walkthrough before I send it to Kaley.

What do you think of using this as the jumping off point for next week's marketing email? We can share a couple of screenshots but then make people opt-in for the full video resource. Do you have the bandwidth to create a simple landing page, opt-in form, thank you page, and delivery email for this?

Let me know if you think I should make any edits in Canva!

cc @Yulia Burris
> **Whitney Hodges** · 2025-08-25 15:17 · [link](https://weddingindustryads.slack.com/archives/C091CPQD8L9/p1756135078173249)
> @daniela Please disregard the request re: an opt-in for the case studies. I'll just ask people to reply to the email if they want a copy

**Whitney Hodges** · 2025-08-21 15:26 · [link](https://weddingindustryads.slack.com/archives/C091CPQD8L9/p1755789985409219)
<!channel> FYI
📎 image.png (png, saved as `files/F09BGU9HKGE-image.png`)

**Whitney Hodges** · 2025-08-29 16:36 · [link](https://weddingindustryads.slack.com/archives/C091CPQD8L9/p1756485419192119)
<!channel> Just had an amazing call with Alyssa. She was averaging $11K months when she started with us. She's now well over $20K months. She's essentially doubling her revenue year over year. @Gisselle Jiménez Please drop the recording and transcript here when it's ready. Thank you!!
> **Gisselle Jiménez** · 2025-08-29 17:00 · [link](https://weddingindustryads.slack.com/archives/C091CPQD8L9/p1756486850736979)
> That's awesome!:partying_face: *<https://drive.google.com/file/d/16WngW5ncfVBlAKVLK2CrgxwkUnMOtXa5/view?usp=drive_link|Here>* is the recording of the meeting. I uploaded it to the WIA Results/Social Proof folder in the WIA | Marketing folder.

**Whitney Hodges** · 2025-09-03 16:58 · [link](https://weddingindustryads.slack.com/archives/C091CPQD8L9/p1756918698235309)
@Yulia Burris Can you please edit this video, so that it can be used a testimonial? We'll need to then send it to Alyssa for approval

**Christina Hill** · 2025-09-05 21:06 · [link](https://weddingindustryads.slack.com/archives/C091CPQD8L9/p1757106390478919)
@Yulia Burris @Whitney Hodges @Gisselle Jiménez - from the email I sent to the Weinberg Team
📎 Screenshot 2025-09-05 at 5.05.49 PM.png (png, saved as `files/F09DQ10EGKV-Screenshot_2025-09-05_at_5.05.49_PM.png`)
> **Yulia Burris** · 2025-09-05 21:07 · [link](https://weddingindustryads.slack.com/archives/C091CPQD8L9/p1757106448707739)
> @Christina Hill Great! Thank you so much! :tada:
> **Whitney Hodges** · 2025-09-06 13:07 · [link](https://weddingindustryads.slack.com/archives/C091CPQD8L9/p1757164075878989)
> @Yulia Burris I'd love to use this in Stories next week, but let's edit first to say "Your overall cost per lead dropped by over 46%!"

**Whitney Hodges** · 2025-10-27 21:44 · [link](https://weddingindustryads.slack.com/archives/C091CPQD8L9/p1761601453544209)
@Yulia Burris @daniela Some real Google Ads results to leverage in our marketing.

Notice how lead volume and conversion rates have increased month to month. Conversion rate more than doubled after the client implemented a dedicated landing page for ads traffic following our formula (exactly what we teach inside the Google Ads Accelerator)
📎 image.png (png, saved as `files/F09P0JR82KU-image.png`)

**Whitney Hodges** · 2025-12-05 19:06 · [link](https://weddingindustryads.slack.com/archives/C091CPQD8L9/p1764961613471629)
@daniela
📎 image.png (png, saved as `files/F0A1EGTTJ9M-image.png`)

**Whitney Hodges** · 2025-12-05 19:09 · [link](https://weddingindustryads.slack.com/archives/C091CPQD8L9/p1764961761817099)
@daniela
📎 image.png (png, saved as `files/F0A1ZHYMVGU-image.png`)

**Whitney Hodges** · 2025-12-15 20:22 · [link](https://weddingindustryads.slack.com/archives/C091CPQD8L9/p1765830151367219)
<!channel> I had a sales call with a venue last week. They asked to see more specifics about the clients we work with. I was proud to share the info below with them. Thank you to each of you for the amazing results you help our clients achieve!! :smiling_face_with_3_hearts:

*Luxurious yet rustic barn and chapel in the heart of Texas*
This client has been with us from the beginning. We've been running their ads for well over five years now. We consistently generate 100-150+ new leads for them every month with Google and Meta Ads.

*Scenic indoor/outdoor venue in the mountains of Tennessee*
They came to us over a year and a half ago after having tried other wedding industry marketing agencies with disappointing results. They had spent thousands of dollars in ads only to achieve zero new tours. This year so far, they've had over 2000 inquiries, over 200 tours, and booked over 40 new weddings totaling nearly $500K in new revenue.

*Modern venue in rural Pennsylvania*
Another client of ours started running Google and Meta Ads about a year and a half ago. They've also been focused on updating their website copy and strengthening their SEO. In 2024, they hosted 30 weddings. For 2025, that more than doubled to 70 weddings.

**Whitney Hodges** · 2026-02-11 19:14 · [link](https://weddingindustryads.slack.com/archives/C091CPQD8L9/p1770837291065459)
📎 image.png (png, saved as `files/F0AEFE6BN9G-image.png`)

**Whitney Hodges** · 2026-02-11 19:15 · [link](https://weddingindustryads.slack.com/archives/C091CPQD8L9/p1770837307465999)
@Carmen Cruickshank Can you please drop a screenshot here of the DM Erin sent you?

**Carmen Cruickshank** · 2026-02-11 19:57 · [link](https://weddingindustryads.slack.com/archives/C091CPQD8L9/p1770839861934639)
@Whitney Hodges yes here it is:
📎 Screenshot 2026-02-11 at 2.56.55 PM.png (png, saved as `files/F0AFA1TU800-Screenshot_2026-02-11_at_2.56.55_PM.png`)

**Whitney Hodges** · 2026-03-30 23:25 · [link](https://weddingindustryads.slack.com/archives/C091CPQD8L9/p1774913100942749)
📎 image.png (png, saved as `files/F0APDLA9WKZ-image.png`)

**Whitney Hodges** · 2026-04-01 21:27 · [link](https://weddingindustryads.slack.com/archives/C091CPQD8L9/p1775078851495279)
📎 Screenshot_20260401-162628.png (png, saved as `files/F0AR747TQ2U-Screenshot_20260401-162628.png`)

**Carmen Cruickshank** · 2026-04-01 21:27 · [link](https://weddingindustryads.slack.com/archives/C091CPQD8L9/p1775078878083779)
:laughing::tada:

**Whitney Hodges** · 2026-05-11 14:50 · [link](https://weddingindustryads.slack.com/archives/C091CPQD8L9/p1778511002334979)
@Gisselle Jiménez Call with Michelle was great! She had a lot of good feedback. Please make sure the recording and transcript gets saved in our Results folder and also extract out the positive things she was saying, so we can use them as social proof. Thank you!
> **Gisselle Jiménez** · 2026-05-13 17:11 · [link](https://weddingindustryads.slack.com/archives/C091CPQD8L9/p1778692274622239)
> @Whitney Hodges Recording, summary and transcript has been updated! I included feedback extracts on the <https://docs.google.com/document/d/1mX7nGFm7NVSOm_9fapOefY6gJv0njYi0pozEZGTMYWw/edit?tab=t.0|verbal testimonial document:>
> 
> &gt; *On results:*
> &gt; "We booked a wedding, we booked an elopement... Since one of the ads we're running features a City Hall wedding, I've noticed a big influx of City Hall wedding leads." — 00:01:43
> &gt; 
> &gt; *On overall experience:*
> &gt; "I don't think so. This has been really great. Like, I feel like I learned a lot. I'm still learning, and I am really glad that I did this. Thank you so much." — 00:10:32
> &gt; 
> &gt; *On the education:*
> &gt; "The education itself is really helpful and you get really detailed with it. I so appreciate that because I do not want to invest in something that is just going to be a bunch of fluff. I need very hard, specific evidence and walkthrough and logic, and that is what you gave, and I love that." — 00:13:47
> **Whitney Hodges** · 2026-05-13 17:51 · [link](https://weddingindustryads.slack.com/archives/C091CPQD8L9/p1778694680390369)
> @Gisselle Jiménez Awesome! Can you please work the first and third quotes onto the Meta Ads Accelerator sales page in some capacity?
> **Gisselle Jiménez** · 2026-05-14 19:46 · [link](https://weddingindustryads.slack.com/archives/C091CPQD8L9/p1778787985977969)
> @Whitney Hodges Should we add them or replace some of the ones we already have?
> <https://app.leadlockpro.com/v2/preview/vOMDrfmJfQSGcg2obX82?notrack=true>
> **Whitney Hodges** · 2026-05-14 20:11 · [link](https://weddingindustryads.slack.com/archives/C091CPQD8L9/p1778789470728429)
> @Gisselle Jiménez I wouldn't replace anything; I would just layer them in in new spots
> **Gisselle Jiménez** · 2026-05-22 17:12 · [link](https://weddingindustryads.slack.com/archives/C091CPQD8L9/p1779469975672439)
> @Whitney Hodges I added it in the second section and after Our Process section. Let me know if it works!
> <https://app.leadlockpro.com/v2/preview/vOMDrfmJfQSGcg2obX82?notrack=true>
> 📎 image.png (png, saved as `files/F0B5G2GP6V9-image.png`)
> 📎 image.png (png, saved as `files/F0B5K25EP3P-image.png`)
> **Whitney Hodges** · 2026-05-22 17:15 · [link](https://weddingindustryads.slack.com/archives/C091CPQD8L9/p1779470147264439)
> @Gisselle Jiménez Looks great! Please publish
> **Gisselle Jiménez** · 2026-05-22 17:26 · [link](https://weddingindustryads.slack.com/archives/C091CPQD8L9/p1779470818617849)
> Published!:raised_hands:

**Whitney Hodges** · 2026-06-11 23:38 · [link](https://weddingindustryads.slack.com/archives/C091CPQD8L9/p1781221097416909)
@Gisselle Jiménez Please add this to our results folder in the drive. I'd also love to see this incorporated onto the Accelerator sales page and Meta Ads Accelerator sales page. Thank you!!
📎 Untitled design (4).png (png, saved as `files/F0BA3CSR2P3-Untitled_design_4_.png`)
> **Gisselle Jiménez** · 2026-06-12 14:52 · [link](https://weddingindustryads.slack.com/archives/C091CPQD8L9/p1781275938497569)
> Will do!
> **Gisselle Jiménez** · 2026-06-16 17:30 · [link](https://weddingindustryads.slack.com/archives/C091CPQD8L9/p1781631042421729)
> @Whitney Hodges Added to results folder! Let me know if this works for ads accelerator and meta ads accelerator pages:
> 📎 image.png (png, saved as `files/F0BAY83F8KY-image.png`)
> 📎 undefined (undefined, not downloaded)
> **Gisselle Jiménez** · 2026-06-16 17:31 · [link](https://weddingindustryads.slack.com/archives/C091CPQD8L9/p1781631067836039)
> 📎 image.png (png, saved as `files/F0BB40TJQH2-image.png`)
> **Whitney Hodges** · 2026-06-16 17:32 · [link](https://weddingindustryads.slack.com/archives/C091CPQD8L9/p1781631131057949)
> @Gisselle Jiménez I'd prefer for us to include the actual screenshot!
> **Gisselle Jiménez** · 2026-06-16 17:36 · [link](https://weddingindustryads.slack.com/archives/C091CPQD8L9/p1781631377929369)
> @Whitney Hodges Ohhh okay, let me modify!
> **Gisselle Jiménez** · 2026-06-16 17:54 · [link](https://weddingindustryads.slack.com/archives/C091CPQD8L9/p1781632475884169)
> @Whitney Hodges Let me know how this looks!
> 📎 image.png (png, saved as `files/F0BAYEF60CW-image.png`)
> 📎 image.png (png, saved as `files/F0BB0HEHLF4-image.png`)
> **Whitney Hodges** · 2026-06-16 18:08 · [link](https://weddingindustryads.slack.com/archives/C091CPQD8L9/p1781633333416069)
> @Gisselle Jiménez I think that should work!

**Whitney Hodges** · 2026-07-07 16:34 · [link](https://weddingindustryads.slack.com/archives/C091CPQD8L9/p1783442041637779)
@Gisselle Jiménez Hi! Erin came to my Q&amp;A. I still have my Zoom room open in case anyone else shows, but once you have the recording, I'd like to have the copy of the transcript saved to our results folder. Also, please put the transcript into ChatGPT and ask for it to create a case study. She shared some really powerful before &amp; after numbers.

I'd then like for you to work this into the copy on the GSA sales page.

FYI @daniela this will be good to add to the new website copy as well
> **Gisselle Jiménez** · 2026-07-07 18:57 · [link](https://weddingindustryads.slack.com/archives/C091CPQD8L9/p1783450646039979)
> @Whitney Hodges Transcript has been uploaded to the folder and here is the case study for your review!
> <https://docs.google.com/document/d/13t349vSZ7xwXZuTq4l4BfuJILSIBq8B4mJ0qMsh6VjA/edit?tab=t.0|docs.google.com/document/d/13t349vSZ7xw…/edit?tab=t.0>
> 
> I'll start working it into the GSA sales page and keep you updated!
> **Gisselle Jiménez** · 2026-07-15 20:31 · [link](https://weddingindustryads.slack.com/archives/C091CPQD8L9/p1784147467642919)
> Hi, @Whitney Hodges! I was working through this copy, and ChatGPT gave some recommendations overall, and I wanted to see what approach you would like or what you think about the suggestions because I don't know if we can have something like "Erin's story", but let me know what you think!
> 
> <https://docs.google.com/document/d/1W_2F0qgQp36y-Xz8yqn-pOu3zqkb7ySfb4f9OaZn4co/edit?tab=t.0|docs.google.com/document/d/1W_2F0qgQp36…/edit?tab=t.0>
> **Whitney Hodges** · 2026-07-16 16:34 · [link](https://weddingindustryads.slack.com/archives/C091CPQD8L9/p1784219690515139)
> @Gisselle Jiménez Although we can't use Erin's name anywhere on the page, I do think the recommendations are spot on and that we could use a refreshed version of this page. Could you please duplicate the existing funnel and take a stab at making these edits/additions?
> **Gisselle Jiménez** · 2026-07-16 21:10 · [link](https://weddingindustryads.slack.com/archives/C091CPQD8L9/p1784236227064829)
> Sounds good, will do!
> **Whitney Hodges** · 2026-07-16 21:13 · [link](https://weddingindustryads.slack.com/archives/C091CPQD8L9/p1784236423489989)
> Just so you are aware, we'll probably have two different versions of this page to use for different situations. The current page speaks to someone who has never run Google Ads before, whereas this new version is for someone who's already been running Google Ads but struggling in some capacity @Gisselle Jiménez fyi @daniela
> **Gisselle Jiménez** · 2026-07-30 16:38 · [link](https://weddingindustryads.slack.com/archives/C091CPQD8L9/p1785429514578799)
> @Whitney Hodges Here is the duplicated funnel: <https://app.leadlockpro.com/v2/location/Xi40zxmRvW8Pbyk5DYHp/funnels-websites/funnels/ImqSeiVE4lyeylc0R21Z/steps/8d143b03-f259-4ae7-8737-321994d8fbfb/overview|app.leadlockpro.com/v2/location/…/overview>
> 
> <https://sites.leadconnectorhq.com/preview/0Pra1g8MzJkq4QxsowSi?notrack=true|Preview >with edits incorporated!

**Gisselle Jiménez** · 2026-07-07 16:58 · [link](https://weddingindustryads.slack.com/archives/C091CPQD8L9/p1783443484791239)
@Whitney Hodges Awesome, will do! Are we doing a post in The VAULT?
> **Whitney Hodges** · 2026-07-07 17:01 · [link](https://weddingindustryads.slack.com/archives/C091CPQD8L9/p1783443662424159)
> @Gisselle Jiménez for the post in the vault, it can just include the recording and a recap of the discussion on the ceremony only Google Ads campaign. We can say congrats about her great results, but I don't want that to be the core focus of the post
> **Gisselle Jiménez** · 2026-07-07 20:17 · [link](https://weddingindustryads.slack.com/archives/C091CPQD8L9/p1783455428978869)
> @Whitney Hodges, got it! I trimmed the recording to include only the section with Erin. Let me know if this works for the post:
> 
> &gt; *Whitney's Monthly Q&amp;A Recording*
> &gt; 
> &gt; @everyone Here's the recording from today's Q&amp;A with @Whitney Hodges!
> &gt; 
> &gt; @Whitney Hodges and @Erin discussed launching a ceremony-only campaign. They talked through structuring it as a separate campaign rather than an experiment, the importance of having distinct keywords like ceremony, elopement, intimate, micro-wedding, and private to avoid competing with existing high-performing campaigns, and how to create a dedicated landing page and creative assets specific to that offer.
> &gt; 
> &gt; They also covered the critical role of follow-up systems and automations in converting leads. Congrats @Erin on the strong results from your adS! A great example of what's possible when strategy and execution align.
> &gt; 
> &gt; Check it out below!
> Are we including this in the vault like we do office hours?
> **Whitney Hodges** · 2026-07-07 20:18 · [link](https://weddingindustryads.slack.com/archives/C091CPQD8L9/p1783455511456199)
> @Gisselle Jiménez I think just posting is probably fine
> **Gisselle Jiménez** · 2026-07-07 20:20 · [link](https://weddingindustryads.slack.com/archives/C091CPQD8L9/p1783455654934319)
> @Whitney Hodges Oki!

**Carmen Cruickshank** · 2026-08-04 17:21 · [link](https://weddingindustryads.slack.com/archives/C091CPQD8L9/p1785864109949659)
@Whitney Hodges @Gisselle Jiménez Hi! I'm putting the screenshots here of the change: (first photo is the actual percentage age change of the first 6 months in 2026 compared to just July (a 50% decrease on in cost per lead, before it was average $51 now its average $25) second photo is just January to June, third photo is just July, fourth photo is the under 2 week span in end of July of increasing budget from $18 to now $40/day (July 20-31st)
📎 Screenshot 2026-08-04 at 12.50.00 PM.png (png, saved as `files/F0BMT8FMTD1-Screenshot_2026-08-04_at_12.50.00_PM.png`)
📎 Screenshot 2026-08-04 at 12.50.41 PM.png (png, saved as `files/F0BMXGCLRSS-Screenshot_2026-08-04_at_12.50.41_PM.png`)
📎 Screenshot 2026-08-04 at 12.51.03 PM.png (png, saved as `files/F0BMW4FC6AZ-Screenshot_2026-08-04_at_12.51.03_PM.png`)
📎 Screenshot 2026-08-04 at 12.51.36 PM.png (png, saved as `files/F0BN37CTMQC-Screenshot_2026-08-04_at_12.51.36_PM.png`)

**Gisselle Jiménez** · 2026-08-05 20:43 · [link](https://weddingindustryads.slack.com/archives/C091CPQD8L9/p1785962638664979)
@Whitney Hodges Here are script options from Alyssa's call!

<https://docs.google.com/document/d/1ufNc3SseiV1TpI71qbPHeUzPC3NPd0ag3x6u4x2SklQ/edit?tab=t.0|docs.google.com/document/d/1ufNc3SseiV1…/edit?tab=t.0>

**Whitney Hodges** · 2026-08-14 14:18 · [link](https://weddingindustryads.slack.com/archives/C091CPQD8L9/p1786717086143459)
📎 Screenshot_20260814-091708.png (png, saved as `files/F0BQ9SKCP4J-Screenshot_20260814-091708.png`)
