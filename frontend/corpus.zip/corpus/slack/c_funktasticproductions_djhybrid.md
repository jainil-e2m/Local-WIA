# #c_funktasticproductions_djhybrid

Private channel · `C08QND0MU5T`
Pulled 2026-09-25 by `corpus/fetch-slack.mjs`.

248 parent messages · 371 thread replies · 43 files downloaded.
Covers 2025-05-05 → 2026-09-24.

Thread replies are indented with `>`. Every message links back to Slack, so a
candidate drawn from here carries its source the way a transcript quote carries
a timecode.

---

**Whitney Hodges** · 2025-05-05 14:04 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1746453849394769)
@Christina Hill @Carmen Cruickshank Can y'all hop on the Funktastic call with me about 10 minutes early? I want to touch base about the tech connections process for the call and also make sure Carmen is set up for success with access to the hello WIA Google account moving forward. Thank you!!

**Nicole Bautista** · 2025-05-05 15:16 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1746458181826089)
@Christina Hill @Carmen Cruickshank Hi! Here's Mike <https://portal.dubsado.com/public/form/view/6813dc47127b10003a32ccd8?|completed onboarding questionnaire>. His <https://drive.google.com/drive/folders/16zxmxLr05khFOKPbAcLSs_e6QgBDXsKu?usp=sharing|client folder> and <https://docs.google.com/document/d/1FRilUXJ94LpWWJLBnC9NgJDW0HYJ3DoLcpZiwCW8q9k/edit?usp=sharing|onboarding checklist> are also pinned at the top of this channel.

**Christina Hill** · 2025-05-05 15:41 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1746459709051509)
@Whitney Hodges Has a LeadLock Sub-Account been made for them yet?

**Christina Hill** · 2025-05-05 17:32 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1746466377786289)
Hi @Nicole Bautista and @Whitney Hodges, please include the following LeadLock instructions for Mike in your email :slightly_smiling_face: . (feel free to reword it if needed) Thanks!

In preparation for our next call on Wednesday, we would like to add all of your users to LeadLock. Here are two ways to do this. Please send me the first name, last name, and email address of additional LeadLock users for both Funktastic and DJ Hybrid. Or, since you have admin access, you can add users using <https://www.loom.com/share/dc647de2d8d14d1b8ac7494fa104767a?sid=2c762f9b-0897-4fe6-8822-748c638dd617|this quick tutorial video>. Thanks!
> **Whitney Hodges** · 2025-05-05 17:40 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1746466836492839)
> @Nicole Bautista we also need to send them their messaging and positioning questions, so they have a chance to review before the call. Template needs to be updated to reflect that. We need to send that before call 2 every time
> **Nicole Bautista** · 2025-05-05 17:48 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1746467326907629)
> @Christina Hill @Whitney Hodges, here’s the email draft. Let me know if this looks good. Thanks!
> 
> _Hi Mike,_
> 
> _We loved meeting with you today! The call recording has been added to your client folder and you can<https://drive.google.com/drive/folders/1uqrFUIroQ5WttezplHOvjQFLgHsDq3NA?usp=sharing| check it out here.>_
> 
> _In preparation for our next call on Wednesday, we would like to add all of your users to LeadLock. Here are two ways to do this. Please send me the first name, last name, and email address of additional LeadLock users for both Funktastic and DJ Hybrid. Or, since you have admin access, you can add users using <https://www.loom.com/share/dc647de2d8d14d1b8ac7494fa104767a?sid=2c762f9b-0897-4fe6-8822-748c638dd617|this quick tutorial video>._ 
> 
> _We also need the <https://docs.google.com/document/d/1IUTVkfK-v-H1XnuuGtscLF5w3pg265gBORcu84_e-4Q/edit?usp=sharing|messaging and positioning> ahead of our next call. Please send them over beforehand so we have time to review._
> 
> _Talk to you soon!_
> _Whitney_
> **Whitney Hodges** · 2025-05-05 17:56 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1746467772000189)
> @Nicole Bautista there should be a template that gives a warm welcome after a first onboarding call and includes a link to their onboarding guide. Also the call is this Wednesday, not next
> **Whitney Hodges** · 2025-05-05 17:56 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1746467810234009)
> And I don't need the messaging and positioning before the next call. It's a preview of part of what they can expect on the next call
> **Nicole Bautista** · 2025-05-05 18:06 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1746468380385529)
> @Whitney Hodges, my apologies—please find the email draft below.
> 
> _Hi Mike,_
> 
> _We want to again extend a heartfelt welcome from the whole team at Wedding Industry Ads! It was a pleasure meeting with you yesterday, and we are so excited to get started!_
> 
> _For your reference, I wanted to share the Messaging & Positioning Questionnaire, Google Folder, recording of the call and the presentation we reviewed. You can access them through the links below:_
> 
> • _<https://drive.google.com/file/d/15R_9rb_6WCUylh6Mdz1ukjWotRwOsJ9Q/view?usp=drive_linkhttps://drive.google.com/file/d/15R_9rb_6WCUylh6Mdz1ukjWotRwOsJ9Q/view?usp=drive_link|Onboarding Guide Presentation>_
> • _<https://drive.google.com/drive/folders/1uqrFUIroQ5WttezplHOvjQFLgHsDq3NA?usp=sharing|Call Recording>_
> • _<https://drive.google.com/drive/folders/17VGO8q-RBUpC0s-ZL2l19UX32eiP4cLV?usp=sharing|Google drive Folder>_
> • _<https://docs.google.com/document/d/1IUTVkfK-v-H1XnuuGtscLF5w3pg265gBORcu84_e-4Q/edit?usp=drive_link|Messaging & Positioning Questionnaire >_
> _In preparation for our next call on Wednesday, we would like to add all of your users to LeadLock. Here are two ways to do this. Please send me the first name, last name, and email address of additional LeadLock users for both Funktastic and DJ Hybrid. Or, since you have admin access, you can add users using <https://www.loom.com/share/dc647de2d8d14d1b8ac7494fa104767a?sid=2c762f9b-0897-4fe6-8822-748c638dd617|this quick tutorial video>_
> 
> _Please reach out if you have any questions or concerns!_
> 
> _Thank you,_
> _Whitney_
> **Nicole Bautista** · 2025-05-06 13:03 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1746536601919529)
> @Whitney Hodges Just checking in to see if the email draft is all set. If it looks good to you, I’ll go ahead and send it out today. Thank you!
> **Whitney Hodges** · 2025-05-06 13:06 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1746536786971659)
> @Nicole Bautista please make it clear why we are including the messaging and positioning questionnaire. We will be reviewing them on the call tomorrow. No action is required on their end at this time, but they are welcome to give them a look if they want to start thinking about their answers
> **Nicole Bautista** · 2025-05-06 13:13 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1746537227570519)
> @Whitney Hodges, let me know if this ready to go. thank you
> 
> _Hi Mike,_
> 
> _We want to again extend a heartfelt welcome from the whole team at Wedding Industry Ads! It was a pleasure meeting with you yesterday, and we are so excited to get started!_
> 
> _For your reference, I wanted to share the Messaging &amp; Positioning Questionnaire, Google Folder, recording of the call and the presentation we reviewed. You can access them through the links below:_
> 
> • _<https://drive.google.com/file/d/15R_9rb_6WCUylh6Mdz1ukjWotRwOsJ9Q/view?usp=drive_linkhttps://drive.google.com/file/d/15R_9rb_6WCUylh6Mdz1ukjWotRwOsJ9Q/view?usp=drive_link|Onboarding Guide Presentation>_
> • _<https://drive.google.com/drive/folders/1uqrFUIroQ5WttezplHOvjQFLgHsDq3NA?usp=sharing|Call Recording>_
> • _<https://drive.google.com/drive/folders/17VGO8q-RBUpC0s-ZL2l19UX32eiP4cLV?usp=sharing|Google drive Folder>_
> • _<https://docs.google.com/document/d/1IUTVkfK-v-H1XnuuGtscLF5w3pg265gBORcu84_e-4Q/edit?usp=drive_link|Messaging &amp; Positioning Questionnaire>_ 
> _We’ll be reviewing the Messaging &amp; Positioning Questionnaire together during our call tomorrow. Feel free to take a look if you’d like to start thinking about your responses ahead of time._
> 
> _In preparation for our next call on Wednesday, we would like to add all of your users to LeadLock. Here are two ways to do this. Please send me the first name, last name, and email address of additional LeadLock users for both Funktastic and DJ Hybrid. Or, since you have admin access, you can add users using <https://www.loom.com/share/dc647de2d8d14d1b8ac7494fa104767a?sid=2c762f9b-0897-4fe6-8822-748c638dd617|this quick tutorial video>_
> 
> _Please reach out if you have any questions or concerns!_
> **Whitney Hodges** · 2025-05-06 13:20 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1746537602316669)
> @Nicole Bautista approved

**Nicole Bautista** · 2025-05-06 22:45 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1746571544167259)
@Whitney Hodges, Mike sent these emails for reference, just sharing them here for future use. I’ve also drafted a simple reply to him. Let me know if you'd like me to add anything.

_Hey!_

_Thank you so much! I'll get our users added, no problem!_

_I'll get started today on the questionnaire today._

_I forgot to attach this on the last questionaire. I also wanted to share some emails we've used for DJ Hybrid Chicago as inspiration. We don’t have a set template for initial inquiry responses, but we've sent out a few nurturing emails over time. These aren’t tied to anything specific—just some ideas for reference!_
_<https://view.flodesk.com/emails/677174607d2d66d1199d0a8c>_
_<https://view.flodesk.com/emails/675471031c09a752b2d5734b>_
_<https://view.flodesk.com/emails/67ea9f8293247ae3c9fa7139>_
_<https://view.flodesk.com/emails/67d2eceb037288709c08265c>_

_Thanks!_

____________________

_Thanks for sharing these emails, they’re fantastic! Looking forward to the call tomorrow._

_Best,_
_Whitney_

**Whitney Hodges** · 2025-05-06 22:46 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1746571607770839)
@Nicole Bautista that is good, thanks!

**Christina Hill** · 2025-05-07 14:06 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1746626788719539)
Hi @Whitney Hodges and @Carmen Cruickshank. I was able to add the subdomains "<http://info.funktasticproductions.com|info.funktasticproductions.com>" and "<http://preferences.funktasticproductions.com|preferences.funktasticproductions.com>" into LeadLock, however, Wix does not support email subdomains (similar to the issue you mentioned before with Bella's account, Whitney). I know we meet with them later this afternoon, so hopefully we can mention CloudFlare again as an option.
> **Whitney Hodges** · 2025-05-07 14:14 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1746627294690079)
> @Christina Hill Thank you! Have you used Cloudflare for any LeadLock clients yet?
> **Christina Hill** · 2025-05-07 17:14 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1746638065138759)
> I think so. It was a while ago, but I believe all of their records just transferred into LeadLock without me having to do it manually.
> **Christina Hill** · 2025-05-07 17:23 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1746638594703609)
> @Whitney Hodges Where are the WIA Domain records hosted again?
> **Whitney Hodges** · 2025-05-07 17:23 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1746638621087839)
> Squarespace I think

**Whitney Hodges** · 2025-05-07 19:13 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1746645193454279)
@Christina Hill Hi! Can you send Carmen a video example of the Google Ads walkthrough you send to full-service clients before you launch their ads?
> **Christina Hill** · 2025-05-07 22:31 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1746657112316489)
> @Carmen Cruickshank I just forwarded you an email of the ad information (walkthrough included) that I sent to Ocaso. :white_check_mark:

**Carmen Cruickshank** · 2025-05-07 20:39 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1746650397778999)
@Christina Hill I will get back to you tomorrow if im unable to access the wix site to put the tracking in, I will let you know though
> **Christina Hill** · 2025-05-07 22:34 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1746657293864239)
> Okay. I will be travelling in the morning tomorrow. But I will be at my desk in the afternoon. If you have questions, we can hang on after Sully's 2-week follow-up call at 2:15 pm, or feel free to send me questions in Slack or with a Loom video anytime. :slightly_smiling_face: @Carmen Cruickshank

**Nicole Bautista** · 2025-05-08 16:36 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1746722190983689)
@Whitney Hodges @Whitney Hodges Just to confirm is this the email sending subdomain for mike? <http://reply.funktasticproductions.com|reply.funktasticproductions.com>
> **Whitney Hodges** · 2025-05-08 16:37 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1746722268522459)
> Yes, that should work, but @Christina Hill hasn't created it yet

**Nicole Bautista** · 2025-05-08 18:17 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1746728262766109)
@Whitney Hodges Just to confirm, should we still create a calendar scheduler in Leadlock, or embed the one Mike provided (calendly) in the onboarding questionnaire?
> **Whitney Hodges** · 2025-05-08 18:22 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1746728525219839)
> @Nicole Bautista create schedulers. Please make sure you and @Jenna Tria both watch the call recording from yesterday. That was one of the items discussed

**Whitney Hodges** · 2025-05-09 16:00 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1746806411836309)
@Christina Hill Hi! Carmen raised the following question:

_For DJ Hybrid, since they currently don’t have a trackable conversion (like form submissions), I’m wondering if it might be wise to hold off on launching their campaign until we have a better signal to help guide Google’s optimization. I'd love your input on that_

I'm looping you in because you're better equipped to answer this than me.

@Carmen Cruickshank my questions are:
1. Have you tested the form and confirmed there is definitely not a thank you page redirect?
2. Is it possible to track if users click the submit button on the form? (I think Christina has done this before)
If the answer to both of these questions is no, and you and Christina think it would do more harm than good to run campaigns now, I'm fine with holding off until we have a LeadLock thank you page
_._

**Carmen Cruickshank** · 2025-05-09 16:43 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1746809005833409)
1. Yes i tested the form, it doesn't redirect 

**Carmen Cruickshank** · 2025-05-09 16:43 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1746809028093339)
2. yes it is possible, i can check on wix and do my best

**Carmen Cruickshank** · 2025-05-12 13:53 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1747058018407789)
Hey @Whitney Hodges @Christina Hill, just an update as im creating the googel campaigns for both this morning, i will hold off on making dk hyrbis campaign until the leadlock thank you page is created, jsut to avoid spending budget on data that is attached to the origional page for DJ Hybrid

**Carmen Cruickshank** · 2025-05-12 13:56 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1747058166339709)
@Whitney Hodges I plan on sending the loom video to Mike and Marisa today walking through the Google Ads campaign and explaining that we find it best to not have a google campaign for DJ Hybrid until there is trackable conversions so Google can help the campaign best perform

**Carmen Cruickshank** · 2025-05-12 13:56 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1747058178695109)
Let me know your input!

**Whitney Hodges** · 2025-05-12 14:09 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1747058973957549)
@Carmen Cruickshank @Christina Hill Why can't/shouldn't we track clicks on the submit button as conversions for now?
📎 image.png (png, saved as `files/F08RWCXND8V-image.png`)

**Carmen Cruickshank** · 2025-05-12 14:22 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1747059765896419)
I will double check how to track form submissions on Wix

**Carmen Cruickshank** · 2025-05-12 14:23 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1747059812094169)
I'm going into google tag manager to check the tracking, it's asking for you to verify
> **Whitney Hodges** · 2025-05-12 14:25 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1747059929894339)
> Are you in? I haven't received anything on my end
> **Carmen Cruickshank** · 2025-05-12 14:25 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1747059940527029)
> ill resend it
> **Whitney Hodges** · 2025-05-12 14:26 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1747059993164569)
> Ok, I think I authorized it
> **Whitney Hodges** · 2025-05-12 14:26 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1747059998651479)
> A number didn't come up
> **Carmen Cruickshank** · 2025-05-12 14:27 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1747060048095719)
> okay perfect thank you
> **Carmen Cruickshank** · 2025-05-12 14:27 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1747060058847739)
> im in
> **Carmen Cruickshank** · 2025-05-12 14:28 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1747060107225439)
> I will update here on whether or not im able to track form submissions, my goal is to sned the video walkthrough of their cmapaign by the end of the day to not delay but ideally i want to have dj hybrids campaign up as well
> **Whitney Hodges** · 2025-05-12 14:31 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1747060312619789)
> Ok, thank you. I'm really just trying to understand what's possible. I know Christina has tracked button clicks on other clients' websites via GTM before.

**Whitney Hodges** · 2025-05-14 13:50 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1747230606953269)
@Christina Hill Hi! I want to make sure we keep things moving with Funktastic's LeadLock set up. Can you please add the subdomains "<http://info.djhybridchicago.com|info.djhybridchicago.com>" and "<http://preferences.djhybridchicago.com|preferences.djhybridchicago.com>" into LeadLock? Also, if you haven't already can you do some research to determine if Cloudflare is the best option for them as far as the email sending subdomains? Thank you!
> **Christina Hill** · 2025-05-15 16:30 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1747326618501109)
> @Whitney Hodges Complete. :white_check_mark: I do believe that Cloudflare would be the best option for their domain hosting. cc: @Carmen Cruickshank
> 
> Here are the instructions that I found for Mike:
> 📎 Screenshot 2025-05-15 at 12.16.45 PM.png (png, saved as `files/F08SMKFRTK4-Screenshot_2025-05-15_at_12.16.45_PM.png`)
> **Whitney Hodges** · 2025-05-15 16:43 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1747327412595639)
> @Christina Hill ok! Can you send Mike email instructions on next steps for Cloudflare or set up a call to help him with this?

**Nicole Bautista** · 2025-05-14 16:17 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1747239421652889)
@Carmen Cruickshank Hi! Mike sent an email. Here’s the email for reference.

_Hey Carmen!_

_Awesome. Thanks so much for sharing. I'll be sharing for Funktastic, and Marisa will comment shortly about DJ Hybrid once she checks it out!_

_For Funktastic:_
_Everything looks GREAT! My only two things_
_1) For Competitors, I think Bluewater Kings was spelled wrong as "blue kings water" so I just wanted ot make sure you've got the right name there! This is their site: <https://www.bluewaterkingsband.com>_

_I love the tag line "why settle go funktastic" so great!_

_2) "All in on Live Music Packages"_
_How about something like all inclusive/one stop entertainment from Ceremony to the After Party or something like that?_

_3) More of a landing page question for the home page: Do you think it makes sense to have a contact form on the home page too, or do you think it's good the way we have it? Let me know what you think_

_Marisa will get right back to you with DJ Hybrid_

_Thanks!_
_Mike_

**Carmen Cruickshank** · 2025-05-14 16:55 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1747241752103859)
Thank you, got back to him with the feedback :slightly_smiling_face:

**Whitney Hodges** · 2025-05-15 15:17 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1747322226188849)
@Nicole Bautista @Jenna Tria Can you upload Funktastic's second onboarding call to their client folder? <https://fathom.video/share/Uvp7jBscZbqmeSLRe753MUotquAhrbtu>

**Whitney Hodges** · 2025-05-21 02:16 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1747793814575409)
@Christina Hill Hi! We're going to need more time before Funktastic's/DJ Hybrid's email copy is ready for their review, but I don't want that to hold you back from reaching out to Mike re: Cloudflare, so please get in touch with him about this at your earliest convenience
> **Christina Hill** · 2025-05-21 15:22 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1747840931806489)
> @Whitney Hodges Okay, thanks! I will send him an email now.

**Carmen Cruickshank** · 2025-05-21 14:28 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1747837693158609)
@Whitney Hodges Hi! The creatives for Funktastic Productions are ready. For the Phase 1 Meta ads, I wanted to see if it’s in your plan to hop on a quick call to align on setup and ensure consistency with the other campaigns. If not, I can reference the settings from existing campaigns—I just want to make sure everything is accurate from the start.
> **Whitney Hodges** · 2025-05-21 14:30 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1747837854086699)
> @Carmen Cruickshank Hi! Thank you for the update!
> 
> The first step is to send the Client Attraction Meta Ads to Mike for his review. We usually email these over in a doc. I'd love to see them before you send them to him.
> 
> Then once he approves, it will be time to build the campaign. And yes, I would love to build this campaign with you together in real time and record it, so we have it as a resource.
> **Carmen Cruickshank** · 2025-05-21 15:24 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1747841045164869)
> Okay makes sense, i can send you a doc with the creatives

**Whitney Hodges** · 2025-05-21 15:58 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1747843138741579)
@Christina Hill Hi! Thank you so much for emailing Mike about the DNS stuff. Question though - can he use Cloudflare without having to transfer the domain registration? The reason I ask is that I'm pretty sure for WIA most of our records are hosted in Squarespace and that is our domain registrar, but I'm pretty sure we have a Cloudflare account too, with some records set up there. I think you probably know more than I do, but just wanted to throw that out there in case there is an easier path for what we're looking to accomplish.

**Christina Hill** · 2025-05-21 16:03 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1747843388868309)
@Whitney Hodges Hmm. I don't know. That would be great if it could be easier on him. Let me look into that. I will see what WIA has set up in Cloudflare. I don't have the WIA Cloudflare password saved to my LastPass. Can you share it with me?
> **Whitney Hodges** · 2025-05-21 16:06 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1747843594733929)
> @Christina Hill Ok, great thank you! I honestly have no idea what we have set up in there. I just know that we do have an account that one of our very first GHL contractors set up for us. And I'm pretty sure he built some records there. I just shared the login with you via LastPass. Lmk if that works
> **Christina Hill** · 2025-05-21 16:08 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1747843737555259)
> It worked. Thank you. I will let you know what I discover. @Whitney Hodges
> **Christina Hill** · 2025-05-21 17:05 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1747847149118139)
> It looks like you use Cloudflare strickly for DNS management for <http://leadlockpro.com|leadlockpro.com>. So it is possible to have your domain somewhere different than your DNS records. That is good to know. I think that is what I am going to try and set up with Mike instead. @Whitney Hodges
> **Christina Hill** · 2025-05-22 16:46 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1747932362682479)
> Hi @Whitney Hodges Do we have contact with anyone who knows how to transfer DNS records properly? Looking at Mike's setup, this may be out of my wheelhouse.
> **Whitney Hodges** · 2025-05-22 17:00 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1747933224931609)
> @Christina Hill we can probably schedule a paid call with Pamela
> **Christina Hill** · 2025-05-22 18:20 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1747938041892109)
> Okay great! I would love to learn how to do this moving forward. <https://www.loom.com/share/374bed70d08c4d2a900fee504fefbee7?sid=77d60c93-7450-45f4-8385-7f3271637be0|Here is a Loom video of where I ran into a roadblock>, for context. Hopefully this is something Pamela would be able to help with.  @Whitney Hodges
> **Whitney Hodges** · 2025-05-22 18:26 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1747938408949359)
> @Christina Hill I reached out to Pamela via email, so hopefully, we'll hear back soon
> **Whitney Hodges** · 2025-05-23 14:17 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1748009874150549)
> @Christina Hill this is Pamela's booking link. <https://speakwithpamela.com/paid|https://speakwithpamela.com/paid> please take a look and let me know what day/time you want to book. I'll get it scheduled for you and will make payment. I'm going to let you handle solo. Thank you!!
> **Christina Hill** · 2025-05-23 18:13 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1748024017286609)
> Hi @Whitney Hodges, Can you book Friday, May 30 at 2pm?
> **Whitney Hodges** · 2025-05-23 19:31 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1748028679455549)
> @Christina Hill Yes, just booked for Friday, May 30 at 2pm CST
> **Whitney Hodges** · 2025-05-23 19:51 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1748029875818069)
> @Christina Hill sorry, I meant EST. You should have gotten the calendar confirmation emailed to you. And if the timing is off for some reason, you should have the option to reschedule for a different time
> **Christina Hill** · 2025-05-24 15:41 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1748101315234819)
> @Whitney Hodges Thank You! I received it. :white_check_mark:

**Carmen Cruickshank** · 2025-05-22 13:52 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1747921961119739)
@Whitney Hodges Hi! Here are the creatives for funktastic productions: <https://docs.google.com/document/d/1rZLeT1SyaMCHnhWlD_2jgty5Of3DgK4sVHWtV5qn2Gs/edit?usp=sharing>
> **Whitney Hodges** · 2025-05-22 23:44 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1747957474550959)
> @Carmen Cruickshank Hi Thank you for sending! Any chance you can meet tomorrow at 1:30pm CST to review together?
> **Carmen Cruickshank** · 2025-05-23 00:43 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1747960988308409)
> Yes that works! @Whitney Hodges 
> **Whitney Hodges** · 2025-05-23 14:52 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1748011941175739)
> @Carmen Cruickshank great! I put it on the calendar. Talk to you then!
> **Whitney Hodges** · 2025-05-23 18:35 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1748025351605869)
> Sorry, on a call that's running late!!
> **Carmen Cruickshank** · 2025-05-23 18:36 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1748025391721889)
> It's ok, ready when you are
> **Whitney Hodges** · 2025-05-23 18:38 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1748025519261499)
> @Carmen Cruickshank Ok! I'm here now

**Carmen Cruickshank** · 2025-05-23 18:57 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1748026633056029)
Creatives breif for funktastic: <https://docs.google.com/document/d/1RYF6TuXoGu1Py5fXozELiQVDF33_JEC3qH_OrdCEVmU/edit?tab=t.0#heading=h.svnk6mynj7bw>

**Jenna Tria** · 2025-05-23 22:30 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1748039453594389)
@Whitney Hodges Here are the email drafts for Funktastic Productions and DJ Hybrid, let me know if you have any feedback or suggestions for adjustments. I've also attached them in <https://app.clickup.com/9011165651/docs/8chpyek-3131|Slack 2.0>. Thank you!

Funktastic Productions Email Draft Copy Workflow - <https://docs.google.com/document/d/1ge8HUpmMYV4zDF-hMLfHc4Pirug8mpOzcHpf_0Ky7ZI/edit?usp=sharing>

DJ Hybrid Email Draft Copy Workflow -
<https://docs.google.com/document/d/1ZVYGJqys5ICWsmqdpILkah49YUYZUZal3PU0kPgjpXw/edit?usp=sharing>

**Jenna Tria** · 2025-05-27 16:15 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1748362522404009)
@Whitney Hodges Here are the <https://docs.google.com/document/d/1_OYFooFc49Xxj22L8mn-U40dAWQrKtNLMPxXzTrHMXQ/edit?usp=sharing|Client Review Email Template> for Funktastic Productions and DJ Hybrid, let me know if you have any feedback or suggestions for adjustments. I've also attached them in <https://app.clickup.com/9011165651/docs/8chpyek-3131|Slack 2.0>. Thank you!

**Megan Jivraj** · 2025-05-27 19:52 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1748375524858599)
Hey team! Here are the follow-ups from the May 27 Team Meeting:
1. @Whitney Hodges to send out items ready for review and mention that Christina is still working on the DNS setup

**Whitney Hodges** · 2025-05-27 21:06 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1748379971134069)
@Jenna Tria @Christina Hill Hi! Mike and Marisa would like for clients to have a choice of phone call or virtual call when they book a consultation through LeadLock. I did a bit of research to see if there is a seamless way to do this, and it looks like there is by enabling Multiple Meeting Locations. Here's a screen shot of what I found from a quick Google search.

Jenna, can you please take a stab at this? Loop in Christina if you need support.
📎 image.png (png, saved as `files/F08U16F2D5Z-image.png`)

**Carmen Cruickshank** · 2025-05-28 20:53 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1748465624451799)
Here is the updated creatives breif @Whitney Hodges. <https://docs.google.com/document/d/1RYF6TuXoGu1Py5fXozELiQVDF33_JEC3qH_OrdCEVmU/edit?tab=t.0> SSome editing needs to still be made but wanted to clarify with you over the phone your thoughts. There are some add-ons such as creative 4, I was wondering if we could hop on a call either this or next week to discuss this, I'm free tomorrow. Wanted to make sure I have the first idea for client attraction ads before I move onto Luxury Travel Boutique
> **Whitney Hodges** · 2025-05-28 21:37 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1748468262129269)
> @Carmen Cruickshank I think this is looking really good! Can you meet tomorrow at 9am EST?
> **Carmen Cruickshank** · 2025-05-28 22:10 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1748470233504009)
> @Whitney Hodges Thank you and Yes! Talk to you then
> **Whitney Hodges** · 2025-05-28 22:12 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1748470320759319)
> @Carmen Cruickshank can you send an invite please? Thx!!
> **Carmen Cruickshank** · 2025-05-28 22:31 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1748471497192039)
> yes Just sent it @Whitney Hodges

**Carmen Cruickshank** · 2025-05-29 14:00 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1748527222523649)
@Ivy Ayala Hi! Here is the updated creative brief for Funktastic Productions: <https://docs.google.com/document/d/1RYF6TuXoGu1Py5fXozELiQVDF33_JEC3qH_OrdCEVmU/edit?tab=t.0> let me know if you have any questions
> **Ivy Ayala** · 2025-06-02 00:34 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1748824459209799)
> Hello! the creatives are in the document, under each outline you will see the link, I remain attentive to your comments!  @Carmen Cruickshank

**Whitney Hodges** · 2025-05-29 17:06 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1748538367105699)
@Megan Jivraj Recurring invoice needs to be created for this client with a monthly due date of the 7th
> **Megan Jivraj** · 2025-05-30 02:44 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1748573055417899)
> @Whitney Hodges created!

**Megan Jivraj** · 2025-05-30 02:37 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1748572645014879)
@Whitney Hodges Should I update this product to reflect $1997.00 (see image below)? Or, create a new one?
📎 Screenshot 2025-05-29 203350.png (png, saved as `files/F08UETM4S8K-Screenshot_2025-05-29_203350.png`)

**Whitney Hodges** · 2025-05-30 02:39 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1748572740004359)
@Megan Jivraj create a new one, please. Let's call it Google &amp; Meta Ads Management. They pay a separate subscription fee for LeadLock

**Carmen Cruickshank** · 2025-06-02 17:09 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1748884157977279)
@Ivy Ayala Hi! The creatives looks amazing! Made 2 comments on the doc. :slightly_smiling_face: Thanks so much! @Jacqueline Hood The creatives as you know are getting done so thats all thats going on for meta ads here for Funktastic. @Christina Hill The ads for Funktastic productions are alright, not many conversions. On the campaign overview page it says 0 conversions but on the conversion page it says 2-3 which i still find odd even though i switched both conversions to be primary.
> **Ivy Ayala** · 2025-06-03 22:53 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1748991189110799)
> Already made the edits! @Carmen Cruickshank

**Carmen Cruickshank** · 2025-06-02 20:48 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1748897290566649)
Update for tommorow's meetings ^

**Carmen Cruickshank** · 2025-06-02 20:55 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1748897707870259)
@Christina Hill Update for DJ Hybrid's Google Ads campaigns aren't converting, there are some searches with specific dj's which I don't think I'll exclude for now but I'm not too worried as I know the landing pages will be created soon.

**Megan Jivraj** · 2025-06-03 20:38 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1748983096412899)
Hey team! Here are the follow-ups from the June 3 Team Meeting:
1. @Carmen Cruickshank to provide status on ad creative (already done above)
2. @Jenna Tria to prioritize feedback and implement requested changes 

**Carmen Cruickshank** · 2025-06-05 15:36 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1749137816614969)
@Whitney Hodges Hi! The Client Attraction ads are complete. Great job @Ivy Ayala! Here is the document again: <https://docs.google.com/document/d/1RYF6TuXoGu1Py5fXozELiQVDF33_JEC3qH_OrdCEVmU/edit?tab=t.0> The creative are below each creative brief.
> **Whitney Hodges** · 2025-06-06 12:47 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1749214065428349)
> @Carmen Cruickshank Can you please put this into a doc for the client to review? All they should need to see is ad creative, copy, and headlines
> **Carmen Cruickshank** · 2025-06-06 14:25 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1749219950605179)
> @Whitney Hodges Okay, so the creative and for copy is that the primary text, for headlines do we usually provide 5 different ones? because i know that Meta Ads allows up to 5
> **Whitney Hodges** · 2025-06-06 14:41 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1749220874267429)
> @Carmen Cruickshank yes, ad copy is the primary text. I like to test just one headline per ad. If you want, you can write text and a headline to complement each creative. Or we can just use the same text and headline for every creative to truly test the creatives against one anothet
> **Carmen Cruickshank** · 2025-06-06 19:11 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1749237080953309)
> @Whitney Hodges Okay got it. I plan on working on the copy (primary text and headlines) on Monday and sending it out to Mike and Marisa.

**Carmen Cruickshank** · 2025-06-10 20:24 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1749587046761169)
@Jacqueline Hood here is the client attraction ads doc: <https://docs.google.com/document/d/1Sax948W9XDLeysF3m3oE_z94JNM4a99mJroIYPazZwY/edit?tab=t.0>
> **Jacqueline Hood** · 2025-06-12 21:16 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1749762970135089)
> @Carmen Cruickshank let you a couple of comments in the doc and I'll put some more feedback here:
> 
> For creative 1, this part here seems a bit too quick with the text and it's a bit jumpy/hard to read. S
> 📎 Screenshot 2025-06-12 at 2.15.11 PM.png (png, saved as `files/F0911UAH9BQ-Screenshot_2025-06-12_at_2.15.11_PM.png`)
> **Jacqueline Hood** · 2025-06-12 21:17 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1749763024067939)
> Where it says "from 6 to 13 piece band options", I feel like there needs to be a follow up sentence to that.
> "From 6 to 13 piece band options....we guarantee the perfect vibe to fit your big day" or something?
> **Jacqueline Hood** · 2025-06-12 21:19 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1749763156928379)
> and then for the beginning, I think the intro text could be more compelling to really attract brides/couples.
> Like "POV you hire the band that keeps your wedding going all night long" or something? I just think it doesn't necessarily lead with it being for weddings
> **Jacqueline Hood** · 2025-06-12 21:21 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1749763289361499)
> For creative 2, I'd start the first text with "Other wedding bands aren't like us"
> **Jacqueline Hood** · 2025-06-12 21:22 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1749763332745779)
> this part seems a bit unclear. maybe something like "where Chicago's best musicians come together to deliver something truly magical"
> 📎 Screenshot 2025-06-12 at 2.20.14 PM.png (png, saved as `files/F0919D8UNS0-Screenshot_2025-06-12_at_2.20.14_PM.png`)
> **Jacqueline Hood** · 2025-06-12 21:22 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1749763351514529)
> I LOVE this line!! You could use this more - in the other creatives and/or ad copy forsure
> 📎 Screenshot 2025-06-12 at 2.20.59 PM.png (png, saved as `files/F091XGS9Y0G-Screenshot_2025-06-12_at_2.20.59_PM.png`)
> **Jacqueline Hood** · 2025-06-12 21:25 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1749763519712459)
> My only other suggestion for the copy would be to test out a longer one. I think adding some additional context as to exactly what sets Funktastic apart from DJ's and other wedding bands. Nothing really screams to be in the ad copy why they are different. We can also lean into the pain points/desires of the bride - this is the biggest party they will throw, make it count. They don't want a boring party. They want something unique that everyone will talk about for years to come. They want people to have the time of their lives, etc.
> **Carmen Cruickshank** · 2025-06-13 00:04 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1749773062646109)
> thank you jacquiline that was all so helpful!
> **Jacqueline Hood** · 2025-06-13 17:42 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1749836540516699)
> You're welcome!

**Megan Jivraj** · 2025-06-10 20:47 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1749588446515079)
Hey team! Here are the follow-ups from the June 10 Team Meeting:
1. @Christina Hill to start A2P registration
2. @Christina Hill to email Mike (DJ Hybrid) about DNS transfer


**Christina Hill** · 2025-06-12 14:20 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1749738004269489)
Good morning @Whitney Hodges! For DJ Hybrid, Wix will not allow me to transfer the domain to cloudflare unless changes are made to their contact information. However, once the contact information is updated, there is a 60-day period during which no domain transfers can be made. What do you think our next steps with Mike should be? Below is an email I was drafting. Should we regroup on strategy as a result? cc:@Carmen Cruickshank

_Hi Mike,_ 

_Thanks for the login information. Wix still won’t allow me to transfer the DNS without first updating your contact information. There is a 60-day period during which I won’t be able to move this domain into Cloudflare to add the necessary records for the email subdomain._

_Within LeadLock, the only feature this will delay is email sending and receiving from a subdomain email address._
> **Whitney Hodges** · 2025-06-12 14:52 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1749739978006769)
> @Christina Hill Thank you for this update! Despite this hurdle, I would love to get them up and running on LeadLock, so we can start tracking a thank you page.
> 
> Is it correct that we can't register for A2P without the email subdomain in place? In which case, auto texts will be delayed too?
> 
> I can't remember what CRM they are currently using for DJ Hybrid, but we could consider Zapping LeadLock leads into their existing CRM for now.
> 
> Or they could keep using their existing DJ hybrid lead form but set it up to redirect to the LeadLock Thank You page.
> 
> Do you want to offer to get on a call with them to review the options? I'm happy to be on the call if you think it would be helpful.
> 
> cc @Carmen Cruickshank
> **Christina Hill** · 2025-06-12 16:10 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1749744650782189)
> @Whitney Hodges
> 
> We can complete A2P without the email subdomain, however all of the emails will be sent directly from their official email address during the testing process (I don't see this being an issue)
> 
> Since they are currently using a Wix form, setting up a redirect to a LeadLock TY page would be super simple. But embedding a LeadLock form would also be easy.
> 
> The only thing not having an email subdomain could possibly affect is email deliverability. Here are two solutions:
> 
> We could embed the form on their website for now, have it trigger a welcome email and text, and then Zap all of the leads to their existing nurture sequence to limit the amount of emails the CRM is sending (at least for the next 60 days until we can transfer the DNS records)
> 
> Or, we can even proceed to go the Landing Page route too, but after the welcome email and text, Zap the leads into their existing nurture sequence.
> 
> They can still send as many texts as they would like.
> 
> What do you think?
> 
> cc:@Carmen Cruickshank
> 📎 Screenshot 2025-06-12 at 12.04.09 PM.png (png, saved as `files/F09108Y1011-Screenshot_2025-06-12_at_12.04.09_PM.png`)
> **Whitney Hodges** · 2025-06-12 18:13 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1749752014869649)
> @Christina Hill Let's go ahead and link the existing form to the LeadLock thank you page ASAP.
> 
> I'm concerned about email deliverability without the email sending subdomain, so I'm thinking maybe we have LeadLock send the text only and Zap the leads into whatever platform they're currently sending emails from.
> 
> I think we probably do need to schedule a call to explain all this and get their buy in
> 
> Cc @Carmen Cruickshank
> **Christina Hill** · 2025-06-12 18:42 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1749753730320989)
> @Whitney Hodges Okay. I will email Mike to set up a call. Is there a good link for me to send him?
> 
> cc:@Carmen Cruickshank
> **Whitney Hodges** · 2025-06-12 18:56 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1749754584175409)
> @Christina Hill pretty much all of our links are in LeadLock. Can you just manually send call options this time? I think you should be able to see my availability through Google calendar, right?
> **Christina Hill** · 2025-06-13 15:30 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1749828640573819)
> Yes! will do.
> **Christina Hill** · 2025-06-13 19:17 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1749842233599799)
> Their website form now redirects to the Website Confirmation Page in LeadLock: <https://info.djhybridchicago.com/thank-you>. GTM is installed on the page, and GA4 tags are firing. @Whitney Hodges @Carmen Cruickshank

**Megan Jivraj** · 2025-06-17 14:27 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1750170475766299)
Hey @Christina Hill! I'm following up on Mike's email over the weekend about Flodesk verifying his new domain. He authenticated on his end and it led him to Cloudfare. He's wondering if he should do this or wait. If you could send him some feedback that would be great!

**Megan Jivraj** · 2025-06-17 20:55 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1750193708643079)
Hey team! Here are the follow-ups from the June 17 Team Meeting:
1. @Christina Hill to explore meeting location options (Zoom vs phone call) in Lead Lock.

**Christina Hill** · 2025-06-18 14:13 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1750256017864989)
Yay! A2P is approved for Funktastic and DJ Hybrid. @Whitney Hodges @Carmen Cruickshank
📎 Screenshot 2025-06-18 at 10.12.28 AM.png (png, saved as `files/F091US5CTEJ-Screenshot_2025-06-18_at_10.12.28_AM.png`)
> **Whitney Hodges** · 2025-06-18 14:20 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1750256459411559)
> Amazing!!

**Carmen Cruickshank** · 2025-06-18 17:55 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1750269314796529)
@Ivy Ayala hi! Here is the creatives brief for the conversion meta ads for Funktastic Productions: <https://docs.google.com/document/d/1b4TMUEUUAhcc6v104TgKjVAcBiywAMhpTX4G828OpEU/edit?tab=t.0> I'd like the first draft in the next 24-48 hours, thank you!
> **Whitney Hodges** · 2025-06-18 18:57 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1750273056749809)
> @Carmen Cruickshank @Ivy Ayala I don't love the source reel for Ad Creative 2. I feel like the audio quality is not great. I do really like the text overlay though. Could we create something from scratch with client-provided photos and/or b-roll?
> **Carmen Cruickshank** · 2025-06-18 19:21 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1750274477087759)
> @Whitney Hodges @Ivy Ayala yea i was trying to get a reel to showcase how Funktastic keep everyone on the dance floor and brings the energy. I could look for another one with better sound quality or we could have 2-3 of those videos where everyone is daning and cheering and instead have a song over the whole video
> **Whitney Hodges** · 2025-06-18 19:36 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1750275372665279)
> I think a mashup of some different videos could be cool
> **Carmen Cruickshank** · 2025-06-18 20:05 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1750277102925859)
> okay i'll look to get that out to you by tommorow morning @Ivy Ayala!!
> **Ivy Ayala** · 2025-06-18 22:55 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1750287339248089)
> ok! thank you :slightly_smiling_face: for these videos I could have them ready by Saturday
> **Carmen Cruickshank** · 2025-06-19 13:42 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1750340531122429)
> okay no rush then cause ill be back on my computer on monday, ill be sure to update the 2nd reel though and resend today
> **Ivy Ayala** · 2025-06-23 03:09 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1750648146033189)
> <https://www.canva.com/design/DAGrIK5xTtM/gSiIhvsrRystJsT6LEKwrg/edit?utm_content=DAGrIK5xTtM&amp;utm_campaign=designshare&amp;utm_medium=link2&amp;utm_source=sharebutton|Ad creative 1>  <https://www.canva.com/design/DAGrINrCzqs/gsb1DPJF8u1kLI6y_Tnn2g/edit?utm_content=DAGrINrCzqs&amp;utm_campaign=designshare&amp;utm_medium=link2&amp;utm_source=sharebutton|Ad creative 2> <https://www.canva.com/design/DAGrIdMNqwE/o9jW31PiTM5cMGTnUgYWpA/edit?utm_content=DAGrIdMNqwE&amp;utm_campaign=designshare&amp;utm_medium=link2&amp;utm_source=sharebutton|Testimonials>
> **Ivy Ayala** · 2025-06-23 03:09 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1750648159044899)
> Hi! here are the creatives, let me know your comments

**Whitney Hodges** · 2025-06-18 19:01 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1750273263760779)
@Christina Hill Are we using Google Meet for this call?

**Whitney Hodges** · 2025-06-18 19:01 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1750273272444369)
I don't see a Zoom link in the invite

**Christina Hill** · 2025-06-18 19:01 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1750273316976819)
Thank you! I just updated the meeting.

**Carmen Cruickshank** · 2025-06-19 14:30 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1750343427961079)
@Ivy Ayala just updated ad 2 in the doc, should be all good to go :slightly_smiling_face:

**Megan Jivraj** · 2025-06-19 19:33 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1750361588533359)
Hey @Christina Hill! Mike has asked for some feedback on his nurture sequences. Could you let me know when you may be able to provide feedback for him? Thank you! :smile:
> **Whitney Hodges** · 2025-06-19 19:46 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1750362394617909)
> @Megan Jivraj On my behalf, could you please respond to Mike first. On our call yesterday, he made it sound like these are nurture emails they send after they send a potential client a proposal. But in taking a quick look at them, that doesn't seem apparent to me. I want to make sure we are reviewing the right thing. Thank you!!
> **Megan Jivraj** · 2025-06-19 19:51 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1750362689364629)
> @Whitney Hodges Absolutely. Thanks for the context!

**Megan Jivraj** · 2025-06-20 12:27 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1750422426722809)
Morning @Whitney Hodges and @Carmen Cruickshank! Mike has asked for your thoughts on his DJ Hybrid intro text. I'm checking in to see who will be responding to him. I'm happy to put together a draft email incorporating both your thoughts (if you'll both provide input) and respond for Whitney or forward it to Carmen to send off. Thanks!
> **Whitney Hodges** · 2025-06-20 12:50 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1750423804667279)
> Thank you! I went ahead and responded

**Whitney Hodges** · 2025-06-20 17:27 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1750440420476689)
@Jenna Tria There are some emails from Mike in your inbox. I'd like for you to look into.

One is regarding the automated text response for DJ Hybrid leads. We can't use their full email nurture sequence yet because of issues with setting up their email sending domain. For the time being, the only thing that will happen when a lead inquires is one automated text response.

Mike would also like to see an email nurture sequence that can be sent to leads after they receive a proposal from him. He sent over some emails he wanted us to incorporate, but I think he had already provided these emails to us and they are what we used to create the inquiry nurture sequence and appointment nurture sequence. Can you please review thoroughly and verify for me?
> **Jenna Tria** · 2025-06-20 19:25 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1750447511434779)
> Here's the <https://docs.google.com/document/d/18dVaLC_-QtLZ3xZRcxdq9U7v2jnJvuhjMJzo73eWz50/edit?usp=sharing|Google Doc> I've created that summarizes the changes and compares Mike’s revision email nurture sequence with the email nurture we created.
> **Megan Jivraj** · 2025-06-27 12:43 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1751028202809679)
> Hey @Whitney Hodges and @Jenna Tria! I'm following up on this to see if we are able to get back to Mike! Thanks.
> **Whitney Hodges** · 2025-06-27 13:21 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1751030484827309)
> @Megan Jivraj Hi! @Jenna Tria is going to write consultation follow-up email nurture sequences for both Funktastic and DJ Hybrid as a special bonus for them, but based on our production schedule, these probably won't be ready for at least a couple more weeks. Could you please draft an email update to Mike on this?
> **Megan Jivraj** · 2025-06-27 15:52 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1751039522668309)
> @Whitney Hodges Draft in the inbox.
> **Megan Jivraj** · 2025-07-11 18:22 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1752258139472689)
> @Whitney Hodges I wanted to follow up on this and see what progress was made and the next steps moving forward for this task? Thanks! Let me know if I can assist in any way.
> **Whitney Hodges** · 2025-07-11 18:29 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1752258577616469)
> @Megan Jivraj Jenna drafted the email sequences. I still need to review them. I might ask Carmen to do this. I let Mike know on our call today that we would  have them over to him for review next week
> **Megan Jivraj** · 2025-07-11 18:30 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1752258632940249)
> @Whitney Hodges Amazing. I appreciate the update.
> **Megan Jivraj** · 2025-07-23 20:28 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1753302525468619)
> @Gisselle Jiménez FYI for the nurture sequences to follow-up on.
> **Whitney Hodges** · 2025-07-23 20:41 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1753303272406449)
> @Gisselle Jiménez @Megan Jivraj Christina sent these to Mike last week

**Carmen Cruickshank** · 2025-06-23 15:27 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1750692472277219)

**Carmen Cruickshank** · 2025-06-23 15:29 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1750692540813339)
@Ivy Ayala these look good! great job! i was wondering if you could switch the first audio for another one that you think fits, not sure what audio but something that is upbeat and has a dancy vibe

**Whitney Hodges** · 2025-06-23 15:50 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1750693808502189)
@Carmen Cruickshank I think it would be great to use as much original audio from Funktastic as we can (as long as it's high quality). What do you think about asking Mike if he has additional audio he can share with us outside of what's included in the videos he's provided? That might give us more to work with.

For Creative 2, could we spin the hook more positively? Something like "Ready to create the ultimate dance party for your wedding reception?"

For Creative 3, I'd definitely like to hear different audio for this one. Something high energy that matches the vibe of the photos. I also think "Testimonial" on the slides can be removed.

cc @Ivy Ayala

Thank you both!!
> **Ivy Ayala** · 2025-06-23 22:29 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1750717774572429)
> Yes! I think would be awesome to incorporate original  music from the band in the ads, so people know what to expect 

**Carmen Cruickshank** · 2025-06-23 19:52 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1750708359754059)
Those sound good I can make some edits to the creatives brief tomorrow @Whitney Hodges @Ivy Ayala 

**Christina Hill** · 2025-06-25 17:47 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1750873646806879)
@Whitney Hodges and @Jenna Tria - Should this <https://info.funktasticproductions.com/thank-you|Thank you Page> button lead to the "Book A Consultation" Page, or to the homepage of the website?
> **Whitney Hodges** · 2025-06-25 17:53 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1750874015692669)
> @Christina Hill Yes, can you please update the button to go to Amber's consultation page?

**Carmen Cruickshank** · 2025-06-25 17:52 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1750873956027079)
@Ivy Ayala I made those edits to the creatives brief and just asked mike if he has any audio we can put for creative 1, remaking 2 and 3 would be helpful right now and i'll let you know when he send over audio for creative 1
> **Ivy Ayala** · 2025-06-25 18:56 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1750877808595899)
> for the testimonial we could also use some music from the band @Carmen Cruickshank I already made the updates
> **Carmen Cruickshank** · 2025-06-25 19:46 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1750880795561199)
> @Ivy Ayala Okay thank you! I'm going to forward you what mike sent me. I like his suggesstion having the song Sir Duke at 2:53 thats a good snippet for creative 1 and creative 3 could be the lizzo song juice or Valerie. You'll see it in the email, let me know if you have any questions
> **Ivy Ayala** · 2025-06-27 23:38 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1751067536108129)
> done! @Carmen Cruickshank
> **Carmen Cruickshank** · 2025-06-28 02:40 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1751078449069179)
> Thanks @Ivy Ayala I’ll check it out Monday

**Christina Hill** · 2025-06-26 13:42 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1750945349214629)
Hi @Whitney Hodges! Funktastic and DJ Hybrid are all set in LeadLock with the exception of Amber's calendar and email integrations. I will send Mike an email this morning about getting on a call, hopefully before the week is out.
> **Whitney Hodges** · 2025-06-26 13:46 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1750945593269729)
> @Christina Hill ok! Can you reach out to Mike to ask him to have Amber connect her email and calendar. I think the tutorial videos should be able to help her with that
> **Christina Hill** · 2025-06-26 13:47 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1750945620449029)
> Yes. Writing the email now.
> **Christina Hill** · 2025-06-26 14:25 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1750947923207089)
> Onboarding Mike today at 11:30 am EST for DJ Hybrid, and maybe Funktastic if Amber is connected by then. I invited you and Carmen to the meeting, but I know it is short notice, so I am prepared to lead it if either of you cannot make it. @Whitney Hodges @Carmen Cruickshank
> **Carmen Cruickshank** · 2025-06-26 14:26 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1750947981600339)
> I’m sorry but my family planned something today and I won’t be able to make it on @Christina Hill 
> **Whitney Hodges** · 2025-06-26 14:27 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1750948039966479)
> @Christina Hill Thank you! I have a sales call at noon today, so I'm going to let you take the lead on this.

**Christina Hill** · 2025-06-26 14:44 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1750949041787209)
@Carmen Cruickshank - Here are the Funnel Maps for Funktastic and DJ Hybrid: <https://docs.google.com/spreadsheets/d/1x3r5NSrkFo9MY1rr1v3fuW4KXq-CYyswRPj5soyZge8/edit?gid=0#gid=0>

Please let me know if you need assistance with installing tracking. :slightly_smiling_face: GTM should be installed on all pages, so I think it would only need Meta and/or the new triggers set up.

**Megan Jivraj** · 2025-06-26 17:41 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1750959661760739)
Hey team! Here are the follow-ups from the June 24 Team Meeting:
1. @Carmen Cruickshank to provide an audit

**Christina Hill** · 2025-06-26 21:36 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1750973814279599)
@Carmen Cruickshank Funktastic and DJ Hybrid's new forms are now live and embedded on their website.

**Carmen Cruickshank** · 2025-06-27 14:29 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1751034587810739)
@Whitney Hodges Hi! The frequency for the client attraction ads is already at 3.01. I forgot to mention this on the weekly team meeting cause on Tuesday it was 2.8. Jacqueline was saying to remove the luxury cars interest in the 3rd layer. As well as possibly combining the second layer into the first layer of interest to broaden the audience more. What are your thoughts?
> **Whitney Hodges** · 2025-06-27 14:31 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1751034691967479)
> @Carmen Cruickshank sounds like a good plan! Go for it

**Carmen Cruickshank** · 2025-07-01 15:45 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1751384721479209)
@Whitney Hodges Here is the final conversion ads creatives doc: <https://docs.google.com/document/d/1CM4-hVc6ZhZmC4k_qIre1VulnZEeG5Dt-KaAL6Gw9nQ/edit?tab=t.0#heading=h.oqaep79iv7f5>
> **Whitney Hodges** · 2025-07-01 17:00 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1751389209334539)
> @Carmen Cruickshank Just requested access!
> **Whitney Hodges** · 2025-07-02 13:51 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1751464301911699)
> @Carmen Cruickshank Hi! I made some copy suggestions in the doc, but overall, really excellent job! I'm excited for you to send these to Mike!!
> **Carmen Cruickshank** · 2025-07-02 14:00 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1751464825346639)
> Okay sounds good, I'll send these to Mike! Thank you!

**Carmen Cruickshank** · 2025-07-01 15:45 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1751384737843609)
let me know your thoughts before i email it to mike to then creatve the campaign

**Carmen Cruickshank** · 2025-07-02 15:30 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1751470237673999)
@Whitney Hodges Mike sent a new landing page that was just created this past week in a reply to my originoal loo video, if you could give it a look for any critiques. I think it looks much better!
> **Whitney Hodges** · 2025-07-02 15:46 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1751471182845349)
> @Carmen Cruickshank yes, I think it looks great!!
> **Carmen Cruickshank** · 2025-07-02 18:54 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1751482489206349)
> amazin!

**Carmen Cruickshank** · 2025-07-04 16:40 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1751647203937659)
@Whitney Hodges Hi! Happy 4th! I was setting up the Meta conversion campaign but would like to go over some things on Monday or Tuesday. Just updating you. Have a great weekend!
> **Whitney Hodges** · 2025-07-04 16:41 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1751647270911039)
> @Carmen Cruickshank happy 4th! Feel free to put something on my calendar. I'd love to meet Monday if our schedules align
> **Carmen Cruickshank** · 2025-07-07 13:25 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1751894725869229)
> @Whitney Hodges Great! Does 12pm EST work?
> **Whitney Hodges** · 2025-07-07 13:59 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1751896788825349)
> @Carmen Cruickshank yes, that should work!

**Whitney Hodges** · 2025-07-07 15:22 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1751901745669679)
@Christina Hill Hi! I noticed a couple of things inside Mike's LeadLock account that I'm hoping you can help with. Can you ask Mike to add a method of payment, so we can start charging him the monthly subscription? Also, could you set up the Opportunities, so there are separate pipelines for Funktastic and DJ Hybrid leads?

**Carmen Cruickshank** · 2025-07-07 15:43 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1751903033447409)
@Jenna Tria Let me know any updates on the monthly report or if i can help with anything:heart_hands:
> **Jenna Tria** · 2025-07-07 15:48 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1751903314364349)
> @Carmen Cruickshank Hi! I just gained access to Google Ads today!
> **Jenna Tria** · 2025-07-07 18:24 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1751912673085029)
> @Carmen Cruickshank Here's the June monthly report for <https://www.canva.com/design/DAGsL0_iAlc/CDno0vWzQVCvhXyzFsmK4g/edit?utm_content=DAGsL0_iAlc&amp;utm_campaign=designshare&amp;utm_medium=link2&amp;utm_source=sharebutton|Funktastic>. Let me know if you need any changes or further adjustments. Thank you!

**Megan Jivraj** · 2025-07-08 19:29 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1752002984128229)
Hey team! Here are the follow-ups from the July 8 Team Meeting:
1. @Carmen Cruickshank to include link to strategy call with Whitney in monthly report email

**Jenna Tria** · 2025-07-08 20:08 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1752005318961689)
@Carmen Cruickshank Here's the June monthly report for <https://www.canva.com/design/DAGsL0_iAlc/CDno0vWzQVCvhXyzFsmK4g/edit?utm_content=DAGsL0_iAlc&amp;utm_campaign=designshare&amp;utm_medium=link2&amp;utm_source=sharebutton|Funktastic and DJ Hybrid>. Let me know if you need any changes or further adjustments. Thank you!

**Whitney Hodges** · 2025-07-09 15:59 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1752076764310219)
@Jenna Tria I was doing some testing for Funktastic last week when their automated texts weren't working. I've been receiving the their inquiry email sequence. The subject lines do not match what was approved by the client in <https://docs.google.com/document/d/12yGstbooLD-DLJeVVdDrjcd3ZbGjV-JiWjlH204Q8-c/edit?tab=t.0|this document>. Please get these updated ASAP. Please check that the subject lines are accurate for DJ Hybrid's emails as well. Thank you!! cc @Christina Hill
> **Whitney Hodges** · 2025-07-10 17:32 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1752168745239219)
> @Christina Hill Jenna said she completed this yesterday. Can you please double check?
> **Christina Hill** · 2025-07-11 16:35 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1752251709914889)
> Hi @Whitney Hodges! Confirmed. I just tested all their emails and the  the subject lines were updated :+1::skin-tone-4:

**Whitney Hodges** · 2025-07-10 17:32 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1752168773231659)
@Christina Hill Can you please handle the LeadLock questions Mike sent over via email?

**Carmen Cruickshank** · 2025-07-10 18:34 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1752172464751519)
@Ivy Ayala Here are the retargeting ads for funktastic: <https://docs.google.com/document/d/190XKR7chODCxcQxMpG7TLp-pFKlaPvJ5SMrH4bOHKm4/edit?tab=t.0#heading=h.pex9bsupsbf> Ideally if we have a first draft in the next 24 hours thatd be great, but no pressure
> **Ivy Ayala** · 2025-07-11 15:54 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1752249251453589)
> Hi! I’ll be working on it this weekend 
> **Ivy Ayala** · 2025-07-14 15:40 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1752507651997639)
> <https://www.canva.com/design/DAGtJyJhcRo/Ize3RqR3135-yflcy9jwXA/edit?utm_content=DAGtJyJhcRo&amp;utm_campaign=designshare&amp;utm_medium=link2&amp;utm_source=sharebutton|Video 2>
> **Ivy Ayala** · 2025-07-14 15:41 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1752507668780109)
> <https://www.canva.com/design/DAGtJbiRTQg/tQNHcoCZiUL_a8jKYqgFYQ/edit?utm_content=DAGtJbiRTQg&amp;utm_campaign=designshare&amp;utm_medium=link2&amp;utm_source=sharebutton|Video 1>
> **Ivy Ayala** · 2025-07-14 15:41 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1752507710436919)
> for the second creative I had to use other videos because the one you sent me was too short for the information to be included.
> **Ivy Ayala** · 2025-07-14 15:42 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1752507725024899)
> let me know what you think!
> **Ivy Ayala** · 2025-07-14 15:42 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1752507727287269)
> @Carmen Cruickshank
> **Carmen Cruickshank** · 2025-07-17 15:57 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1752767871859509)
> Great job @Ivy Ayala! @Whitney Hodges I think these look great and im ready to create the ad copy and send them to Mike, let me know what you think of these creatives!
> **Whitney Hodges** · 2025-07-17 18:53 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1752778397883949)
> @Carmen Cruickshank @Ivy Ayala Great job! Thoughts below:
> 
> For Video 1, I'm not sure the song choice will resonate with their ideal clients. Did they provide any other original audio we haven't used yet?
> 
> Also, the first FAQ has kind of a negative connotation. Can we change it to "How can I check you out before I book?". And in the response leave out the beginning about performances being private.
> 
> I think with these minor changes they'll be ready to send to Mike
> **Ivy Ayala** · 2025-07-17 19:37 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1752781042983409)
> ok! I added another song
> **Ivy Ayala** · 2025-07-17 19:37 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1752781068546589)
> and changed the question
> **Ivy Ayala** · 2025-07-17 19:37 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1752781072373799)
> @Whitney Hodges
> **Carmen Cruickshank** · 2025-07-17 19:55 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1752782107239489)
> Thank you @Ivy Ayala @Whitney Hodges 

**Whitney Hodges** · 2025-07-11 16:46 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1752252412993249)
@Christina Hill @Carmen Cruickshank Meta is tracking 3 leads!!! However, I'm not seeing any leads attributed to Meta inside their LeadLock account. I'm not sure why. Their form has fields for UTM parameters, and we're using UTMs in the ads. Can y'all please look into this? Thank you!!!

**Carmen Cruickshank** · 2025-07-14 15:27 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1752506852513939)
Update for meeting tomorrow: Google Ads - DJ Hybrid now has 3 leads with CPL being $100/lead, which is high but at least theyre getting form submissions, for Funktastic, they're not getting leads so far for June, but everything looks good for CTR, search terms and more

**Carmen Cruickshank** · 2025-07-14 15:27 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1752506878490429)
Meta Ads - 3 leads so far for Funktastic at $70 per lead, client attractoin ads look good too for landing page views

**Christina Hill** · 2025-07-15 00:13 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1752538412562759)
@Whitney Hodges Payment method was added inside of LeadLock
> **Whitney Hodges** · 2025-07-15 00:30 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1752539449612039)
> @Christina Hill thank you! I started billing him for the subscription today

**Whitney Hodges** · 2025-07-17 21:16 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1752786979134019)
@Christina Hill Hi! When you respond to Mike's email with LeadLock questions, can you please include this <https://docs.google.com/document/d/1DCZ24JbriYOgbpqMAmG0_E2cqzihgd4JaJAEGa0Xeok/edit?usp=sharing|post-consultation emails doc> for their review? He really wants email sequences to put people in following sales calls as he mentions in his email. Jenna drafted this. I gave it a quick onceover and think it's ok to send. If you wouldn't mind giving it a review too, that would be great.

Also, we had told him on our call with him last week that we'd give him access to Audit &amp; Adapt, too. Could you please also handle this piece and let him know what to look out for with that welcome email?

Thank you! I appreciate you so much!!

cc @Carmen Cruickshank @Megan Jivraj
> **Christina Hill** · 2025-07-18 18:33 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1752863595381629)
> @Whitney Hodges Done :white_check_mark:

**Carmen Cruickshank** · 2025-07-21 15:25 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1753111551272369)
@Christina Hill Hi! I saw Funktastic got 4 more leads this past week, do you see the connection on the UTM parameters? i can check in leadlock too

**Carmen Cruickshank** · 2025-07-21 15:37 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1753112235863049)
update: I see it! everything looks good :smile:
> **Christina Hill** · 2025-07-21 17:56 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1753120594324729)
> Hi @Carmen Cruickshank, I see that Funktastic has new leads, but they are still only listing 'Website' as the contact source on my end. Tomorrow during our call, we can look at this together and I can show you some of the tweaks I've made. It may be that the campaign needs to be relaunched, but I would love to talk this through with you and see what you think. :slightly_smiling_face:
> **Carmen Cruickshank** · 2025-07-21 18:24 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1753122293147139)
> @Christina Hill sounds good!!

**Megan Jivraj** · 2025-07-23 14:29 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1753280960675259)
Hey team! Here are the follow-ups from the July 22 Team Meeting:
1. @Christina Hill to troubleshoot UTM &amp; lead tracking in *LeadLock. —* Sync again &amp; test UTM fields (possibly rebuild form)
2. @Carmen Cruickshank to send updates on Meta retargeting ads. Once greenlight is given, launch the campaigns.

**Whitney Hodges** · 2025-07-30 14:29 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1753885760765229)
@Gisselle Jiménez I'm also seeing an overdue invoice for Mike. It was due back at the beginning of the month. :woman-facepalming: I want to get payment for this ASAP. Can you please draft an email to him that includes a link to the invoice? My guess would be that the email that was originally sent to him from LeadLock went to his junk mail.

Let's look at the Payments section of LeadLock together when we meet. I want to make sure we're staying on top of overdue payments moving forward. Thank you!!
> **Gisselle Jiménez** · 2025-07-30 14:33 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1753885990686009)
> @Whitney Hodges Do I send these follow-ups through LeadLock again?
> **Whitney Hodges** · 2025-07-30 14:34 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1753886078704419)
> @Gisselle Jiménez No, I would send it from Gmail
> **Gisselle Jiménez** · 2025-07-30 14:36 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1753886189177439)
> Noted! Working on it.
> **Gisselle Jiménez** · 2025-07-30 15:01 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1753887712528669)
> @Whitney Hodges Mike's draft with a hyperlink:
> 📎 image.png (png, saved as `files/F097R407D3R-image.png`)
> **Whitney Hodges** · 2025-07-30 15:23 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1753889036953349)
> Slightly revised and sent! @Gisselle Jiménez

**Ivy Ayala** · 2025-08-04 02:15 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1754273713361409)
Hello! <https://www.canva.com/design/DAGvEXJAIvk/Wq801AvSPf3RPip1C5OHig/edit?utm_content=DAGvEXJAIvk&amp;utm_campaign=designshare&amp;utm_medium=link2&amp;utm_source=sharebutton|Monthly report July> @Carmen Cruickshank  let me know your comments! thanks

**Carmen Cruickshank** · 2025-08-04 18:40 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1754332825635789)
Thank you! @Ivy Ayala 

**Gisselle Jiménez** · 2025-08-05 13:51 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1754401884828129)
Hi, team! Just a quick reminder to acknowledge Mike's recent emails. @Carmen Cruickshank Mike replied to the retargeting ads email. He’s happy with the post-consultation email copy and is ready to move forward with it. He said he’ll need the weekend to review the retargeting ads and will follow up shortly. Kindly find below an email draft you can start with for your convenience!
> **Gisselle Jiménez** · 2025-08-05 13:51 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1754401907343539)
> Hi Mike,
> 
> Thanks so much for the update. I hope you had a wonderful time in Europe!
> 
> So glad to hear the post-consultation email copy looks good to you. We’ll go ahead and move forward with that on our end. No worries at all on the retargeting ads — just let us know once you’ve had a chance to review.
> 
> Looking forward to getting everything into motion!
> 
> Best,
> Carmen
> **Carmen Cruickshank** · 2025-08-05 14:58 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1754405929200479)
> Thank you @Gisselle Jiménez! I will get back to him now

**Gisselle Jiménez** · 2025-08-05 13:54 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1754402061483809)
@Christina Hill Mike’s good to move forward with the nurture sequence and also asked if it’s possible to create a separate calendar link that connects to _his_ calendar (similar to Amber’s), so he can share it directly with leads if needed. If this will take a bit to set up, here’s a quick email draft you can send to acknowledge his message and keep things moving:
> **Gisselle Jiménez** · 2025-08-05 13:54 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1754402098919959)
> Hi Mike,
> 
> Thanks for the update! I hope you had a great time in Europe.
> 
> So glad to hear you’re happy with the nurture sequence. We’ll go ahead and get that implemented on our end.
> 
> As for the calendar link, I’ll look into getting that set up for you so you can share it as needed. I’ll follow up shortly once I confirm the best way to connect it directly to your calendar.
> 
> Appreciate the quick reply and will be in touch soon!
> 
> Best,
> Christina
> **Christina Hill** · 2025-08-05 15:59 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1754409555481329)
> Hi @Gisselle Jiménez I don't see his email. The lst one I received from him was a question about a new email template. Can you forward me the email you are talking about. In the meantime, I will respond to his last message to me with additional things he wants me to do and cc you.
> **Gisselle Jiménez** · 2025-08-05 16:05 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1754409921779309)
> @Christina Hill Just forwarded it to you. :raised_hands:
> **Christina Hill** · 2025-08-05 16:12 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1754410353133539)
> Thank you! I just responded to both. @Gisselle Jiménez

**Gisselle Jiménez** · 2025-08-05 13:55 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1754402107416179)
Thanks, team! :revolving_hearts:

**Gisselle Jiménez** · 2025-08-13 16:38 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1755103088152519)
Hi, @Christina Hill! Kindly find below the links to Funktastic and DJ Hybrid nurture sequences! I have also forwarded the email to you, so you should also see it in your inbox. Let me know if you need anything else.:raised_hands:

*Funktastic*

Email 1
<https://view.flodesk.com/emails/681a2a09fc43cb909107e988>

Email 2
<https://view.flodesk.com/emails/679be633a13c0826b2fe2a4a>

Email 3
<https://view.flodesk.com/emails/679be651719b45416c8f68a7>

Email 4
<https://view.flodesk.com/emails/67cf2132d49555fbdd036617>

Email 5
<https://view.flodesk.com/emails/67cf2158a5fb7e712549bd1f>


*DJ Hybrid* 

Email 1
<https://view.flodesk.com/emails/684b0cc71786bff58a5738c2>

Email 2
<https://view.flodesk.com/emails/684b0cde9ae0d110738f780e>

Email 3
<https://view.flodesk.com/emails/684b0d103113142ee3cbca58>

Email 4
<https://view.flodesk.com/emails/684b0cf3e589e42454cc4d40>
> **Christina Hill** · 2025-08-14 16:12 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1755187943611409)
> Thank you! Super helpful.

**Gisselle Jiménez** · 2025-08-14 17:42 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1755193334496159)
@Christina HillHi! Just in case you missed it, Mike sent over some questions about the DJ Hybrid domain timeline and LeadLock tracking. Here’s an email draft you can use to acknowledge his message if you need a little more time to reply:
> **Gisselle Jiménez** · 2025-08-14 17:42 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1755193359574259)
> &gt; Hi Mike,
> &gt; 
> &gt; Don’t worry — your questions are always welcome! I’ll check on the DJ Hybrid domain timeline and also look into the LeadLock tracking to see what might help in the meantime.
> &gt; 
> &gt; I’ll follow up with you soon once I have more details.
> &gt; 
> &gt; Thank you,
> &gt; Christina
> **Christina Hill** · 2025-08-14 18:58 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1755197930686879)
> Thank you!

**Christina Hill** · 2025-08-14 19:52 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1755201175182249)
@Whitney Hodges Since <https://docs.google.com/document/d/1DCZ24JbriYOgbpqMAmG0_E2cqzihgd4JaJAEGa0Xeok/edit?usp=sharing|these emails> are after the consultation takes place, should the CTA be "Contact Us for Availability?" How do you feel about me changing it to "Contact Us Today to Book Your Date"? Or should I remove the CTA altogether?
> **Whitney Hodges** · 2025-08-14 20:00 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1755201605038969)
> @Christina Hill it's my understanding that after a consultation, they send them a proposal/contract, and that would be the next step for them to confirm. But since those are personalized, there's not a way to link to that in these emails. I think the purpose of these emails is to keep them top of mind following a consultation. Each email doesn't necessarily need a CTA. Maybe for those that we do include CTAs, it's more like: "still have questions? Hit reply and we're happy to help!"
> **Christina Hill** · 2025-08-14 20:05 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1755201919466209)
> Okay, sounds good. I will make some changes. The links are in place, so after I make those CTA tweaks and build the workflow, we should be good to test and enable. :+1::skin-tone-4:
> 
> @Whitney Hodges cc: @Gisselle Jiménez

**Gisselle Jiménez** · 2025-08-26 20:44 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1756241046929789)
@Christina Hill Mike just replied to Carmen about the retargeting ads, so no need to include that in your email:)  I’ve removed that item from the action list and added instead: Update Mike on the DJ Hybrid domain timeline and LeadLock tracking, and answer his questions about the post-nurture sequence based on his most recent emails.

**Carmen Cruickshank** · 2025-08-28 15:40 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1756395649157219)
@Whitney Hodges Hi ! For retargeting ads for funktastic, is the objective leads or traffic on Meta?
> **Whitney Hodges** · 2025-08-28 16:17 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1756397827485399)
> Traffic! @Carmen Cruickshank

**Carmen Cruickshank** · 2025-08-28 16:00 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1756396845846679)
@Jacqueline Hood ^

**Ivy Ayala** · 2025-09-03 20:59 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1756933163916619)
Hello! <https://www.canva.com/design/DAGx9L804Sk/7_sOcF3cXlOGtsixnbPYJw/edit?utm_content=DAGx9L804Sk&amp;utm_campaign=designshare&amp;utm_medium=link2&amp;utm_source=sharebutton|Monthly report- August> @Carmen Cruickshank

**Carmen Cruickshank** · 2025-09-03 21:00 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1756933245468809)
Thank you! @Ivy Ayala 

**Ivy Ayala** · 2025-09-06 23:48 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1757202524862789)
hey there! Here are some video ideas for funktastic : <https://vt.tiktok.com/ZSATC5ymE/>

<https://vt.tiktok.com/ZSATCU3HV/>

<https://vt.tiktok.com/ZSATCXXAy/>

<https://vt.tiktok.com/ZSATCum71/>

<https://vt.tiktok.com/ZSATCDy7E/>

<https://vt.tiktok.com/ZSATC4j5H/> @Carmen Cruickshank

**Carmen Cruickshank** · 2025-09-10 18:54 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1757530486318969)
@Ivy Ayala here is the creatives brief for the refresh of the conversion ads! <https://docs.google.com/document/d/1RYF6TuXoGu1Py5fXozELiQVDF33_JEC3qH_OrdCEVmU/edit?usp=sharing>  In the notes section, I referenced the “Exciting Wedding Band” reel you created to give a clearer picture of what I’m aiming for. That reel alone has been bringing in about one lead per day, sometimes every other day, so it’s been very successful. Let me know if you have any questions!
> **Ivy Ayala** · 2025-09-11 20:56 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1757624191457739)
> Great! I’ll work on it this weekend 
> **Carmen Cruickshank** · 2025-09-12 03:00 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1757646041962009)
> Sounds good thanks!
> **Ivy Ayala** · 2025-09-14 21:01 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1757883705166229)
> Hey there! here are the <https://drive.google.com/drive/folders/1yCoGs-O_BhSGbhUai61xYByIgeQhhPbB?usp=sharing|creatives>
> **Ivy Ayala** · 2025-09-14 21:02 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1757883747358329)
> @Carmen Cruickshank let me know your comments!
> **Carmen Cruickshank** · 2025-09-15 16:07 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1757952467103179)
> thank you @Ivy Ayala! These look great

**Christina Hill** · 2025-09-15 21:41 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1757972469898439)
Hi @Gisselle Jiménez. Update: I have the email drafted for Mike. Once I have the link for him to book a call with me, Whitney, and Carmen, I will send it over. :slightly_smiling_face: Thank you
> **Gisselle Jiménez** · 2025-09-16 13:47 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1758030472429129)
> @Christina Hill @Whitney Hodges Hi! Here is the <https://app.leadlockpro.com/v2/location/Xi40zxmRvW8Pbyk5DYHp/settings/calendars/?user_ids=CkGMAJQ07hnb8QeKuGOg|calendar>, <https://weddingindustryads.com/strategy-call-whitney-carmen-christina|landing page>, and <https://app.leadlockpro.com/location/Xi40zxmRvW8Pbyk5DYHp/workflow/28684828-7b76-4739-aa8d-79408e821d09|automation>. Feel free to review, and let me know if anything needs to be modified!
> **Whitney Hodges** · 2025-09-16 13:50 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1758030600525179)
> @Gisselle Jiménez Looks good from what I can see! Have you tested it?
> **Gisselle Jiménez** · 2025-09-16 14:21 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1758032487939669)
> @Whitney Hodges Let me test it now. :raised_hands:
> **Gisselle Jiménez** · 2025-09-16 14:25 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1758032722144149)
> All looks good so far!
> **Whitney Hodges** · 2025-09-16 14:26 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1758032763797459)
> @Gisselle Jiménez Thank you! @Christina Hill You should be good to send your email and include this booking link <https://weddingindustryads.com/strategy-call-whitney-carmen-christina>
> **Christina Hill** · 2025-09-16 14:50 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1758034211709489)
> Thank you, @Gisselle Jiménez and @Whitney Hodges. I just sent the email to Mike. :white_check_mark:

**Whitney Hodges** · 2025-09-19 17:23 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1758302590301739)
@Christina Hill Not sure how exactly, but there should be a way to do what Marisa is asking, by setting it up so that auto texts only go out on certain days/hours of the day
> **Christina Hill** · 2025-09-22 14:00 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1758549613604939)
> Okay @Whitney Hodges I will check on this.

**Christina Hill** · 2025-09-22 14:17 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1758550659138389)
Hi @Whitney Hodges. I was working on the Wix Domain transfer this morning while following Pamela's video, but I have some hesitations. The DJHybrid domain was purchased inside of Wix, versus the Funktastic Productions domain that was purchased from <http://Gandhi.net|Gandhi.net>. It was a little simpler (surprisingly) to transfer the domain from Ghandi and point the nameservers to Wix than it is to transfer a domain from Wix.  Below is a screenshot of the message Wix gave me. I checked on ChatGPT as well, and they confirmed that the only way to move forward with Cloudflare is to transfer the domain away (I was hoping the alternative would be to only transfer the DNS records, but Wix has locked any nameserver edits to prevent this).

Is it possible to schedule another call with Pamela to get this done? Or is there another option, or a person I should reach out to help me with this?
📎 Screenshot 2025-09-22 at 10.03.15 AM.png (png, saved as `files/F09GVHG23AM-Screenshot_2025-09-22_at_10.03.15_AM.png`)
> **Whitney Hodges** · 2025-09-22 15:05 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1758553528205589)
> @Christina Hill Yes, you can schedule a call with Pamela. Do you still have her link? I'll look for it now
> **Whitney Hodges** · 2025-09-22 15:06 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1758553577149559)
> @Christina Hill Here it is! <https://speakwithpamela.com/paid>
> **Christina Hill** · 2025-09-22 15:58 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1758556693207829)
> Thank you! :pray::skin-tone-4: Can you schedule the meeting for Thursday? I have availability all day. @Whitney Hodges, It asks for payment details when booking; otherwise, I would book it now.
> **Whitney Hodges** · 2025-09-22 16:03 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1758557006612739)
> @Christina Hill Booked for Thursday at noon!
> **Christina Hill** · 2025-09-22 17:55 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1758563751162799)
> Thank you!

**Christina Hill** · 2025-09-23 15:52 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1758642729758809)
Hi @Tina Henares! I hope you are doing well. I have a new LeadLock Landing Page project for you. :slightly_smiling_face: Mike is the owner of Funktastic and DJ Hybrid. Because of a tracking issue, we need to create an Ads Traffic LeadLock Landing page inside of the Funktastic Productions Sub-Account and the DJ Hybrid Sub-Account. I believe you already designed the Funktastic <https://info.funktasticproductions.com/THANK-YOU|Thank You Page>.  I would love to have this ready for Mike to review before October 1st, if possible. Please let me know what you need from me or the client to complete this project.

<https://www.funktasticproductions.com/|Funktastic Productions Website>

<https://www.djhybridchicago.com/|DJ Hybrid Chicago Website>

<https://drive.google.com/drive/folders/1mTNaU3VIbvTjA_tbKIO1QEF-kpNozWy-?usp=sharing|Collective Brand Guide>

cc: @Gisselle Jiménez @Whitney Hodges
> **Whitney Hodges** · 2025-09-23 15:55 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1758642906103219)
> @Christina Hill Thank you for bringing Tina up to speed on this! If I remember correctly, Mike created a landing page for Funktastic for ads traffic, and it's performing well. So I think we can mirror that pretty closely but also improve it as we see fit with the LeadLock version we create.
> 
> @Carmen Cruickshank Can you share the link to that landing page?
> **Carmen Cruickshank** · 2025-09-23 16:42 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1758645761531379)
> yes here is the link: <https://www.funktasticproductions.com/chicago-bands?rc=test-site>
> **Tina Henares** · 2025-09-24 01:46 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1758678366516309)
> Hi @Christina Hill Thank you for this information! I'll start working on it tomorrow :slightly_smiling_face: Just to clarify, I'm creating two separate landing pages correct?
> **Christina Hill** · 2025-09-25 18:08 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1758823708171459)
> Correct  :+1::skin-tone-4: @Tina Henares
> **Tina Henares** · 2025-10-01 02:35 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1759286115051799)
> @Christina Hill Hi! Let me know what you think about these two Landing Page drafts. I'll review them tomorrow again and refine them a bit :slightly_smiling_face:
> 
> <https://app.leadlockpro.com/location/OhK5iHgR19YiVHrq6rMw/page-builder/Xv8qOKunFwMhCqh9bqMd>
> 
> <https://app.leadlockpro.com/location/mj0FRsBhHcNFDaJltdHZ/page-builder/T5ezzMCH3irn8PfwIiKI>
> **Christina Hill** · 2025-10-01 19:19 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1759346396726479)
> Thank you, @Tina Henares! These look good. Is there a way to make more of the header image show for the Funktastic page? I know it can be a little tricky with font colors, but I would love to see that image pop more, like with a darker fade and white text, like their current landing page has.
> 
> @Carmen Cruickshank @Whitney Hodges I would love to get your input on these landing pages.
> **Tina Henares** · 2025-10-07 00:39 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1759797567635609)
> Hi! @Christina Hill Do you think this works better?
> 📎 Screenshot 2025-10-06 193637.png (png, saved as `files/F09K2NQRMK4-Screenshot_2025-10-06_193637.png`)
> **Christina Hill** · 2025-10-08 21:14 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1759958054913249)
> Hi @Tina Henares, Sorry for the delay in getting back with you. The DJ Hybrid page is great. I just sent that over to Mike.
> 
> Yes! The edits to the Hero Image for Funktastic's page make it so much easier to read. Thank you! Can you also seperate the copy? <https://www.loom.com/share/3f2f80caf85a4bac9fecf7dc6c7c11c5?sid=812c5376-8b7d-48d9-ab39-69a8df56749c|Here is a Loom video that does a better job at explaining what I mean>.
> 
> One reason for the delay is that we are working with Mike to make some revisions to how his prices/packages are listed online. He has just updated them <https://www.funktasticproductions.com/chicago-bands-old|on this page of his website>. Can you make these updates to the pricing on the Funktastic Landing Page, too?
> 
> Please let me know if you have any questions. :slightly_smiling_face:
> 
> @Gisselle Jiménez @Whitney Hodges
> **Tina Henares** · 2025-10-15 22:34 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1760567689061679)
> @Christina Hill Hi! Thank you for this feedback :slightly_smiling_face: as I was editing the page I noticed on Funktastic's website that they changed their packages again, so I have updated that in LeadLock as well. Here's how the packages section looks now. Please let me know what you think, thanks!
> 📎 Screenshot 2025-10-15 173108.png (png, saved as `files/F09LS6VPVT4-Screenshot_2025-10-15_173108.png`)
> **Christina Hill** · 2025-10-16 14:30 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1760625054671689)
> This looks great!

**Carmen Cruickshank** · 2025-09-25 16:48 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1758818928909019)
@Whitney Hodges @Jacqueline Hood Hi! I was reviewing Funktastic’s Retargeting Campaign on Meta and noticed that over the last 30 days the overall frequency shows as 4.4. But when I look at the individual ad level it’s closer to 2.6–2.7, and week-to-week it averages around 2.65. Does this mean the creatives really need to be refreshed, or are they still in a good spot?
> **Whitney Hodges** · 2025-09-30 16:36 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1759250200085579)
> @Carmen Cruickshank Hi! Seeing retargeting ads less than 3x per week isn't high, so I think it's fine. However, if you are seeing Link CTR decline or alerts like Creative Fatigue, then it's time to refresh

**Christina Hill** · 2025-09-25 17:32 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1758821561575409)
Update: DJHybrid's domain is in the process of transferring to <http://Gandi.net|Gandi.net>. It now on step 6 out of 7 and is waiting for Wix to verify the transfer. After the transfer is complete, I will start moving the DNS records into Cloudflare and connecting the LeadLock subdomains. Payment updates were needed on the Wix side to complete the transfer, so thankfully, Mike was able to hop on the call with Pamela and me today, and it allowed the process to run more easily. Also, Mike said that he is going to schedule a call with us soon.

cc: @Whitney Hodges @Carmen Cruickshank @Gisselle Jiménez

**Christina Hill** · 2025-09-25 18:39 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1758825574723119)
Hi @Ivy Ayala! Do you have some availability to help me with a LeadLock project for DJ Hybrid? I am setting up an email sequence for them. Design elements can be added later, but setting up the emails is the first step. <https://www.loom.com/share/11f507f322814f6c8d7399d448a209b7?sid=5dc63478-039e-4e13-9e52-6bf24329f774|Here is a video walkthrough on how I set up email templates>. And <https://docs.google.com/document/d/13rlceTpu5j9brHsFmwb5RBgHRcr29RVPdjZHaz1jymw/edit?usp=sharing|here is the link to the approved email copy that we will be using>. Please let me know if this is something you can do. I would love to have this completed by Tuesday, September 30th. If you have any questions for me, please let me know. We can also work on this together sometime on Friday or Monday, if needed. Thanks!

cc: @Gisselle Jiménez @Whitney Hodges
> **Ivy Ayala** · 2025-09-25 20:34 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1758832490154519)
> Hi! wow sounds great! I'll check the video tomorrow and drop you a message if I have any questions. @Christina Hill
> **Ivy Ayala** · 2025-09-27 20:16 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1759004187188559)
> Hey cristina! I already saw the video, so I start making these sequences in the leadlock account of DJ hybrid right?
> **Ivy Ayala** · 2025-09-27 20:16 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1759004195394639)
> @Christina Hill
> **Ivy Ayala** · 2025-09-27 20:40 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1759005611521209)
> hi! i already did the emails in the DJ hybrid account, the 5 in the inquiry folder and two in the consultations folder.
> 📎 image.png (png, saved as `files/F09HG7P6RN2-image.png`)
> **Ivy Ayala** · 2025-09-27 20:40 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1759005620759119)
> @Christina Hill @Whitney Hodges
> **Ivy Ayala** · 2025-09-27 20:40 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1759005655508089)
> let me know if they look good, I think we should also put the company logo on top since it has a random image.
> **Christina Hill** · 2025-09-29 16:33 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1759163611433509)
> Thank you @Ivy Ayala. I will take a look at these today. :slightly_smiling_face:
> **Christina Hill** · 2025-10-01 19:07 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1759345674988989)
> Hi @Ivy Ayala, these all looked great! Thank you for your help. I may loop you in on some other LeadLock projects soon, if that is something you are interested in.
> **Ivy Ayala** · 2025-10-01 19:14 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1759346086359239)
> Absolutely! I like doing email marketing aswell @Christina Hill 

**Christina Hill** · 2025-10-01 19:06 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1759345594939149)
Update: DJ Hybrid's domain has been successfully transfered to <http://gandi.net|gandi.net>, it's DNS records are in Clouflare, and its Wix website experienced no downtime. :partying_face: Next steps: Mike has instructions for purcahsing a phone number and then I will begin A2P process.

Delimna: Because the workflows are inside of the Funktastic Account and we are using the subdomain info.djhybrid currently. I think that creating a new subdomain could make the entire process go quicker and smoother. What do you think about me building everything in the DJ Hybrid account with the subdomain <http://lp.djhybridchicago.com|lp.djhybridchicago.com> or <http://go.djhybridchicago.com|go.djhybridchicago.com>? I am also very open to better subdomain suggestions. @Whitney Hodges

cc:@Gisselle Jiménez @Carmen Cruickshank

**Gisselle Jiménez** · 2025-10-02 17:47 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1759427260273909)
@Whitney Hodges @Carmen Cruickshank Hi! Kindly find below the email recap for today's strategy call with Mike and Marisa. Let me know if anything needs to be modified!

Subject: October 2, 2025 | Strategy Call Recap

&gt; Hi Mike and Marisa,
&gt; 
&gt; Thank you for taking the time to meet today!
&gt; 
&gt; I’ve uploaded the recording from our call to your client folder. You can access it here:
&gt;  :open_file_folder:<https://drive.google.com/file/d/1WrwKojWTWnZFG61lPC_XUACv6LZ-ngpB/view?usp=drive_link|Call recording>
&gt; 
&gt; Our team will start working on the following items and will keep you in the loop as we move forward:
&gt; • Reviewing your website pricing display and sharing feedback on adjustments
&gt; • Preparing a proposal for Meta ads for DJ Hybrid
&gt; • Completing your DJ Hybrid LeadLock account setup with A2P registration
&gt; • Updating future reports to include sales call and booking data
&gt; 
&gt; On your side, here are a couple of next steps:
&gt; • Sending over photo and video assets for DJ Hybrid Meta ads.
&gt; • Reviewing the contact information below for web designers, we recommend:
&gt; 
&gt; *Ava and the Bee*
&gt; <mailto:accounts@avaandthebee.com|accounts@avaandthebee.com>
&gt; <https://avaandthebee.com/>
&gt; 
&gt; *Emily Foster*
&gt; <mailto:hello@emilyfostercreative.com|hello@emilyfostercreative.com>
&gt; <http://emilyfostercreative.com|emilyfostercreative.com> 
&gt; 
&gt; We’re so excited to keep building momentum with you and truly appreciate your partnership!
&gt; 
&gt; Warmly,
&gt; Whitney
> **Whitney Hodges** · 2025-10-03 15:05 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1759503930119939)
> @Yulia Burris this call recording would be good for you to check out. You can probably pull out a few quotes/anecdotes. This could tie into the carousel you've been working on and beyond. Thank you!!
> **Whitney Hodges** · 2025-10-03 15:06 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1759503983821879)
> @Yulia Burris just tagged you above then realized you weren't in this channel!

**Whitney Hodges** · 2025-10-02 19:31 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1759433504860789)
@Christina Hill Hi! I'm working on a follow up email to Mike after our call from today. Do they still need to purchase a LeadLock phone number for DJ Hybrid?
> **Christina Hill** · 2025-10-03 15:14 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1759504462148679)
> Yes. I believe He still needs to do this. However I  traveling and will check in LeadLock when I am at my computer around 1pm 
> **Christina Hill** · 2025-10-03 15:14 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1759504481183339)
> @Whitney Hodges 
> **Whitney Hodges** · 2025-10-03 15:20 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1759504820486669)
> @Christina Hill Hi! Based on his email from last night, he's aware he still needs to purchase the phone number but needs some guidance on logging into the DJ Hybrid account
> **Christina Hill** · 2025-10-03 15:24 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1759505042386889)
> Okay! I will make sure I send instructions to him today @Whitney Hodges 
> **Whitney Hodges** · 2025-10-03 15:24 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1759505070684909)
> @Christina Hill thank you so much!! Safe travels
> **Christina Hill** · 2025-10-03 15:50 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1759506632566769)
> Hi @Whitney Hodges I was able to take a quick break from travelling. Mike and Marisa should have the access they need now for DJ Hybrid's LeadLock Account. Mike works quickly, so he will probably purchase the phone number before Monday, and I will submit the A2P early next week.
> **Whitney Hodges** · 2025-10-03 15:59 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1759507194479959)
> @Christina Hill That's great! Tysm! Would we estimate about 2 weeks until DJ Hybrid is fully switched over to their own account? Marisa wants to time layering Meta Ads on accordingly
> **Christina Hill** · 2025-10-03 18:01 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1759514511540459)
> Yes. I believe that 2 weeks is very reasonable. @Whitney Hodges

**Ivy Ayala** · 2025-10-06 00:08 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1759709307015769)
<https://www.canva.com/design/DAG09_cPK4I/L2cSMCn5qIeDt7rSzQADGA/edit?utm_content=DAG09_cPK4I&amp;utm_campaign=designshare&amp;utm_medium=link2&amp;utm_source=sharebutton|Monthly report- September> @Christina Hill @Carmen Cruickshank

**Gisselle Jiménez** · 2025-10-07 18:07 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1759860463761119)
@Christina Hill Mike followed up on his last message about the error he got when trying to purchase a phone number — he included a screenshot and mentioned it happened right after the verification step.

Here’s a quick acknowledgment email you could send if you’re still looking into it:

&gt; Hi Mike,
&gt; 
&gt; Thanks so much for sending this over and for sharing the screenshot. I’ve received your message and am looking into the issue. I’ll follow up shortly once I have an update!
&gt; 
&gt; Best,
&gt; Christina

> **Whitney Hodges** · 2025-10-07 18:09 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1759860566531809)
> @Gisselle Jiménez Since you're familiarizing yourself with LeadLock/GHL, would you be able to look into it?
> **Gisselle Jiménez** · 2025-10-07 18:41 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1759862497756749)
> @Whitney Hodges Sure!
> **Christina Hill** · 2025-10-08 02:19 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1759889947753669)
> Hi @Gisselle Jiménez. I think it has something to do with the verification process Mike had to do for the phone number. It should go through if he tries again :crossed_fingers::skin-tone-4: . I sent him an email asking him to try again.
> **Whitney Hodges** · 2025-10-08 15:31 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1759937480721559)
> @Christina Hill can we purchase the number on Mike's behalf?

**Christina Hill** · 2025-10-16 15:44 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1760629498862089)
Update: I just got off a call with Mike and Marisa. We are all set to put the final tweaks on their new account and start switching everything over. I am going to try and switch them over today. Here are the next steps:

• I am going to make some revisions to their first email and SMS message
• Then the new form will be embedded on their website
• Ads Tracking needs to be tested for the new landing page
• Lastly, Google and Meta Ads will need to send traffic to the new page
Additionally, Marisa and Mike are going to tag the DJ Hybrid leads that are inside the Funktastic Account with the tag "switch over" to let me know that they are ready to be exported and added to the new account. I am waiting on an email from them once this is complete. (side note: we will proabably be doing this in batches)
> **Christina Hill** · 2025-10-16 15:45 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1760629529567269)
> (sorry I forgot to add a tag.) :arrow_up:
> 
> I would like to complete this all today, if possible. @Carmen Cruickshank how does your schedule look for this switch over?
> 
> cc: @Whitney Hodges @Gisselle Jiménez
> **Christina Hill** · 2025-10-16 16:47 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1760633237216779)
> Update: The Website form is embedded on the Home Page.
> **Carmen Cruickshank** · 2025-10-17 16:59 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1760720359053689)
> hi @Christina Hill! My apologies I just saw this message pop up now, is there anything else that needs to be done?
> **Christina Hill** · 2025-10-20 15:57 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1760975867213929)
> Hi @Carmen Cruickshank. No, nothing else except sending ads traffice there for Google and Meta and checking the Meta tracking. The Google tracking should be all set within GTM for the new pages. I think Meta conversion tracking was set up within the Meta Event Manager. If you need me to set anything up in GTM for Meta let me know. :slightly_smiling_face:

**Christina Hill** · 2025-10-16 16:46 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1760633167230929)
<https://docs.google.com/spreadsheets/d/1x3r5NSrkFo9MY1rr1v3fuW4KXq-CYyswRPj5soyZge8/edit?gid=240684129#gid=240684129|DJ Hybrid's Funnel Map> is updated. @Carmen Cruickshank, please let me know if you would like me to add an additional conversion event for Booked Calls, or if you need anything set up for Meta. :slightly_smiling_face:
> **Carmen Cruickshank** · 2025-10-17 16:57 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1760720228140919)
> hi @Christina Hill! Yes, that'd be helpful to have an additional conversion event for booked calls, let me know anything i need to do to help with this!

**Gisselle Jiménez** · 2025-10-16 18:39 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1760639993223349)
@Whitney Hodges Mike's invoice has been updated! He received an email notification about the updated amount for next month's invoice.

**Gisselle Jiménez** · 2025-10-20 20:36 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1760992605217679)
@Whitney Hodges Here is Funktastic's <https://docs.google.com/document/d/1rgsX8MQB1CZmziTVeAmYqg4e-46PmJCEWVzhT63ACxE/edit?tab=t.0|text and email blast draft document> for your review!
> **Whitney Hodges** · 2025-10-21 19:03 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1761073409797599)
> @Gisselle Jiménez thank you! Can you please update the text and email, so they specify that the promo ends October 31? Also, please include the booking link in the doc.
> **Gisselle Jiménez** · 2025-10-21 19:17 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1761074233191569)
> @Whitney Hodges Done! I couldn't find the booking link in that email thread, but found this one in another thread:
> <https://info.funktasticproductions.com/consult-with-mike>
> **Whitney Hodges** · 2025-10-21 19:27 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1761074872066489)
> Can you check their leadlock account please? I don't think Mike likes to be the one to book all the consults. I think Amber takes the majority of them @Gisselle Jiménez
> **Gisselle Jiménez** · 2025-10-21 19:33 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1761075222494419)
> @Whitney Hodges Oh, got it! I found this Funktastic Productions Consult Funnel:
> <https://info.funktasticproductions.com/funktastic-productions-consult>

**Gisselle Jiménez** · 2025-10-27 21:08 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1761599284101349)
Hey @Carmen Cruickshank! Mike’s invoice is due November 7, which will include Meta Ads management. I’ll confirm with you once payment has gone through, so you can start asking them for all of the photo and video assets for ad creatives!
> **Gisselle Jiménez** · 2025-11-10 13:28 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1762781326731769)
> Happy Monday, @Carmen Cruickshank! Confirming Funtastic’s invoice is processed, and we’re set to start Meta Ads management for them! :partying_face:
> **Carmen Cruickshank** · 2025-11-10 16:57 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1762793836311929)
> amazing! thank you ! @Gisselle Jiménez

**Carmen Cruickshank** · 2025-10-28 18:18 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1761675508506269)
okay thank you so much! @Gisselle Jiménez !

**Gisselle Jiménez** · 2025-10-30 13:54 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1761832467915309)
Hey @Christina Hill! Quick nudge on Mike’s note from yesterday regarding the mobile tweaks for Funktastic. Acknowledgement email draft is below if helpful!

&gt; Hi Mike,
&gt; 
&gt; Thank you for the quick feedback and the screenshots! I’ll take care of the mobile updates you mentioned, and we’ll remove the awards on mobile to keep things clean. I’ll share the updated version for your review shortly.
&gt; 
&gt; Best,
&gt; Christina

**Christina Hill** · 2025-10-30 14:29 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1761834589037339)
Thank you!

**Carmen Cruickshank** · 2025-10-30 16:23 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1761841438152979)
Hi @Christina Hill! I will apply the new Funktastic landing page to both Google and Meta ads. What are your thoughts on switching to maximize converisons on Google? Should I switch the landing page and wait a bit before switching the bid strategy? Funktastic has only seen 16 conversions in the past 5 months
> **Christina Hill** · 2025-10-30 19:04 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1761851071648069)
> Hi @Carmen Cruickshank. I think you should switch the bidding strategy to Maximize Conversions when you relaunch the new ads to the landing page :slightly_smiling_face: I think this page is going to do well with increasing their conversion volume.

**Christina Hill** · 2025-10-30 21:37 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1761860268795799)
@Carmen Cruickshank DJ Hybrid Update: Google Ads Conversion Tracking Event is installed for Booked Appointments. I only created the conversion event, but I didn't make any updates to the campaign goals. :white_check_mark:
📎 Screenshot 2025-10-30 at 5.35.38 PM.png (png, saved as `files/F09Q6QVD4NM-Screenshot_2025-10-30_at_5.35.38_PM.png`)

**Christina Hill** · 2025-10-30 21:45 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1761860712225959)
@Carmen Cruickshank Funktastic Productions Update: Google Ads Conversion Tracking Event is installed for Booked Appointments. I only created the conversion event, but I didn't make any updates to the campaign goals. :white_check_mark:
📎 Screenshot 2025-10-30 at 5.44.36 PM.png (png, saved as `files/F09PXFQ415J-Screenshot_2025-10-30_at_5.44.36_PM.png`)

**Carmen Cruickshank** · 2025-10-31 17:18 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1761931116866859)
Thank you! @Christina Hill

**Ivy Ayala** · 2025-11-06 15:27 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1762442870238929)
Hi! @Carmen Cruickshank Here's the <https://www.canva.com/design/DAG37uAXU10/ZSq4Tl3-9cWplHwsTBCqwQ/edit?utm_content=DAG37uAXU10&amp;utm_campaign=designshare&amp;utm_medium=link2&amp;utm_source=sharebutton|Monthly report Oct> We just need to add the pipeline stats (not sure where is that info)

**Carmen Cruickshank** · 2025-11-06 16:39 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1762447154295599)
thank you! @Ivy Ayala

**Carmen Cruickshank** · 2025-11-13 17:39 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1763055543330379)
@Ivy Ayala Hi! I'm sorry for the late notice. Meta Ads for DJ Hybrid are supposed to launch soon (hopefully by mid-next week), if you could help with Client Attraction Ads for DJ Hybrid, I'll try to get you a creatives brief by the morning tomorrow.

**Carmen Cruickshank** · 2025-11-14 18:04 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1763143452560149)
@Ivy Ayala Hi! Here is the creatives brief for the client attraction ads for DJ Hybrid: <https://docs.google.com/document/d/19uzmweO_YTorqihRUVtgGLvlcusLCVfMYyH99d5eTS0/edit?tab=t.0> Let me know if you have an questions
> **Ivy Ayala** · 2025-11-17 01:05 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1763341507417709)
> Hi! here are the <https://drive.google.com/drive/folders/1KNdxQC5NpTJtRZzDzA9ujTKhYTD8fcZP?usp=sharing|creatives> let me know your comments! @Carmen Cruickshank
> **Carmen Cruickshank** · 2025-11-17 17:27 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1763400436299229)
> Thank you @Ivy Ayala! I'll check it out and let you know!

**Carmen Cruickshank** · 2025-11-21 17:04 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1763744690821669)
@Ivy Ayala Hi! Great work on DJ Hybrid's ads. Mike had some feedback on the creatives for DJ Hybrid, some small changes. For Ad 1, he loved it! For Ad 2 he wanted to take out a certain portion of the video where the band/DJ is in the background and it can be replaced with either the band performing or some their promo videos: <https://vimeo.com/1050994661?share=copy&amp;fl=sv&amp;fe=ci> or <https://vimeo.com/1069637673?share=copy&amp;fl=sv&amp;fe=ci> or <https://drive.google.com/file/d/1_hwmfOj1a3WB1VBUJOP23F1sfrLDRxUM/view>. With Ad 3, mik wanted a promo style video instead of the live band. The text overlay for videos 2 and 3 can remain the same, it's just the actual visual and audio he wants to change. Let me know if you have any questions! Thank you so much Ivy
📎 Screenshot 2025-11-21 at 12.00.33 PM.png (png, saved as `files/F09UMJHQJ2G-Screenshot_2025-11-21_at_12.00.33_PM.png`)
> **Ivy Ayala** · 2025-11-24 22:43 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1764024197378209)
> Hey! please check the edits ( the videos are already in the folder)
> **Ivy Ayala** · 2025-11-24 22:43 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1764024201011279)
> @Carmen Cruickshank

**Gisselle Jiménez** · 2025-11-25 14:03 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1764079396613789)
Hi @Christina Hill! For visibility, new email from Mike confirming he'd like the second text to go out a few days after the initial text. Please acknowledge when you can. Thanks!

**Gisselle Jiménez** · 2025-12-03 14:17 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1764771467724649)
Hi, @Christina Hill! New email from Mike about the additional SMS text:

&gt; Hi!!
&gt; I just wanted to show you this for someone who booked a consult but still received a second text:
📎 image.png (png, saved as `files/F0A189T9F1U-image.png`)

**Ivy Ayala** · 2025-12-06 23:20 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1765063241023239)
Hi there! Here's the <https://www.canva.com/design/DAG6xgNujBM/HsyNypFW3Xo14H4yAlsjxw/edit?utm_content=DAG6xgNujBM&amp;utm_campaign=designshare&amp;utm_medium=link2&amp;utm_source=sharebutton|Monthly Report Nov 2025> I haven't been able to add Google's November statistics. I get this error in LeadLock:
📎 image.png (png, saved as `files/F0A24BV1D36-image.png`)

**Ivy Ayala** · 2025-12-06 23:21 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1765063260079959)
@Carmen Cruickshank

**Whitney Hodges** · 2025-12-09 18:32 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1765305154044739)
@Carmen Cruickshank Hi! Have you heard from Mike? I'm just now seeing that he declined the meeting for today

**Carmen Cruickshank** · 2025-12-09 19:20 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1765308001833609)
@Whitney Hodges yes I should have forwarded his email 30+ minutes ago. I just cc'd you on his recent email, he said he can do 4 or 5pm cst, i told him i could do 4pm cst so 5pm my time, does that work for you too?
> **Whitney Hodges** · 2025-12-09 19:25 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1765308343112959)
> @Carmen Cruickshank Unfortunately, I won't be home then, but I'm good with you handling the call solo. I can send you instructions on what you need to walk through with him as far as the DJ Hybrid Meta Ads side of thing. Does that work for you?
> **Carmen Cruickshank** · 2025-12-09 19:27 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1765308473684459)
> Okay that sounds good. Yes instructions would be very helpful, thank you so much!
> **Whitney Hodges** · 2025-12-09 19:37 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1765309073463869)
> @Carmen Cruickshank Ok, <https://www.loom.com/share/11a73eb181f947fda40a949f59d179f1|here's a loom>!
> **Carmen Cruickshank** · 2025-12-09 20:51 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1765313462719239)
> thank you @Whitney Hodges! Very helpful, i'll update you after the call

**Carmen Cruickshank** · 2025-12-09 21:08 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1765314492031959)
@Whitney Hodges to clarify, if i create a new pixel for them in the business manager then do i still need to make one in the event manager? or was the events manager an example for if Mike cant create a new pixel in the business manager
> **Whitney Hodges** · 2025-12-09 21:09 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1765314574674559)
> @Carmen Cruickshank only one pixel for DJ Hybrid is needed. Just an example of a couple ways to go about it in case you run into any road blocks

**Carmen Cruickshank** · 2025-12-09 22:41 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1765320118492349)
@Whitney Hodges Hi! The call went well clarifying everything on ads and they were able to set up the meta ad account as well as the pixel id. The only thin I wasn't able to fully figure out was how to get access from my end on the WIA business portfolio to the DJ Hybrid account. Here is the ad account ID if that helps: *DJ Hybrid Chicago*
ID: <https://business.facebook.com/latest/settings/ad_accounts?business_id=324544761666326&amp;selected_asset_id=6922715135764&amp;selected_asset_type=ad-account#|1182924860483368>
> **Whitney Hodges** · 2025-12-10 17:04 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1765386287202619)
> @Carmen Cruickshank I'm so sorry I forgot to mention this in my video! The last step is for him to assign the new ad account and pixel to us.
> 
> He'll need to go inside his business portfolio, click on partners, click on Wedding Industry Ads. Then click Assign assets. He should then be able to assign the new ad account and pixel to us.
> 
> Can you please ask him to do this and offer to get on another quick zoom call today if he needs help? Apologize for the oversight yesterday.
> 
> Thank you!!
> **Carmen Cruickshank** · 2025-12-10 18:04 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1765389872143889)
> thank you @Whitney Hodges! i sent him the instructions

**Gisselle Jiménez** · 2025-12-10 14:04 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1765375457529819)
Hi @Christina Hill! New email from Mike regarding a template logo on a DJ Hybrid email. A quick acknowledgment when you can would be great!

**Carmen Cruickshank** · 2025-12-12 19:38 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1765568280165709)
hey @Ivy Ayala! I spoke with Funktastic and DJ Hybrid about Meta ad creatives. I don’t have time to send updates today, but on Monday I’ll share the edits they requested for the DJ Hybrid client attraction ads.
For Funktastic Productions, they noted that some of the video clips used in the November creatives were mixed with DJ Hybrid content. To avoid any confusion going forward, I’ll send separate Google Drive folders for each business as a clear reference. Thank you so much for all your work

**Whitney Hodges** · 2025-12-12 20:02 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1765569779686339)
@Carmen Cruickshank Hi! I've assigned the DJ Hybrid ad account and pixel to you. You should now have access!

**Gisselle Jiménez** · 2025-12-16 14:23 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1765895033063539)
Hi, @Christina Hill Just a reminder about Mike's most recent email. A quick acknowledgment when you can would be great!

&gt; Thanks so much!!
&gt; 
&gt; Hey, I've got one more question for you. I got an email from Gandi asking me to renew my domain for <http://funktasticproductions.com|funktasticproductions.com>
&gt; 
&gt; Should I follow these steps through Gandi? I wasn't sure if i should or if everything is on cloudflare now. Let me know! (screen shot attached)
> **Christina Hill** · 2025-12-16 16:29 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1765902543592869)
> Thank You! I will respond now. :slightly_smiling_face:

**Carmen Cruickshank** · 2025-12-16 17:37 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1765906655160929)
@Christina Hill @Jacqueline Hood Hi! I'm just working on getting DJ Hybrid's ad set up on Meta and idk how to set up the proper conversion tracking. Maybe we could set up a call tomorrow Christina or figure this out during office hours Thursday. Let me know, thank you!
> **Christina Hill** · 2025-12-16 18:40 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1765910421279449)
> Hi @Carmen Cruickshank If you want, you can fill out the <https://docs.google.com/spreadsheets/d/1x3r5NSrkFo9MY1rr1v3fuW4KXq-CYyswRPj5soyZge8/edit?gid=240684129#gid=240684129|funnel map> (tab 2 for DJ Hybrid) and I can set up the tracking you need. I would mainly need the Meta Pixel ID filled in at the top of the spreadsheet to get started. If you would like to hop on a call and talk about it tomorrow, I am available at 12:30 pm EST. Let me know :slightly_smiling_face:
> **Carmen Cruickshank** · 2025-12-16 18:55 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1765911316818529)
> okay i'll fill it out and let you know thank you!

**Carmen Cruickshank** · 2025-12-23 14:39 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1766500795377359)
hi! @Ivy Ayala Here is the creatives brief for DJ Hybrid's Conversion Campaign on Meta: <https://docs.google.com/document/d/1M50YgnBd6xiBW02Nqje8sgQDM8Tp1ZQSqVf7CUSAf-4/edit?tab=t.0#heading=h.svnk6mynj7bw> if you have any questions please let me know
> **Ivy Ayala** · 2025-12-28 23:03 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1766963017780029)
> Hi @Carmen Cruickshank! here are the videos <https://drive.google.com/drive/folders/1NRosj6yEQNfpyBy9O8gww3sPPYca5ix5?usp=sharing>
> **Carmen Cruickshank** · 2025-12-29 19:02 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1767034974719869)
> Thank you @Ivy Ayala ! I'll check it out soon

**Whitney Hodges** · 2025-12-23 16:44 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1766508284504209)
@Carmen Cruickshank @Christina Hill Hi! While I was creating a pixel for LUXE Whitening Lounge, I noticed that DJ Hybrid's pixel isn't collecting data. Is it installed on their website?
📎 image.png (png, saved as `files/F0A5DBL4HRA-image.png`)
> **Christina Hill** · 2025-12-23 20:14 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1766520859234849)
> Hi @Whitney Hodges This is what is installed for DJ Hybrid's LeadLock pages. It looks like a different pixel, though. @Carmen Cruickshank, Maybe we are using the wrong one?
> 
> Are there multiple inside of their account? If so, I can quickly swap the ID's out.
> 📎 Screenshot 2025-12-23 at 3.11.15 PM.png (png, saved as `files/F0A57DX4V0V-Screenshot_2025-12-23_at_3.11.15_PM.png`)
> **Whitney Hodges** · 2025-12-23 20:22 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1766521347751809)
> @Christina Hill @Carmen Cruickshank Somehow they have three pixels for DJ Hybrid. Not sure where they all came from, but the first one on the list appears to be tracking data properly, so I think we're ok
> 📎 image.png (png, saved as `files/F0A5PRTEG1X-image.png`)

**Carmen Cruickshank** · 2025-12-23 19:25 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1766517911696059)
@Whitney Hodges Hi! I believe it is sending data, the meta campaign has been tracking landing page views so far and I checked with the Meta Pixel helper on Chrome and it says its connected. There's two pixel's that show up but the one installed for DJ Hybrid is the one that shows it's connected for me on Chrome. Should I look deeper?
📎 Screenshot 2025-12-23 at 2.22.50 PM.png (png, saved as `files/F0A576YE6UD-Screenshot_2025-12-23_at_2.22.50_PM.png`)
📎 Screenshot 2025-12-23 at 2.23.11 PM.png (png, saved as `files/F0A577154PP-Screenshot_2025-12-23_at_2.23.11_PM.png`)
> **Whitney Hodges** · 2025-12-23 19:28 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1766518113986079)
> @Carmen Cruickshank Ok, got it! It looks like the one starting with 152 isn't connected, and that's what I was seeing. I didn't realize they have another pixel
> **Whitney Hodges** · 2025-12-23 19:28 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1766518117311589)
> Thank you!!
> **Carmen Cruickshank** · 2025-12-23 19:30 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1766518216332439)
> @Whitney Hodges Okay good to know, thank you for checking and your welcome!

**Ivy Ayala** · 2026-01-05 22:21 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1767651670043189)
Hi! here's the <https://www.canva.com/design/DAG9ljTJvSU/m0Q6PI5aMsfwDKzzj4sRVw/edit?utm_content=DAG9ljTJvSU&amp;utm_campaign=designshare&amp;utm_medium=link2&amp;utm_source=sharebutton|monthly report DEC 2025>  @Carmen Cruickshank

**Ivy Ayala** · 2026-01-05 22:21 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1767651698865629)
Unable to see google ads data @Carmen Cruickshank
📎 image.png (png, saved as `files/F0A6UNPG0P7-image.png`)

**Carmen Cruickshank** · 2026-01-09 14:30 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1767969008700109)
@Christina Hill @Ivy Ayala hi! Unsure how I add google ads to this too or connect it to GHL to show data, should I just get Google ads screenshot?
> **Christina Hill** · 2026-01-09 14:38 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1767969530642699)
> Hi @Carmen Cruickshank, when you log into their LeadLock Account, click on "reporting" on the left hand size. Then click on "Google Ads" at the top of the screen.
> 
> When you get the screen (this is the one that Ivy uses), it should say "This is sample data. *Click Here* to integrate..." Click the "Click Here," and it should take you to the integrations.
> 
> On the Integrations page, you should see the second card where it says sign in. Please sign in and link your Gmail account (or the Hello Gmail Account) to connect it.
> 
> After it is connected, it should let you select which ad account you want to integrate with the drop-down menu. This should fix the problem.
> 
> Let me know if you run into any issues. :slightly_smiling_face:
> 📎 Screenshot 2026-01-09 at 9.35.46 AM.png (png, saved as `files/F0A7WM6QZ1S-Screenshot_2026-01-09_at_9.35.46_AM.png`)
> **Carmen Cruickshank** · 2026-01-09 16:14 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1767975262885329)
> thank you @Christina Hill! I was trying to connect the google ads account and I am only able to see the Wedding industry ads google ads account and cant see it connected, let me know if these screenshots gives more context
> 📎 Screenshot 2026-01-09 at 10.56.03 AM.png (png, saved as `files/F0A7RRE9XFG-Screenshot_2026-01-09_at_10.56.03_AM.png`)
> 📎 Screenshot 2026-01-09 at 10.58.22 AM.png (png, saved as `files/F0A7RRCAHHU-Screenshot_2026-01-09_at_10.58.22_AM.png`)
> **Carmen Cruickshank** · 2026-01-09 16:15 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1767975304904679)
> i can just do google screenshots in the meantime tho

**Carmen Cruickshank** · 2026-01-23 21:56 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1769205396058639)
Hi @Ivy Ayala! here is the creatives brief for DJ Hybrid retargeting ads for Meta: <https://docs.google.com/document/d/1ch6mn8L2iKhbbwVypnSVAsPEI_YSypTcNRe5KxqeqNI/edit?tab=t.0#heading=h.jzj30jdp2sdw>
> **Ivy Ayala** · 2026-01-29 21:57 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1769723829202849)
> <https://www.canva.com/design/DAG51nX1MEo/2b-HkuQRPdHYS-FIWZn-6Q/edit?utm_content=DAG51nX1MEo&amp;utm_campaign=designshare&amp;utm_medium=link2&amp;utm_source=sharebutton|Creative 1> <https://www.canva.com/design/DAG_1dpBDs4/JxKHruASu1qydMxmuVrNww/edit?utm_content=DAG_1dpBDs4&amp;utm_campaign=designshare&amp;utm_medium=link2&amp;utm_source=sharebutton|Creative 2> <https://www.canva.com/design/DAG_1WdDBlk/goNqwqzd0s30bsxnGd2VXQ/edit?utm_content=DAG_1WdDBlk&amp;utm_campaign=designshare&amp;utm_medium=link2&amp;utm_source=sharebutton|Creative 3> @Carmen Cruickshank
> **Ivy Ayala** · 2026-01-29 21:57 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1769723835728369)
> Let me know your comments!
> **Carmen Cruickshank** · 2026-01-29 22:06 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1769724363627369)
> @Ivy Ayala Thank you! i'll get back to you with any comments:heart:

**Whitney Hodges** · 2026-02-02 19:57 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1770062270810539)
@Carmen Cruickshank DJ Hybrid just DMed us this reel on IG <https://www.instagram.com/reel/DURE2VkAUYq/?igsh=aHk1eGZoY2FuNHA2|https://www.instagram.com/reel/DURE2VkAUYq/?igsh=aHk1eGZoY2FuNHA2>. Maybe they want us to use it as an ad?

**Carmen Cruickshank** · 2026-02-02 21:14 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1770066888931829)
yes that sounds good, I'll look into it @Whitney Hodges

**Whitney Hodges** · 2026-02-04 15:14 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1770218059180499)
@Carmen Cruickshank Hi! Mike wants to meet this week instead of next. I sent him an invite for tomorrow afternoon and included you. Please join if you can, but if not, we'll share the recording, so you can catch up. Thanks!

**Carmen Cruickshank** · 2026-02-04 16:37 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1770223030702689)
@Whitney Hodges that's a good time to meet for me, thanks!

**Ivy Ayala** · 2026-02-05 00:27 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1770251262079859)
Hello! here's the monthly report <https://www.canva.com/design/DAHAZw8Mmms/B524upqCKcLawdWAxd8QcA/edit?utm_content=DAHAZw8Mmms&amp;utm_campaign=designshare&amp;utm_medium=link2&amp;utm_source=sharebutton|Jan 2026>  Pending to add: LEAD &amp; CONVERSION METRICS I was not able to access to this info @Carmen Cruickshank

**Gisselle Jiménez** · 2026-02-06 15:35 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1770392135534239)
Hi, @Carmen Cruickshank! Quick reminder to send Funktastic's recap email for yesterday's strategy call. (cc Whitney) Here is an email recap template you can use to get started, but feel free to modify as needed to fit the context of the call:

<https://docs.google.com/document/d/1X2mKpe9KZKe6cXrEc6OJs7w-NEDovPdeNsHOS9ZMFfQ/edit?tab=t.0|General Post Call Follow-Up Message>

cc: @Whitney Hodges
> **Whitney Hodges** · 2026-02-06 15:41 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1770392490693289)
> @Gisselle Jiménez thanks! It was my meeting room and I forgot to record the call. Is there a Zoom recap you can post here for reference?
> **Whitney Hodges** · 2026-02-06 15:42 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1770392540134739)
> @Carmen Cruickshank can you cancel the meeting with Mike that's on the calendar next week since we met yesterday? Thanks!
> **Gisselle Jiménez** · 2026-02-06 15:46 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1770392804084079)
> @Whitney Hodges Got it! The <https://drive.google.com/file/d/1cVWwISsNnOUYw5rt8_3rLEgcnAmsskxd/view?usp=drive_link|transcript >and <https://docs.google.com/document/d/1BAzCSD2-oYnA-ndPDbC4pc05orMw5w0BT2kELXjTbBI/edit?usp=drive_link|summary> have been uploaded to the <https://drive.google.com/drive/folders/17VGO8q-RBUpC0s-ZL2l19UX32eiP4cLV?usp=drive_link|client's drive>.
> 
> @Carmen Cruickshank Do you have a notetaker that can join all meetings?
> **Carmen Cruickshank** · 2026-02-06 16:00 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1770393622180749)
> @Gisselle Jiménez Yes, ill send them a recap email today, can i do that in the monthly report? @Whitney Hodges
> **Carmen Cruickshank** · 2026-02-06 16:01 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1770393674100499)
> @Whitney Hodges yes I'll cancel it, and @Gisselle Jiménez yes i have a fathom notetaker, i'll make sure to include it in all needed meetings to record

**Carmen Cruickshank** · 2026-02-09 22:03 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1770674582725089)
@Whitney Hodges Hi! I find the halloween ad copy in the conversions section and search up October in leadlock, correct?

**Carmen Cruickshank** · 2026-02-09 22:09 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1770674969435859)
i found it, here is the Valentine's version: <https://docs.google.com/document/d/1Uym3C6_sG8mXT52cN88ICs9Uw58WUcXU7e3-HYp1ifI/edit?usp=sharing>

**Carmen Cruickshank** · 2026-02-09 22:09 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1770674992256509)
i believe i only find the email one, i'm not sure if there's a seperate text version

**Whitney Hodges** · 2026-02-10 19:18 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1770751137354319)
@Carmen Cruickshank Here is the Halloween text
📎 image.png (png, saved as `files/F0AEL4G7PLH-image.png`)

**Whitney Hodges** · 2026-02-10 19:21 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1770751288900869)
@Carmen Cruickshank The email copy looks good! If you can add a version for the SMS copy to the doc, it's good to send off to Mike for approval. I think the plan should be for this to get sent out on Friday. Can you ask Mike if he wants an offer end date? Maybe the 21st or the 28th?
> **Carmen Cruickshank** · 2026-02-10 21:09 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1770757743314969)
> sent! @Whitney Hodges

**Gisselle Jiménez** · 2026-02-12 16:34 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1770914098879919)
Hi, @Carmen Cruickshank! Here is the <https://drive.google.com/file/d/1McoWHue8jcBaffKDyP5pr0xCutYtrUFX/view?usp=drive_link|email and text blast walkthrough> that you can find in our <https://drive.google.com/drive/folders/1gS4dzHrJVWzV0dULAsvaDtndF5SezVXH?usp=drive_link|SOPs folder.> Let me know if you need anything else!
> **Whitney Hodges** · 2026-02-12 17:30 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1770917459374249)
> @Carmen Cruickshank if you could use this to take your best stab at getting the promo set up for Mike, that would be great. Based on his request for it to go out on Monday, the language may need to be slightly adjusted since Valentine's Day will already be over. Happy to help if you run into any questions or get stuck. I can also review before anything actually gets sent out. Thank you!!
> **Carmen Cruickshank** · 2026-02-12 18:11 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1770919865796289)
> okay thank you @Whitney Hodges I'll let you know
> **Whitney Hodges** · 2026-02-16 15:21 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1771255288381939)
> @Carmen Cruickshank Hi! Just checking in on this. Let me know if we need to schedule a quick meeting today to review this together or if you have any questions
> **Carmen Cruickshank** · 2026-02-16 17:56 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1771264562942879)
> @Whitney Hodges Hi! Sorry for the late update, I published the promo this morning at around 10:30 for both SMS and email
> **Whitney Hodges** · 2026-02-16 17:57 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1771264671089029)
> @Carmen Cruickshank Awesome! Thank you!!

**Carmen Cruickshank** · 2026-02-13 18:26 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1771007164864289)
@Ivy Ayala Hi! Mike just asked for the visual to change on this <https://www.canva.com/design/DAG51nX1MEo/2b-HkuQRPdHYS-FIWZn-6Q/edit|creative> for DJ Hybrid because the video is apparently from Funktastic and not DJ Hybrid, my bad. Here is a folder of DJ Hybrid content, not too much to chose form but here is a good variety, simple change let me know if you have any questions: <https://drive.google.com/drive/folders/14u8yCs8BW9jcAd1e4q1ibkRgPqePVKYZ>
> **Ivy Ayala** · 2026-02-19 22:11 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1771539106576409)
> Hi! here's an updated video <https://www.canva.com/design/DAHBziZfnBA/phv64Csulv4k7qD5HoUNFw/edit?utm_content=DAHBziZfnBA&amp;utm_campaign=designshare&amp;utm_medium=link2&amp;utm_source=sharebutton|https://www.canva.com/design/DAHBziZfnBA/phv64Csulv4k7qD5HoUNFw/edit?utm_content=DA[…]m_campaign=designshare&amp;utm_medium=link2&amp;utm_source=sharebutton>
> **Ivy Ayala** · 2026-02-19 22:11 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1771539114663819)
> @Carmen Cruickshank
> **Carmen Cruickshank** · 2026-02-20 16:24 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1771604699633699)
> thank you @Ivy Ayala! great job

**Whitney Hodges** · 2026-02-18 16:58 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1771433905289619)
has renamed the channel from "c_funktasticproductions" to "c_funktasticproductions_djhybrid"

**Carmen Cruickshank** · 2026-02-19 21:54 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1771538094159059)
@Whitney Hodges Hi! I did an audit of the messaging and positioning across the Funktastic and DJ Hybrid landing pages, email, and SMS to identify areas of opportunity for Funktastic.
On the email side specifically, DJ Hybrid’s content feels more readable and clearly positioned as an elevated wedding music experience, while Funktastic’s is more paragraph-heavy and doesn’t stand out as strongly.
I also did a deeper dive into messaging and copy improvements for the landing page. <https://docs.google.com/document/d/1MBvZcHcU-Qr7wlJ9UwFlnco2qNUMb4umX00ttciCiBE/edit?tab=t.0#heading=h.vykizlhq5omg|Here is the summary I put together> to share with Mike to support the web redesign. I’d love your thoughts before I send it over.
> **Whitney Hodges** · 2026-02-24 19:56 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1771963010097189)
> @Carmen Cruickshank Hi! I think this is spot on. What I want to be careful about is the fact that we created the Funktastic email sequence and landing page. What we pull together is only as strong as the foundations that we have to work with, but I do want to be mindful of presenting Mike with a laundry list of shortcomings when it's ultimately our work.
> 
> Is there a way to present this that's more like: these are the areas we've spotted to improve and here's how we'll be implementing them, highlighting that we'll be doing a complimentary refresh of the Funktastic landing page copy and emails.
> 
> So I'm thinking this doc should only be shared internally with Tina, so she can work on a revised page.
> 
> For what we send to Mike, I'd like to frame it differently.
> 
> Let me know what you think. Thanks!!
> **Carmen Cruickshank** · 2026-02-24 20:44 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1771965847286929)
> @Whitney Hodges Yes, totally agree.
> We’ll keep the detailed audit internal for Tina, and for Mike I’ll simplify it so it doesn’t feel like a list of fixes. I’ll narrow it down, suggest a few key improvement areas, and position it as proactive optimization along with a complimentary refresh of the landing page and emails.
> I’ll adjust the messaging with that in mind.

**Gisselle Jiménez** · 2026-03-05 15:21 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1772724110658649)
Hi, @Danielle McGinnis! Just making sure you saw the email we forwarded from Marissa from Funktastic:

&gt; This is a little off topic, but I've asked a couple times so I'm not sure if this can be helped -- for the DJ Hybrid Chicago Account I am getting email notifications for emails I receive. I just found the notifications center and it looks like I actually have 0 email notifications turned on so I'm wondering if you can help me turn this off. It is making my email inbox pretty unmanageable.
Let me know if you need me to forward it again!

**Danielle McGinnis** · 2026-03-05 15:22 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1772724149022039)
@Gisselle Jiménez yes I did and plan to look i to this further today :-)
> **Gisselle Jiménez** · 2026-03-05 15:23 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1772724195003359)
> Awesome, thanks!
> **Danielle McGinnis** · 2026-03-05 19:20 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1772738451065429)
> @Gisselle Jiménez I've responded to Funktasktic. FYI

**Danielle McGinnis** · 2026-03-05 15:22 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1772724161224029)
Thanks for following up!

**Carmen Cruickshank** · 2026-03-11 13:27 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1773235676547009)
@Ivy Ayala Hi! Do we have the monthly report for Funktastic/DJHybrid?
> **Ivy Ayala** · 2026-03-11 15:43 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1773243796247179)
> Hi! sorry about that, here's the report <https://www.canva.com/design/DAHDp0APwyM/Aua99RPJG9sWzyBiScEQ9g/edit?utm_content=DAHDp0APwyM&amp;utm_campaign=designshare&amp;utm_medium=link2&amp;utm_source=sharebutton|https://www.canva.com/design/DAHDp0APwyM/Aua99RPJG9sWzyBiScEQ9g/edit?utm_content=DA[…]m_campaign=designshare&amp;utm_medium=link2&amp;utm_source=sharebutton>
> **Ivy Ayala** · 2026-03-11 15:43 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1773243818553069)
> Pending to add :  LEAD &amp; CONVERSION METRICS  @Carmen Cruickshank
> **Carmen Cruickshank** · 2026-03-11 15:50 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1773244257077649)
> @Ivy Ayala thank you! no worries

**Danielle McGinnis** · 2026-03-11 19:03 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1773255833967179)
@Whitney Hodges Just hopped off Office Hours. Marisa ended up joining and i got her squared away!
> **Whitney Hodges** · 2026-03-11 19:04 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1773255879407509)
> @Danielle McGinnis tysm!!!
> **Danielle McGinnis** · 2026-03-11 19:05 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1773255904592779)
> yw!

**Danielle McGinnis** · 2026-03-25 13:00 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1774443613830889)
Good morning @Carmen Cruickshank! We received a support ticket from Mike at Funktastic Productions yesterday about receiving the following error message in LeadLock. The only installed app I can see is for Google Ads so I want to make sure nothing things reconnected in their account?  I don't see anything that seems to be disconnected, it says 'active' but is there a way you can check when you get am moment so I can reply back to Mike? Thanks so much!
📎 Screenshot 2026-03-24 at 9.05.14 PM.png (png, saved as `files/F0ANGAACKMZ-Screenshot_2026-03-24_at_9.05.14_PM.png`)
> **Carmen Cruickshank** · 2026-03-27 20:13 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1774642430844009)
> @Danielle McGinnis Hi! Sorry for the late response, checking this now
> **Carmen Cruickshank** · 2026-03-27 20:27 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1774643225889939)
> @Danielle McGinnis I saw the google ads account wasn't connected to Mike's funktastic leadlock account but i made sure its integrated now with his google ads account. let me know if theres anything else you need!
> 📎 Screenshot 2026-03-27 at 4.25.17 PM.png (png, saved as `files/F0APHBYQCHJ-Screenshot_2026-03-27_at_4.25.17_PM.png`)

**Carmen Cruickshank** · 2026-03-27 20:15 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1774642548353079)
@Jacqueline Hood Hi! Thank you for suggestions to improve ad copy to improve CPL, so far with the change made in the past 48 hours, we got leads at $12-13! (ss of Dj Hybrid results)
📎 Screenshot 2026-03-27 at 4.12.35 PM.png (png, saved as `files/F0APBKVNN22-Screenshot_2026-03-27_at_4.12.35_PM.png`)

**Jacqueline Hood** · 2026-03-27 21:27 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1774646835390559)
oh my gosh, that's amazing!! Woohoo!

Great job on the new copy!1

**Danielle McGinnis** · 2026-04-03 18:51 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1775242280516519)
@Carmen Cruickshank Happy Friday! Please forgive me but Mike reached out again bc he's still getting an alert in his LeadLock account for Funktasktic.  Something is definitely up with their Google Ads account.  It looks like an authentication failure? Can. you take another look? :pray::skin-tone-4:
📎 Screenshot 2026-04-03 at 2.49.18 PM.png (png, saved as `files/F0AQPNEHP6Z-Screenshot_2026-04-03_at_2.49.18_PM.png`)

**Ivy Ayala** · 2026-04-06 22:04 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1775513099483469)
Hi team! Here's the monthly report MARCH 2026 <https://canva.link/kazlt8f4a7nxo8t>
> **Ivy Ayala** · 2026-04-06 22:21 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1775514074216289)
> I'm a little unsure about how to organize the information on  DJ hybrid , so I'd love to hear your suggestions!
> **Ivy Ayala** · 2026-04-06 22:21 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1775514078916419)
> @Carmen Cruickshank
> **Carmen Cruickshank** · 2026-04-10 20:16 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1775852173685159)
> we could just do a side by side of funktsatic vs dj hyrbid with each slide we track if that makes sense
> **Carmen Cruickshank** · 2026-04-10 20:16 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1775852185819519)
> so this doesnt have dj hybrid data right now? just checked by making sure
> **Ivy Ayala** · 2026-04-10 21:18 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1775855929586649)
> I've added more slides from DJ Hybrid. The name “Funktastic” or “DJ Hybrid” appears in the left corner so you can tell the difference.  @Carmen Cruickshank

**Ivy Ayala** · 2026-04-06 22:05 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1775513103025219)
@Carmen Cruickshank

**Gisselle Jiménez** · 2026-04-13 14:33 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1776090812447879)
Hi, @Danielle McGinnis Happy Monday! Were you able to reach out to Mike about the intergation alert and or GHL support?

**Danielle McGinnis** · 2026-04-13 17:30 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1776101458112879)
@Gisselle Jiménez will do so today!

**Danielle McGinnis** · 2026-04-13 18:21 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1776104476918729)
@Gisselle Jiménez I found the issue responded to Marissa!

**Gisselle Jiménez** · 2026-04-27 20:55 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1777323336244789)
@Whitney Hodges @Danielle McGinnis @Carmen Cruickshank Hi! Can you confirm which contact forms need to be shared with Emily? Not sure which ones are active especially for DJ Hybrid:
📎 image.png (png, saved as `files/F0B072HAU58-image.png`)
📎 image.png (png, saved as `files/F0B0AKWC6AG-image.png`)
> **Whitney Hodges** · 2026-04-27 21:01 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1777323665424979)
> @Gisselle Jiménez can you look at the submissions history of the forms to see which are currently in use? Pretty sure it would be the funktastic website form from July and the Dj hybrid website form inside the Dj hybrid subaccount
> **Gisselle Jiménez** · 2026-04-27 21:02 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1777323758904959)
> @Whitney Hodges Will do! So we are only sending the website inquiry forms?
> **Whitney Hodges** · 2026-04-27 21:03 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1777323822025279)
> @Gisselle Jiménez correct!
> **Gisselle Jiménez** · 2026-04-28 13:32 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1777383152088929)
> Morning @Whitney Hodges! I have the forms with both having recent submissions! Before sending I want to confirm these settings, or if I should ask Emily in the email:
> 📎 image.png (png, saved as `files/F0B0AF4KK6J-image.png`)
> **Whitney Hodges** · 2026-04-28 13:36 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1777383371755179)
> @Gisselle Jiménez those settings should be fine!

**daniela** · 2026-04-29 16:15 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1777479328582349)
Hi @Danielle McGinnis! I met with Mike last week (for a market research/feedback call) - he was very complimentary, and really loves LeadLock!

On the call, he mentioned needing support in creating a zap between GHL and their CRM once the client is "won" to bring that contact info into their CRM (I want to say they are using Dubsado, but don't quote me on that).

I wanted to get this on your radar - would you please send Mike an invitation to your next office hours to look into creating that zap together? Thank you so much!

cc: @Whitney Hodges

**Danielle McGinnis** · 2026-04-29 18:22 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1777486950111069)
Sure thing @daniela !

**Ivy Ayala** · 2026-05-08 21:41 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1778276503955329)
Hi team! Here's the monthly report APR  2026  @Carmen Cruickshank <https://canva.link/wdy4ks9mlbpaj7x>

**Carmen Cruickshank** · 2026-05-13 19:01 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1778698871240279)
report sent!

**Gisselle Jiménez** · 2026-05-29 14:50 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1780066249221949)
Hi, @Carmen Cruickshank! Quick reminder to reply to Mike's latest email:
&gt; Hey Carmen! 
&gt; 
&gt; Just a heads up I put up a new wedding album for DJ Hybrid! It's in this folder
&gt; 
&gt; <https://drive.google.com/drive/folders/1Lj-PhBN-zj3HF9lsZZab3XLN5VS9ULqB?usp=sharing>
&gt; (DJ hybrid photos -&gt; wedding album google doc)
&gt; 
&gt; Also, I've been trying to get everything on Youtube too (some might be under "shorts"
&gt; 
&gt; <https://www.youtube.com/@Djhybridchicago>
&gt; 
&gt; <https://www.youtube.com/@funktasticproductions>
&gt; 
&gt; I think that this one in particular is amazing for a ceremony
&gt; <https://www.youtube.com/watch?v=4C6_9HmGfIA>

**Gisselle Jiménez** · 2026-06-01 17:09 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1780333787777389)
Hi! The following tasks are currently overdue for this project. Please update, complete, or let us know if you need anything adjusted:

• Acknowledge Mike's email on new assets (@Carmen Cruickshank)
Thank you!

**Tina Henares** · 2026-06-05 12:32 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1780662767195999)
Good morning @Carmen Cruickshank! Here is the monthly report for Funktastic / DJ Hybrid. Thanks!
<https://www.canva.com/design/DAHLhhnUtWM/n2McghCDjj2ywkHYD14NMg/edit>

**Whitney Hodges** · 2026-06-09 20:11 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1781035865472679)
@Carmen Cruickshank DJ Hybrid just sent an IG DM saying this would be a great potential image for ads! <https://www.instagram.com/p/DZV38q1gW5i/?igsh=MWR5N21rZnEwNno3Mw==|https://www.instagram.com/p/DZV38q1gW5i/?igsh=MWR5N21rZnEwNno3Mw==>

**Whitney Hodges** · 2026-06-09 20:27 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1781036864449809)
@Carmen Cruickshank And Funktastic DMed me this: <https://www.instagram.com/reel/DZDn1ThJiEV/?igsh=OXJpYjd4dnFmOHdz|https://www.instagram.com/reel/DZDn1ThJiEV/?igsh=OXJpYjd4dnFmOHdz>

**Whitney Hodges** · 2026-06-11 18:50 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1781203814572109)
@Carmen Cruickshank another reel from DJ Hybrid <https://www.instagram.com/reel/DZdI6tQBhu0/?igsh=ZWJ6ZDJueXVqMHo0|https://www.instagram.com/reel/DZdI6tQBhu0/?igsh=ZWJ6ZDJueXVqMHo0>

**Carmen Cruickshank** · 2026-06-11 21:45 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1781214304637259)
awesome thank you so much! @Whitney Hodges

**Carmen Cruickshank** · 2026-06-12 16:11 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1781280674603169)
report sent!

**Gisselle Jiménez** · 2026-06-15 20:38 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1781555886594659)
Hi, @Carmen Cruickshank! Just making sure you saw Mike's last email, as we would need to pull that LeadLock data on booked clients for Funktastic/The DJ Hybrid before the call with him tomorrow. Thank you!!
> **Carmen Cruickshank** · 2026-06-16 15:03 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1781622202064189)
> replied, thank you! @Gisselle Jiménez

**Whitney Hodges** · 2026-06-16 18:16 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1781633767921219)
@Carmen Cruickshank Hi! That was a great call! When the recording is ready, can you please link it here? I want @Gisselle Jiménez to be able to extract out some social proof.

@Carmen Cruickshank For the market research survey, if you could please <https://members.weddingindustryads.com/courses/products/4b766a56-cd9d-4946-9812-1c4f7f936946/categories/703d664b-bc59-4182-89a5-1b94a35a0803/posts/633e789b-4fa0-4854-9a34-c396e097c92d?source=communities&amp;group_slug=the-vault|check out this recording> if you haven't already, and then draft the questions/answers for Funktastic and DJ Hybrid, that would be great.

@Gisselle Jiménez Can you please drop the Google Drive recording link from that training here, so that Carmen can include it in her recap email to Mike and Marisa?

Thank you both!!

**Carmen Cruickshank** · 2026-06-16 18:21 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1781634118233799)
@Whitney Hodges Hi! yes i'll be sure to get all of this, this is my draft of my recap email, thoughts?: _Hi Mike and Marisa,_

_So great meeting with you today and loved getting to dig into everything. Both Funktastic and DJ Hybrid are showing strong growth and it was exciting to see the numbers._

_Once we get the rebrand assets we'll get everything updated and cohesive across the board. We'll also be putting together market research surveys for both brands to help sharpen targeting going forward. Looking forward to connecting again on July 15th!_
> **Whitney Hodges** · 2026-06-16 19:55 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1781639725290529)
> @Carmen Cruickshank I think you also need to please mention that you'll be pulling the sales numbers from Jan-Apr to send to them and confirm that we'll be including sales numbers in future reports.
> 
> (Please make sure their template is updated accordingly) 
> 
> FYI @Tina Henares @Gisselle Jiménez
> **Gisselle Jiménez** · 2026-07-08 16:40 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1783528822408289)
> @Carmen Cruickshank Hi! Quick reminder to include in the monthly report! :arrow_up:

**Carmen Cruickshank** · 2026-06-16 18:22 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1781634133028029)
and i'll be including the google drive call on market research too correct?

**Gisselle Jiménez** · 2026-06-16 19:26 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1781637964555119)
@Carmen Cruickshank Here it is!

<https://drive.google.com/file/d/1xGZprTzHTQMfv7qRfafNOqutlTxduMIE/view?usp=drive_link|Workshop training>
<https://drive.google.com/file/d/1pICLwhWMF8eUoqh0zXL9ZA3s3VCkJ0Dx/view?usp=drive_link|PDF Resource>
> **Whitney Hodges** · 2026-06-16 19:52 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1781639568095199)
> @Gisselle Jiménez thank you! I updated access for both

**Carmen Cruickshank** · 2026-06-17 19:32 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1781724756272759)
@Whitney Hodges Hi! heres the link to the uploaded call reocrding in Google drive: <https://drive.google.com/drive/u/1/folders/1uqrFUIroQ5WttezplHOvjQFLgHsDq3NA>
> **Gisselle Jiménez** · 2026-09-17 18:20 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1789669203752809)
> Hi @Carmen Cruickshank! I can no longer find this meeting in the drive for some reason. Are you able to go into your zoom account and get the recording by any chance? Thank you!
> **Carmen Cruickshank** · 2026-09-18 19:11 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1789758673303499)
> heres the link: <https://fathom.video/share/56R_mDm5dyT8UmL82u22MaRcrddpNgvu|fathom.video/share/…>
> **Gisselle Jiménez** · 2026-09-18 19:21 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1789759276325509)
> @Carmen Cruickshank tsym! Could you please share the video or reupload it to the drive please? I'm not able to download it from fathom:')
> **Carmen Cruickshank** · 2026-09-18 19:25 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1789759500027519)
> oh ok
> **Carmen Cruickshank** · 2026-09-18 19:31 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1789759912979149)
> uploaded!

**Carmen Cruickshank** · 2026-06-23 19:32 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1782243157977429)
@Whitney Hodges Hi! heres the doc with the market research questions I came up with, let me know your thoughts! <https://docs.google.com/document/d/139zOs1kvI47UCxQKsT6i15-q0JnE3OqpDAK-ldFNyGM/edit?tab=t.0>
> **Whitney Hodges** · 2026-06-24 16:15 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1782317701219039)
> @Carmen Cruickshank Great job!!! I made some minor edits. This is good to send. You can piggyback off of the email I just sent to Mike with the link to the training. Thank you!!
> **Carmen Cruickshank** · 2026-06-24 16:35 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1782318924241139)
> sent! @Whitney Hodges

**Carmen Cruickshank** · 2026-06-25 15:52 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1782402721898449)
@Jacqueline Hood Hi! Here's the draft I created to send to mike and marisa for DJ Hybrid landing page changes, let me know your thoughts!: _Hi Mike and Marisa,_

_Hope you're both doing well!_ 
_While the new site is being built out, I wanted to share a few smaller tweaks that could help the current landing page perform a little better in the meantime._

_First, the headline. Right now it says "The DJ Experience for Live Music Lovers," which is a little general. Since weddings are the bulk of what comes through this page, leaning into that directly in the headline could help visitors feel like the page was made for them right away. A few options that might work well are "The DJ and Live Music Experience for Your Wedding Day," "Chicago's DJ and Live Music Experience for Weddings," or "Live Music Meets DJ Energy, Made for Your Wedding Day."_

_Second, the hero image. It's a great photo, but it's black and white and doesn't immediately signal wedding. A color photo of DJ Hybrid performing at a real wedding could make that connection faster._

_Third, the section right below the hero jumps into your DJ personas pretty quickly. Adding a short section before that with a wedding photo and a few benefits, like the energy you bring to the dance floor or who you typically work with, could help build trust before someone has to choose a persona._

_These are all small enough that they shouldn't compete with the redesign timeline, if you approve of the edits we will make the changes on your behalf. Would love to hear your thoughts!_

_Best,_
_Carmen_
> **Whitney Hodges** · 2026-06-25 15:54 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1782402895296449)
> @Carmen Cruickshank Can you please make it clear that if they approve, we will make the edits on their behalf?

**Carmen Cruickshank** · 2026-06-30 19:04 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1782846291203379)
@Ivy Ayala Hi! The new creatives look awesome for June, I added both DJ Hybrid and Funktastic's new content to the ideas/notes section of the creative spreadsheet. They have their new content in their Youtube channels which i linked in there. <https://www.youtube.com/@Djhybridchicago>

<https://www.youtube.com/@funktasticproductions>  Just for reference for future new ads!

**Gisselle Jiménez** · 2026-07-02 16:56 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1783011379223209)
Hi, @Tina Henares! Just making sure you have all new brand logos and copy for Funktastic and DJ Hybrid! I have put them all in the new brand assets folder: <https://drive.google.com/drive/folders/1ovpkleW8rHtotQOw1d1AEymskyHfmOen?usp=drive_link|drive.google.com/drive/folders/…?usp=drive_link>
> **Tina Henares** · 2026-07-02 17:23 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1783013013869329)
> @Gisselle Jiménez thank you!
> **Tina Henares** · 2026-07-09 18:42 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1783622576147539)
> @Gisselle Jiménez did Funktastic and DJ Hybrid send over any of these font files for their new branding?
> 📎 Screenshot 2026-07-09 144150.png (png, saved as `files/F0BGD9QG5C1-Screenshot_2026-07-09_144150.png`)
> **Gisselle Jiménez** · 2026-07-09 20:28 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1783628937503939)
> Hi, @Tina Henares! I don't see any fonts but believe we can ask Emily for them. @Whitney Hodges I have drafted an email to Emily about fonts!
> **Tina Henares** · 2026-07-13 14:39 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1783953594018129)
> Thank you @Gisselle Jiménez! I found free trial versions of most of the fonts online to use in the meantime :slightly_smiling_face:
> **Gisselle Jiménez** · 2026-07-13 16:34 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1783960441214649)
> Okay, great! @Tina Henares Are we good to use those then? Or do you still want us to reach out to Emily?
> **Tina Henares** · 2026-07-13 17:09 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1783962556734519)
> @Gisselle Jiménez It might be good to reach out still to make sure they have the commercial license to use those fonts? Let me know what you think / if I'm being overly cautious. From a design perspective though I should have enough to work with :slightly_smiling_face: Thank you!
> **Gisselle Jiménez** · 2026-07-13 19:02 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1783969364436499)
> @Whitney Hodges Draft to Emily is readyy

**Tina Henares** · 2026-07-08 15:48 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1783525707342389)
Hi @Carmen Cruickshank! Here is the monthly report for Funktastic and DJ Hybrid. I swapped out their logos to be the new ones :slightly_smiling_face:
<https://canva.link/cgnjjijj8b0jhgi|canva.link/cgnjjijj8b0jhgi>
> **Carmen Cruickshank** · 2026-07-13 14:57 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1783954628473009)
> report sent!

**Tina Henares** · 2026-07-13 14:40 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1783953644243869)
Hi team! The landing page for Funktastic is ready for review! I'll have the DJ Hybrid one done later today as well. Sorry for the delay!
 <https://info.funktasticproductions.com/lp|info.funktasticproductions.com/lp>

**Tina Henares** · 2026-07-14 00:47 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1783990054043959)
Hi team! Here is the DJ Hybrid landing page with their new branding and copy <https://go.djhybridchicago.com/landing-ads|go.djhybridchicago.com/landing-ads>

**Whitney Hodges** · 2026-07-14 14:07 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1784038023755769)
@Tina Henares Hi! The landing pages are looking good so far. I just viewed on mobile, and I think the DJ Hybrid one could use some more finessing like margins, removing a heading from a template, making sure font color is legible on blue background. Also, near the beginning of the page, "completely" is misspelled.

For Funktastic, there was just one minor thing - a space between a couple of boxes but not between others. Here are a few screenshots of what stood out to me.

Please let me know once these edits are complete and will send this over to the client. Thank you so much!!
📎 Screenshot_20260714-090016.png (png, saved as `files/F0BH562PM7X-Screenshot_20260714-090016.png`)
📎 Screenshot_20260714-090023.png (png, saved as `files/F0BHACCKY7K-Screenshot_20260714-090023.png`)
📎 Screenshot_20260714-090054.png (png, saved as `files/F0BH563QN69-Screenshot_20260714-090054.png`)
📎 Screenshot_20260714-085932.png (png, saved as `files/F0BH284A9NF-Screenshot_20260714-085932.png`)
> **Tina Henares** · 2026-07-14 18:01 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1784052071890979)
> @Whitney Hodges edits are done! Thank you!

**Carmen Cruickshank** · 2026-07-15 17:09 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1784135385442649)
hey @Ivy Ayala! I sent Mike and Marisa the amazing ads you made for the new monthly creatives each month and here is 2 edits they wanted to be made. The ad change for DJ Hybrid is: <https://drive.google.com/file/d/1Q8WeCmW67-VlRVMg2J29XgEdzH5_Co3g/view?usp=sharing|Ad 2>
Do you think we can switch out the clip to get another Sax player in the mix? How about this one? I do love the text you wrote on the ad!!! <https://www.youtube.com/shorts/V9fMU2p7FSA|youtube.com/shorts/…>
Funktastic:
<https://drive.google.com/file/d/1aSv6NUlPga6ui0zTsDutKC5G3VK4Z2D7/view|Ad 2> Instead of that first clip of Aint No Mountain High Enough and audio, I'm wondering if you can almost even take the last part of this video (or whatever will fit) to get that crazy high note at the end haha
<https://www.youtube.com/shorts/JFYt-RrxrvI|youtube.com/shorts/JFYt-RrxrvI>. They also asked "if the text on the creative where it says "Now Booking 2026 and 2027 weddings" - In all of these, can we remove 2026 and just focus on 2027?"
> **Gisselle Jiménez** · 2026-07-20 16:44 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1784565844546509)
> Hi, @Carmen Cruickshank @Ivy Ayala, just checking on progress here. Let me know. Thanks!
> **Ivy Ayala** · 2026-07-21 14:23 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1784643834283269)
> working on it! :
> **Ivy Ayala** · 2026-07-21 16:39 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1784651962623599)
> Hi there! @Carmen Cruickshank <https://drive.google.com/file/d/1lzTiB5oqI22TGbqgapmpkeHy2FQnPW0T/view?usp=sharing|drive.google.com/file/d/…/view?usp=sharing> <https://drive.google.com/file/d/1ugMC2NQcnu_89NIJH8r15dfc0RB-UZU3/view?usp=sharing|drive.google.com/file/d/…/view?usp=sharing>  Here are the two updated videos with the changes. Let me know what you think or if there's anything else you'd like me to adjust. Have a wonderful day!
> **Gisselle Jiménez** · 2026-07-21 17:37 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1784655457613199)
> Thank you, @Ivy Ayala! @Whitney Hodges Should we send this to Mike in the meantime, or wait till Carmen reviews and send them?
> **Carmen Cruickshank** · 2026-07-24 16:47 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1784911630288429)
> checking the ads now!
> **Carmen Cruickshank** · 2026-07-24 17:04 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1784912673815489)
> @Ivy Ayala Hi! great job with the ads! for the first one the only change it'd make it having more wedding works in it so in the first line "Anyone can play music. Not every *wedding* band can fill the dance floor." thats all though, thakn you so much!
> **Ivy Ayala** · 2026-07-24 18:56 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1784919369117069)
> got it! <https://drive.google.com/file/d/1lzTiB5oqI22TGbqgapmpkeHy2FQnPW0T/view?usp=sharing|drive.google.com/file/d/…/view?usp=sharing> I just added more wedding videos @Carmen Cruickshank

**Carmen Cruickshank** · 2026-07-15 17:10 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1784135438241509)
please let me know if you have any questions!

**Whitney Hodges** · 2026-07-15 17:35 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1784136928149949)
@Tina Henares Hi! Mike and Marisa love the new landing pages! Could you please make sure that all other pages like thank you pages, consultation pages, etc. are updated to reflect the new branding if they haven't been already?

Same thing goes for the email sequences. They'd like for these to reflect the new branding and new copy, where needed.

Thank you!!

**Whitney Hodges** · 2026-07-15 17:37 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1784137022834209)
@Gisselle Jiménez Market research surveys have been approved by Mike and Marisa. Can you please build these in their LeadLock accounts? <https://docs.google.com/document/d/139zOs1kvI47UCxQKsT6i15-q0JnE3OqpDAK-ldFNyGM/edit?tab=t.0|docs.google.com/document/d/139zOs1kvI47…/edit?tab=t.0>
> **Gisselle Jiménez** · 2026-07-15 18:18 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1784139499119849)
> @Whitney Hodges Will do!
> 
> Side question, will you keep being the organizer in the recurring monthly meetings and should Carmen send recap email?
> **Whitney Hodges** · 2026-07-15 18:19 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1784139565384769)
> @Gisselle Jiménez Yes, please
> **Gisselle Jiménez** · 2026-07-15 18:30 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1784140206032329)
> @Whitney Hodges I don't see a recording for Funktastic's strategy call:face_holding_back_tears:
> 
> @Carmen Cruickshank Was your fathom recording? I have set up tasks to upload it to the client folder and send the email recap to the client. You can find the template in the tasks description! Let me know if you need anything:)
> **Whitney Hodges** · 2026-07-15 18:30 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1784140244677999)
> Carmen's fathom was in the room
> **Carmen Cruickshank** · 2026-07-15 18:44 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1784141092564529)
> @Gisselle Jiménez Yes i'll get to it

**Gisselle Jiménez** · 2026-07-16 21:26 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1784237211584089)
Hi, @Tina Henares! Making sure you saw Emily's last email:

Here are the custom fonts for Brookleigh and Cristalle:
<https://drive.google.com/drive/folders/1VedYwPcV_8W5CPAj-Te1Bz2mjBvNXACm?usp=drive_link|drive.google.com/drive/folders/…?usp=drive_link>

Reem Kufi and Mulish are free Google fonts that you can find here:
<https://fonts.google.com/specimen/Mulish|fonts.google.com/specimen/Mulish>
<https://fonts.google.com/specimen/Reem+Kufi|fonts.google.com/specimen/Reem+Kufi>

Let me know if you need anything else!
> **Tina Henares** · 2026-07-17 14:05 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1784297147644589)
> @Gisselle Jiménez thank you so much! 

**Gisselle Jiménez** · 2026-07-17 20:07 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1784318861945679)
Hi, @Whitney Hodges! Quick update on surveys! Funktastic is almost ready for review, but for some reason the checklist field isn't working. Hopefully is just some glitch, so I'll retry later. I'll start  working on the DJ Hybrid one in the meantime

<https://info.funktasticproductions.com/market-research-survey|info.funktasticproductions.com/market-research-survey>

**Gisselle Jiménez** · 2026-07-21 17:23 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1784654604323069)
@Tina Henares @Ivy Ayala Hi! Mike reached out asking about this Google Drive folder he had been using to store photos and videos for their Meta ads.
<https://drive.google.com/drive/folders/1Lj-PhBN-zj3HF9lsZZab3XLN5VS9ULqB?usp=sharing|drive.google.com/drive/folders/…?usp=sharing>

It seems the content is no longer there, and he's wondering if it may have been moved. I checked the brand assets folder and couldn't find anything on my end. Since Carmen is OOO, I wanted to check with you both. Do you know anything about this, or what's the folder we've been using?

**Ivy Ayala** · 2026-07-21 17:25 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1784654727094779)
<https://drive.google.com/drive/folders/1yCoGs-O_BhSGbhUai61xYByIgeQhhPbB?usp=sharing|drive.google.com/drive/folders/…?usp=sharing> Hi! Yes, I have this one @Gisselle Jiménez
> **Gisselle Jiménez** · 2026-07-21 17:44 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1784655880908459)
> Thank you, @Ivy Ayala! I think he's referring to an album where we was adding photos and videos for us to use in ads. Do we have a folder like that?
> 
> cc: @Tina Henares
> **Ivy Ayala** · 2026-07-21 17:51 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1784656312363119)
> <https://drive.google.com/drive/folders/11O5rBbmnvSzJ1GvLrs07a5vU2hwUMnK9?usp=sharing|drive.google.com/drive/folders/…?usp=sharing>
> **Ivy Ayala** · 2026-07-21 17:52 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1784656337427069)
> <https://drive.google.com/drive/folders/1mh3NBkJfxuqOeHwT5-6ZjIPypZQlJeY2?usp=sharing|drive.google.com/drive/folders/…?usp=sharing>
> **Ivy Ayala** · 2026-07-21 17:52 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1784656369108439)
> Ahhh, okay, I found these @Gisselle Jiménez
> **Gisselle Jiménez** · 2026-07-22 17:12 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1784740344567259)
> @Ivy Ayala Thak you!

**Ivy Ayala** · 2026-07-21 17:26 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1784654762613219)
&amp; you can find more here: <https://docs.google.com/spreadsheets/d/1MTLSfEDHs8Gv9WEqhk2h1IGdxD4zL6fIP-IOtXyAbHg/edit?usp=sharing|docs.google.com/spreadsheets/d/1MTLSfEDHs8G…/edit?usp=sharing>

**Gisselle Jiménez** · 2026-07-22 17:55 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1784742906330589)
@Whitney Hodges Both surveys have been tested and are ready for review! (I'll start working on Jill's)

<https://info.funktasticproductions.com/market-research-survey|info.funktasticproductions.com/market-research-survey>
<https://go.djhybridchicago.com/market-research-survey|go.djhybridchicago.com/market-research-survey>

**Tina Henares** · 2026-07-22 18:21 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1784744512765129)
@Whitney Hodges @Gisselle Jiménez @Carmen Cruickshank Confirming that the Funktastic + DJ Hybrid email sequences have been updated in LeadLock to reflect their new branding and are ready for review!
> **Gisselle Jiménez** · 2026-07-28 15:45 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1785253526217849)
> @Whitney Hodges This has been reviewed and email has been drafted! I only didn't see a post-consult workflow for DJ Hybrid

**Gisselle Jiménez** · 2026-07-28 15:30 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1785252612737329)
Hi, @Carmen Cruickshank!

Here's the email to share market research surveys with Mike and Marissa:

&gt; Hi Mike and Marisa,
&gt; 
&gt; Your market research surveys for Funktastic and DJ Hybrid are ready to go!
&gt; 
&gt; *Funktastic:* <https://info.funktasticproductions.com/market-research-survey|info.funktasticproductions.com/market-research-survey>
&gt; *DJ Hybrid:* <https://go.djhybridchicago.com/market-research-survey|go.djhybridchicago.com/market-research-survey>
&gt; 
&gt; They're set up so responses come directly to you, and we'll receive a copy as well. Feel free to test them out, and once you're happy with everything, you can start sending them to new clients as they book.
&gt; 
&gt; Let me know if you'd like to make any adjustments or if any questions come up!
&gt; 
&gt; Best,
&gt; Carmen
cc: @Whitney Hodges
> **Carmen Cruickshank** · 2026-07-28 16:12 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1785255143866929)
> sent! @Gisselle Jiménez @Whitney Hodges

**Carmen Cruickshank** · 2026-07-28 18:09 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1785262169584399)
@Ivy Ayala Hi! How can i turn this into a still image ad (carousel) and not video:<https://www.canva.com/design/DAHC0HmaQx8/sVJVYowMVaMRS1NZLGWQhQ/edit|canva.com/design/…/sVJVYowMVaMRS1NZLGWQhQ/edit> only asking because as im trying to download it its downloading as a video and not as a carousel
> **Carmen Cruickshank** · 2026-07-28 18:14 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1785262486763329)
> also just wondering if these videos could add the new logos at the end for funktastic and dj hybrid (client requested it). Funktastic one: <https://drive.google.com/file/d/1lzTiB5oqI22TGbqgapmpkeHy2FQnPW0T/view?usp=sharing|drive.google.com/file/d/…/view?usp=sharing> DJ hybrid one: <https://drive.google.com/file/d/1lzTiB5oqI22TGbqgapmpkeHy2FQnPW0T/view?usp=sharing|drive.google.com/file/d/…/view?usp=sharing> let me know if you need the folders that contain the new logo!
> **Ivy Ayala** · 2026-07-29 15:11 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1785337901958799)
> Hi there! so here's the carosuel: <https://drive.google.com/drive/folders/1iN91kLTF1Qf-ZDObMrb8O6anpKs9eZ3w?usp=sharing|drive.google.com/drive/folders/…?usp=sharing>
> **Ivy Ayala** · 2026-07-29 15:13 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1785337989036459)
> &amp; yes! can you please share with me the new logos? @Carmen Cruickshank
> **Ivy Ayala** · 2026-07-29 15:21 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1785338492647609)
> <https://drive.google.com/file/d/16fuVRAH1qqaN1ISgsCygMm_39LkAymU1/view?usp=sharing|drive.google.com/file/d/…/view?usp=sharing>
> **Ivy Ayala** · 2026-07-29 15:22 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1785338542454679)
> I think you pasted the same link from Funktastic into DJ Hybrid.
> **Carmen Cruickshank** · 2026-07-30 18:25 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1785435949285329)
> oh, ill get the other one
> **Carmen Cruickshank** · 2026-07-30 18:28 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1785436096723819)
> heres the DJ Hybrid one: <https://drive.google.com/file/d/1ugMC2NQcnu_89NIJH8r15dfc0RB-UZU3/view|drive.google.com/file/d/…/view>
> **Carmen Cruickshank** · 2026-07-30 18:28 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1785436104074779)
> sorry about that @Ivy Ayala
> **Ivy Ayala** · 2026-07-30 20:08 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1785442084499959)
> <https://drive.google.com/file/d/1xj6ZDSt3Y99Thb1HgtClW3Xhg2DUwwuI/view?usp=sharing|drive.google.com/file/d/…/view?usp=sharing> @Carmen Cruickshank No problem! here's the ad @Gisselle Jiménez
> **Gisselle Jiménez** · 2026-07-31 12:59 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1785502795341619)
> @Ivy Ayala Thank you! @Carmen Cruickshank I believe you have an email thread with Mike to send these with the new logos! We'll just confirm with him in a different email thread that all ads have the new logo now. :raised_hands:
> **Gisselle Jiménez** · 2026-07-31 13:29 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1785504566997669)
> @Whitney Hodges New email drafted to Mike!

**Gisselle Jiménez** · 2026-07-29 14:47 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1785336430512019)
Hi, @Carmen Cruickshank @Ivy Ayala! Just a quick reminder to implement the new logos for Funktastic and DJ Hybrid ads as I believe they're launching tomorrow! Let us know once done so we can confirm with Mike. Thanks!!

cc: @Whitney Hodges
> **Ivy Ayala** · 2026-07-29 15:07 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1785337628109419)
> yes! working on it now
> **Ivy Ayala** · 2026-07-29 15:14 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1785338042002239)
> hey! can you pls share with me the new logos? I cant find them @Gisselle Jiménez
> **Gisselle Jiménez** · 2026-07-29 15:15 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1785338110921079)
> @Ivy Ayala ofc! All new branding is in this folder: <https://drive.google.com/drive/folders/1ovpkleW8rHtotQOw1d1AEymskyHfmOen?usp=drive_link|drive.google.com/drive/folders/…?usp=drive_link>
> **Carmen Cruickshank** · 2026-07-30 18:13 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1785435206528829)
> @Ivy Ayala I'm so sorry for the late response, i also put the folders with the new logos in the monthly creatives note section in july just for future reference
> **Gisselle Jiménez** · 2026-07-30 19:53 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1785441222568749)
> @Ivy Ayala @Carmen Cruickshank Has this been completed so we confirm with Mike?
> **Carmen Cruickshank** · 2026-08-03 15:28 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1785770904703839)
> just sent the new ads to mike with the logos @Gisselle Jiménez!

**Gisselle Jiménez** · 2026-07-31 14:02 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1785506539673689)
Hi @Carmen Cruickshank! Wanted to make sure you saw Emily's email about the tracking codes for the new sites. If we can prioritize this, please! I've added the task to ClickUp. Thank you!!
> **Carmen Cruickshank** · 2026-07-31 19:35 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1785526518567789)
> yes ill check it out!

**Gisselle Jiménez** · 2026-07-31 14:09 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1785506992300739)
Funktastic and DJ Hybrid sites are live! They're officially announcing Monday. @Tina Henares Mike loved the branding on the sequences! The only thing he mentioned was they moved from Vimeo to YouTube, so we need to swap out those embedded video links. Also need to update any website URLs in the sequences that changed with the new site launch (Like the pricing link). Let me know if we need any specific new links from Mike. (Clickup task has been added)
> **Tina Henares** · 2026-07-31 22:02 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1785535345910269)
> @Gisselle Jiménez Updated the links! :slightly_smiling_face:
> **Gisselle Jiménez** · 2026-08-04 13:58 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1785851894869839)
> @Tina Henares Thank you!! @Whitney Hodges I checked the sequences and drafted a reply to Mike's last email updating him on the links!

**Whitney Hodges** · 2026-08-04 15:27 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1785857252113509)
@Gisselle Jiménez can you please head up Mike's newsletter request?
> **Gisselle Jiménez** · 2026-08-04 15:48 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1785858495113949)
> Hi, @Whitney Hodges! Of course! Will it be basically drafting an email camapaign?
> **Whitney Hodges** · 2026-08-04 15:54 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1785858883483709)
> @Gisselle Jiménez yes, I think so. I didn't look at the links yet though. Just take a stab at it and lmk if you have questions
> **Gisselle Jiménez** · 2026-08-04 15:55 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1785858901919429)
> Okii, will work on it today
> **Gisselle Jiménez** · 2026-08-05 16:34 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1785947642959039)
> @Whitney Hodges Hi! Here are previews of the newsletters for your review:
> 
> Funktastic: <https://backend.leadconnectorhq.com/emails/schedule/preview/mj0FRsBhHcNFDaJltdHZ/6a725dffa713fe2f41028b0f|backend.leadconnectorhq.com/emails/…/…>
> 
> DJ Hybrid: <https://backend.leadconnectorhq.com/emails/schedule/preview/OhK5iHgR19YiVHrq6rMw/6a725ecc5a16ab45d45f1775|backend.leadconnectorhq.com/emails/schedule/preview/…>
> **Gisselle Jiménez** · 2026-08-05 19:21 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1785957679604319)
> @Whitney Hodges Looks like Mike wants to send tomorrow or Friday. Let me know if they're any edits to be made or if you want me to draft an email sharing them and letting them know they can go in an schedule it or do we do that for them?:eyes:
> **Whitney Hodges** · 2026-08-05 19:41 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1785958861494249)
> @Gisselle Jiménez Thank you!! Please send him an email with the previews and ask if he's good with us scheduling them for Friday
> **Gisselle Jiménez** · 2026-08-05 20:46 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1785962818314339)
> @Whitney Hodges Sent!

**Carmen Cruickshank** · 2026-08-04 16:20 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1785860422310059)
Hi @Ivy Ayala! last little edit request Mike made was to replace the video from this ad: <https://drive.google.com/file/d/1xj6ZDSt3Y99Thb1HgtClW3Xhg2DUwwuI/view?usp=sharing|drive.google.com/file/d/…/view?usp=sharing> with this raw video instead: <https://drive.google.com/file/d/1Y7hH3O39sUp4QCgUuWRigNE0AH-kXGlw/view|drive.google.com/file/d/…/view> (they just dont want the instagram tag in the background, thank you so much!
> **Ivy Ayala** · 2026-08-04 20:48 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1785876539188329)
> <https://drive.google.com/file/d/1SpNGZm4pfGFMcGbXAlTEl3vGiWvFZkrq/view?usp=sharing|drive.google.com/file/d/…/view?usp=sharing> No problem! It looks great! It would be cool if you could send us those more raw videos sometime, because most of the time I get them from social media and they lose quality. @Carmen Cruickshank
> **Carmen Cruickshank** · 2026-08-07 19:42 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1786131743826959)
> @Ivy Ayala thank you! ill try my best with that and yea thats true it is lower quality, thank you for your patience!

**Tina Henares** · 2026-08-06 16:14 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1786032885120999)
Hi @Carmen Cruickshank! Here's Funktastic / DJ Hybrid's monthly report. Thanks!
<https://canva.link/cgnjjijj8b0jhgi|canva.link/…>

**Gisselle Jiménez** · 2026-08-10 19:24 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1786389856557749)
@Whitney Hodges Campaigns have been sent! I had to send 2 different campaigns for the DJ Hybrid one to include the other contacts, which were just 7. I had check the calendar bookings and then went through each contact's conversation as they were not a lot, and did see some were lost or won so I didn't include them.

Seems like they created this calendar around March this year, and have booked 11 people so far by sending them the direct calendar link., so there's no funnel or automation.

Let me know if I should go ahead and at least create and automation, mirroring what we do for inquiries?
> **Whitney Hodges** · 2026-08-10 19:26 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1786389996564159)
> @Gisselle Jiménez I think it would be ideal if someone books that call that it creates a Consult Scheduled opportunity and puts them in the appointment reminders sequence
> **Gisselle Jiménez** · 2026-08-10 19:42 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1786390928414239)
> @Whitney Hodges perfect! Could you please review the email to Mike confirming the campaigns has been sent and explaining all of this:eyes:

**Whitney Hodges** · 2026-08-11 16:37 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1786466246243209)
@Carmen Cruickshank Hi! For Funktastic, I'm not seeing Google Ads UTM parameters pull through for leads from Google. See example in screenshot. Can you please look into this?
📎 image.png (png, saved as `files/F0BP2AUM6VD-image.png`)

**Viktor** · 2026-08-19 12:37 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1787143045438419)
**Call prep — Funktastic / DJ Hybrid Monthly Meeting, today 12:00pm CT** (Mike + Marisa) · @Whitney Hodges @Carmen Cruickshank  1. **Funktastic's new Showit site looks untagged** — a scan of <http://funktasticproductions.com|funktasticproductions.com> finds no GTM, GA4 or Meta pixel; DJ Hybrid's site has all three live. That's the likely root of the missing Google UTMs Whitney flagged on 8/13. 2. **Meta leads down on both accounts** at flat spend (Funktastic 7 vs 11, DJ Hybrid 8 vs 13 prior 30d) — Google went the other way for Funktastic (CPL $89 vs $203). 3. **DJ Hybrid's "Homepage vs Services Page Test" campaign is enabled but has spent $0 / 0 impressions in 30 days** — half the daily budget is parked.  Full brief in thread :point_down:
> **Viktor** · 2026-08-19 12:38 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1787143087870119)
> ### Monthly meeting brief — Funktastic Productions + DJ Hybrid · Wed Aug 19, 12:00pm CT All figures pulled live this morning. Windows: **L30 = Jul 20–Aug 18**, **prior 30 = Jun 20–Jul 19**.  ### 1. What this call has to decide - **Is the tracking on the new sites actually finished?** Carmen sent Emily Foster the IDs on Aug 3 (Funktastic GTM-PMDSTCG5 / pixel 1256846685830972; DJ Hybrid GTM-5CCHCKVL / pixel 2260780051070035). Today's page scan finds GTM + GA4 (G-93D9Q9VXYW) + pixel live on <http://djhybridchicago.com|djhybridchicago.com>, but **nothing on <http://funktasticproductions.com|funktasticproductions.com>**. Worth a Tag Assistant check before the call — a Showit page can load tags oddly — but this lines up exactly with Whitney's 8/13 note that Google UTMs aren't pulling through on Funktastic leads. Ad landing pages themselves (<http://info.funktasticproductions.com/lp|info.funktasticproductions.com/lp>, <http://go.djhybridchicago.com/landing-ads|go.djhybridchicago.com/landing-ads>) are tagged and converting, so ad conversions are safe; what's missing is retargeting audiences + site-side attribution. - **Meta lead volume is sliding on both accounts** while spend holds. Not a cliff, a drift — creative fatigue is the most likely cause, which is why Carmen's 8/18 testimonial-video ask matters. - **Do we redeploy DJ Hybrid's parked test budget?** $16.66/day sitting on a campaign with zero delivery.  ### 2. Performance — L30 vs prior 30  **Funktastic Productions**  | Channel | Spend L30 | Leads L30 | CPL L30 | Spend P30 | Leads P30 | CPL P30 | | --- | --- | --- | --- | --- | --- | --- | | Google Ads | $759.72 | 8.5 | $89.03 | $741.21 | 3.7 | $202.74 | | Meta Ads | $782.08 | 7 | $111.73 | $742.81 | 11 | $67.53 | | **Blended** | **$1,541.80** | **15.5** | **$99.26** | $1,484.02 | 14.7 | $101.08 |  Google detail: 124 clicks / 1,897 impr / CTR 6.54% / CPC $6.13. Every conversion is the **Contact Form** action — clean, no double-counting. One enabled campaign, `Search | Leads | WIA` at $25/day; MTD Aug 1–18 spend $466.11 = **$25.90/day, fully pacing**. Top spend search terms are brand ("funktastic band/chicago", $82 combined, 0 conversions) plus "wedding bands chicago" cluster — brand terms converting at zero is worth a look.  **DJ Hybrid Chicago**  | Channel | Spend L30 | Leads L30 | CPL L30 | Spend P30 | Leads P30 | CPL P30 | | --- | --- | --- | --- | --- | --- | --- | | Google Ads | $522.55 | 8.0 | $65.32 | $461.80 | 12.0 | $38.48 | | Meta Ads | $717.76 | 8 | $89.72 | $680.69 | 13 | $52.36 | | **Blended** | **$1,240.31** | **16** | **$77.52** | $1,142.49 | 25 | $45.70 |  Google detail: 76 clicks / 3,601 impr / CTR 2.11% / CPC $6.88. Conversion mix L30 = 6 Form Submissions + 2 Booked Call (prior: 7 + 5) — the drop is mostly **Booked Calls**. MTD spend $311.66 = $17.31/day against $33.32/day of enabled budget, because the second campaign delivers nothing.  Week-by-week (Meta leads / Google conv): Funktastic 4/2 → 2/0 → 2/3.6 → 0/1.9 → 2/3.0; DJ Hybrid 3/5 → 2/3 → 4/1.5 → 0/0 → 2/2.5. The Aug 3–9 zero-lead week on both is the standout, and it lands right on the site cutover — another reason to confirm tagging.  ### 3. Tracking / config issues - Funktastic site: no GTM / GA4 / pixel detected today (see above). DJ Hybrid site: clean. - Both Google accounts **do** have the account-level final URL suffix set correctly (`utm_source=google&amp;utm_medium=cpc&amp;utm_campaign={campaignid}&amp;...`) and no campaign-level override — so the UTM gap is on the receiving end (site/LeadLock hidden fields), not in Google Ads. - DJ Hybrid `Search | Leads | WIA Homepage vs Services Page Test`: ENABLED, $16.66/day, **0 impressions / $0 in 30 days**. Its ads point at <http://djhybridchicago.com|djhybridchicago.com> (homepage) vs the go. LP. Either fix or pause. - No change events recorded in either Google account in the last 14 days — nobody has touched them since the UTM flag. - The Knot / Wedding Wire bookings on DJ Hybrid's calendar still create **no opportunity** in LeadLock (Gisselle's 8/10 finding) — those contacts fall out of every "active leads" filter. Her offer to mirror the inquiry automation is still awaiting a yes.  ### 4. Open items &amp; owners | Item | Owner | Status | | --- | --- | --- | | Switch to new logos in all ads (ClickUp) | Carmen | Overdue, due 8/14, touched 8/18 | | Testimonial videos for new creative | Mike/Marisa | Asked 8/18, no reply | | Market research survey responses — feedback | Mike/Marisa | Asked 7/9, still open | | New-site tracking codes install + verify | Emily Foster / Carmen | IDs sent 8/3, Funktastic unverified | | Booking-calendar → opportunity automation | Gisselle | Awaiting Whitney's go-ahead | | Monthly report | Carmen | **June 2026 report emailed 8/7; July not sent yet** — expect Mike to ask |  ### 5. Suggested talk track 1. Open with the win they gave us: Mike's 7/14 note — revenue +39.3% YTD, June net income +180.9%. Congratulate on the sites going live (and on baby Marcella). 2. "Two things we want to nail down today": confirm site tags are firing, and get testimonial video so we can refresh Meta creative — tie it directly to the lead dip rather than presenting it as a favor. 3. Google story is genuinely good for Funktastic — CPL more than halved. DJ Hybrid's Google CPL rose because Booked Calls fell; frame as "fewer self-serve bookings, so we're testing the LP path." 4. Ask for the yes on the Knot/Wedding Wire booking automation — it's the fix for contacts vanishing from campaigns. 5. Set the July report date so it doesn't slide again.  ### 6. What I could not verify - **LeadLock (in scope, not connected):** Funktastic and DJ Hybrid sub-accounts aren't linked to Viktor, so opportunity counts, pipeline stages and lead follow-up are unverified — all CRM points above come from Slack/email, not a live pull. - Whether the Funktastic tags are truly absent or just not in the raw HTML — needs 60 seconds in Tag Assistant. - Google conversions for Aug 17–18 may still be lagging; treat the last two days as partial.
> **Whitney Hodges** · 2026-08-19 12:51 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1787143919677059)
> Remind me how I give you access to their LeadLock (GHL) subaccount
> **Viktor** · 2026-08-19 12:52 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1787143976039549)
> Same way you did Ridgefield: add a *new* HighLevel connection and, on the GHL authorize screen, pick the **client sub-account** (location) instead of the agency — one connection per sub-account, so Funktastic and DJ Hybrid are two separate ones. Log into GHL as the right sub-account first so the picker defaults correctly.  [Connect HighLevel](<https://app.viktor.com/integrations/pd:highlevel_oauth?team=d7L4imSKRHPa6Z9A6xyXnG&amp;source_thread_id=L4coks2i6UGrHkV3P8Lh3Q>) — ping me when they're in and I'll verify which location each one landed on and label them.
> **Whitney Hodges** · 2026-08-19 13:31 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1787146295596879)
> I added both of them
> **Viktor** · 2026-08-19 13:35 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1787146512153009)
> Both are live and I verified them — one is **Funktastic Productions**, the other **DJ Hybrid Chicago**, correct locations, read access working. Three things I can already see (last 30 days, live):  - **Funktastic: 37 new opportunities** (41 prior 30) — 20 still in *Inquired*, 11 ConsultComplete, **3 Won**. - **DJ Hybrid: 42 new** (61 prior 30) — **31 sitting in *Inquired*, 5 ConsultScheduled, 0 Won.** That's the follow-up gap, and it lines up with the Knot/Wedding Wire bookings never creating an opportunity. - **Attribution is mostly blank:** source is just `+` on 33 of 37 Funktastic opps and 30 of 42 DJ Hybrid — so LeadLock can't tell you which ads produced them. Same root cause as the missing UTMs. DJ Hybrid at least shows some `googleads`/`ig`/`fb` sources; Funktastic shows almost none, which fits the untagged site.  Also minor: Funktastic's pipeline is literally named "DJ Hybrid Pipeline" — looks like a copy from the DJ Hybrid build. Happy to work these into today's 12pm talk track if useful.
> **Whitney Hodges** · 2026-08-19 13:56 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1787147791505489)
> We used to run DJ Hybrid's leads through the Funktastic subaccount before we created a separate subaccount for DJ Hybrid. That pipeline is old, there shouldn't be any new opportunities flowing through it
> **Viktor** · 2026-08-19 13:57 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1787147838598149)
> You're right, and my "misnamed pipeline" line was wrong — sorry. Funktastic actually has 4 pipelines, and the legacy **DJ Hybrid Pipeline** is dormant: 76 opps, all created Sep–Oct 2025, last touched 2026-02-16, **nothing new**. All 37 of the L30 opps I reported are in **Funktastic Inquiry Pipeline**, so those numbers stand. Corrected in my notes.

**Whitney Hodges** · 2026-08-19 13:56 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1787147770978149)
@Gisselle Jiménez Following up on this note that was sent to Mike last week. Has this been implemented yet?

_While working on the DJ Hybrid send, we noticed some contacts weren't showing up on the active leads list. After digging in, we found this is because those contacts booked through your DJ Hybrid Chicago calendar for The Knot and Wedding Wire, which doesn't have any automation tied to it to create an opportunity when someone books. Since there's no opportunity created, our filter (which requires an open opportunity) wasn't picking them up._
_We went through each of those contacts individually, filtered out anyone lost or won, and sent a second campaign to include the remaining active ones, just 7 in total._
_We can go ahead and set it up so that when someone books through that calendar, it automatically creates an opportunity and enters them into an appointment reminder sequence, similar to what we do for your other inquiries._
> **Gisselle Jiménez** · 2026-08-19 14:25 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1787149536758889)
> @Whitney Hodges It's set up!
> <https://app.leadlockpro.com/v2/location/OhK5iHgR19YiVHrq6rMw/automation/workflow/5c90b646-b57e-4dbd-bccd-6c559b3e3058|app.leadlockpro.com/v2/location/…/…>
> 
> I think we can leave the same appointment emails, right? I can draft an email to Mike confirming
> **Whitney Hodges** · 2026-08-19 15:33 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1787153616656399)
> @Gisselle Jiménez Looks good. No need to draft an email. I'll share this with them on our call today

**Carmen Cruickshank** · 2026-08-20 18:56 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1787252218323309)
@Ivy Ayala Hi! I was wondering if you could help me with switching out the old logos on DJ Hybrid and Funktastic’s ads to now match the new branding. Heres the ones that need to be fixed right now for DJ Hybrid: <https://drive.google.com/file/d/1kdXIH3qFgbqWbKErye1xWmDEMiBNYJcD/view|drive.google.com/file/d/…/view>
<https://www.canva.com/design/DAHQaDdRfoU/fcjm2YbkLMhjRzkKkPJ3ZQ/edit|canva.com/design/DAHQaDdRfoU/…/edit> (just adding the new logo for this one)
And for Funktastic:
<https://www.canva.com/design/DAHQaDjlM1k/UsvJUxS5BTIseXFpNQey5A/edit|canva.com/design/DAHQaDjlM1k/…/edit>
<https://www.canva.com/design/DAHQaJC2_mY/YVsZGadRiCL4gw59IOsBzA/edit|canva.com/design/DAHQaJC2_mY/…/edit>
(just adding the new funktastic logo to these ones)
Here’s the drive folder again with the new logos:
Funktastic: <https://drive.google.com/drive/folders/1ZENZhi342YUTmjsIfh_UrFLA6ZRemAWW|drive.google.com/drive/folders/…>
DJ Hybrid: <https://drive.google.com/drive/folders/1dftpcP7JH-dC5-v3HDouO0IXl7BGQ5H4|drive.google.com/drive/folders/…>
Once that’s done ill upload it into the ads manager :)
Let me know if you have any questions!
Thank you Ivy!

**Ivy Ayala** · 2026-08-24 22:45 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1787611555014439)
yes! working on it

**Ivy Ayala** · 2026-08-24 23:04 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1787612655608699)
Dj H: <https://drive.google.com/drive/folders/1bzgGABB9PwdYrZO22EqyIzpJxwTJt6yj?usp=sharing|drive.google.com/drive/folders/…?usp=sharing>

**Ivy Ayala** · 2026-08-24 23:04 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1787612675874519)
Funktastic: <https://drive.google.com/drive/folders/11iuT3FB21fsAt_3AmxbZDcjCKPoScj-0?usp=sharing|drive.google.com/drive/folders/…?usp=sharing>

**Ivy Ayala** · 2026-08-24 23:05 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1787612701329019)
Hi! I hope you're doing well. Here are the videos with the new logos.
> **Carmen Cruickshank** · 2026-08-25 17:07 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1787677654209249)
> thank you ivy! ill check it out

**Viktor** · 2026-08-26 12:35 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1787747721833609)
**Call prep DELTA — Funktastic / DJ Hybrid Monthly Meeting, today 12:00pm CT** (this is the 8/19 call Mike rescheduled) · @Whitney Hodges @Carmen Cruickshank  1. **Good news to open with: <http://funktasticproductions.com|funktasticproductions.com> is now fully tagged** — GTM-PMDSTCG5, GA4 (G-ETB67NPTEM) and pixel 1256846685830972 all present today. The 8/19 "no tags on the new Funktastic site" flag is resolved. 2. **DJ Hybrid is the problem child now** — Google conversions **5 vs 13** prior 30d (CPL $97.86 vs $38.40), Meta leads 8 vs 11, and LeadLock shows **38 new opportunities vs 61**, 28 stuck in *Inquired*, **0 Won**. 3. **Funktastic is quietly winning** — Google CPL $79.31 vs $206.94, blended CPL flat at ~$93, and **4 Won opportunities in L30 vs 2** prior.  Delta detail in thread :point_down: (Marisa is on parental leave OOO — expect Mike solo)
> **Viktor** · 2026-08-26 12:36 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1787747761497329)
> ### Delta on the Aug 19 brief — monthly meeting, Wed Aug 26, 12:00pm CT Mike asked to reschedule on 8/19 (baby Marcella + family in town) and Whitney moved it to today, so this is the *same* call — below is only what changed, every number re-pulled live this morning. Windows: **L30 = Jul 27–Aug 25**, **prior 30 = Jun 27–Jul 26**. Aug 24–25 conversions may still lag.  ### 1. What changed since the 8/19 brief - **Funktastic site tagging is FIXED.** Today's scan of <http://funktasticproductions.com|funktasticproductions.com> finds GTM-PMDSTCG5, GA4 `G-ETB67NPTEM` and Meta pixel `1256846685830972`. <http://djhybridchicago.com|djhybridchicago.com> still clean (GTM-5CCHCKVL / G-93D9Q9VXYW / pixel 2260780051070035). Worth noting the site GA4 property (`G-ETB67NPTEM`) is *not* the same as the LP's — fine, just know which property you're reporting from. - **LeadLock is now readable** (it was the big "could not verify" last week), so CRM numbers below are live, not hearsay. - **DJ Hybrid Google got worse, not better** — last week's snapshot was 8 conv vs 12; it's now 5 vs 13. - **Logo refresh landed:** Ivy's "Update DJ Hybrid and Funktastic ads with new logos" closed 8/25. Carmen's "Switch to new logos in all ads" is still open (due 8/25) — uploads pending. - **The Knot / Wedding Wire booking → opportunity automation is built** (Gisselle, 8/19). Whitney said she'd share it on the call — that's today.  ### 2. Performance — L30 vs prior 30 (live)  **Funktastic Productions**  | Channel | Spend L30 | Leads L30 | CPL L30 | Spend P30 | Leads P30 | CPL P30 | | --- | --- | --- | --- | --- | --- | --- | | Google Ads | $756.11 | 9.53 | $79.31 | $756.53 | 3.66 | $206.94 | | Meta Ads | $784.99 | 7 | $112.14 | $768.36 | 12 | $64.03 | | **Blended** | **$1,541.10** | **16.5** | **$93.22** | $1,524.89 | 15.7 | $97.40 |  Google: 121 clicks / 1,907 impr / CTR 6.35% / CPC $6.25. **100% of conversions are the *Contact Form* action** — clean comparison, no definition change. One enabled campaign `Search | Leads | WIA` at $25/day; MTD Aug 1–25 = $631.12 = **$25.24/day, pacing perfectly**. Brand terms still burn without converting: "funktastic band" $39.67/0 conv, "funktastic band chicago" $27.62/0, "funktastic chicago" $27.17/0 — ~$95 on people already looking for them. "chicago wedding bands" produced the 1 clean conversion.  **DJ Hybrid Chicago**  | Channel | Spend L30 | Leads L30 | CPL L30 | Spend P30 | Leads P30 | CPL P30 | | --- | --- | --- | --- | --- | --- | --- | | Google Ads | $489.32 | 5 | $97.86 | $499.21 | 13 | $38.40 | | Meta Ads | $727.70 | 8 | $90.96 | $716.71 | 11 | $65.16 | | **Blended** | **$1,217.02** | **13** | **$93.62** | $1,215.92 | 24 | $50.66 |  Google: 81 clicks / 3,691 impr / CTR 2.19% / CPC $6.04. Conversion mix L30 = 3 Form Submissions + 2 Booked Call (prior: 9 + 4) — so the drop is **form fills**, not just bookings. Same spend, half the leads, at a CTR that didn't move: this reads as landing-page/offer, not delivery.  ### 3. CRM — LeadLock (live, first time we can show this) | | New opps L30 | Prior 30 | Won L30 | Sitting in *Inquired* | Source blank | | --- | --- | --- | --- | --- | --- | | Funktastic (Inquiry Pipeline) | 40 | 40 | **4** (vs 2) | 23 | 35 of 40 | | DJ Hybrid (Inquiry) | **38** | **61** | 0 | 28 | 26 of 38 |  Funktastic's volume is flat but conversion to Won doubled. DJ Hybrid lost a third of its opportunity volume and closed none in the window — and `googleads` as a source fell from 8 to 2, which tracks the Google conversion drop. Attribution is still blank on ~2/3 of opps; the Funktastic tag fix should start improving that from here, not retroactively.  ### 4. Tracking / config — still open - `Search | Leads | WIA Homepage vs Services Page Test` (DJ Hybrid): still **ENABLED, $0 spend, 0 impressions in 30 days**, sharing the $16.66/day budget. MTD DJ Hybrid spend $423.45 = **$16.94/day against $33.32/day of enabled budget** — half the stated budget physically cannot be spent. Fix or pause it; it also makes the client's budget math look wrong. - **No change events in either Google account in the last 14 days** — nobody has touched them since the last call. If we promise action today, it needs to actually get made. - Attribution blanks in LeadLock (above).  ### 5. Open items &amp; owners | Item | Owner | Status | | --- | --- | --- | | Switch to new logos in all ads (upload) | Carmen | Open, due 8/25 — creative delivered by Ivy 8/25 | | Testimonial videos for new creative | Mike / Marisa | Asked 8/18, no reply (Marisa OOO) | | Knot/WW booking → opportunity automation | Gisselle (built) | Built 8/19, to be shared with Mike today | | DJ Hybrid parked test campaign | Carmen | Untouched | | Market research survey responses | Mike / Marisa | Asked 7/9, still open | | Monthly report | Carmen | Next recurring due 9/8; I found **no July report email** to Mike in Whitney's mailbox — confirm before the call |  ### 6. Suggested talk track 1. Congratulate on Marcella; note Marisa's OOO and confirm Amber/Emily as interim contacts if anything needs client input. 2. Lead with the two wins: Funktastic Google CPL down ~62% and 4 booked wins in the CRM; site tracking now fully live. 3. Be straight about DJ Hybrid: leads down across Google, Meta *and* the CRM at flat spend. Frame the plan — new-logo creative going up this week, retire or fix the dead test campaign so the full budget delivers, and get testimonial video to break creative fatigue. 4. Show the Knot/Wedding Wire automation as a delivered fix — it's the reason contacts were vanishing from campaigns. 5. Confirm the July report timing so it doesn't slide into the September one.  ### 7. What I could not verify - Whether the July monthly report was ever sent (no email found; Canva link for the prior report was shared in-channel 8/7). - Whether tags on <http://funktasticproductions.com|funktasticproductions.com> are *firing* correctly, not just present — raw HTML only; 60 seconds in Tag Assistant confirms. - Any reply from Mike/Marisa on testimonial videos after 8/18 — nothing in Whitney's mailbox. - GA4 behaviour/traffic data (out of scope for this brief).

**Whitney Hodges** · 2026-08-26 17:20 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1787764842657999)
@Carmen Cruickshank Thanks for the call with them today! Quick reminder in your recap email to include a few questions they can ask of their past couples to help prompt them to record testimonial videos

**Gisselle Jiménez** · 2026-08-31 16:11 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1788192708770609)
Hey @Carmen Cruickshank! Just checking in on the DJ Hybrid video for Mike to see if you were you able to swap out the raw clip without the Instagram tag? Wanted to confirm so we can loop Mike in. Thanks!
> **Carmen Cruickshank** · 2026-08-31 18:41 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1788201684488679)
> i do remember doing that i think 2-3 weeks ago and then publishing the ad, unless somehting else came up recently about that
> **Gisselle Jiménez** · 2026-09-01 13:53 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1788270832807779)
> @Carmen Cruickshank It was from an old email so we should be good:) Did we send it to mike?
> 📎 image.png (png, saved as `files/F0BU1ETK05T-image.png`)
> **Carmen Cruickshank** · 2026-09-02 21:46 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1788385607397809)
> @Gisselle Jiménez Hi! unless i emailed him again about it , ithink i just uploaded it to the ad account

**Tina Henares** · 2026-09-03 15:00 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1788447625523609)
@Carmen Cruickshank Here's the monthly report for Funktastic/DJ Hybrid!
<https://canva.link/cgnjjijj8b0jhgi|canva.link/…>

**Carmen Cruickshank** · 2026-09-05 17:51 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1788630668761219)
report sent!

**Viktor** · 2026-09-16 12:36 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1789562161380379)
**Call prep — Funktastic / DJ Hybrid Monthly Meeting, today 12:00pm CT** (Mike + Marisa) · @Whitney Hodges @Carmen Cruickshank  1. **The two accounts swapped places.** Funktastic Google conversions halved at identical spend (4 vs 8.5, CPL $187.61 vs $88.18) while DJ Hybrid grew CRM volume (49 opps vs 42) and logged its **first Won opportunity ever**. 2. **Funktastic booked 0 Won opportunities in the last 30 days vs 5 the month before** — leads are still coming in (33), they're stalling after the consult. 3. **No change events in either Google account in 14 days** — third monthly call in a row where nothing was touched between meetings. Also a correction to my last two briefs below: DJ Hybrid's "parked" test budget is *shared*, so no money was ever stranded.  Full brief in thread :point_down:
> **Viktor** · 2026-09-16 12:36 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1789562208561439)
> ### Monthly meeting brief — Funktastic Productions + DJ Hybrid · Wed Sep 16, 12:00pm CT Every figure pulled live this morning. Windows: **L30 = Aug 17–Sep 15**, **prior 30 = Jul 18–Aug 16**; CRM windows Aug 17–Sep 16 vs Jul 18–Aug 16. Last 1–2 days of Google conversions may still lag.  ### 1. What this call has to decide - **Funktastic's Google performance broke this month, and it isn't a spend or traffic problem.** Same money ($750.42 vs $752.46), same clicks (122 vs 119), better CTR (6.96%) — but 4 conversions vs 8.5. All conversions in both windows are the single *Contact Form* action, so the definition didn't change. Something on the form/LP path or in query quality is the suspect, not delivery. - **Funktastic's CRM says the bottleneck moved further down the funnel:** 33 new opportunities, 10 already ConsultComplete, but **0 Won vs 5 Won** in the prior 30 days. Volume is fine, closing isn't. Worth asking Mike directly what changed in their follow-up/quoting since Marisa went on leave. - **Where does the next dollar go?** Funktastic is losing 22.2% of impression share to budget and 55.5% to rank; DJ Hybrid loses 29.8% to budget. Both are capped, and DJ Hybrid is currently the cheaper lead. That's a real budget-split conversation, not a metrics recap.  ### 2. Performance — L30 vs prior 30 (live)  **Funktastic Productions**  | Channel | Spend L30 | Leads L30 | CPL L30 | Spend P30 | Leads P30 | CPL P30 | | --- | --- | --- | --- | --- | --- | --- | | Google Ads | $750.42 | 4.0 | **$187.61** | $752.46 | 8.53 | $88.18 | | Meta Ads | $787.98 | 11 | **$71.63** | $771.46 | 9 | $85.72 | | **Blended** | **$1,538.40** | **15** | **$102.56** | $1,523.92 | 17.53 | $86.93 |  Google detail: 122 clicks / 1,753 impr / CTR 6.96% / CPC $6.15. One enabled campaign `Search | Leads | WIA`, Maximize Conversions, $25/day; MTD Sep 1–15 = $403.38 = **$26.89/day, fully pacing**. Meta is the good news here — leads up 9→11 at flat spend, CPL down 16%.  **DJ Hybrid Chicago**  | Channel | Spend L30 | Leads L30 | CPL L30 | Spend P30 | Leads P30 | CPL P30 | | --- | --- | --- | --- | --- | --- | --- | | Google Ads | $500.92 | 7.0 | $71.56 | $505.79 | 9.0 | $56.20 | | Meta Ads | $747.22 | 7 | $106.75 | $719.49 | 8 | $89.94 | | **Blended** | **$1,248.14** | **14** | **$89.15** | $1,225.28 | 17 | $72.08 |  Google detail: 80 clicks / 3,499 impr / CTR 2.29% / CPC $6.26. Conversion mix L30 = **7 Form Submissions, 0 Booked Call** (prior: 6 form + 3 booked call) — form fills are actually up; the self-serve call bookings stopped entirely. MTD $274.65 = $18.31/day.  Meta lead counts above are the `onsite_web_lead` action on each account — the same definition both periods.  ### 3. CRM — LeadLock (live)  | | New opps L30 | Prior 30 | Won L30 | Inquired | ConsultScheduled | ConsultComplete | | --- | --- | --- | --- | --- | --- | --- | | Funktastic (Inquiry Pipeline) | 33 | 40 | **0** (vs 5) | 18 | 4 | 10 | | DJ Hybrid (Inquiry) | **49** | 42 | **1** (vs 0) | 34 | 4 | 9 |  - **Attribution is finally working, partially.** Funktastic now shows 5 opps tagged `google + 22536371986` (the real campaign ID) plus 1 Facebook Ads; DJ Hybrid shows 7 `google + 22551375112` and 8 fb/ig. Still bare `+` on 26 of 33 (FK) and 34 of 49 (DJH), so channel splits from the CRM remain directional only. - Funktastic's 5 google-tagged opps vs 4 Google-reported conversions lines up well — more evidence the Google drop is real demand/quality, not broken tracking. - DJ Hybrid's 34 opps sitting in *Inquired* is the same follow-up backlog we flagged in August; it has grown, not shrunk.  ### 4. Tracking / config - **Correction to my Aug 19 + Aug 26 briefs:** I said DJ Hybrid's dead `Homepage vs Services Page Test` campaign meant half the daily budget "physically cannot be spent." That was wrong — both campaigns point at the **same shared budget** (`14552153207`, $16.66/day), so the main campaign always had access to all of it. MTD delivery is $18.31/day, i.e. spending the full budget. Sorry for the bad number; the campaign is still worth retiring, but for hygiene, not for money. - That test campaign is still ENABLED with **0 impressions / $0 in 30 days and MTD**; its one ad points at `<http://www.djhybridchicago.com|www.djhybridchicago.com>`. - DJ Hybrid's enabled ads in the live campaign point at `<http://www.djhybridchicago.com|www.djhybridchicago.com>` and `<http://go.djhybridchicago.com|go.djhybridchicago.com>` (root), **not** the `/landing-ads` LP Tina built. Worth confirming that's intentional. - Both client sites are fully tagged today: `<http://funktasticproductions.com|funktasticproductions.com>` → GTM-PMDSTCG5 + GA4 G-ETB67NPTEM + pixel 1256846685830972; `<http://djhybridchicago.com|djhybridchicago.com>` → GTM-5CCHCKVL + G-93D9Q9VXYW + pixel 2260780051070035. LPs load their GTM containers. - **Funktastic's conversion setup is noisy:** 13 enabled actions, 8 of them primary — including *YouTube follow-on views*, *Clicks to call* and four Smart-campaign call/direction actions. Only *Contact Form* has produced anything, but any of those firing later would silently distort CPL. DJ Hybrid is clean (2 actions). - **No change events in either Google account in the last 14 days.**  ### 5. Open items &amp; owners  | Item | Owner | Status | | --- | --- | --- | | Recap email + recording upload for today's call | Carmen | Due today (ClickUp) | | August monthly report | Carmen | **Sent Sep 4** — on time, first time in a while | | Next monthly report | Carmen | Due Oct 10 | | New creative round ("If this isn't my wedding", Imagine, collages) | Mike/Marisa | Sent for review Sep 3, no reply found | | Testimonial videos from past couples | Mike/Marisa | Asked Aug 18, still open | | Market research surveys | Mike/Marisa | **Live and producing responses** (latest submission Sep 11) | | DJ Hybrid dead test campaign | Carmen | Untouched since Aug |  ### 6. Suggested talk track 1. Open with what's working: Meta CPL down on Funktastic, DJ Hybrid opportunity volume up 17% with its first booked win, surveys now returning real answers (Cameron's Sep 11 response is a good one to quote back). 2. Be straight on Funktastic Google: half the conversions at the same spend. Say what we're checking (search-term quality, form path, bid strategy) and commit to a specific action this week — nothing has changed in the account in 14 days and Mike may notice. 3. Ask the closing question on Funktastic: 10 consults completed and 0 bookings in 30 days. Their side of that story determines whether we push volume or push quality. 4. Budget: both accounts are capped by budget share. If Mike wants more bookings, the honest lever is a modest Google increase on whichever account we agree is converting — today DJ Hybrid's Google leads cost $71.56 vs Funktastic's $187.61. 5. Close with the testimonial-video ask again, tied to Meta creative fatigue, plus the specific questions to send past couples.  ### 7. What I could not verify - Whether Funktastic's *Contact Form* action is still firing on every real submission — tags are present, but present ≠ firing; 60 seconds in Tag Assistant or a test submit would settle it, and it's the cheapest explanation for the conversion drop. - Any client reply to the Sep 3 creative round or the testimonial-video ask (nothing in Whitney's mailbox). - Why DJ Hybrid's *Booked Call* conversions went to zero — the action is enabled; whether the booking page changed is not something I can see. - CRM stage moves are read from `pipelineStageId`, so "Won" counts reflect what the team actually maintains in LeadLock; ~2/3 of opportunities still carry no source, so please don't attribute those wins to a channel on the call.
> **Carmen Cruickshank** · 2026-09-16 16:56 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1789577805317619)
> is there anything i can fix on the google side
> **Viktor** · 2026-09-16 16:57 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1789577823369419)
> Yes, three quick ones @Carmen Cruickshank:  1. **Funktastic conversion actions** — 8 are set to primary but only *Contact Form* has ever fired. Demote *YouTube follow-on views*, *Clicks to call* and the four Smart-campaign call/direction actions to secondary so Maximize Conversions is only optimizing on real form fills. 2. **Verify Contact Form is still firing** — a test submit / Tag Assistant pass. It's the cheapest explanation for 4 conversions vs 8.5 at identical spend, and worth being able to say on the call that you checked. 3. **DJ Hybrid** — retire `Search | Leads | WIA Homepage vs Services Page Test` (0 impressions in 30 days), and decide whether the live ads should point at `/landing-ads` instead of the homepage + `go.` root.  All read-only on my end — I haven't touched anything in either account.

**Gisselle Jiménez** · 2026-09-16 21:58 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1789595900412669)
Hi @Carmen Cruickshank! Quick reminder to send email recap to Mike &amp; Marissa! Also, were you able to review the ad creatives on the call?
> **Gisselle Jiménez** · 2026-09-16 21:58 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1789595925897349)
> If not, could you please follow up on the recap email? Thank you!
> **Whitney Hodges** · 2026-09-16 23:43 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1789602200250649)
> @Gisselle Jiménez they no-showed us
> **Gisselle Jiménez** · 2026-09-17 14:01 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1789653668693509)
> Oh:face_holding_back_tears:

**Whitney Hodges** · 2026-09-21 16:23 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1790007824734669)
@Gisselle Jiménez Can you please draft a follow up for Mike re: approving creatives?
> **Gisselle Jiménez** · 2026-09-21 16:26 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1790007973779529)
> @Whitney Hodges Oh yes! Email is drafted:)

**Gisselle Jiménez** · 2026-09-23 17:48 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1790185682390879)
@Whitney Hodges @Carmen Cruickshank Workflow is in place to store market research survey responses in <https://docs.google.com/spreadsheets/d/1z9ozScHq4gCIulaaXOG_OiKwBOw5Y4DzIXUjF_rQ7G0/edit?gid=1535287832#gid=1535287832|this spreadsheet>, as well as getting a slack alert in this channel.

@Ivy Ayala FYI for client feedback to use in creatives! We recently got a first submission:raised_hands:

**Gisselle Jiménez** · 2026-09-23 23:05 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1790204742050919)
New Market Research Survey Submission for DJ Hybrid! :tada:

**Gisselle Jiménez** · 2026-09-24 18:11 · [link](https://weddingindustryads.slack.com/archives/C08QND0MU5T/p1790273498217549)
Here's the spreadsheet for DJ hybrid's submissions! <https://docs.google.com/spreadsheets/d/1fjQNYvpMzXkFFrUp6dP_7aLLF6U0XZNhhsYutdiEa2k/edit?gid=1535287832#gid=1535287832|docs.google.com/spreadsheets/d/1fjQNYvpMzXk…/edit?gid=1535287832#gid=1535287832>
