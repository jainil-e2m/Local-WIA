# #googlesearchaccelerator

Private channel · `C09LQ656BPU`
Pulled 2026-09-25 by `corpus/fetch-slack.mjs`.

152 parent messages · 221 thread replies · 21 files downloaded · 26 left in place.
Covers 2025-10-24 → 2026-09-24.

Thread replies are indented with `>`. Every message links back to Slack, so a
candidate drawn from here carries its source the way a transcript quote carries
a timecode.

## Not downloaded — over the 25 MB cap

These stayed in Slack. The link needs the bot token in an `Authorization`
header; a plain browser fetch returns a login page with a 200.

| File | Size | Link |
|---|---|---|
| Google Ads Office Hours - 09.24.26 - Sep 24 2026.mp4 | 135.5 MB | [download](https://files.slack.com/files-pri/T03P5A3L1DK-F0C43V45JNR/download/google_ads_office_hours_-_09.24.26_-_sep_24_2026.mp4) |
| Google Ads Office Hours - 09.10.26 - Sep 10 2026.mp4 | 56.2 MB | [download](https://files.slack.com/files-pri/T03P5A3L1DK-F0C0XJASPRC/download/google_ads_office_hours_-_09.10.26_-_sep_10_2026.mp4) |
| 08.27.26- Google Ads Office Hours - Aug 27 2026.mp4 | 162.2 MB | [download](https://files.slack.com/files-pri/T03P5A3L1DK-F0BT2UBHZ3P/download/08.27.26-_google_ads_office_hours_-_aug_27_2026.mp4) |
| Google Ads Office Hours - Aug 20 2026.mp4 | 80.6 MB | [download](https://files.slack.com/files-pri/T03P5A3L1DK-F0BRK042UJJ/download/google_ads_office_hours_-_aug_20_2026.mp4) |
| Google Ads Office Hours - 08.13.26 - Aug 13 2026.mp4 | 210 MB | [download](https://files.slack.com/files-pri/T03P5A3L1DK-F0BQ4NJ9J01/download/google_ads_office_hours_-_08.13.26_-_aug_13_2026.mp4) |
| Promises 2919 with Tony Google Ads Audit - Jul 20 2026.mp4 | 305.2 MB | [download](https://files.slack.com/files-pri/T03P5A3L1DK-F0BNDFTGW5D/download/promises_2919_with_tony_google_ads_audit_-_jul_20_2026.mp4) |
| Noam - Sunny Entertainment Google Ads Audit - Aug 7 2026.mp4 | 161.7 MB | [download](https://files.slack.com/files-pri/T03P5A3L1DK-F0BNNK1DMBM/download/noam_-_sunny_entertainment_google_ads_audit_-_aug_7_2026.mp4) |
| Google Ads Office Hours - 08.06.26 - Aug 6 2026.mp4 | 136.4 MB | [download](https://files.slack.com/files-pri/T03P5A3L1DK-F0BNDD9QXHV/download/google_ads_office_hours_-_08.06.26_-_aug_6_2026.mp4) |
| Google Ads Office Hours - 07.30.26 - Jul 30 2026.mp4 | 214.7 MB | [download](https://files.slack.com/files-pri/T03P5A3L1DK-F0BLT8FKB7V/download/google_ads_office_hours_-_07.30.26_-_jul_30_2026.mp4) |
| Google Ads Office Hours - 07.16.26 - Jul 16 2026.mp4 | 351.6 MB | [download](https://files.slack.com/files-pri/T03P5A3L1DK-F0BHXL81JE5/download/google_ads_office_hours_-_07.16.26_-_jul_16_2026.mp4) |
| Google Ads Weekly Office Hours - 7.9.26 - Jul 9 2026.mp4 | 123.2 MB | [download](https://files.slack.com/files-pri/T03P5A3L1DK-F0BH5292FDW/download/google_ads_weekly_office_hours_-_7.9.26_-_jul_9_2026.mp4) |
| Google Ads Office Hours - 06.11.26 - Jun 11 2026.mp4 | 261.1 MB | [download](https://files.slack.com/files-pri/T03P5A3L1DK-F0BA2G0ULA0/download/google_ads_office_hours_-_06.11.26_-_jun_11_2026.mp4) |
| Google Ads Office Hours - 06.05.26 - Jun 4 2026.mp4 | 216.1 MB | [download](https://files.slack.com/files-pri/T03P5A3L1DK-F0B9G8TUV3J/download/google_ads_office_hours_-_06.05.26_-_jun_4_2026.mp4) |
| Google Ads Office Hours - 05.20.26 - May 21 2026.mp4 | 292 MB | [download](https://files.slack.com/files-pri/T03P5A3L1DK-F0B57RAJNBV/download/google_ads_office_hours_-_05.20.26_-_may_21_2026.mp4) |
| Google Ads Office Hours - 05.07.26 - May 7 2026.mp4 | 208.5 MB | [download](https://files.slack.com/files-pri/T03P5A3L1DK-F0B2BSDA23U/download/google_ads_office_hours_-_05.07.26_-_may_7_2026.mp4) |
| Google Ads Office Hours - 04.30.26 - Apr 30 2026.mp4 | 201.7 MB | [download](https://files.slack.com/files-pri/T03P5A3L1DK-F0B0S9N0GLB/download/google_ads_office_hours_-_04.30.26_-_apr_30_2026.mp4) |
| Google Ads Office Hours - 04.23.26 - Apr 23 2026.mp4 | 119.7 MB | [download](https://files.slack.com/files-pri/T03P5A3L1DK-F0AUEUEUUDV/download/google_ads_office_hours_-_04.23.26_-_apr_23_2026.mp4) |
| Google Ads Office Hours - 04.16.26 - Apr 16 2026.mp4 | 213.2 MB | [download](https://files.slack.com/files-pri/T03P5A3L1DK-F0ATF3TSVTL/download/google_ads_office_hours_-_04.16.26_-_apr_16_2026.mp4) |
| Google Ads Office Hours - 04.09.26 - Apr 9 2026.mp4 | 304.6 MB | [download](https://files.slack.com/files-pri/T03P5A3L1DK-F0ASBS5GYRX/download/google_ads_office_hours_-_04.09.26_-_apr_9_2026.mp4) |
| Google Ads Office Hours - 04.02.26 - Apr 2 2026.mp4 | 376.4 MB | [download](https://files.slack.com/files-pri/T03P5A3L1DK-F0AREMEP3Q8/download/google_ads_office_hours_-_04.02.26_-_apr_2_2026.mp4) |
| Google Ads Office Hours  - 03.26.26 - Mar 26 2026.mp4 | 135.2 MB | [download](https://files.slack.com/files-pri/T03P5A3L1DK-F0AP0F24B1T/download/google_ads_office_hours___-_03.26.26_-_mar_26_2026.mp4) |
| Impromptu Zoom Meeting - Mar 19 2026.mp4 | 41.4 MB | [download](https://files.slack.com/files-pri/T03P5A3L1DK-F0AMJHCAL11/download/impromptu_zoom_meeting_-_mar_19_2026.mp4) |
| Google Ads Office Hours  - 3.12.26 - Mar 12 2026.mp4 | 85.3 MB | [download](https://files.slack.com/files-pri/T03P5A3L1DK-F0AL2FPGTMH/download/google_ads_office_hours___-_3.12.26_-_mar_12_2026.mp4) |
| Google Ads Office Hours - 3.05.26 - Mar 5 2026.mp4 | 73 MB | [download](https://files.slack.com/files-pri/T03P5A3L1DK-F0AJRN819V3/download/google_ads_office_hours_-_3.05.26_-_mar_5_2026.mp4) |
| Google Ads Office Hours  - 2.12.26 - Feb 12 2026.mp4 | 301.6 MB | [download](https://files.slack.com/files-pri/T03P5A3L1DK-F0AF3JGNHR7/download/google_ads_office_hours___-_2.12.26_-_feb_12_2026.mp4) |
| f5f2cd16d1964a05968ca884b4b0006c.MP4 | 113.3 MB | [download](https://files.slack.com/files-pri/T03P5A3L1DK-F09SB83K6GJ/download/f5f2cd16d1964a05968ca884b4b0006c.mp4) |

---

**Whitney Hodges** · 2025-10-24 02:24 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1761272651170699)
<!channel> We are getting so close to launching our Google Search Accelerator! I'm pumped because I know the momentum we've been building leading up to this is all going to pay off! Thank you all in advance for the final push to get this offer off the ground!!!

Here are our remaining action items:

@Gisselle Jiménez can you please turn this into a doc and help us keep track of progress?

*Marketing*
• @daniela 
    ◦ Finalize landing page design including adding VSL and mobile optimization
    ◦ Live Q&amp;A Funnel
        ▪︎ landing page
        ▪︎ form
        ▪︎ thank you page
        ▪︎ simple email sequence - confirmation, 24 hr reminder, 1 hr reminder
• @Gisselle Jiménez 
    ◦ Discovery call confirmation page design including adding thank you video
    ◦ Discovery call confirmation workflow (I think this may currently be linked to the Google Ads VIP Day application workflow, so language probably needs to be tweaked slightly.) Can you please take a look?
    ◦ Check on Discovery call availability particularly for October 29-31. Open up the 31st for me to take calls, if needed  
• @Whitney Hodges 
    ◦ Email copy
        ▪︎ Announcing Google Search Accelerator (October 28)
        ▪︎ Live Q&amp;A invitations (October 29-November 5)
        ▪︎ Post Discovery Call emails
        ▪︎ Post Q&amp;A emails (November 5-12)
    ◦ IG content plan/copy that mirrors email cadence
    ◦ Revisit Foolproof Follow-Up Advantage launch for additional prompts/content ideas
• @Yulia Burris 
    ◦ Execute on emails and IG posts with Whitney's
    ◦ Edit Google videos from Indy into reels to support launch content
*Sales*
• @Whitney Hodges 
    ◦ Manual outreach via DMs and emails
• @daniela 
    ◦ Update pitch deck for use for the live Q&amp;A session keeping in mind some attendees may have already had a discovery call and seen it. Opportunity to add some testimonials/social proof. Break somewhere in the middle for us to go inside VAULT and give tour
    ◦ Finalize $1497 version of proposal, contract, invoice in Dubsado
• @Gisselle Jiménez
    ◦ Dubsado automation - after contract signed &amp; invoice paid email sent
        ▪︎ Prior to November 3 - confirmation that they're in and invitation will come on November 3
        ▪︎ November 3 onward - confirmation and invitation to VAULT
*Program*
• @Whitney Hodges 
    ◦ Record Welcome/Start Here video
    ◦ Add Google Ads Office Hours to the Events calendar
• @Gisselle Jiménez 
    ◦ Plug Christina's recordings into the appropriate course products
    ◦ Update Meta Ads Immersive thumbnails to include Meta somewhere in the title because some members will have access to both programs, and we want it to be clear. "Share Your Landing Page for Feedback" and "Audit &amp; Adapt" titles can stay as is because they will be available in both courses
    ◦ Create booking calendar for Google Ads VIP Day that gives choice between Carmen's &amp; Christina's availability and requires completion of questionnaire in order to schedule
*Important Dates:*
*October 28* - Sales funnel is live; formal promotions begin; discovery calls open
*November 3* - Course opens inside The VAULT
*November 5* - Live Information Session + Q&amp;A
*November 12* - Introductory Rate of $1497 ends
> **Gisselle Jiménez** · 2025-10-24 14:02 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1761314550967679)
> @Whitney Hodges Exciting! :partying_face: I'll share the document once it's ready.
> **daniela** · 2025-10-24 15:22 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1761319323154169)
> Awesome!! :star-struck: 
> **Gisselle Jiménez** · 2025-10-24 15:51 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1761321098166569)
> @Whitney Hodges @daniela @Yulia Burris
> 
> Here is the tracker! Let me know if this works. :raised_hands:
> 
> <https://docs.google.com/document/d/1FRp5uehiuSQGXzJ8IqWtnuKCy5M2EHyP_oEBfczeINI/edit?tab=t.0>
> **Whitney Hodges** · 2025-10-24 15:54 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1761321263028549)
> @Gisselle Jiménez I think that works: thank you!
> **daniela** · 2025-10-24 16:41 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1761324083901159)
> This is perfect - thanks for helping us stay organized @Gisselle Jiménez!

**daniela** · 2025-10-24 17:26 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1761326791397549)
Hi team! Would love feedback on the GSA sales page if you have any!  URL: <https://weddingindustryads.com/google-search-accelerator>
If someone could please review my mobile edits, I'd appreciate that - there were a few graphics I had to split up so they wouldn't stretch. Thanks!
> **Whitney Hodges** · 2025-10-24 17:39 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1761327575246209)
> @daniela thank you! I just reviewed on mobile. Attached are screenshots of what stood out to me. One graphic was kind of stretched and the spacing of the value stack feels kind of overwhelming as is.
> 
> Also, if you have a chance can you please update the SEO description and thumbnails?
> 
> I'm so excited about this page!!! The video is great
> 📎 Screenshot_20251024-123058.png (png, saved as `files/F09NFC4S5UN-Screenshot_20251024-123058.png`)
> 📎 Screenshot_20251024-123317.png (png, saved as `files/F09NWAZCUE5-Screenshot_20251024-123317.png`)
> **daniela** · 2025-10-24 21:33 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1761341604584789)
> Thanks - super helpful @Whitney Hodges!

**daniela** · 2025-10-24 21:39 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1761341996532519)
Opt-In Funnel for this lives inside the WIA Freebie Funnels (One-Time Use) folder, and it's titled: *WIA Opt-In | Google Search Accelerator - Nov 5, 2025 Live Information Session and Q+A*

First drafts ready for review:
• opt-in / landing page: <https://weddingindustryads.com/gsa-info-session-11-5>
• ty page: <https://weddingindustryads.com/gsa-info-session-confirmed> 
Open to any/all feedback! The only thing driving me nuts is that I can't find where to square off those pesky button corners :zany_face:

I'm still working on the email copy for the reminder (so the workflow has not yet been created - there are no automations currently triggered by this form)
> **Whitney Hodges** · 2025-10-24 21:48 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1761342532591959)
> @daniela These look great! I took a look at the buttons. I think there used to be the option to change the corner radius under the button style, but it looks like that's gone. The only way I could find to change the button shape is to add a different button element. See screenshot
> 
> But honestly, this isn't a big deal for a page that's a short term promo. I changed the buttons to our periwinkle color and think they're fine as is
> 📎 image.png (png, saved as `files/F09NJUY8PJ6-image.png`)
> **daniela** · 2025-10-27 16:44 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1761583477025399)
> Email drafts are <https://docs.google.com/document/d/1dZxRhDW7lW7I-aNgukZKEVufebKENONKffGki-H6llo/edit?usp=sharing|here> - including confirmation/reminder emails, as well as a follow-up sequence. Feel free to edit directly in the doc @Whitney Hodges
> **Whitney Hodges** · 2025-10-27 19:31 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1761593503390099)
> @daniela Thank you for this! I made some edits to the confirmation email but still need to more closely review the others.
> **daniela** · 2025-10-27 21:29 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1761600586427469)
> Sounds good!
> **Whitney Hodges** · 2025-10-27 21:57 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1761602271258759)
> @daniela Hi! I've reviewed/edited all of the confirmation/reminder emails in the doc.
> 
> I can look at the post-Zoom emails later this week.
> 
> Thank you!
> **daniela** · 2025-10-28 13:39 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1761658750750489)
> @Whitney Hodges is Giselle or maybe Christina available to build out the back end workflows/email automations for this opt-in? I'm pretty covered up today and wouldn't be able to get to it until later in the week. Lmk what you think! :heart:
> **Whitney Hodges** · 2025-10-28 13:40 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1761658807986569)
> @daniela yes, we'll figure out a way to get it done. Thanks!
> **daniela** · 2025-10-28 13:40 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1761658820199509)
> Thank you!!!!

**Whitney Hodges** · 2025-10-24 23:04 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1761347043521439)
@daniela Working on promo emails now. Thoughts on giving 10 founding members not only the $1497 introductory rate but 4 or maybe even 5 months of support instead of just 3? Trying to think of how to make this more enticing and create some more urgency
> **daniela** · 2025-10-24 23:51 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1761349874460809)
> I think one extra month of support included is a great bonus! 

**Gisselle Jiménez** · 2025-10-27 17:16 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1761585392578749)
@Whitney Hodges @daniela Google Search Accelerator booking confirmation page for your review!

<https://app.leadlockpro.com/v2/preview/Yqveajx5ANBXmpUxnUYG?notrack=true>
> **daniela** · 2025-10-27 17:20 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1761585601925169)
> Love it! @Gisselle Jiménez  For those who might not watch the video, can we add a quick note in smaller font that says something like:
> 
> _Please check your email for important appointment details. If you don't see us in your main inbox, be sure to check your spam or promotions tab and move us to your primary inbox so that you receive any future resources we share!_
> **Gisselle Jiménez** · 2025-10-27 17:26 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1761585991203029)
> @daniela sounds good! Do you want it at the top as a sub-headline or at the bottom of the video?
> **Gisselle Jiménez** · 2025-10-27 17:27 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1761586043006029)
> Right now, it's added in both places, so you can see how it looks!
> **daniela** · 2025-10-27 17:37 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1761586621149649)
> I think below it is better - thanks for the preview!
> **daniela** · 2025-10-27 17:38 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1761586694542169)
> @Whitney Hodges what are your thoughts around linking straight to the pitch deck from here? If we keep it, maybe we add a small headline there for context - letting them know they can explore it in the meantime
> **Whitney Hodges** · 2025-10-27 19:01 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1761591664347609)
> @Gisselle Jiménez I think it looks great; thank you! @daniela I like the idea of including the pitch deck; it can't hurt!

**Gisselle Jiménez** · 2025-10-27 19:22 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1761592951441819)
@Whitney Hodges<https://app.leadlockpro.com/location/Xi40zxmRvW8Pbyk5DYHp/workflow/d4b12619-240c-4e30-b890-6947aa1b4c30| GSA Application workflow> is almost done! Some of the email language was adapted from the MAIE emails since the VIP Day versions didn’t always fit.

I haven’t updated the “Create Opportunity” actions yet — will we be creating separate pipelines for this, and will there be a waiting opt-in?

Finally, I checked and there’s no availability in your calendar for the 29th–30th, so we’ll need to open up Friday.
> **Whitney Hodges** · 2025-10-27 19:24 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1761593091101799)
> @Gisselle Jiménez Hi! Ok, I'll take a look. Yes, please create a pipeline just for the Google Search Accelerator.
> 
> Can you please clarify what you mean about the waiting opt-in?
> 
> You can remove the block on my calendar for this Friday. I can take calls from 10am-2pm CST. Thank you!
> **Gisselle Jiménez** · 2025-10-27 20:40 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1761597629557469)
> @Whitney Hodges These are the stages of the MAIE applicants. So wondering if there will be a waitlist opt-in form for GSA or if they would go directly to consultation scheduled?
> 
> 1. MAIE applicants
>     a. Waitlist Opt-in
>     b. Chatting
>     c. Consultation Scheduled
>     d. Consultation Complete
>     e. Contract Pending
> Noted on Friday's availability!
> **Whitney Hodges** · 2025-10-27 20:43 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1761597839076199)
> @Gisselle Jiménez got it! There is no wait-list for this offer. Let's make the stages mirror the Google Ads VIP Day application funnel. That will probably match up more closely. Thank you!
> **Whitney Hodges** · 2025-10-27 23:12 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1761606735710269)
> @Gisselle Jiménez Email copy within the application workflow has been updated and is now good to go

**Whitney Hodges** · 2025-10-27 23:46 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1761608787481489)
@daniela Hi! I noticed that the Get Started button wasn't working on the <https://weddingindustryads.com/google-search-accelerator|GSA landing page>. I moved it below the video and made it so that it scrolls to the value stack section the way the other buttons do.

Do we like this functionality? It's the same as the Google Ads VIP Day page which didn't convert well, but maybe those folks self-disqualified when they saw pricing. Also, I think the video + copy on this page is better than the VIP Day.

I updated the language on the <https://weddingindustryads.com/google-search-accelerator-calendar|calendar/application page>. Do you see any additional areas of opportunity (including application questions)?

We have an announcement email scheduled for tomorrow at noon that includes a link to the sales page, but if we need to push that later, we can. (FYI @Yulia Burris)

Thank you!
> **Whitney Hodges** · 2025-10-28 13:04 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1761656650185449)
> @Gisselle Jiménez Hi! Can you please test this funnel from start to finish this morning? Check the buttons on the landing page, book a discovery call, and make sure all is working with the workflow? Thank you!!
> **Gisselle Jiménez** · 2025-10-28 13:19 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1761657579571309)
> @Whitney Hodges On it!
> **daniela** · 2025-10-28 13:35 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1761658548717769)
> Thanks for helping with the back end elements @Gisselle Jiménez!
> 
> I guess people can book a sales call with @Whitney Hodges from this page, but then they also have the option to join us for the information session next week (when will we start promoting that session?)
> 
> I'm working on the pitch deck for that, and it's becoming like a mini-webby ( common mistakes / why this program is the solution / how it works / client results / strong CTA to join with urgency deadline )
> 
> And then from the info session, we will send them the proposal directly (so no additional sales call after that)
> **Whitney Hodges** · 2025-10-28 13:39 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1761658763524699)
> @daniela I'll work on promo emails for the live session. First will probably go out tomorrow. I'll spin it like we're doing it because discovery calls filled so quickly this week (I only have Friday availability)
> **daniela** · 2025-10-28 13:40 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1761658803530649)
> Good plan!
> **Gisselle Jiménez** · 2025-10-28 14:21 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1761661302553489)
> @Whitney Hodges Sorry for all the tests :smiling_face_with_tear: I had a bit of trouble getting the confirmation page to update. There was a step in the calendar funnel that needed adjusting. Everything looks good now!
> **Whitney Hodges** · 2025-10-28 14:50 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1761663028323609)
> @Gisselle Jiménez Thank you!!

**Gisselle Jiménez** · 2025-10-28 18:59 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1761677957740939)
@Whitney Hodges Here is the Google Ads VIP Day questionnaire created in LeadLock for review!
<https://api.leadconnectorhq.com/widget/form/ER1rr5mS1COyIHfAM3z3?notrack=true>

I was about to create the calendar, but ran into an issue. For clients to book through one calendar and choose between team members, it has to be set up as a _service-type_ calendar. However, this type doesn’t allow us to limit the maximum number of bookings, that option only exists with a _personal_ calendar.

Would you prefer that I keep it as a service calendar so clients can choose between team members, or would you rather I create individual personal calendars with a set booking limit?
> **Whitney Hodges** · 2025-10-28 19:20 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1761679255888609)
> @Gisselle Jiménez Thank you for letting me know. If they were individual calendars, how would that look on the landing page?
> **Gisselle Jiménez** · 2025-10-28 19:47 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1761680854746369)
> @Whitney Hodges We can include both calendars:
> <https://app.leadlockpro.com/v2/preview/qnUp6fIVOVJaiOnmIGnk?notrack=true>
> **Whitney Hodges** · 2025-10-28 20:56 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1761684961177519)
> @Gisselle Jiménez Ok, let me think about it
> 
> @daniela This is something else we need to discuss tomorrow
> **Whitney Hodges** · 2025-10-28 20:58 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1761685115879949)
> @Gisselle Jiménez I think we probably need to go the route of one service calendar with a choice of team members. Then set up a workflow on the back end, so that after a VIP Day is booked a new calendar event is created that blocks their schedule for the rest of the day
> **daniela** · 2025-10-28 21:33 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1761687192670209)
> I wonder if this would be a good use case for the GHL round robin calendar feature (<https://help.gohighlevel.com/support/solutions/articles/155000001484-appointment-distribution-logic-for-round-robin-calendars|here>) - my understanding is that it automates distribution of appointments while consolidating availability (and that way, the decision isn't put on the client to choose between Carmen/Christina). Thoughts? @Whitney Hodges
> **Whitney Hodges** · 2025-10-28 21:33 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1761687237064569)
> Yes!! Totally forgot that round robin was a thing!

**Whitney Hodges** · 2025-10-29 00:02 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1761696165498429)
@daniela Please check out the <https://docs.google.com/document/d/1nNn04VVQkdZGcnxdg7dGWUXfxgkDRGfq3AnRn-lVTws/edit?usp=sharing|October 29 email in this doc> that I'm hoping to send out tomorrow and lmk if it tracks with what you have in mind for the live session. Thank you!
> **Whitney Hodges** · 2025-10-29 20:01 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1761768064145919)
> @Yulia Burris Hi! Could you please schedule this email for this afternoon or evening? Sorry for the late notice. If that isn't doable, please just let me know. Thank you!!
> **Yulia Burris** · 2025-10-29 21:12 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1761772324212369)
> @Whitney Hodges I scheduled the email for 5:30 PM CT
> **Whitney Hodges** · 2025-10-29 21:30 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1761773429305829)
> @Yulia Burris Perfect, thank you!!
> **Whitney Hodges** · 2025-10-29 22:56 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1761778597293749)
> @daniela This email went out less than 30 minutes ago and we already have 4 opt-ins!

**Whitney Hodges** · 2025-10-29 02:11 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1761703881194729)
@daniela The workflow for the GSA live session is good to go. We'll use it for the confirmation email only. We'll send out the reminders via campaigns.

@Gisselle Jiménez Can you please test this funnel? <https://weddingindustryads.com/gsa-info-session-11-5> Additionally, I'm seeing opportunity to add a "Add to Google Calendar" button on the thank you page as well as a link inside the confirmation email. This <https://www.youtube.com/watch?v=-oyhFU8_i3Y|YouTube video> should walk you through how to do it. Please prioritize this Wednesday morning. Thank you!

**Gisselle Jiménez** · 2025-10-29 14:54 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1761749696207589)
@Whitney Hodges Hi! I forgot to mention that the funnel is working great, and I received the confirmation email successfully. The only thing I noticed is that the company name field seems to be using the custom field instead of the default one, which would populate correctly in the contact record. Let me know if we can adjust this!
📎 image.png (png, saved as `files/F09Q9Q3L49W-image.png`)
> **Whitney Hodges** · 2025-10-29 14:59 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1761749995318259)
> @Gisselle Jiménez yes, please update

**Gisselle Jiménez** · 2025-10-29 19:21 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1761765688190069)
@Whitney Hodges Google Ads VIP Day funnel and automation have been tested!

• <https://weddingindustryads.com/google-ads-vip-day-kickoff-call-2948|Scheduler>
• <https://weddingindustryads.com/google-ads-vip-day-confirmation|Confirmation page>
• <https://app.leadlockpro.com/location/Xi40zxmRvW8Pbyk5DYHp/workflow/831b99de-7357-4010-990d-8243d5f9156c|Automation> (Clients are automatically assigned to the team member they booked with through the calendar, and all workflow steps use merge tags to personalize each notification based on the assigned user and appointment details)

**Whitney Hodges** · 2025-10-29 23:46 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1761781598521319)
@daniela I'm working on emails to promote the Google Search Accelerator over the next week. Should I include a PS about the info session in some or all of them?

Should we add a banner about that event to the top of the sales page?

@Yulia Burris I think we should do at least a couple of posts about the info session on IG.

We have 0 discovery calls booked but now 5 signups for the live
> **daniela** · 2025-10-30 14:33 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1761834786674669)
> I think the info session is a lot lower barrier than a disco call - since we have such a short promo runway for that, I’d say plug it everywhere for the next 6 days. I think having a PS in every email is good, and maybe even one email focused on the info session itself. 
> 
> I think we can promote the info session in stories, too! Maybe 1-2 newsfeed post(s), but I think the newsfeed can have more evergreen content about the GSA program itself. 
> **Whitney Hodges** · 2025-10-30 14:35 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1761834959442749)
> @daniela Perfect! We're on the same page. We're up to 10 signups for the info session just from that one email yesterday evening
> 
> @Yulia Burris Can you please add a PS about the info session with a link to that page to this morning's email that is scheduled to go out?
> **Yulia Burris** · 2025-10-30 14:44 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1761835473820819)
> @Whitney Hodges *PS:* You can also join us November 5th at 11 a.m. CST for a Google Search Accelerator Information Session + *Live Q&amp;A — it’s FREE*! If you’ve been wanting a clear, confident path to running Google Ads that actually convert, this session is for you.
> 
> Register here
> **Yulia Burris** · 2025-10-30 14:46 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1761835594091879)
> @Whitney Hodges Let me know if that works)
> **Whitney Hodges** · 2025-10-30 14:50 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1761835821127219)
> @Yulia Burris If you could just remove the "it's free" part, then it's good to go. Thank you so much!!!
> **Yulia Burris** · 2025-10-30 15:21 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1761837708861269)
> @Whitney Hodges @daniela edited :heavy_check_mark:

**Gisselle Jiménez** · 2025-10-30 16:53 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1761843236194839)
@Whitney Hodges Christina's videos have been uploaded!

• <https://members.weddingindustryads.com/courses/products/6e9557fe-fcb3-477f-a1a7-47e0e60c90d8/categories/20eef22e-fc0c-4c49-9365-109947fd382f/posts/6c13e7c9-232e-472f-8881-a9579112a126?source=communities&amp;group_slug=the-vault|The VAULT>
• <https://app.leadlockpro.com/v2/location/Xi40zxmRvW8Pbyk5DYHp/memberships/courses/products/6e9557fe-fcb3-477f-a1a7-47e0e60c90d8|LeadLock>

**Gisselle Jiménez** · 2025-10-30 16:55 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1761843309603659)
I just noticed there are 2 more videos with documents. Will the document content be in the description of the video or just hyperlinked?

<https://www.loom.com/share/8875a11a73a9401dbe69b6903662a52a?sid=202f20da-85b4-4189-b9b9-f5ab3c05053a|Google Ads Best Practices>
• <https://docs.google.com/document/d/1QurSJ05VTyEPPwlngDzXNjosmTEBK7Zd/edit|Document>
<https://www.loom.com/share/eff8cdd0770a404f9abde7761e39f6b0?sid=99ca24c4-7838-4169-92fd-a1349a9b8b1b|How to Use the Google Ads Reporting Sheet>
• <https://docs.google.com/spreadsheets/d/10GFqedYotAHmkJ9By7hwltDZSVinjSErigdmrI5980o/edit?usp=sharing|Document>

**Gisselle Jiménez** · 2025-10-30 17:46 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1761846380978709)
@Whitney Hodges Titles and thumbnails for MAIE have been updated to reflect _Meta Ads_ for distinction.

Here's a list of what was updated:

• Submit Your *Meta Ads* for Campaign Builds
• Tweak Campaigns to Optimize *Meta Ads* Performance
    ◦ Tweak: Maintain & Optimize *Meta Ads*
• Enhance Results with *Meta Ads* Retargeting Campaigns
    ◦ Enhance: *Meta Ads* Retargeting Campaigns
• Create Your Direct Response *Meta* Ads
    ◦ Create: *Meta Ads* Direct Response Campaign
• Curate Your *Meta Ads* Client Attraction Campaign
• Connect: *Meta Ads* Kickoff Call & Tech Connections
• Track: Mastering *Meta Ads* Metrics

These are the only items where I wasn’t sure how to include Meta Ads. Let me know your preference!
• Share your landing page for feedback
• LEARN: Audit & Adapt
> **Whitney Hodges** · 2025-10-30 18:33 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1761849211169109)
> @Gisselle Jiménez Thank you!!! The landing page and Audit &amp; Adapt courses are great as is. Those will be used for both GSA and MAIE!

**Whitney Hodges** · 2025-11-03 17:05 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1762189522854549)
@Yulia Burris Hi! Several <https://docs.google.com/document/d/1nNn04VVQkdZGcnxdg7dGWUXfxgkDRGfq3AnRn-lVTws/edit?usp=sharing|GSA marketing emails> are are ready to be scheduled. They all specify the list they should be sent to.

I'd love for today's to go out this afternoon or evening. The others have a specified send time as well.

There will be more emails to come for Wednesday onwards, but if you could go ahead and get started on these, that would be great.

Thank you so much!
> **Yulia Burris** · 2025-11-03 21:29 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1762205362456459)
> @Whitney Hodges Hi! The email for today is <https://app.leadlockpro.com/v2/location/Xi40zxmRvW8Pbyk5DYHp/marketing/emails/scheduled?pageNumber=1|scheduled> for 5:30 PM CT.

**Whitney Hodges** · 2025-11-03 20:34 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1762202067449829)
@Yulia Burris FYI based on some feedback on sales calls and lack of discovery calls, we've updated the positioning on the <https://weddingindustryads.com/google-search-accelerator|GSA sales page>. Today's email aligns with this. I'm finding it helpful to think of GSA as a Google Ads VIP Day rebrand with bonus support, as opposed to a new program/course that includes a Google Ads VIP Day

**Whitney Hodges** · 2025-11-03 23:09 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1762211360596659)
@Christina Hill I've added an <https://members.weddingindustryads.com/communities/groups/the-vault/events|Event in the VAULT> for Google Ads Office Hours. Can you please check to see if the Zoom link is correct?

@Gisselle Jiménez Can you please add a thumbnail image for this event?
> **Christina Hill** · 2025-11-06 15:32 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1762443167703429)
> @Whitney Hodges @Gisselle Jiménez :white_check_mark: Zoom Link is correct.

**Whitney Hodges** · 2025-11-04 00:25 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1762215958673069)
<!channel> I think the Google Search Accelerator is now pretty much good to go inside of the VAULT! If everyone could please take a look at the following and let me know if there's anything you see that needs to be tweaked, I would appreciate it:

• <https://members.weddingindustryads.com/courses/products/b304db05-d141-4b37-a84e-060802db5f8d?source=communities&amp;group_slug=the-vault|Start Here! Google Search Accelerator>
• <https://members.weddingindustryads.com/courses/products/4b766a56-cd9d-4946-9812-1c4f7f936946?source=communities&amp;group_slug=the-vault|Audit &amp; Adapt> - @Gisselle Jiménez This is where the Five Foundations for Success with Ads thumbnail needs to be updated to remove Meta
• <https://members.weddingindustryads.com/courses/products/4f457b88-047f-4f70-b0e2-83b82cfb8f0a?source=communities&amp;group_slug=the-vault|LAUNCH: Book Your Google Ads VIP Day>
• <https://members.weddingindustryads.com/courses/products/6e9557fe-fcb3-477f-a1a7-47e0e60c90d8?source=communities&amp;group_slug=the-vault|LEVERAGE: Google Ads Resources>
• <https://members.weddingindustryads.com/courses/products/052f33d0-cf79-4f26-b445-4af577b4530a?source=communities&amp;group_slug=the-vault|Google Ads Office Hours> - @daniela Can you please change the theme on this one?
Thank you all!! This is very exciting!!!!
> **daniela** · 2025-11-04 01:34 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1762220087444009)
> :white_check_mark: confirming updated theme for google ads office hours

**Gisselle Jiménez** · 2025-11-04 13:49 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1762264165334699)
@Whitney Hodges Both thumbnails have been updated. :white_check_mark:
📎 image.png (png, saved as `files/F09QH358NAF-image.png`)
📎 image.png (png, saved as `files/F09QMGW81RU-image.png`)

**Gisselle Jiménez** · 2025-11-05 16:33 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1762360439661429)
Hey, @Yulia Burris! We’d like a simple email to go out at 11:00 a.m. CST for the GSA Live session participants to join. Here’s a draft you can use. Thanks!

> Hi there,
> 
> We're live now for the *Google Search Acccelerator Q&A session*! Here's the link to join: <https://www.google.com/url?q=https://zoom.us/j/95428361024?pwd%3Db35vscCYt2CaixB5o0d4dpxPzyLTle.1%26jst%3D2&sa=D&source=calendar&ust=1762779494479026&usg=AOvVaw2AOyjL-CgLiHVAoXa4lj0p
> |Zoom link>
> 
> See you inside!
> 
> Best,
> Daniela & Whitney
cc: @Whitney Hodges
> **Gisselle Jiménez** · 2025-11-05 17:11 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1762362672693269)
> @Yulia Burris Hi! Could you confirm if this went out?
> **Yulia Burris** · 2025-11-05 17:17 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1762363065246219)
> @Gisselle Jiménez Yes :white_check_mark:
> **Gisselle Jiménez** · 2025-11-05 17:18 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1762363083601759)
> @Yulia Burris Tysm!:heartbeat:

**Gisselle Jiménez** · 2025-11-05 16:39 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1762360761681239)
@Whitney Hodges @daniela Here is the list of the GSA Live Session Opt-ins!

<https://docs.google.com/spreadsheets/d/1YG-RDrp_5_VcFtxXi5gmbRQMwqJxu0PuoMy7Ubb1SvA/edit?gid=839970872#gid=839970872>

**daniela** · 2025-11-05 18:09 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1762366158335769)
The session went really well!
Just a few additional questions were asked at the end @Whitney Hodges - I'm waiting on the recording to generate, and will upload the replay video shortly @Gisselle Jiménez
> **Gisselle Jiménez** · 2025-11-05 18:28 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1762367304409689)
> @daniela Thank you! In the meantime, here is a preview of the draft landing page for the replay:
> 
> <https://app.leadlockpro.com/v2/preview/xfmuk8Fu73gsqrTV5XR8?notrack=true>
> **daniela** · 2025-11-05 18:50 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1762368616263129)
> Perfect - it looks like the recording has been generated (it's in two parts). I think since Whitney was the original host, I'm not able to download it from my zoom login... @Gisselle Jiménez are you able to log into the <mailto:hello@weddingindustryads.com|hello@weddingindustryads.com> zoom to download those replay videos directly from the cloud?
> 
> cc: @Whitney Hodges
> **Gisselle Jiménez** · 2025-11-05 18:59 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1762369169007659)
> @daniela Yes! I was able to download them. Are both videos going in the landing page?
> 
> @Whitney Hodges
> **Whitney Hodges** · 2025-11-05 19:08 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1762369690499679)
> @Gisselle Jiménez I'm not sure why there are two videos. Did it cut out somewhere in the middle? We probably need to splice them together, so that's it's one video on the landing page. Do you have capabilities to do that?
> 
> If not, maybe @Yulia Burris can jump in to support?
> 
> cc @daniela
> **Gisselle Jiménez** · 2025-11-05 19:54 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1762372479840189)
> @Whitney Hodges Yeah, there was like a connection issue. I was able to merge them in Canva. I'm trying to download and add it to landing page.:face_holding_back_tears:
> **Gisselle Jiménez** · 2025-11-05 20:30 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1762374617066589)
> @Whitney Hodges @daniela Ready for your review!
> 
> <https://app.leadlockpro.com/location/Xi40zxmRvW8Pbyk5DYHp/page-builder/xfmuk8Fu73gsqrTV5XR8|Edit>
> <https://app.leadlockpro.com/v2/preview/xfmuk8Fu73gsqrTV5XR8?notrack=true|Preview>
> **daniela** · 2025-11-05 20:57 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1762376230664489)
> Looks great!! Thanks for stitching those videos together
> **Whitney Hodges** · 2025-11-05 21:16 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1762377414085439)
> @Gisselle Jiménez Thank you so much for all of this!
> 
> For the landing page, can you please change the copy to:
> 
> REPLAY: Google Search Accelerator Info Session
> Check out the recording to learn how to master Google Ads for your business. Ready to work with us? Click the link below to secure introductory pricing!
> 
> Button: SIGN UP NOW
> 
> Can you please publish the page? Something like gsa-replay for the URL slug should work. Thank you!!
> 
> Cc @daniela
> **Gisselle Jiménez** · 2025-11-05 21:20 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1762377635079799)
> @Whitney Hodges Of course! Edited and published. :white_check_mark:
> 
> <https://weddingindustryads.com/gsa-replay>
> 
> cc: @daniela

**Whitney Hodges** · 2025-11-06 15:36 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1762443381377169)
@Christina Hill @Carmen Cruickshank Inside the Vault, I posted a welcome comment for Erin and Diana. Can you please comment on the thread to welcome them as well?
> **Carmen Cruickshank** · 2025-11-06 16:39 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1762447140468369)
> @Whitney Hodges yes!

**Christina Hill** · 2025-11-06 17:38 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1762450720180459)
Update: No one came to Google Ads Office Hours today, but Carmen and I had a great meeting. I was able to show her how to find LL attributions from her ads for Funktastic and DJ Hybrid.
> **Whitney Hodges** · 2025-11-06 17:44 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1762451040680249)
> @Christina Hill Ok, thank you! Not a huge surprise since Fernanda doesn't seem very engaged, Julie &amp; Bianca just had their VIP Days yesterday and Diana &amp; Erin haven't had their VIP Days yet.
> 
> @Gisselle Jiménez Can you please start posting same-day reminders in GSA and MAIE about office hours?
> **Gisselle Jiménez** · 2025-11-06 18:53 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1762455233870319)
> @Whitney Hodges Of course! Something like this an hour before works?
> 📎 image.png (png, saved as `files/F09R3TEL8QK-image.png`)
> **Gisselle Jiménez** · 2025-11-06 18:55 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1762455304611569)
> (I can now tag @everyone!)
> **Whitney Hodges** · 2025-11-06 20:12 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1762459922159449)
> Yes!! And same thing for Jacqueline's Meta office hours. Thank you!!

**Whitney Hodges** · 2025-11-06 21:26 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1762464393031369)
@Gisselle Jiménez @Yulia Burris fyi, today we updated the buttons on the gsl sales page to go straight to the proposal, contract and invoice, so people can sign up straight from the page. 

On Monday, I want to send out an email to all live session registrants and anyone who requested the replay offering a Google ads clarity call. 

@Gisselle Jiménez Can you update all of the discovery call pages and automation to reflect this language change. Also, I'd like to change it to a 15-minute call. Not sure if the video that's on the thank you page is still going to make sense or if we'll need to remove it. Please take a look and let me know
> **Whitney Hodges** · 2025-11-07 01:43 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1762479780698689)
> @Gisselle Jiménez Also, this one time, I'll want to let people be able to book same day appointments. I would just need a couple of hours notice to make sure I don't miss it, and if you could help me stay on top of this too, that would be great!
> **Whitney Hodges** · 2025-11-07 13:11 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1762521114655139)
> @Yulia Burris The <https://docs.google.com/document/d/1nNn04VVQkdZGcnxdg7dGWUXfxgkDRGfq3AnRn-lVTws/edit?usp=sharing|clarity call email> is in our doc. You'll just need to insert the link when it's ready. I'd like for this to go out at 6am on Monday. Thank you!!
> **Gisselle Jiménez** · 2025-11-07 14:58 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1762527513427669)
> Hi, @Whitney Hodges Done! For the <https://weddingindustryads.com/calendar-page-645042|scheduler>, let me know if this sounds good:
> 30 minute service interval, 3-hour minimum scheduling notice, 1-week date range, 15-minute post-buffer.
> 
> Do you still want them to fill out the application form?
> 
> Regarding the <https://weddingindustryads.com/gsa-call-booked-439776|thank you page> video, I think it should be fine. You say, "We're excited you booked your call for the Google Search Accelerator. This call is where we'll get to know your business better, talk about your goals, and start walking you through how you can get more leads from google fast"
> 
> Automation has been also been tailored. :white_check_mark:
> **Whitney Hodges** · 2025-11-07 21:05 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1762549533570579)
> @Gisselle Jiménez all sounds good, thank you!

**Whitney Hodges** · 2025-11-07 04:57 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1762491454995869)
@daniela The VSL on the GSA page has a CTA inside the video to book a discovery call. Should we trim that part out? Or remove the VSL and put the replay there instead?

cc @Yulia Burris @Gisselle Jiménez
> **Whitney Hodges** · 2025-11-07 18:15 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1762539310087289)
> @daniela I know I sent this message late last night so I just want to make sure you saw it.
> **Whitney Hodges** · 2025-11-07 21:06 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1762549593201439)
> @Gisselle Jiménez Sorry this is last minute, but could you go ahead and update the video on the GSA sales page to be the replay instead of the VSL? Thank you!!
> **Gisselle Jiménez** · 2025-11-07 21:33 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1762551180359119)
> @Whitney Hodges Just saw this! It has been changed.:white_check_mark:
> 
> <https://app.leadlockpro.com/v2/preview/wN2c4ygowlmD64NOdkUm?notrack=true>
> **daniela** · 2025-11-09 16:32 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1762705927654349)
> Hey @Whitney Hodges! So sorry I missed this - I think replacing the VSL with the replay was a good move!

**Whitney Hodges** · 2025-11-11 02:01 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1762826463278779)
@Yulia Burris Hi! Sorry it's so late. I've added a couple of <https://docs.google.com/document/d/1nNn04VVQkdZGcnxdg7dGWUXfxgkDRGfq3AnRn-lVTws/edit?usp=sharing|emails to our doc> for tomorrow. One for the morning, one for the afternoon/evening. Please don't feel obligated to set these up tonight. You can schedule them tomorrow. Feel free to pick the times that you think may perform best. Thank you so much!!
> **Yulia Burris** · 2025-11-11 02:23 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1762827789311459)
> @Whitney Hodges Hi! <https://app.leadlockpro.com/v2/location/Xi40zxmRvW8Pbyk5DYHp/marketing/emails/scheduled?pageNumber=1|I scheduled the email> for tomorrow morning at 6 AM
> **daniela** · 2025-11-11 14:41 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1762872077727899)
> Great! <https://docs.google.com/document/d/1ADJfWW8GPqBCcoeZvoSW7CGToK78D1PnPZzEiT8GdFA/edit?usp=sharing|Here>'s what I've been working on for "closed cart" socials (stories/carousels or short videos - I can record this afternoon if you guys like the concepts!) There are a few final email drafts in there as well. We can take a closer look together when we meet this morning :slightly_smiling_face:
> **Whitney Hodges** · 2025-11-11 16:42 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1762879370143399)
> @Yulia Burris I added a carousel and email concept at the end of this doc. Please feel free to take all of this and run with it. Copy may still need a bit of refining. Let's push out as much as possible today and tomorrow. Thank you!

**Whitney Hodges** · 2025-11-11 14:50 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1762872626394219)
@Carmen Cruickshank Hi! Are you able to see Erin's post in the vault about her landing page? Can you respond with feedback? If you aren't working today because of the holiday, lmk!

**Carmen Cruickshank** · 2025-11-11 15:19 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1762874361875019)
@Whitney Hodges Hi! Yes I’ll make sure to respond to her soon on the vault. For the most part I’m not working today because of the holiday but I’ll get back to clients via email and the vault.

**daniela** · 2025-11-12 00:49 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1762908547100859)
Here is a video that can be shared in stories! I edited it in the reels app, so it added a watermark…  but I think it’s still ok! 
📎 f5f2cd16d1964a05968ca884b4b0006c.MP4 (mp4, **not downloaded** — over cap (113.3 MB), [fetch it](https://files.slack.com/files-pri/T03P5A3L1DK-F09SB83K6GJ/download/f5f2cd16d1964a05968ca884b4b0006c.mp4))

**Carmen Cruickshank** · 2025-11-12 18:26 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1762971986031649)
@Gisselle Jiménez Hi! I'm preparing for Erin Smith's VIP day tomorrow for her business Carroll Hall, I was looking in the VIP Day folder but I can't find her folder. I'm not sure the full process of creating a new folder if I'd miss anything creating a new one but was just wondering if i could just make a new one if needed
> **Gisselle Jiménez** · 2025-11-12 18:28 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1762972100887689)
> Hi, @Carmen Cruickshank! <https://drive.google.com/drive/folders/1V8kVUGU8G0yfB0IVxGg0F3zXIKYuQE3B?usp=drive_link|Here> is the folder! I actually created it in the GSA folder inside WIA | Clients.
> 
> @Whitney Hodges Should we keep using the VIP Day folder?
> **Carmen Cruickshank** · 2025-11-12 18:29 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1762972145552139)
> oh okay thank you! @Gisselle Jiménez
> **Gisselle Jiménez** · 2025-11-12 18:30 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1762972218797409)
> @Carmen Cruickshank This is also for internal documentation only, so there's no WIA + Carroll Hall folder, as we won't share folders with GSA clients!
> **Whitney Hodges** · 2025-11-12 18:30 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1762972223814609)
> @Gisselle Jiménez @Carmen Cruickshank I don't have a preference on where the folder is located. Whatever is easiest for the team. We're just not going to be sharing the folders with GSA members (at least we're going to try not to, and we'll see how that goes
> **Whitney Hodges** · 2025-11-12 18:34 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1762972487847389)
> @Carmen Cruickshank Erin asked about the possibility of launching a pmax campaign instead of a search campaign for her VIP day. I told her it was a possibility. Just want you to have that on your radar, so it doesn't catch you off guard. Based on what you see in her account, if you think she's a good candidate, go for it. But if it's better to recommend a search campaign set up the right way and optimized before pmax, feel free to explain that to her.
> 
> She had an audit with Christina in October, so things in her account may have gotten cleaned up after that.
> 
> @Christina Hill Feel free to chime in with any insights on this.
> 
> Also, Erin has expressed that spam leads are a real pain point for her right now. If you could touch on this during the VIP Day, that would be great. You can also let her know that my workshop next week will cover this in more depth.
> **Carmen Cruickshank** · 2025-11-12 18:40 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1762972837140309)
> Good to know, thank you @Whitney Hodges. And yes would love to hear you'r input @Christina Hill!
> **Christina Hill** · 2025-11-12 19:11 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1762974719775369)
> I agree that pmax campaigns should wait. After talking to Brooklake and Adriana, it looks like pmax increased the amount of spam inquiries they were receiving. Because she is interested in a pmax campaign, I suggest a Search Campaign and a Display Campaign. In order to get this all done during a VIP Day call, she would need to have assets (images and maybe some videos) prepared to share with you on the call. @Carmen Cruickshank @Whitney Hodges
> **Carmen Cruickshank** · 2025-11-12 19:26 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1762975570043089)
> Sounds good, thank you! @Christina Hill
> **Whitney Hodges** · 2025-11-12 22:34 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1762986869984919)
> @Christina Hill @Carmen Cruickshank Do you think we should include the display campaign in the VIP Day? I've been trying to make it pretty clear in the contract that the scope is just a Google Search Campaign
> 
> We could also consider: helping her with launching a display campaign during an upcoming office hours call or adding a training resource to the VAULT showing clients how to do this for themselves.
> 
> Let me know what you think!
> 
> cc @daniela
> **Christina Hill** · 2025-11-13 13:29 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1763040594900379)
> @Whitney Hodges I think that is a good idea. It would help them have hands-on work to do inside the program.
> **Whitney Hodges** · 2025-11-13 15:16 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1763046974270069)
> Can you please record a quick training video on how to set up a display campaign? @Christina Hill
> **Christina Hill** · 2025-11-13 15:23 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1763047413814299)
> Yes. I will do some recording today after my call with Pooja for the spam video and Display Campaign. @Whitney Hodges 
> **Carmen Cruickshank** · 2025-11-13 21:53 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1763070806832129)
> @Whitney Hodges @Christina Hill That’s a great idea. Just a quick update, she decided to move forward with one search campaign today. I also audited her other search campaigns since she mentioned she had made changes with a Google rep after you helped her, Christina, build the new one, and the rep ended up causing issues. She really wanted to avoid any spam, so we stuck with just the search campaign for now.

**Carmen Cruickshank** · 2025-11-12 18:28 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1762972115526589)
@Whitney Hodges Hey! I saw on the VIP call tomorrow that Erin is invited but I didn't see you on the invite list, just wanted to double check if it's on your calendar too
> **Whitney Hodges** · 2025-11-13 13:22 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1763040152445129)
> @Carmen Cruickshank Hi! I'm sorry I didn't see this message yesterday! It's not on my calendar, and I have a conflict. Are you ok to handle solo?

**Whitney Hodges** · 2025-11-13 12:33 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1763037215258889)
@Yulia Burris @daniela Good morning! Everyone is starting to announce their Black Friday specials, and we don't have anything planned.

What if for today's email instead of announcing that the GSA intro price is available for one more day. We announce that it's sticking around through Black Friday?
> **Yulia Burris** · 2025-11-13 14:08 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1763042931803319)
> @Whitney Hodges Good morning! That sounds great! Would you like me to reschedule the email and update the text?
> **Whitney Hodges** · 2025-11-13 14:16 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1763043411571219)
> @daniela what do you think?
> **daniela** · 2025-11-13 16:33 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1763051601979839)
> @Whitney Hodges I feel like Black Friday is still a long way out… what if we approach this more like a flash sale that BFCM weekend and actually close doors in the meantime, focus on client results, bts launch day progress and such, and that way we create some demand/fomo before we open it back up. 
> **daniela** · 2025-11-13 16:34 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1763051659563259)
> I think the optics of closing doors for now are better than the impression it might give for us to extend the deadline that long 
> **Whitney Hodges** · 2025-11-13 16:37 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1763051846333249)
> @daniela yes, that works
> 
> @Yulia Burris we don't need to send out an email today at all, thank you!

**Christina Hill** · 2025-11-13 20:12 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1763064747871349)
Hi @Whitney Hodges and @Gisselle Jiménez! I just finished recording two new videos. <https://docs.google.com/document/d/1TldXmutSA2B4H76vKE2wjSXQ_ewaah2WF0GWMcIJUoo/edit?usp=sharing|They are linked on this Google Doc and highlighted in yellow>. I feel like I did too much rambling, and my computer isn't allowing me to make proper edits with Loom. Please feel free to clean these videos up however you would like before adding them to The Vault. If I need to re-record anything, please let me know. Thanks!
> **Whitney Hodges** · 2025-11-14 14:36 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1763130967509299)
> @Christina Hill thank you so much for this!
> 
> @Gisselle Jiménez can you please download these loom videos and add them to our drive if you haven't already?
> 
> Can you please take what Christina is saying in the spam reduction video and organize it into a doc? I'd like to post in the vault today that my workshop on Tuesday will cover this. If I don't get to it, please remind me to do it first thing on Monday.
> 
> @Yulia Burris can you please edit the video about display campaigns as you see fit and get it added to the Google Resources course in the vault?
> **Gisselle Jiménez** · 2025-11-14 15:15 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1763133346195649)
> @Whitney Hodges Videos have been added to the <https://drive.google.com/drive/folders/1xfTfWGsX_wjCED-_xbPoWD02y19Welsl?usp=drive_link|Resources folder> in the GSA folder:
> • <https://drive.google.com/file/d/1199X4z2wGHlNTlytamY1Gi9DexncdgtT/view?usp=drive_link|Setting up a display campaign>
> • <https://drive.google.com/file/d/1bGGXQxtdnhNzt2uSsxUE3b6DQRvJ_9si/view?usp=drive_link|Strategies to Reduce Spam Leads>
> Here is the document on spam reduction:
> <https://docs.google.com/document/d/1Kk40AXkUwpZsh0rTK4c8P-UxnJvVCgzwGmuKJv_NfZ8/edit?tab=t.0#heading=h.flq2er5hko8q>
> **Gisselle Jiménez** · 2025-11-17 15:33 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1763393635440569)
> @Whitney Hodges Hi! Quick reminder on posting in the vault about tomorrow's workshop on Spam leads! :bangbang:
> **Whitney Hodges** · 2025-11-18 18:17 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1763489835922359)
> @Yulia Burris Hi! I just watched the display campaign training. Around the 15 minute mark, Christina is searching for a website that shows display ad examples. I think it can be edited out until she reaches the recipe page with the examples. Can you please make this edit and add it as a lesson to the Google Resources course in the vault?
> 
> For the strategies to reduce spam leads video, it needs to be cleaned up a bit around the 1:20 minute mark when she's talking about reCAPTCHA
> 
> @Christina Hill Any other edits you'd like to see on your end? These videos are awesome; thank you so much!!!
> **Christina Hill** · 2025-11-19 15:35 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1763566508863269)
> Hi @Whitney Hodges! Thank you! I am relieved that they are getting edited. :raised_hands::skin-tone-4:
> 
> Hi @Yulia Burris, can you cut *17:18-17:22* and *22:09-22:29* from the 'Setting up a Display Campaign' Video, please?
> **Yulia Burris** · 2025-11-20 00:19 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1763597998237749)
> @Whitney Hodges @Gisselle Jiménez
> Hi! Both videos have been edited and added to the <https://drive.google.com/drive/folders/1xfTfWGsX_wjCED-_xbPoWD02y19Welsl?usp=share_link|folder here>.
> 
> Also, the two lessons have been uploaded to the <https://app.leadlockpro.com/v2/location/Xi40zxmRvW8Pbyk5DYHp/memberships/courses/products/6e9557fe-fcb3-477f-a1a7-47e0e60c90d8|VAULT>. Please let me know if the Google Doc _“How to Reduce Spam Leads in Your Google Ads Account”_ should be added inside the lesson as well. And let me know if you'd like any edits to the videos.
> 
> Thank you!
> **Whitney Hodges** · 2025-11-20 18:41 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1763664098746339)
> @Yulia Burris Thank you! I think if you could just add all of the text from the doc into the description for the Google Ads spam video, that would be great!
> **Yulia Burris** · 2025-11-21 15:30 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1763739012825039)
> @Whitney Hodges @Gisselle Jiménez I’ve added all of the text from the doc into the description for the Google Ads spam video :heavy_check_mark:

**Notification Bot** · 2025-11-18 21:46 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1763502399642279)
Uche Ojuntahas joined on for the Google Search Accelerator! :tada:

**Christina Hill** · 2025-11-20 18:17 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1763662647405559)
@Whitney Hodges Office Hours went well. I am not sure if the recording gets added to The Vault, but I've added it to a <https://drive.google.com/drive/u/0/folders/1yC8IdjshDSuRkwvxQZr4JjJXwyrcxFT8|Google Drive Folder Here>. @Gisselle Jiménez, please feel free to reorganize this if there is a better place to put it. :slightly_smiling_face:
> **Whitney Hodges** · 2025-11-20 18:18 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1763662702499979)
> @Christina Hill Amazing! Yes, we'll upload replays to the vault. Who attended today?
> **Christina Hill** · 2025-11-20 18:52 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1763664759611949)
> @Whitney Hodges Erin from Carroll Hall was there, and Carmen and I were able to tag-team her account.
> **Gisselle Jiménez** · 2025-11-20 19:30 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1763667034880509)
> @Whitney Hodges Does this thumbnail work or do you want the same picture as the meta ads office hours one?
> 📎 Thumbnail (1).png (png, saved as `files/F09UE7SFVFW-Thumbnail_1_.png`)
> **Whitney Hodges** · 2025-11-20 19:43 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1763667802807669)
> @Gisselle Jiménez That works!
> **Gisselle Jiménez** · 2025-11-20 19:47 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1763668056660079)
> Office hours have been published!:white_check_mark:

**Whitney Hodges** · 2025-11-20 18:54 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1763664862017309)
@Christina Hill @Carmen Cruickshank Hi! I'm seeing the opportunity for us to add some sort of guidance within GSA about Google reps and what to do if one reaches out to you. Thoughts?
📎 image.png (png, saved as `files/F09UP9Q7BND-image.png`)
> **Carmen Cruickshank** · 2025-11-21 16:25 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1763742309276959)
> @Whitney Hodges That's a good idea to add some guidance so that clients aren't confused
> **Whitney Hodges** · 2025-11-21 16:40 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1763743223194529)
> @Carmen Cruickshank @Christina Hill Ok, in general, I think our guidance would be to just ignore the Google Reps unless they are truly encountering a technical problem or something along the lines of advertiser verification not being approved, ads being rejected, policy violations, billing issues. Does that track? We also have some <https://www.instagram.com/p/DOgPINqDknC/?img_index=6|past marketing like this> that speaks to why. What else needs to be addressed?
> **Carmen Cruickshank** · 2025-11-21 16:53 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1763744022463169)
> @Whitney Hodges Yes, I agree with all of that, including the Instagram post explaining it. The only thing I’d add is this: if a client isn’t getting leads and, for example, I have them on Maximize Clicks but a Google rep suggests switching to Maximize Conversions and the client becomes curious, then Christina and I can walk them through it. We can explain why we chose their current strategy and what outcomes they can expect from any changes.
> And yea, I just don’t want to come across as “don’t listen to them, we’re always right,” because that’s not what we’re saying. I like that you point out the reps’ goal is to promote Google’s tools and increase ad spend, while our goal is what’s actually best for the client’s results. cc:@Christina Hill let me know your thoughts!
> **Whitney Hodges** · 2025-11-21 16:54 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1763744094589739)
> @Carmen Cruickshank ok, got it! That example is perfect, thanks!
> **Christina Hill** · 2025-11-24 17:43 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1764006193549809)
> I agree @Carmen Cruickshank! Sounds great :+1::skin-tone-4:
> 
> @Whitney Hodges

**Notification Bot** · 2025-11-24 14:19 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1763993977605419)
Mario Lopezhas joined on for the Google Search Accelerator! :tada:

**Christina Hill** · 2025-12-04 17:47 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1764870441185029)
Update: No attendees for office hours today, but Carmen and I had a productive call. We were able to discuss ad strategies, prep for her 2-week follow-up call, and the Quarterly Strategy Meeting for Miss Lyss.

**Christina Hill** · 2025-12-18 17:58 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1766080731265899)
Update: No attendees for office hours today, but Carmen and I were able to install Meta tracking for DJ Hybrid and make some tracking updates for Montgomery Creek.

**Christina Hill** · 2025-12-30 18:02 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1767117765866779)
Google Ads Office Hours - December 30

*<https://fathom.video/share/ZbQ5e6jySwyAHoywHNYyzPjn4xw_iceG|VIEW RECORDING - 54 mins (No highlights)>*
<https://fathom.video/share/ZbQ5e6jySwyAHoywHNYyzPjn4xw_iceG?tab=summary&amp;timestamp=0|Discussing Campaign Performance @ 0:00>
Erin and Christina reviewed the performance of Erin's Google Ads campaign for Carol Hall wedding venue. They discussed the competitor campaign, which was getting impressions but few conversions. Christina recommended testing a new landing page for the competitor campaign to improve conversion rate.
<https://fathom.video/share/ZbQ5e6jySwyAHoywHNYyzPjn4xw_iceG?tab=summary&amp;timestamp=223|Optimizing Keyword Targeting @ 3:43>
Christina and Erin identified that the campaign was spending a significant amount on Erin's branded keywords like "Carol Hall" and "Carol Hall Brooklyn", which were already ranking organically. They agreed to add these as negative keywords to the campaign to avoid wasting budget on branded searches.
<https://fathom.video/share/ZbQ5e6jySwyAHoywHNYyzPjn4xw_iceG?tab=summary&amp;timestamp=994|Experimenting with A/B Testing @ 16:34>
Christina walked Erin through the process of setting up an A/B test experiment in Google Ads to test different landing page variations. They agreed to run the experiment for 45 days to gather sufficient data before making any changes.
<https://fathom.video/share/ZbQ5e6jySwyAHoywHNYyzPjn4xw_iceG?tab=summary&amp;timestamp=2275|Increasing Budget for January @ 37:55>
Erin and Christina discussed plans to increase the campaign budget for January, a traditionally high-volume period for wedding venue bookings. They agreed to pause the competitor campaign and shift that $5 daily budget to the main campaign to capitalize on the seasonal demand.
<https://fathom.video/share/ZbQ5e6jySwyAHoywHNYyzPjn4xw_iceG?tab=summary&amp;timestamp=3209|Recap and Next Steps @ 53:29>
Erin summarized the key action items: pause the competitor campaign, increase budget on the main campaign, reinstate the "Inquire Now" click goal, and check in on performance in a couple weeks. Christina emphasized the importance of monitoring the campaign closely, especially during the busy January period.
> **Gisselle Jiménez** · 2025-12-30 20:39 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1767127194015429)
> Hi, @Christina Hill! Are you able to download and share the recording? I think I'm not able to download the video from Fathom. Thanks!!
> **Christina Hill** · 2025-12-31 14:35 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1767191718530039)
> Hi! I uploaded the recording to the Office Hours folder on the Google Drive for the Google Ads Accelerator. @Gisselle Jiménez
> **Gisselle Jiménez** · 2026-01-02 14:16 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1767363399690879)
> Awesome! Published. :white_check_mark:

**Whitney Hodges** · 2025-12-31 15:42 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1767195761199069)
@Christina Hill @Carmen Cruickshank I've got a question from a potential GSA member about the time commitment they need to plan for on their end. For what to expect leading up to and on the VIP Day, I'm clear, but for the 3 months of support following, I think we need to define this more clearly. What would your recommendations be?

Should they be checking their account for a few minutes weekly? And adding negative keywords at that time?

And would we recommend that they come to every office hours? (I'm thinking yes but looking for guidance here)
> **Christina Hill** · 2026-01-03 15:52 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1767455573574089)
> Hi @Whitney Hodges! Yes. For their 3 months of support, they should definitely attend the office hours. I usually tell them to check their accounts weekly to review metrics and add negative keywords (about 5-10 minutes).
> **Carmen Cruickshank** · 2026-01-05 16:34 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1767630853453559)
> Hi @Whitney Hodges, I agree with @Christina Hill, i don't see a need for more than 10-15 min per week checking accounts unless something's wrong and they're doing a deep dive
> **Whitney Hodges** · 2026-01-05 16:55 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1767632126801649)
> @Carmen Cruickshank @Christina Hill Thank you for your input. So helpful!
> 
> @Gisselle Jiménez We need to add these recommendations to the curriculum in the VAULT in some capacity.  If I'm remembering correctly, for Meta Ads, we have something like "My Ads are running. Now what?". We need something similar for Google. I think it should live inside the Google Resources course and be at the top. Thank you!!
> **Gisselle Jiménez** · 2026-01-22 14:12 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1769091155710009)
> @Whitney Hodges This has been drafted! The section in the meta ads one is under <https://app.leadlockpro.com/v2/location/Xi40zxmRvW8Pbyk5DYHp/memberships/courses/course-creator-studio?view=manager&amp;sub_view=outline&amp;product_id=f5d55f07-83e9-4f4a-8e04-733c32c400e9|Meta Ads Metrics &amp; Benchmarcs.> I added it to the <https://app.leadlockpro.com/v2/location/Xi40zxmRvW8Pbyk5DYHp/memberships/courses/course-creator-studio?view=manager&amp;sub_view=outline&amp;product_id=6e9557fe-fcb3-477f-a1a7-47e0e60c90d8|Google Ads Resources under "Manage  &amp; Optimize">. Let me know if it's good to publish. :raised_hands:
> 📎 image.png (png, saved as `files/F0AAB54J43C-image.png`)
> **Whitney Hodges** · 2026-01-22 14:18 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1769091480377049)
> @Gisselle Jiménez Thank you!!! Let's word it as "your Google Search Campaign is now live" in both the name and description. Then it's good to go!
> **Gisselle Jiménez** · 2026-01-22 14:37 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1769092621293799)
> @Whitney Hodges Edited and published:
> <https://xi40zxmrvw8pbyk5dyhp.memberships.msgsndr.com/products/6e9557fe-fcb3-477f-a1a7-47e0e60c90d8/categories/356f6fee-2438-43bf-908b-408bd304cb55/posts/ff9d586e-aef1-472d-b330-01e5fc5abe6f?token=eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJhdXRoQ2xhc3MiOiJVc2VyIiwiYXV0aENsYXNzSWQiOiJ1enRia0R2SmJPVXNpalVxOVlFMSIsImNoYW5uZWwiOiJBUFAiLCJzb3VyY2UiOiJXRUJfVVNFUiIsInNvdXJjZUlkIjoidXp0YmtEdkpiT1VzaWpVcTlZRTEiLCJwcmltYXJ5QXV0aENsYXNzSWQiOiJDa0dNQUpRMDdobmI4UWVLdUdPZyIsImFwcE1ldGEiOnt9LCJqdGkiOiI2OTcyMmFhZWIwMmQ0NTRmMDlhZmJjN2IiLCJpYXQiOjE3NjkwODk3MTAuNDI4LCJleHAiOjE3NjkwOTMzMTAuNDI4fQ.KYtNZnaqoq4oYlwvAmhB3hTKlPYoDEZ5mLR3l5L3WlCukrmhm4xJR1bJzGO8ooYklL15_nSDKToy9fK2c64-tOx2Qu98TmY7oKf0VWwQYNTXoJ01hRn-XL3NmcdAx6xs6cm_LUk4iK3aYxJluM00tOAP7e-7b-jCKcRSLRKc3spjwdh6zPG_S-BxBMbj4UkKhOiyLBr80BhtmLk2XYkRj-bdWAzDxRiq76ZgyvFXEUOydx6vV0pEbrBkDCpavVkrOVz8-tfdS-aWJJnIraKLGQBfsncMEp_fhcfsOBsVDa55Q5m3cdsXrhm7F8dbS2iCaM16LDDziQes3a_r9peaF5KEPRv3IF2jvxHWdxWbmkW5XMUq2sASln74FXkx9g5oO5Ql0JrRoZJ3xrfK5s8m2FkDm_ZJEPBz9ECVLuYhAt7ZPaBSt1tBiYl4VgJ2T_sy-d97bKmcpajy09xAxaADzewwNnIDzQB8Ywf48KgxpBg7tlpVmXcdm6UImliPXyBrRu5w8xBUvOzDogLvToxGLiDzh8WbdrUDbMcr9Yg-Ft7odG10A2GAKrUvJtSIzI1AGWei55YLLyVBiy4vGYqitXk92bvzNIyXeNzBcszAOySzOArTaZOid76IS8GyTP-9bSc0CmJAiTVFVz46Ig46vk1VcUPXWG3eh1kmcrBG4GU&amp;location_id=Xi40zxmRvW8Pbyk5DYHp&amp;is_preview=true|https://xi40zxmrvw8pbyk5dyhp.memberships.msgsndr.com/products/6e9557fe-fcb3-477f-a1a7-47e0e60c90d8/[…]cation_id=Xi40zxmRvW8Pbyk5DYHp&amp;is_preview=true>

**Gisselle Jiménez** · 2026-01-07 03:06 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1767755183012189)
Diana Leimbach completed the Google Search Accelerator Check-in Survey!:star2: 
> **Gisselle Jiménez** · 2026-01-07 14:57 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1767797820141869)
> Diana's completed survey. :raised_hands:
> 📎 Diana Leimbach - Check-in Survey.pdf (pdf, saved as `files/F0A7AT7TPPU-Diana_Leimbach_-_Check-in_Survey.pdf`)
> **Gisselle Jiménez** · 2026-01-07 14:58 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1767797903966369)
> @Whitney Hodges This has been uploaded to Diana's internal folder and the social proof folder. :white_check_mark:

**Christina Hill** · 2026-01-09 15:55 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1767974137873649)
Hi @Gisselle Jiménez! Next week, I will not be able to host Google Office hours with Carmen because I will be on a flight. Right now, Office Hours are hosted in my Zoom Room. Are you able to change it to Carmen's Zoom Room for next week?

cc: @Carmen Cruickshank
> **Gisselle Jiménez** · 2026-01-09 16:07 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1767974855109249)
> @Christina Hill Done!
> **Christina Hill** · 2026-01-12 20:28 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1768249733505259)
> You're awesome! Thank you, @Gisselle Jiménez.
> 
> @Carmen Cruickshank are you set to handle office hours this week?
> **Carmen Cruickshank** · 2026-01-12 21:48 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1768254510869799)
> @Christina Hill yes! enjoy your time in Houston :heart:
> **Christina Hill** · 2026-01-13 03:16 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1768274165600319)
> Thank you! @Carmen Cruickshank

**Gisselle Jiménez** · 2026-01-13 16:39 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1768322359851909)
Erin Smith completed the Google Search Accelerator Check-in Survey!:star2: 
> **Gisselle Jiménez** · 2026-01-13 17:20 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1768324826194799)
> Erin's Completed Survey. :raised_hands:
> 📎 NOYrCxaHBOv9gTBCjUNy.pdf (pdf, saved as `files/F0A8D5LH9FX-NOYrCxaHBOv9gTBCjUNy.pdf`)
> **Gisselle Jiménez** · 2026-01-13 17:26 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1768325176309559)
> @Whitney Hodges I can draft an email follow up to Erin especially answering her question.
> 
> Let me know if they would be able to continue at a monthly rate and what that price would be!

**Carmen Cruickshank** · 2026-01-16 15:46 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1768578376435779)
Update on Google Ads Office Hours yesterday: I helped Uche with her ads, she's been getting no leads and I set up an extra conversion action of seeing who view her contact page to see any bottlenecks. As well as letting her know to improve messaging on her site, qualifiers, headlines, etc. I helped Diana with her ads, she's been getting a lot of calls since ads started of people asking how to book online, i told her a video of her explaining the process would help early in the page. As well as adding tracking to her booking system to see where drop offs may be. Shelby was also on, she just wanted to see how her ads can improve, we added negative keywords, added her new landing page to her ads and more.
> **Gisselle Jiménez** · 2026-01-16 16:57 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1768582626537219)
> Hi, @Carmen Cruickshank! Were you able to record the meeting?
> **Carmen Cruickshank** · 2026-01-16 19:48 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1768592928078709)
> no :disappointed: but next time i will @Gisselle Jiménez
> **daniela** · 2026-01-16 21:39 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1768599593143559)
> Great suggestions! Sounds like this was a really productive call - thanks for running it @Carmen Cruickshank

**Gisselle Jiménez** · 2026-01-29 16:04 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1769702676218979)
Hi, @Christina Hill @Carmen Cruickshank!! Are you both attending office hours today?

Current zoom link is: <https://zoom.us/j/4037725916>

**Carmen Cruickshank** · 2026-01-29 16:24 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1769703862861439)
@Gisselle Jiménez yes

**Whitney Hodges** · 2026-01-29 17:19 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1769707158823109)
@Carmen Cruickshank Has Uche attended office hours at all?

**Carmen Cruickshank** · 2026-01-29 18:04 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1769709848261299)
@Whitney Hodges she did last office hours and not today

**Christina Hill** · 2026-01-29 18:08 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1769710108518329)
GSA Office Hours - January 29

*<https://fathom.video/share/TS4tW-7yMTChz85-rjnbKBG-sn-JCqF7|VIEW RECORDING - 64 mins (No highlights)>*
<https://fathom.video/share/TS4tW-7yMTChz85-rjnbKBG-sn-JCqF7?tab=summary&amp;timestamp=0|Tracking form conversions @ 0:00>
The team discussed setting up tracking for the client's website forms, including a weddings form and an events form. They worked to ensure the forms were properly redirecting to thank you pages so that conversions could be tracked accurately in Google Ads.
<https://fathom.video/share/TS4tW-7yMTChz85-rjnbKBG-sn-JCqF7?tab=summary&amp;timestamp=524|Optimizing the client's Google Ads campaign @ 8:44>
The team reviewed the client's current Google Ads performance, including impressions, clicks, and conversion rates. They discussed potential optimization strategies such as testing broad match and Performance Max campaigns, as well as ways to improve the client's ad copy and landing pages.
<https://fathom.video/share/TS4tW-7yMTChz85-rjnbKBG-sn-JCqF7?tab=summary&amp;timestamp=934|Using HoneyBook for lead management @ 15:34>
The team discussed the client's use of HoneyBook to manage leads, including challenges with the platform's form settings and redirect functionality. They explored ways to better leverage HoneyBook to track and nurture leads.
<https://fathom.video/share/TS4tW-7yMTChz85-rjnbKBG-sn-JCqF7?tab=summary&amp;timestamp=3327|Coordinating with the Google Ads specialist @ 55:27>
The team discussed an upcoming meeting with the Google Ads specialist, Priyanka, and how to best prepare for and participate in that discussion to ensure the client's campaigns are optimized and performing well.
> **Christina Hill** · 2026-01-29 18:09 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1769710178753829)
> @Whitney Hodges Today we had Julie &amp; Taylor (Barnwood Events WI) and Diana (Luxe Whitening Lounge) attend office hours.
> **Whitney Hodges** · 2026-01-29 18:28 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1769711311671799)
> @Christina Hill Awesome! How are they doing?
> **Christina Hill** · 2026-01-29 18:40 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1769712040610129)
> Both are doing great. Good ad performance. They came online for tech support. Barnwood needed a redirect created for their honeybook forms and Luxe had a website indexing issue that Carmen helped solve 
> **Christina Hill** · 2026-01-29 18:40 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1769712050062169)
> @Whitney Hodges :arrow_up:

**Carmen Cruickshank** · 2026-01-29 18:11 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1769710266612129)
@Whitney Hodges for more info i gave her suggestions to have FAQ's in her page and "who this is for who this is not for" on her site, i also told her that since Google ads are more generic, when people search for "wedding planner" they're not expecting to see a super high end wedding designer, so i told her ill make sure the ad copy reflects that and I told her updating the ad copy on site to bridge that gap would help, also doing meta ads would probably be more effective for her since her service is very high end and visual, i added extra conversion tracking to see how many people are going to contact page, and cleaned up things overall on her account on Jan 15
> **Carmen Cruickshank** · 2026-01-29 18:12 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1769710337420719)
> i also told her to add a heatmap to her site to what what's going on. she id have i think a 50% bounce rate on her site

**Notification Bot** · 2026-02-02 21:02 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1770066175624639)
Jillian  Dalu-Ford has joined on for the Google Search Accelerator! :tada:

**Notification Bot** · 2026-02-09 19:25 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1770665122614219)
Alexis Gaston has joined on for the Google Search Accelerator! :tada:

**Carmen Cruickshank** · 2026-02-12 19:24 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1770924298491529)
@Gisselle Jiménez @Whitney Hodges Hi! Google ads office hours went well today, helped answer Jillian's questions about upcoming VIP Day, Erin get clarity on improving conversion rate by. a possible A/B split test of a shorter form, and Diana with boosting conversions by switching from max clicks to conversions.
> **Whitney Hodges** · 2026-02-12 19:28 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1770924511983159)
> @Gisselle Jiménez do we post each office hours recording in the GSA discussion or just add the recording to the course? I think it would be good to do a post with a recap like what Carmen just mentioned if we aren't already. Same thing on the MAA side. Thanks!!
> **Gisselle Jiménez** · 2026-02-12 19:54 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1770926088915789)
> @Whitney Hodges Currently, just the recording, but yes, I think that would be good!
> 
> Should we do it under the 1-hour announcement post? Let me know if something like this work:
> 
> &gt; @everyone Here's the recording from today's Google Ads Office Hours with @Carmen Cruickshank!
> &gt; Carmen worked with Jillian on prepping for her upcoming VIP Day, helped Erin explore A/B testing a shorter form to improve conversion rates, and guided Diana on switching from max clicks to conversions to boost results.
> &gt; Check out the recording here: Link
> 
> **Whitney Hodges** · 2026-02-12 20:00 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1770926437331969)
> @Gisselle Jiménez we could do that or we could create a new post and actually have the video attached to the post. What do you think? @Carmen Cruickshank thoughts?
> **Carmen Cruickshank** · 2026-02-12 20:16 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1770927398119089)
> thats a good idea cause its easily accessible when the video is embedded @Whitney Hodges
> **Carmen Cruickshank** · 2026-02-12 20:17 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1770927437392089)
> and the only edit i would make to that post is from "max clicks to conversions" to "maximize Clicks to Conversions while ensuring proper maintenance on ads" or something like that
> **Gisselle Jiménez** · 2026-02-12 20:19 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1770927566499799)
> Thank you, @Carmen Cruickshank! Will doo

**Carmen Cruickshank** · 2026-02-12 19:24 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1770924299695729)
<https://fathom.video/share/Cryvtr44zga6NY-5Lggfc9wJEHCzBpsM>

**Carmen Cruickshank** · 2026-02-12 19:29 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1770924549234669)
also @Whitney Hodges, Erin said out of the 2 new bookings, one of them was the BIGGEST wedding shes ever booked

**Gisselle Jiménez** · 2026-02-12 19:53 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1770926010017579)
Thank you, @Carmen Cruickshank! Could you please share the recording? I'm not able to download it from fathom link. :face_holding_back_tears:
> **Carmen Cruickshank** · 2026-02-12 20:18 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1770927502374969)
> @Gisselle Jiménez do you mean download it and put it here?
> **Gisselle Jiménez** · 2026-02-12 20:19 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1770927574785419)
> @Carmen Cruickshank Yes, please!
> **Gisselle Jiménez** · 2026-02-12 20:20 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1770927610743689)
> You can also upload it directly here: <https://drive.google.com/drive/folders/1T66RBu53fyQu-KzaMYK0DOCfjBda_UYQ?usp=drive_link>

**Carmen Cruickshank** · 2026-02-12 20:23 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1770927805701639)
@Gisselle Jiménez let me know if you can access this!
📎 Google Ads Office Hours  - 2.12.26 - Feb 12 2026.mp4 (mp4, **not downloaded** — over cap (301.6 MB), [fetch it](https://files.slack.com/files-pri/T03P5A3L1DK-F0AF3JGNHR7/download/google_ads_office_hours___-_2.12.26_-_feb_12_2026.mp4))
> **Gisselle Jiménez** · 2026-02-12 20:32 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1770928345982759)
> Yes, thankss!
> **Gisselle Jiménez** · 2026-02-12 20:50 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1770929406570249)
> Posted:white_check_mark:

**Gisselle Jiménez** · 2026-02-13 19:17 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1771010278436759)
Hi, @Carmen Cruickshank and @Whitney Hodges! Here is the Google Ads Tracking Request Page for your review. I also created the Google Ads tracking request pipeline for this. Let me know if anything needs to be changed.

• <https://weddingindustryads.com/google-ads-tracking-request-page|Submit ticket page>
    ◦ <https://app.leadlockpro.com/v2/location/Xi40zxmRvW8Pbyk5DYHp/funnels-websites/funnels/DKRk9KeQfrlBMimpCbvu/steps|Funnel>
    ◦ <https://weddingindustryads.com/google-ads-tracking-request-received|Confirmation>
• <https://app.leadlockpro.com/location/Xi40zxmRvW8Pbyk5DYHp/workflow/b007898a-50f4-46e6-a7bb-51e601f3d4f8|Automation>

**Notification Bot** · 2026-02-16 22:27 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1771280821085209)
Lora Taub has joined on for the Google Search Accelerator! :tada:

**Notification Bot** · 2026-02-18 17:26 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1771435614932789)
Krista Lax has joined on for the Google Search Accelerator! :tada:

**Carmen Cruickshank** · 2026-03-03 14:29 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1772548197252619)
Hey @Gisselle Jiménez! Love this email being sent out 1 day before the VIP day, i was wondering if the fact that they need to check for availability on their calendar for a second call that day cause 70-80% of the time when i tell tell them there's a second call that day, they're suprised and sometimes we have the second call the next day cc: @Whitney Hodges
📎 Screenshot 2026-03-03 at 9.27.58 AM.png (png, saved as `files/F0AJ59FU2N9-Screenshot_2026-03-03_at_9.27.58_AM.png`)
> **Whitney Hodges** · 2026-03-03 17:13 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1772558024577349)
> @Carmen Cruickshank Thanks for this feedback! I thought we made it pretty clear that there are two calls for the VIP Day, so I appreciate the heads up that people are often surprised about it.
> 
> I wonder if there's a way for us to automatically book the second call four hours later or so?
> 
> I'd love to hear your thoughts on that approach, Carmen
> 
> cc @Gisselle Jiménez
> **Carmen Cruickshank** · 2026-03-04 16:36 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1772642163685479)
> @Whitney Hodges Hi! Yes that sounds good, to have the other call booked for 4 hours later
> **Whitney Hodges** · 2026-03-04 17:10 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1772644224327899)
> @Gisselle Jiménez Is there a way to automate this in the workflow?
> **Gisselle Jiménez** · 2026-03-04 17:33 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1772645628008459)
> @Whitney Hodges Let me check!

**Carmen Cruickshank** · 2026-03-05 21:09 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1772744963288969)
@Gisselle Jiménez Hi! So for today's google office hours, it was Krista on the call (the most recent VIP Day from 2 days ago, Dear Jane Photography) and we went over her account, i let her know that since her account is still new and in the learning mode that not having a ton of clicks is expected but it should pick up soon, everything was looking relevant for search traffic and we were just checking the account.
> **Gisselle Jiménez** · 2026-03-06 15:24 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1772810695795469)
> Thank you!! Published:white_check_mark:

**Carmen Cruickshank** · 2026-03-05 21:09 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1772744998598759)
📎 Google Ads Office Hours - 3.05.26 - Mar 5 2026.mp4 (mp4, **not downloaded** — over cap (73 MB), [fetch it](https://files.slack.com/files-pri/T03P5A3L1DK-F0AJRN819V3/download/google_ads_office_hours_-_3.05.26_-_mar_5_2026.mp4))

**Whitney Hodges** · 2026-03-12 15:32 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1773329548678189)
@Carmen Cruickshank Hi! Erin asked a question in the VAULT yesterday. Can you please respond to her today?
📎 image.png (png, saved as `files/F0AL49GK2BX-image.png`)

**Whitney Hodges** · 2026-03-12 15:39 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1773329957280899)
@Carmen Cruickshank Also, Krista sent me these DMs this morning. I'll work on a reply to her, but can you also take a look at what she has sent you and please get back to her? Please fill me in on what she said and your response.

I'm seeing an opportunity for us in the VAULT curriculum to set better expectations about the time it may take to see results and not to freak out unnecessarily.

I feel like with VIP Days, when we used to have the two week follow-up call, we'd advise clients to not even look at the ads until that call because they need time to spend/learn. Maybe we need to revisit this?

Looking forward to your thoughts!
📎 image.png (png, saved as `files/F0AL7N984DQ-image.png`)
📎 image.png (png, saved as `files/F0AKS9B618F-image.png`)
> **Whitney Hodges** · 2026-03-12 15:52 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1773330740434149)
> @Carmen Cruickshank This was my response to Krista:
> 
> Hi Krista! Thanks so much for reaching out! I’m really glad you did. I know it can feel stressful when the ads are new and you’re not seeing leads yet, but based on what you shared nothing here is raising red flags so far.
> You’ve only spent about $162 and you’re getting clicks around $3.23, which is actually a very normal CPC for the wedding industry. At this stage the campaign is still very much in the “data gathering” phase. It usually takes a bit more spend and time for Google to optimize and for patterns to start emerging.
> Not getting a lead in the at this point isn’t unusual. What we’re really looking for first is that people _are_ clicking and the cost per click is reasonable, which it is in your case.
> On the images: you’re correct that sometimes newer accounts won’t have access to all asset types right away, so that may be why you’re not seeing that option yet. Once the account has a little more history, Google usually unlocks additional features.
> Carmen actually has Google Ads office hours starting in just a few minutes today. If you’re able to hop on, that would be the perfect place to look at your account together and troubleshoot anything in real time. She can walk through your campaign and make sure everything looks good.
> You’re definitely not wasting money. You’re still very early in the testing phase. Hang in there and let’s get Carmen’s eyes on it during office hours if you can!
> **Carmen Cruickshank** · 2026-03-12 15:58 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1773331122046359)
> this is a great response, i completely agree. she is now getting 8-10 clicks per day so things are going well ill update her with this

**Carmen Cruickshank** · 2026-03-12 15:55 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1773330924765129)
I just saw this, im going to reply to her now in the vault

**Carmen Cruickshank** · 2026-03-12 15:55 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1773330957607659)
we could revisit this with the 2 week follow up call and give them reassurance
> **Whitney Hodges** · 2026-03-12 15:59 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1773331153499309)
> @Carmen Cruickshank It could be a 1:1 2 week follow-up call. Or it could just be that we advise that the first office hours they attend is about two weeks following their VIP Day. More like we're advising just let the account spend at least a couple of hundred dollars before digging into the data and making adjustments. Normalizing  that you may not get leads right away and it's nothing to freak out about

**Carmen Cruickshank** · 2026-03-12 15:56 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1773330965418909)
ill see your response

**Carmen Cruickshank** · 2026-03-12 17:44 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1773337481779169)
@Gisselle Jiménez Hi! Heres my office hours summary: Carmen advised Jillian on how to share her unpublished landing pages for review by sending a preview link or copying the page content, and they also discussed preparing for their upcoming VIP Day event. With Erin, Carmen helped plan a *summer wedding ad campaign*, recommending a $5–$10/day display campaign with summer/garden imagery and the creation of a dedicated summer weddings landing page starting in April.
📎 Google Ads Office Hours  - 3.12.26 - Mar 12 2026.mp4 (mp4, **not downloaded** — over cap (85.3 MB), [fetch it](https://files.slack.com/files-pri/T03P5A3L1DK-F0AL2FPGTMH/download/google_ads_office_hours___-_3.12.26_-_mar_12_2026.mp4))
> **Gisselle Jiménez** · 2026-03-12 21:13 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1773350038287049)
> Thank you!! Published:white_check_mark:

**Carmen Cruickshank** · 2026-03-12 18:15 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1773339339172729)
@Whitney Hodges This is what Krista said: The ads do not seem to be doing well at all. Do you have any idea when they will pick up? I have no where near 10 clicks a day (42 total over the course of 8 days and the CPC is over $3 when you said we were shooting between 1-2. I just feel like I am wasting money at this point, maybe we can pause them until we figure out what's going on?

**Carmen Cruickshank** · 2026-03-12 18:15 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1773339357531679)
I said: Hi Krista, I apologize for my late response. I understand the concern. I will send you an in depth response after office hours or if you want to come on the call we can talk about it.  (Message 2) I completely understand the concern when the numbers don’t look exactly how we hoped right away.
Since Sunday, which is about the past 4 to 5 days, the ads have actually been getting around 8 to 10 clicks consistently, which is a good sign that people are finding and engaging with them. The $1 to $2 CPC I mentioned earlier was more of a general lower end benchmark, but costs can vary depending on the market and location, so a slightly higher CPC is not unusual.
Right now the campaign is still in the early testing and learning phase. Google Ads typically needs at least a couple of weeks of data, and often closer to 30 to 90 days, before it fully optimizes and we can clearly see performance trends.
I also initially set the campaign to Maximize Clicks, which is intentional at the start. This strategy helps generate traffic and confirm we are attracting the right audience. Later on we typically shift the campaign to Maximize Conversions (leads) once enough data has been collected. While we are in the Maximize Clicks phase it does not mean you will not get leads, it just means Google is currently prioritizing traffic while it learns. As the data builds, we should start seeing more consistent inquiries coming in.
Based on what I am seeing so far, nothing is indicating a problem with the campaign. It is very normal for performance to fluctuate a bit in the first couple of weeks while Google is learning who is most likely to click and inquire. We will keep monitoring things closely as the data builds and adjust as needed.

**Carmen Cruickshank** · 2026-03-16 16:01 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1773676904116899)
@Whitney Hodges Hi! Just curious if Krista responded to you, i haven't heard anything from her, wanted to know her thoughts

**Whitney Hodges** · 2026-03-17 16:47 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1773766076875399)
@Gisselle Jiménez Hi! Can you please drop here the form that you had created for Google Ads tracking changes? I want to take a look again and see about adding it to the vault. Thank you!

cc @Carmen Cruickshank

**Gisselle Jiménez** · 2026-03-17 18:03 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1773770588611639)
@Whitney Hodges Here it is:

• <https://weddingindustryads.com/google-ads-tracking-request-page|Submit ticket page>
    ◦ <https://app.leadlockpro.com/v2/location/Xi40zxmRvW8Pbyk5DYHp/funnels-websites/funnels/DKRk9KeQfrlBMimpCbvu/steps|Funnel>
    ◦ <https://weddingindustryads.com/google-ads-tracking-request-received|Confirmation>
• <https://app.leadlockpro.com/location/Xi40zxmRvW8Pbyk5DYHp/workflow/b007898a-50f4-46e6-a7bb-51e601f3d4f8|Automation>


**Carmen Cruickshank** · 2026-03-19 16:59 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1773939564595599)
@Gisselle Jiménez Hi! My VIP Day is about to start and im trying to get the download but ill get that soon
> **Gisselle Jiménez** · 2026-03-19 19:36 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1773948993786299)
> Thank you! Just share the video and summary when you can. I'm not able to download it from the link:face_holding_back_tears:
> **Carmen Cruickshank** · 2026-03-19 20:45 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1773953111007239)
> no worries, doing it now

**Carmen Cruickshank** · 2026-03-19 16:59 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1773939575078829)
heres the link if you can access it: <https://fathom.video/calls/607620714>

**Carmen Cruickshank** · 2026-03-19 16:59 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1773939591932219)
no one came, but at the end i made a video updating Krista on her ads and changes i made

**Carmen Cruickshank** · 2026-03-19 20:53 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1773953596987799)
Heres the recording for Krista. I went over her account, if you could cut out a bit of the first seconds as i was setting things up and the last seconds before i ended the recording. Summary: Carmen reviewed Krista’s keywords and paused a few that were not performing well to help strengthen overall campaign performance. She also updated the Microsoft Clarity tracking to help ensure recordings are being captured accurately and are available for review during next week’s office hours. In addition, the “Unknown” age group was excluded to help improve traffic quality.
📎 Impromptu Zoom Meeting - Mar 19 2026.mp4 (mp4, **not downloaded** — over cap (41.4 MB), [fetch it](https://files.slack.com/files-pri/T03P5A3L1DK-F0AMJHCAL11/download/impromptu_zoom_meeting_-_mar_19_2026.mp4))
> **Gisselle Jiménez** · 2026-03-20 13:52 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1774014757557379)
> Thank you so much! Video was trimmed and posted. :blob-bear-dance:

**Carmen Cruickshank** · 2026-03-19 22:24 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1773959094783769)
Update, VIP Day went very well with Jillian. I clarified with her about the communication in the Vault for the follow up, 72 hour follow up and future. I also clarified about expecting a good testing phase for the first 2-4 weeks and everything looked like it clicked with her. She's rly excited and looking forward to learning.:partying_face:

**Whitney Hodges** · 2026-03-25 15:32 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1774452735801879)
@Carmen Cruickshank Hi! I just got this DM from Krista.
📎 image.png (png, saved as `files/F0ANRQW5Y1L-image.png`)

**Whitney Hodges** · 2026-03-25 15:32 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1774452765501039)
📎 image.png (png, saved as `files/F0ANTT2D5U2-image.png`)

**Whitney Hodges** · 2026-03-25 15:33 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1774452794565669)
@Carmen Cruickshank Is it time to switch to Maximize Conversions? Has she sent you any DMs?

**Carmen Cruickshank** · 2026-03-25 16:44 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1774457045278789)
@Whitney Hodges Hi! thank you for updating me on this, not sure why she hasn't reached out to me about this, i'll check her microsoft clarity too, i'll get back to you if its time to switch to max conversions but i might just do this anyway because nothing can really go wrong, ill update you

**Carmen Cruickshank** · 2026-03-25 18:26 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1774463219649049)
@Whitney Hodges Hey! I took a deeper look at Dear Jane’s landing page performance and wanted to share a quick update.
Overall bounce rate is showing ~98%, but that’s largely coming from Meta traffic. From Google specifically, bounce rate is around 43%, which is still a bit high but much more reasonable.
Looking at session recordings, most users aren’t getting past the hero section, which tells me the main issue is how quickly the page communicates what she does and builds trust.
She did get her first lead from Google Ads on March 22, so that’s a great sign that the campaign is working. Would definitely be good to hear how that lead went.
I put together <https://docs.google.com/document/d/14abxdIzBvhNzXsvNyAgArHijSvbqovDR1WzFmC1dWbw/edit?tab=t.0#heading=h.1qvgheiiv14o|a doc with a few focused recommendations> to improve the landing page (mainly simplifying the hero, adding early trust, and making the content easier to scan).
I don’t recommend switching to Max Conversions just yet. With the current bounce rate and limited conversion data, it likely wouldn’t perform better. Ideally, we want at least a few more conversions (2–4+) and stronger on-page engagement before making that shift.
I think she may be running Meta ads on her own, which could be contributing to the higher overall bounce rate. Let me know your thoughts!
> **Whitney Hodges** · 2026-03-25 22:50 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1774479026703129)
> @Carmen Cruickshank So helpful! Thank you so much! I just sent the message below to Krista. Let's see if she attends office hours tomorrow. If not, you can post the doc with recommendations in the landing page feedback channel and tag her. I requested access, so I haven't checked it out yet. Just be sure to make it so anyone can view it before you post it. Thank you!!
> **Carmen Cruickshank** · 2026-03-26 15:36 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1774539360796969)
> @Whitney Hodges Glad this was helpful! ill share the doc on a post if she doesn't show up on office hours, your welcome!

**Carmen Cruickshank** · 2026-03-26 17:11 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1774545079372789)
@Gisselle Jiménez Hi! Here's is the recording from today's office hours. Summary: Carmen helped Jillian with advertiser verification on Google ads, removing negative keywords and doing it in an efficient way, as well as going more in depth of the value of Google My Business to build trust of potential clients. You can cut the last 20 minutes, that was just me on mute.
📎 Google Ads Office Hours  - 03.26.26 - Mar 26 2026.mp4 (mp4, **not downloaded** — over cap (135.2 MB), [fetch it](https://files.slack.com/files-pri/T03P5A3L1DK-F0AP0F24B1T/download/google_ads_office_hours___-_03.26.26_-_mar_26_2026.mp4))
> **Gisselle Jiménez** · 2026-03-27 15:07 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1774624057298939)
> Thank you! Edited and published:white_check_mark:

**Carmen Cruickshank** · 2026-04-02 18:57 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1775156259752939)
@Gisselle Jiménez Hi! Here's the summary of Google Ads OH: Carmen helped Jillian review her account, including switching from Maximize Clicks to Maximize Conversions. She also walked through ways to build trust with cold traffic, specifically by adding a video to the landing page and what that could look like. They also reviewed Microsoft Clarity to better understand how users are interacting with the site.
Erin asked about her summer landing page, and Carmen provided feedback on potential improvements. They also reviewed an upcoming display campaign focused on summer garden weddings at her NYC venue.
Carmen reviewed Krista’s Google Ads account and identified that the main opportunity right now is improving landing page retention. This may include updating the hero image and headline for better readability, since the current black-and-white image with white text can be difficult to read, as well as adjusting the location font. Retention is the primary focus moving forward. Additional tracking, like scroll depth (for example, 50%), could also be implemented to better understand user behavior.
Carmen also reviewed Beth’s ads for her luxury travel boutique. Performance is strong, with relevant traffic coming to the site. Increasing the budget would likely help generate more leads and provide more data on user behavior. It was also suggested to add a “Benefits of working with us” section on the landing page, summarizing key points from the video into clear bullet points to better connect the offer to the client’s desires.

**Carmen Cruickshank** · 2026-04-02 19:00 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1775156447204779)
📎 Google Ads Office Hours - 04.02.26 - Apr 2 2026.mp4 (mp4, **not downloaded** — over cap (376.4 MB), [fetch it](https://files.slack.com/files-pri/T03P5A3L1DK-F0AREMEP3Q8/download/google_ads_office_hours_-_04.02.26_-_apr_2_2026.mp4))
> **Whitney Hodges** · 2026-04-03 17:52 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1775238730205829)
> @Gisselle Jiménez I posted this in the Discussion, but it needs to be uploaded to the Office Hours course. Thanks!!
> **Gisselle Jiménez** · 2026-04-06 16:00 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1775491205798139)
> Published! :white_check_mark:

**Gisselle Jiménez** · 2026-04-09 21:23 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1775769837241149)
Hi, @Carmen Cruickshank! Did you hold Office hours today?

**Carmen Cruickshank** · 2026-04-09 22:01 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1775772094420439)
yes! here is the recording and the summary: Carmen helped review *Jillian’s* account, where performance is strong and multiple appointments are coming in after the shift from Maximize Clicks to Maximize Conversions.
Carmen also reviewed *Krista’s* account and identified that performance is currently being limited by landing page engagement. The next step is to run a split test with a new landing page. Additionally, a missing ad image was flagged as a priority to resolve with Google support, as it may be impacting overall performance.
For *Felipe*, Carmen reviewed the account and identified key opportunities for improvement. The primary focus is optimizing the landing page to improve clarity and build trust, which should help reduce drop-off and increase lead quality. Once those improvements are in place, the plan is to increase the budget slightly to gather more data and continue refining performance.
📎 Google Ads Office Hours - 04.09.26 - Apr 9 2026.mp4 (mp4, **not downloaded** — over cap (304.6 MB), [fetch it](https://files.slack.com/files-pri/T03P5A3L1DK-F0ASBS5GYRX/download/google_ads_office_hours_-_04.09.26_-_apr_9_2026.mp4))
> **Gisselle Jiménez** · 2026-04-10 15:52 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1775836344375079)
> Thank you!! Uploaded and posted!

**Carmen Cruickshank** · 2026-04-16 17:43 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1776361411935539)
@Gisselle Jiménez Hi! here's the summary for the office hours today: Carmen worked with Felipe to review the account overall, set expectations for a potential landing page split test in the near future, and discuss best practices for promoting an upcoming offer. She also connected with Erin at Carroll Hall to review results and data from a recent split test, outline next steps, and assess performance from the newly launched Display campaign. Additionally, Carmen reviewed Alexis’ account for Karis Concepts, identifying the landing page as the primary bottleneck. She expressed interest in the upcoming landing page updates and recommended implementing Microsoft Clarity to gain deeper insights into visitor behavior.
📎 Google Ads Office Hours - 04.16.26 - Apr 16 2026.mp4 (mp4, **not downloaded** — over cap (213.2 MB), [fetch it](https://files.slack.com/files-pri/T03P5A3L1DK-F0ATF3TSVTL/download/google_ads_office_hours_-_04.16.26_-_apr_16_2026.mp4))
> **Gisselle Jiménez** · 2026-04-16 20:08 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1776370130590169)
> Thank you!! Posted:white_check_mark:

**Carmen Cruickshank** · 2026-04-23 17:13 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1776964434596079)
@Gisselle Jiménez Hi! heres the summary of office hours today as well as the recording. *Summary:* Carmen reviewed Lora's account following launch earlier this week and everything is looking clean with a solid click through rate and strong views on the inquiry page. Next steps include reviewing Microsoft Clarity for behavioral insights and optimizing the campaign settings for leads.
Carmen also checked in on Jillian's account, where the main update was removing the "Unknown" category to prevent bot clicks. They also looked over Microsoft Clarity to better understand how visitors are engaging with and scrolling through the page.
📎 Google Ads Office Hours - 04.23.26 - Apr 23 2026.mp4 (mp4, **not downloaded** — over cap (119.7 MB), [fetch it](https://files.slack.com/files-pri/T03P5A3L1DK-F0AUEUEUUDV/download/google_ads_office_hours_-_04.23.26_-_apr_23_2026.mp4))
> **Gisselle Jiménez** · 2026-04-23 19:21 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1776972097486289)
> Thank you! Posted:white_check_mark:

**Gisselle Jiménez** · 2026-04-26 16:27 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1777220842724059)
Jillian Dalu-Ford completed the Google Search Accelerator Check-in Survey!:star2: 
> **Gisselle Jiménez** · 2026-04-27 15:55 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1777305319600429)
> Hi team! Here is Jillian's survey:blob-bear-dance:
> 📎 GSA Check-in Survey - Esthetics by Jillian.pdf (pdf, saved as `files/F0B02MYVA78-GSA_Check-in_Survey_-_Esthetics_by_Jillian.pdf`)

**Gisselle Jiménez** · 2026-04-30 16:46 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1777567568426749)
Alexis Gaston completed the Google Search Accelerator Check-in Survey!:star2: 
> **Gisselle Jiménez** · 2026-04-30 17:31 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1777570278804569)
> Alexis' survey!
> 📎 7a04d7b2-c865-42dc-83e9-fffa49bf8bb9.pdf (pdf, saved as `files/F0B0V337WF7-7a04d7b2-c865-42dc-83e9-fffa49bf8bb9.pdf`)

**Carmen Cruickshank** · 2026-04-30 17:58 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1777571905203639)
@Gisselle Jiménez Hi! Here's the summary for today's google office hours: Carmen help Felipe with questions regarding over all ad performance, VEO, and next future steps. Erin got help with clarity on where budget should be allocated with what campaign over the next months with 1-2 new campaigns being added to the account.
📎 Google Ads Office Hours - 04.30.26 - Apr 30 2026.mp4 (mp4, **not downloaded** — over cap (201.7 MB), [fetch it](https://files.slack.com/files-pri/T03P5A3L1DK-F0B0S9N0GLB/download/google_ads_office_hours_-_04.30.26_-_apr_30_2026.mp4))
> **Gisselle Jiménez** · 2026-04-30 21:10 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1777583413179249)
> Thank you! Published

**Whitney Hodges** · 2026-05-06 19:02 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1778094164905429)
@Carmen Cruickshank Hi! I wanted to check in with you re: Erin with Carroll Hall. She had a meeting with Daniela recently for us to do a bit of market research. She mentioned wanting to launch some non-wedding campaigns. It sounds like this came up during the last office hours call, too. I was planning to reach out to her to see if she wanted to schedule a follow up VIP Day for us to launch another campaign or two for her. Just wanted to loop you in and get your thoughts first. Thank you!!

**Carmen Cruickshank** · 2026-05-06 21:42 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1778103743600439)
@Whitney Hodges Hi! Yes i believe she mentioned having the summer promo which is a simple demand gen campaign that i walked her through how to do, she verbally said she's comfortable creating that. I believe she also wanted to make another campaign for corporate events during the weekdays, i can help her by doing a VIP Day for that if that's what she mentioned

**Carmen Cruickshank** · 2026-05-07 18:22 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1778178159111379)
@Gisselle Jiménez Hi! here's the summary for todays call: Carmen helped Lora at Hartlot Happening with diagnosing any issues in the account as well as fine-tuning conversion trackings and turning off auto-apply recommendations from Google. Carmen also helped Felipe at Luxury Travel Boutique create a performance max campaign for an air credit promo.
📎 Google Ads Office Hours - 05.07.26 - May 7 2026.mp4 (mp4, **not downloaded** — over cap (208.5 MB), [fetch it](https://files.slack.com/files-pri/T03P5A3L1DK-F0B2BSDA23U/download/google_ads_office_hours_-_05.07.26_-_may_7_2026.mp4))
> **Gisselle Jiménez** · 2026-05-07 20:19 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1778185178409049)
> Thank you! Posted :white_check_mark: I'm also just realizing it's Hartlot Happening with a T...
> I'm going to update all her docs lol

**Carmen Cruickshank** · 2026-05-21 18:20 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1779387658495569)
@Gisselle Jiménez Hi! Here's the summary of todays office hours: Carmen reviewed Lora's landing page and ad platform for performance improvement opportunities, supported Jillian with a performance review, Microsoft Clarity analysis, and future ad strategy discussion, and followed up on Erin's recently launched Corporate Events and Demand Gen summer promotion campaigns.
📎 Google Ads Office Hours - 05.20.26 - May 21 2026.mp4 (mp4, **not downloaded** — over cap (292 MB), [fetch it](https://files.slack.com/files-pri/T03P5A3L1DK-F0B57RAJNBV/download/google_ads_office_hours_-_05.20.26_-_may_21_2026.mp4))
> **Gisselle Jiménez** · 2026-05-21 20:07 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1779394068949999)
> Thank you! Posted:white_check_mark:

**Carmen Cruickshank** · 2026-05-28 15:54 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1779983684208599)
@Fallon Looney @Whitney Hodges Hi! I'm sorry for the short notice, typing this message in my phone but my computer has been acting up the past few days to where I can use safari because nothing loads, so I've using Chrome but I can't load Chrome today or my Google Calendar to properly help our clients in office hours today, should we cancel it or Fallon do you think you could step in? I can try to join on zoom on my phone if you're able to share your screen

**Carmen Cruickshank** · 2026-05-28 15:55 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1779983704717189)
I tried fixing the WiFi issue using the personal hotspot from my phone and it’s not working

**Carmen Cruickshank** · 2026-05-28 16:00 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1779984038124779)
cc: @Gisselle Jiménez

**Fallon Looney** · 2026-05-28 16:17 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1779985049905869)
Just confirming I am jumping on to support Carmen :slightly_smiling_face:

**Whitney Hodges** · 2026-05-28 16:36 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1779986189565329)
@Carmen Cruickshank @Fallon Looney just saw this! Thank you both!!

**Carmen Cruickshank** · 2026-05-28 18:59 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1779994741999399)
@Gisselle Jiménez Hi! i couldn't retrieve the recording but i just helped Felipe with auditing any issues with the ads by assessing metrics, viewing microsoft clarity recordings and assessing site speed.

**Carmen Cruickshank** · 2026-06-01 15:48 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1780328927727329)
Google Ads Weekly Meeting - June 01

*<https://fathom.video/share/hXto5Dt274z2maKtvjXN3myiKDXPAq9y|VIEW RECORDING - 42 mins (No highlights)>*
Meeting Purpose
<https://fathom.video/share/hXto5Dt274z2maKtvjXN3myiKDXPAq9y?tab=summary&amp;timestamp=28.0|Review Google Ads performance and align on client transitions.>
Key Takeaways
• *<https://fathom.video/share/hXto5Dt274z2maKtvjXN3myiKDXPAq9y?tab=summary&amp;timestamp=782.0|Destination Wedding Planner:>*<https://fathom.video/share/hXto5Dt274z2maKtvjXN3myiKDXPAq9y?tab=summary&amp;timestamp=782.0| Google Ads underperform due to a vague landing page headline ("Find the perfect venue"). The fix is to use clear, direct messaging from high-performing Meta ads to set user expectations.>
• *<https://fathom.video/share/hXto5Dt274z2maKtvjXN3myiKDXPAq9y?tab=summary&amp;timestamp=933.0|Davis and Gray Farms:>*<https://fathom.video/share/hXto5Dt274z2maKtvjXN3myiKDXPAq9y?tab=summary&amp;timestamp=933.0| High tour cancellations (55%) are a funnel issue, not an ad problem. The fix involves clarifying the landing page and narrowing geo-targeting to reduce travel-related cancellations.>
• *<https://fathom.video/share/hXto5Dt274z2maKtvjXN3myiKDXPAq9y?tab=summary&amp;timestamp=1626.0|Client Transition Plan:>*<https://fathom.video/share/hXto5Dt274z2maKtvjXN3myiKDXPAq9y?tab=summary&amp;timestamp=1626.0| To manage Fallon's onboarding load, transitions will be staggered: Exquisite Moments this week, Diamond Day Ranch after its June 10 strategy call, and Ridgefield after its ad launch.>
• *<https://fathom.video/share/hXto5Dt274z2maKtvjXN3myiKDXPAq9y?tab=summary&amp;timestamp=2391.0|VIP Day Prep:>*<https://fathom.video/share/hXto5Dt274z2maKtvjXN3myiKDXPAq9y?tab=summary&amp;timestamp=2391.0| Carmen will send Fallon a Loom video detailing the prep process for the "Love Like Wild" VIP day, enabling Fallon to shadow asynchronously.>
Topics
Client Performance &amp; Strategy
• *<https://fathom.video/share/hXto5Dt274z2maKtvjXN3myiKDXPAq9y?tab=summary&amp;timestamp=38.0|Destination Wedding Planner (Felipe):>*
    ◦ *<https://fathom.video/share/hXto5Dt274z2maKtvjXN3myiKDXPAq9y?tab=summary&amp;timestamp=593.0|Problem:>*<https://fathom.video/share/hXto5Dt274z2maKtvjXN3myiKDXPAq9y?tab=summary&amp;timestamp=593.0| Google Ads consistently underperform, while Meta Ads are effective ($21 CPL).>
    ◦ *<https://fathom.video/share/hXto5Dt274z2maKtvjXN3myiKDXPAq9y?tab=summary&amp;timestamp=203.0|Analysis:>*<https://fathom.video/share/hXto5Dt274z2maKtvjXN3myiKDXPAq9y?tab=summary&amp;timestamp=203.0| The Google Ads landing page headline is vague ("Find the perfect venue"), causing user confusion and high bounce rates.>
    ◦ *<https://fathom.video/share/hXto5Dt274z2maKtvjXN3myiKDXPAq9y?tab=summary&amp;timestamp=782.0|Solution:>*<https://fathom.video/share/hXto5Dt274z2maKtvjXN3myiKDXPAq9y?tab=summary&amp;timestamp=782.0| Adopt the direct, value-driven messaging from the successful Meta ads for the landing page headline.>
        ▪︎ *<https://fathom.video/share/hXto5Dt274z2maKtvjXN3myiKDXPAq9y?tab=summary&amp;timestamp=720.0|Meta Ad Messaging:>*<https://fathom.video/share/hXto5Dt274z2maKtvjXN3myiKDXPAq9y?tab=summary&amp;timestamp=720.0| "Destination wedding planner and travel agent... simplifies the whole process... no cost to work with me.">
        ▪︎ *<https://fathom.video/share/hXto5Dt274z2maKtvjXN3myiKDXPAq9y?tab=summary&amp;timestamp=297.0|Google LP Headline:>*<https://fathom.video/share/hXto5Dt274z2maKtvjXN3myiKDXPAq9y?tab=summary&amp;timestamp=297.0| "Destination Wedding Planner &amp; Travel Agent for Mexico &amp; the Caribbean.">
• *<https://fathom.video/share/hXto5Dt274z2maKtvjXN3myiKDXPAq9y?tab=summary&amp;timestamp=933.0|Davis and Gray Farms (Jill):>*
    ◦ *<https://fathom.video/share/hXto5Dt274z2maKtvjXN3myiKDXPAq9y?tab=summary&amp;timestamp=1031.0|Problem:>*<https://fathom.video/share/hXto5Dt274z2maKtvjXN3myiKDXPAq9y?tab=summary&amp;timestamp=1031.0| High tour cancellation rate (55%) is impacting conversion.>
    ◦ *<https://fathom.video/share/hXto5Dt274z2maKtvjXN3myiKDXPAq9y?tab=summary&amp;timestamp=1101.0|Analysis:>*<https://fathom.video/share/hXto5Dt274z2maKtvjXN3myiKDXPAq9y?tab=summary&amp;timestamp=1101.0| The issue is a deeper-funnel problem, not ad performance.>
        ▪︎ *<https://fathom.video/share/hXto5Dt274z2maKtvjXN3myiKDXPAq9y?tab=summary&amp;timestamp=989.0|Landing Page:>*<https://fathom.video/share/hXto5Dt274z2maKtvjXN3myiKDXPAq9y?tab=summary&amp;timestamp=989.0| Lacks a clear, 3-step process from the organic site, which could improve clarity.>
        ▪︎ *<https://fathom.video/share/hXto5Dt274z2maKtvjXN3myiKDXPAq9y?tab=summary&amp;timestamp=1070.0|Geo-Targeting:>*<https://fathom.video/share/hXto5Dt274z2maKtvjXN3myiKDXPAq9y?tab=summary&amp;timestamp=1070.0| Leads are canceling because the venue is too far.>
    ◦ *<https://fathom.video/share/hXto5Dt274z2maKtvjXN3myiKDXPAq9y?tab=summary&amp;timestamp=1070.0|Solution:>*<https://fathom.video/share/hXto5Dt274z2maKtvjXN3myiKDXPAq9y?tab=summary&amp;timestamp=1070.0| Narrow geo-targeting using zip codes from the client and add the 3-step process to the landing page.>
• *<https://fathom.video/share/hXto5Dt274z2maKtvjXN3myiKDXPAq9y?tab=summary&amp;timestamp=1184.0|DJ Hybrid:>*
    ◦ *<https://fathom.video/share/hXto5Dt274z2maKtvjXN3myiKDXPAq9y?tab=summary&amp;timestamp=1184.0|Problem:>*<https://fathom.video/share/hXto5Dt274z2maKtvjXN3myiKDXPAq9y?tab=summary&amp;timestamp=1184.0| Google Ads CPL is $126, far above the typical $30–$50 range.>
    ◦ *<https://fathom.video/share/hXto5Dt274z2maKtvjXN3myiKDXPAq9y?tab=summary&amp;timestamp=1184.0|Action:>*<https://fathom.video/share/hXto5Dt274z2maKtvjXN3myiKDXPAq9y?tab=summary&amp;timestamp=1184.0| Investigate the campaign to identify the cause of the cost increase.>
Client Transition Plan
• *<https://fathom.video/share/hXto5Dt274z2maKtvjXN3myiKDXPAq9y?tab=summary&amp;timestamp=1564.0|Context:>*<https://fathom.video/share/hXto5Dt274z2maKtvjXN3myiKDXPAq9y?tab=summary&amp;timestamp=1564.0| Fallon is onboarding several new clients (Press Record, The Penny, Views at Sunset Ridge) while also taking over existing accounts.>
• *<https://fathom.video/share/hXto5Dt274z2maKtvjXN3myiKDXPAq9y?tab=summary&amp;timestamp=1626.0|Transition Timeline:>*
    ◦ *<https://fathom.video/share/hXto5Dt274z2maKtvjXN3myiKDXPAq9y?tab=summary&amp;timestamp=1665.0|Exquisite Moments (Kelly):>*<https://fathom.video/share/hXto5Dt274z2maKtvjXN3myiKDXPAq9y?tab=summary&amp;timestamp=1665.0| Fallon to take over this week.>
        ▪︎ *<https://fathom.video/share/hXto5Dt274z2maKtvjXN3myiKDXPAq9y?tab=summary&amp;timestamp=1730.0|Rationale:>*<https://fathom.video/share/hXto5Dt274z2maKtvjXN3myiKDXPAq9y?tab=summary&amp;timestamp=1730.0| Low-maintenance client focused on lead quality, not CPL.>
        ▪︎ *<https://fathom.video/share/hXto5Dt274z2maKtvjXN3myiKDXPAq9y?tab=summary&amp;timestamp=1730.0|Performance:>*<https://fathom.video/share/hXto5Dt274z2maKtvjXN3myiKDXPAq9y?tab=summary&amp;timestamp=1730.0| Consistent $100 CPL.>
    ◦ *<https://fathom.video/share/hXto5Dt274z2maKtvjXN3myiKDXPAq9y?tab=summary&amp;timestamp=1626.0|Diamond Day Ranch (Ollie):>*<https://fathom.video/share/hXto5Dt274z2maKtvjXN3myiKDXPAq9y?tab=summary&amp;timestamp=1626.0| Carmen to manage until the June 10 strategy call.>
        ▪︎ *<https://fathom.video/share/hXto5Dt274z2maKtvjXN3myiKDXPAq9y?tab=summary&amp;timestamp=1626.0|Rationale:>*<https://fathom.video/share/hXto5Dt274z2maKtvjXN3myiKDXPAq9y?tab=summary&amp;timestamp=1626.0| High-maintenance client; transition is best after Fallon meets them.>
        ▪︎ *<https://fathom.video/share/hXto5Dt274z2maKtvjXN3myiKDXPAq9y?tab=summary&amp;timestamp=1473.0|Performance:>*<https://fathom.video/share/hXto5Dt274z2maKtvjXN3myiKDXPAq9y?tab=summary&amp;timestamp=1473.0| Currently on "Maximize Clicks" to build conversion data before switching to "Maximize Conversions.">
    ◦ *<https://fathom.video/share/hXto5Dt274z2maKtvjXN3myiKDXPAq9y?tab=summary&amp;timestamp=2031.0|Ridgefield:>*<https://fathom.video/share/hXto5Dt274z2maKtvjXN3myiKDXPAq9y?tab=summary&amp;timestamp=2031.0| Fallon to take over after the ad campaign launches.>
        ▪︎ *<https://fathom.video/share/hXto5Dt274z2maKtvjXN3myiKDXPAq9y?tab=summary&amp;timestamp=2031.0|Rationale:>*<https://fathom.video/share/hXto5Dt274z2maKtvjXN3myiKDXPAq9y?tab=summary&amp;timestamp=2031.0| Onboarding is stalled by client approvals; Fallon will manage the account post-launch.>
VIP Day Prep: "Love Like Wild"
• *<https://fathom.video/share/hXto5Dt274z2maKtvjXN3myiKDXPAq9y?tab=summary&amp;timestamp=2117.0|Purpose:>*<https://fathom.video/share/hXto5Dt274z2maKtvjXN3myiKDXPAq9y?tab=summary&amp;timestamp=2117.0| Prepare for tomorrow's VIP day with client "Love Like Wild.">
• *<https://fathom.video/share/hXto5Dt274z2maKtvjXN3myiKDXPAq9y?tab=summary&amp;timestamp=2137.0|Process:>*
    ◦ *<https://fathom.video/share/hXto5Dt274z2maKtvjXN3myiKDXPAq9y?tab=summary&amp;timestamp=2361.0|Prep:>*<https://fathom.video/share/hXto5Dt274z2maKtvjXN3myiKDXPAq9y?tab=summary&amp;timestamp=2361.0| Carmen will create a strategy doc and conduct keyword research based on the client's questionnaire.>
    ◦ *<https://fathom.video/share/hXto5Dt274z2maKtvjXN3myiKDXPAq9y?tab=summary&amp;timestamp=2391.0|Shadowing:>*<https://fathom.video/share/hXto5Dt274z2maKtvjXN3myiKDXPAq9y?tab=summary&amp;timestamp=2391.0| Fallon will shadow the process asynchronously via a Loom video from Carmen.>
• *<https://fathom.video/share/hXto5Dt274z2maKtvjXN3myiKDXPAq9y?tab=summary&amp;timestamp=2444.0|Client Details:>*<https://fathom.video/share/hXto5Dt274z2maKtvjXN3myiKDXPAq9y?tab=summary&amp;timestamp=2444.0| Photographer targeting two distinct markets: Orlando, FL, and Denver, CO.>
Next Steps
• *<https://fathom.video/share/hXto5Dt274z2maKtvjXN3myiKDXPAq9y?tab=summary&amp;timestamp=297.0|Carmen:>*
    ◦ <https://fathom.video/share/hXto5Dt274z2maKtvjXN3myiKDXPAq9y?tab=summary&amp;timestamp=297.0|Propose landing page headline change to the Destination Wedding Planner client.>
    ◦ <https://fathom.video/share/hXto5Dt274z2maKtvjXN3myiKDXPAq9y?tab=summary&amp;timestamp=1184.0|Investigate high CPL for DJ Hybrid.>
    ◦ <https://fathom.video/share/hXto5Dt274z2maKtvjXN3myiKDXPAq9y?tab=summary&amp;timestamp=2391.0|Send Fallon a Loom video detailing the "Love Like Wild" VIP day prep.>
    ◦ <https://fathom.video/share/hXto5Dt274z2maKtvjXN3myiKDXPAq9y?tab=summary&amp;timestamp=1626.0|Continue managing Diamond Day Ranch until the June 10 strategy call.>
• *<https://fathom.video/share/hXto5Dt274z2maKtvjXN3myiKDXPAq9y?tab=summary&amp;timestamp=1626.0|Fallon:>*
    ◦ <https://fathom.video/share/hXto5Dt274z2maKtvjXN3myiKDXPAq9y?tab=summary&amp;timestamp=1665.0|Take over management of the Exquisite Moments account this week.>
    ◦ <https://fathom.video/share/hXto5Dt274z2maKtvjXN3myiKDXPAq9y?tab=summary&amp;timestamp=2031.0|Take over management of the Ridgefield account after ad launch.>
    ◦ <https://fathom.video/share/hXto5Dt274z2maKtvjXN3myiKDXPAq9y?tab=summary&amp;timestamp=2391.0|Review the "Love Like Wild" strategy doc and Loom video.>
Action Items
• *Email Felipe re: landing page hero/bullets/CTA; add Meta ad value props* - <https://fathom.video/share/hXto5Dt274z2maKtvjXN3myiKDXPAq9y?timestamp=318.9999|WATCH (5 secs)>
• *Rename Google Ads account to Press Record Co.* - <https://fathom.video/share/hXto5Dt274z2maKtvjXN3myiKDXPAq9y?timestamp=874.9999|WATCH (5 secs)>
• *Review DJ Hybrid Meta performance; recommend optimizations* - <https://fathom.video/share/hXto5Dt274z2maKtvjXN3myiKDXPAq9y?timestamp=1175.9999|WATCH (5 secs)>
• *Verify Dos Palomas lead tracking (pricing page); fix if needed* - <https://fathom.video/share/hXto5Dt274z2maKtvjXN3myiKDXPAq9y?timestamp=1205.9999|WATCH (5 secs)>
• *Monitor Diamond Day Ranch Google Ads until strategy call (Jun 10)* - <https://fathom.video/share/hXto5Dt274z2maKtvjXN3myiKDXPAq9y?timestamp=1636.9999|WATCH (5 secs)>
• *Complete Exquisite Moments handover; take over by week's end* - <https://fathom.video/share/hXto5Dt274z2maKtvjXN3myiKDXPAq9y?timestamp=1654.9999|WATCH (5 secs)>
• *Check w/ Whitney re: Ridgefield Google Ads ownership post-launch* - <https://fathom.video/share/hXto5Dt274z2maKtvjXN3myiKDXPAq9y?timestamp=1894.9999|WATCH (5 secs)>
• *Send Fallon Love Like Wild VIP doc + Loom; request comments* - <https://fathom.video/share/hXto5Dt274z2maKtvjXN3myiKDXPAq9y?timestamp=2419.9999|WATCH (5 secs)>


**Carmen Cruickshank** · 2026-06-05 18:27 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1780684041999749)
summary: Carmen helped Jillian with switching bid strategy to most effectively allocate ad spend. As well as helping Felipe check ads for proper account maintenance and assess whether to continue a recently new Performance Max campaign

**Carmen Cruickshank** · 2026-06-05 18:27 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1780684045338139)
@Gisselle Jiménez Hi! Sorry for the late upload but here is the call from yesutrday
📎 Google Ads Office Hours - 06.05.26 - Jun 4 2026.mp4 (mp4, **not downloaded** — over cap (216.1 MB), [fetch it](https://files.slack.com/files-pri/T03P5A3L1DK-F0B9G8TUV3J/download/google_ads_office_hours_-_06.05.26_-_jun_4_2026.mp4))
> **Gisselle Jiménez** · 2026-06-05 18:42 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1780684973418419)
> Thank you, posted!!

**Carmen Cruickshank** · 2026-06-11 17:08 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1781197722021189)
Summary: Carmen helped Felipe check stats with the primary campaign running as well as pausing the Performance Max campaign and assessing if the final URL's are correct. She also helped Erin at Carroll Hall see the performance of their new corperate camapign and comcluded to see any landing page changes.
📎 Google Ads Office Hours - 06.11.26 - Jun 11 2026.mp4 (mp4, **not downloaded** — over cap (261.1 MB), [fetch it](https://files.slack.com/files-pri/T03P5A3L1DK-F0BA2G0ULA0/download/google_ads_office_hours_-_06.11.26_-_jun_11_2026.mp4))
> **Gisselle Jiménez** · 2026-06-12 14:42 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1781275329942399)
> Thank youu, posted

**Whitney Hodges** · 2026-06-16 15:12 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1781622761926299)
@Carmen Cruickshank @Gisselle Jiménez Hi!! I had a great check-in call with Alexis. She definitely wants to move forward with staying month-to-month in the VAULT. She realizes that she hasn't really tapped into the curriculum or office hours and wants to especially now that her wedding season has slowed down for the summer.

Gisselle, please issue a recurring $197 invoice for her with a due date of June 23.

Carmen, Alexis won't be able to attend office hours this week, and she admitted that her Google Ads were kind of set it and forget for her. She hasn't looked at them and doesn't know how they are performing. If you have time during office hours will you please look into how things are going for her. Or if there isn't time, record a separate video, please. Then let's make sure she gets tagged when the video is posted.

Thank you both!!
> **Gisselle Jiménez** · 2026-06-16 16:28 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1781627333943709)
> @Whitney Hodges Great to hear!:blob-bear-dance: The invoice has been scheduled. Recording and transcript has also been filed in her folder and the market research folder.
> **Whitney Hodges** · 2026-06-24 16:07 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1782317241398319)
> @Gisselle Jiménez Did this invoice go out? We should probably send a personal email as well
> **Gisselle Jiménez** · 2026-06-24 16:23 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1782318230942139)
> @Whitney Hodges Yes, it went out yesterday! But I see it's overdue, let me draft a personal reminder email
> **Gisselle Jiménez** · 2026-06-24 18:08 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1782324538302369)
> @Whitney Hodges Draft is ready! sorry for the delay, was stuck in a long meeting:face_holding_back_tears:

**Carmen Cruickshank** · 2026-06-18 17:52 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1781805123541039)
@Gisselle Jiménez Hi! My fathom recorder was off today for some reason but only Jill came on for her last office hours and just reviewed her account to make sure everything is going well. @Whitney Hodges For alexis, I'll film the video and post it in the vault or should i just record a loom video for her to update her and emial and dm it to her
> **Whitney Hodges** · 2026-06-18 17:52 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1781805171145369)
> @Carmen Cruickshank please post in the vault and tag her. Thank you!

**Gisselle Jiménez** · 2026-06-26 13:17 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1782479832048059)
Hi, @Carmen Cruickshank! Were there any attendees yesterday during office hours?

**Carmen Cruickshank** · 2026-06-29 15:56 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1782748566265949)
no, im so sorry for the late update, wont happen again @Gisselle Jiménez
> **Gisselle Jiménez** · 2026-06-29 18:33 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1782758032071149)
> @Carmen Cruickshank No worries, thank you for the update!

**Whitney Hodges** · 2026-06-30 14:19 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1782829168937429)
@Carmen Cruickshank To link your <https://business.google.com/|Google Business Profile> to <https://ads.google.com/?subid=xs-ip-aimode-control|Google Ads>, sign into your Google Ads account, navigate to the *Data Manager* or *Assets* menu, locate the Google Business Profile connection option, select your profile, and click *Link*. [<https://support.google.com/business/thread/278053779/how-to-link-profile-to-google-ads-account?hl=en|1>, <https://www.youtube.com/watch?v=QRZQE5cAT1E|2>, <https://support.google.com/google-ads/thread/370224262/how-to-link-google-business-profile-to-google-ads?hl=en-AU|3>]


Step-by-Step Instructions
You can link the two platforms using either of the following methods:



*Method 1: Using the Data Manager*

1. Sign in to your Google Ads account.
2. Click on *Tools* in the left-hand navigation menu and select *Data Manager*.
3. Under the "Featured products" or "Connected products" section, find *Google Business Profile* and select *Manage &amp; link*.
4. Choose the account you wish to link. If using the same email for both, select your profile. If your profile is under a different email, click *Link to other account* and enter the email address that manages your Google Business Profile. [<https://support.google.com/google-ads/answer/13450314?hl=en|1>, <https://support.google.com/business/thread/363913271/how-do-i-link-my-google-my-business-account-to-ads-account?hl=en|2>, <https://www.youtube.com/watch?v=QRZQE5cAT1E|3>, <https://support.google.com/google-ads/thread/370224262/how-to-link-google-business-profile-to-google-ads?hl=en-AU|4>]

*Method 2: Adding a Location Asset (Campaign Level)*

1. In your Google Ads account, click the *Campaigns* icon on the left menu.
2. Click the *Assets* drop-down in the section menu and select *Assets*.
3. Click the blue *+* button and choose *Location asset*.
4. Select *Link to a Business Profile Manager account I know* and choose *Select a Business Profile that I manage*.
5. Select your account from the drop-down menu and click *Continue*.
6. Apply any required business name or label filters, then click *Finish*. [<https://support.google.com/business/thread/278053779/how-to-link-profile-to-google-ads-account?hl=en|1>]


**Carmen Cruickshank** · 2026-06-30 14:48 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1782830898838189)
thank you for this @Whitney Hodges! forgot to update, i found out their Google my business is connected and showing for Davis and Grey, i will double check for all google accounts today

**Carmen Cruickshank** · 2026-06-30 17:16 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1782839769346159)
@Whitney Hodges Hey! Wanted to give you an update after checking that all our Google Ads accounts are connected to Google My Business and actually showing up with the ads.

Most are connected and showing correctly. DJ Hybrid, Funktastic, and Ridgefield were connected to Google Ads but weren't actually showing up with the ads, so I disconnected and reconnected each of them. They're all pending right now while Google re-verifies the link.

Will keep an eye on those and update once they come through.

**Carmen Cruickshank** · 2026-07-03 15:56 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1783094213336759)
No attendees for google ads office hours yesturday

**Carmen Cruickshank** · 2026-07-09 17:19 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1783617546790269)
Summary: Carmen helped Erin at Carroll Hall with reviewing their ceremony only campaign, looking over keywords to ensure this doesn't compete with their current campaigns. As well as checking over ad copy and initial landing page impression.
📎 Google Ads Weekly Office Hours - 7.9.26 - Jul 9 2026.mp4 (mp4, **not downloaded** — over cap (123.2 MB), [fetch it](https://files.slack.com/files-pri/T03P5A3L1DK-F0BH5292FDW/download/google_ads_weekly_office_hours_-_7.9.26_-_jul_9_2026.mp4))
> **Gisselle Jiménez** · 2026-07-09 20:16 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1783628210217399)
> Thank you, posted!

**Carmen Cruickshank** · 2026-07-16 18:20 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1784226027434579)
Summary: Carmen helped Shannon with checking her ads account for proper maintenance and look through Google's recommendations. As well as helping Erin at Carroll Hall with budget allocation and looking through the account. And looked through Lora's account, decreasing visiblity on mobile and removing the Page View campaign goal to improve lead volume.
📎 Google Ads Office Hours - 07.16.26 - Jul 16 2026.mp4 (mp4, **not downloaded** — over cap (351.6 MB), [fetch it](https://files.slack.com/files-pri/T03P5A3L1DK-F0BHXL81JE5/download/google_ads_office_hours_-_07.16.26_-_jul_16_2026.mp4))
> **Gisselle Jiménez** · 2026-07-16 20:53 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1784235182243749)
> Posted!

**Gisselle Jiménez** · 2026-07-20 19:27 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1784575650634759)
Hi, @Carmen Cruickshank! Let me know if office hours would be at the same time on Friday so you can post tomorrow and I'll modify the event in the vault. Thank you!!

**Carmen Cruickshank** · 2026-07-20 19:31 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1784575876419259)
Yes same hours! @Gisselle Jiménez 
> **Gisselle Jiménez** · 2026-07-21 15:07 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1784646421647579)
> @Carmen Cruickshank It has been modified! You can post the rescheduling notice on today's ad check post :) Thanks!

**Carmen Cruickshank** · 2026-07-24 17:50 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1784915456501119)
update: no office hours attendees today @Gisselle Jiménez

**Gisselle Jiménez** · 2026-07-29 15:04 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1785337456787029)
Hi! FYI @Carmen Cruickshank <https://members.weddingindustryads.com/communities/groups/the-vault/channels/Google-Search-Accelerator-7pVuz/posts/6a68d835a673e93ce911b9df?commentId=6a6a15403636b7b5ccb73c9a&amp;parentId=6a68d835a673e93ce911b9df|New comment >from Erin under the ads-checkin post. :raised_hands:

&gt; Hi Carmen. I am not sure if my conversion tracking is working correctly. I will join tomorrow.
> **Carmen Cruickshank** · 2026-07-30 18:14 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1785435244490779)
> replied, thanks for mentioning!

**Carmen Cruickshank** · 2026-07-30 18:22 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1785435771111989)
Hi @Gisselle Jiménez! Here's the Office Hours Summary: Carmen helped Felipe review his account and what he needs to look out for in the future for proper maintenance of his ads. As well as helping Erin with ensuring conversion tracking is working properly for a recently launched campaign and removing negative keywords for the new campaign.
📎 Google Ads Office Hours - 07.30.26 - Jul 30 2026.mp4 (mp4, **not downloaded** — over cap (214.7 MB), [fetch it](https://files.slack.com/files-pri/T03P5A3L1DK-F0BLT8FKB7V/download/google_ads_office_hours_-_07.30.26_-_jul_30_2026.mp4))
> **Gisselle Jiménez** · 2026-07-31 14:37 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1785508666753139)
> Posted!

**Whitney Hodges** · 2026-08-04 15:45 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1785858300132639)
@Carmen Cruickshank Hi! Can you please look into what we need to be aware with required passkeys coming for Google Ads? I'd love to get in front of this, if we can. FYI @Fallon Looney
📎 image.png (png, saved as `files/F0BMH948LUX-image.png`)
> **Carmen Cruickshank** · 2026-08-04 16:34 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1785861278440749)
> looking into it! @Whitney Hodges

**Carmen Cruickshank** · 2026-08-06 15:53 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1786031587650569)
@Whitney Hodges Hi! i looked into the Aug 19 update, the one thing to actually do ahead of time is set up your own passkey now, not wait until the 19th. It's tied to you individually so mine won't cover you. You can add it at <http://myaccount.google.com|myaccount.google.com> under Security. Only thing to watch is it can take up to 7 days to fully activate, let me know if you have any questions!

**Gisselle Jiménez** · 2026-08-07 17:19 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1786123184375849)
Hi, @Carmen Cruickshank! Any attendees for office hours yesterday?

**Carmen Cruickshank** · 2026-08-07 18:25 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1786127112571639)
@Gisselle Jiménez Hi! yes, sorry for the delay ill send it after the ads audit
> **Gisselle Jiménez** · 2026-08-07 19:00 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1786129248245499)
> @Carmen Cruickshank Okay, thanks! Also, could you please record the audit or get a transcript afterwards so we can create a framework for this paid audits. Thanks!
> **Carmen Cruickshank** · 2026-08-07 19:24 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1786130698235739)
> okay i'll do that

**Carmen Cruickshank** · 2026-08-07 19:26 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1786130796580079)
@Gisselle Jiménez Heres the summary: Carmen helped Shannon check the account, assess adding keywords and see anything that needed to be adjusted form the campaign level as well as helping Alexis check on her ads and look deeper into any landing page work that could be done to improve lead volume.

**Carmen Cruickshank** · 2026-08-07 19:27 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1786130850051309)
📎 Google Ads Office Hours - 08.06.26 - Aug 6 2026.mp4 (mp4, **not downloaded** — over cap (136.4 MB), [fetch it](https://files.slack.com/files-pri/T03P5A3L1DK-F0BNDD9QXHV/download/google_ads_office_hours_-_08.06.26_-_aug_6_2026.mp4))

**Carmen Cruickshank** · 2026-08-07 19:37 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1786131453789239)
google ads audit with Noam summary google doc: <https://docs.google.com/document/d/1_HYwbq58Xr_a9Pes90o8Jnax3Mxkhv6bmJssjpzP7vw/edit?tab=t.0|docs.google.com/document/d/1_HYwbq58Xr_…/edit?tab=t.0> and the recording if helpful:
📎 Noam - Sunny Entertainment Google Ads Audit - Aug 7 2026.mp4 (mp4, **not downloaded** — over cap (161.7 MB), [fetch it](https://files.slack.com/files-pri/T03P5A3L1DK-F0BNNK1DMBM/download/noam_-_sunny_entertainment_google_ads_audit_-_aug_7_2026.mp4))
> **Whitney Hodges** · 2026-08-07 19:51 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1786132285044969)
> @Carmen Cruickshank tysm!! How do you feel like to went with Noam?
> **Carmen Cruickshank** · 2026-08-10 14:29 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1786372192661099)
> @Whitney Hodges of course! i feel like it went great, she got the information she needed, didnt seem clueless because of how much shes researched google ads, but she seemed really happy with knowing the changes that needed to be made for moving forward

**Carmen Cruickshank** · 2026-08-07 19:41 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1786131686215209)
and heres the ads audit with tony a few weeks back if that's helpful for another reference: <https://docs.google.com/document/d/1_j2s4sHdSsLcs755OL5wG0JUkp5HM9EysuBmpvA3IRk/edit?tab=t.0|docs.google.com/document/d/1_j2s4sHdSsL…/edit?tab=t.0> and heres the upload:
📎 Promises 2919 with Tony Google Ads Audit - Jul 20 2026.mp4 (mp4, **not downloaded** — over cap (305.2 MB), [fetch it](https://files.slack.com/files-pri/T03P5A3L1DK-F0BNDFTGW5D/download/promises_2919_with_tony_google_ads_audit_-_jul_20_2026.mp4))

**Carmen Cruickshank** · 2026-08-13 17:24 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1786641871771019)
Summary: Carmen helped Erin look into performance on her Google ads, specifically the main one. Seeing that all is working well with audience targeting and concluded that she will get back to her on fixing an enhanced conversion issues and seeing the heatmap. Carmen also helped Shannon look into her performance and into targeting more elopement services through Google since that's becoming more popular.
📎 Google Ads Office Hours - 08.13.26 - Aug 13 2026.mp4 (mp4, **not downloaded** — over cap (210 MB), [fetch it](https://files.slack.com/files-pri/T03P5A3L1DK-F0BQ4NJ9J01/download/google_ads_office_hours_-_08.13.26_-_aug_13_2026.mp4))
> **Gisselle Jiménez** · 2026-08-13 18:06 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1786644413623229)
> @Carmen Cruickshank Thank you, posted!

**Notification Bot** · 2026-08-15 21:08 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1786828121859729)
Morgan Presti has joined on for the Google Search Accelerator! :tada:

**Whitney Hodges** · 2026-08-20 13:27 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1787232467414069)
@Viktor can you please take a look at what's going on with Carroll Hall's Google Ads and let us know what advice you have if any. Feel free to point out any areas of opportunity you see, not only with the ads but the landing pages they point to. Feel free to reference recent office hours that Erin attended (shared here in this channel) if needed.

Cc @Carmen Cruickshank
> **Viktor** · 2026-08-20 13:28 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1787232481010009)
> On it — pulling Carroll Hall's Google Ads data and reviewing the office hours context Erin attended. Will report back with findings and recommendations.
> **Viktor** · 2026-08-20 13:38 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1787233124527789)
> **Carroll Hall (VIP – 5170626399) — audit done.** Last 30 days: **$1,111 spend → 14 lead-form conversions (~$79/lead)** across 2 live Search campaigns. Nothing is broken account-side, but there are 5 clear opportunities and one of them is worth more than any bid or budget change:  1. **Landing pages are the bottleneck** — landing page experience is *Below Average* on **every** scored keyword, the wedding LP takes **~23s to finish loading on mobile**, and ~**3 of every 4 people who tap INQUIRE NOW never submit** the form. 2. **The two live campaigns compete with each other** — 9 of the main campaign's 12 keywords also run in Ceremony Only. 3. **~78% / 72% of impressions are lost to Ad Rank** (not budget) — Quality Scores of 1–3 on the top spenders, so extra budget would just buy pricier clicks today. 4. **The account tracking template is malformed** — I verified live that Tripleseat leads come in with a blank campaign, medium and keyword-term, so Erin can't tell which campaign produced a lead (this is likely what's behind her "is my conversion tracking working?" question — the Google Ads side *is* counting). 5. **Housekeeping**: a campaign that looks Enabled has actually ended, Ceremony Only has zero sitelinks, and ~50 stale conversion actions are cluttering the account.  Full detail + suggested fix order in the next reply. @Carmen Cruickshank these are suggestions from the data — your call on what's worth doing with Erin at office hours.
> **Viktor** · 2026-08-20 13:39 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1787233182007139)
> ### Carroll Hall — full audit (data pulled live 8/20, last 30 days = 7/21–8/19)  **Where the money is going**  | Campaign | Spend | Impr | Clicks | CTR | CPC | Lead-form conv | CPL | Search IS | Lost to rank | Lost to budget | |---|---|---|---|---|---|---|---|---|---|---| | Search \| Leads \| WIA | $579 | 2,598 | 279 | 10.7% | $2.08 | 6.3 | $91 | 10% | 78% | 14% | | Search \| Ceremony Only | $532 | 2,658 | 238 | 9.0% | $2.23 | 7.7 | $69 | 10% | 72% | 20% |  Trend: leads have slid from **18/mo (Apr–Jun)** on the main campaign to **3.3 in Aug**, while Ceremony Only picked up part of the slack (5 in Jul, 3.7 so far in Aug). Combined spend is flat, so the two campaigns are effectively trading leads rather than adding them. Mobile is **82% of clicks**, and desktop produced **0 conversions on Ceremony Only** ($108 spent).  ---  ### 1. Landing pages — the biggest lever  Every keyword with a Quality Score in the account has **Landing page experience: Below Average** (12 of 12 scored). Measured on a real mobile viewport:  | | `/2026-book-your-wedding` | `/book-your-ceremony` | |---|---|---| | Load event | **22.8s** | 6.7s | | Page height | 9,857px | 7,795px | | HTML weight | 750 KB | 286 KB | | Form | **old Tripleseat form** | newer Tripleseat dynamic form |  What I'd flag: - **Speed.** 23s to settle on mobile, where 82% of clicks land. Squarespace + 14 images + Tripleseat + GTM + Meta pixel + Clarity all firing. This alone explains much of the Below Average LP score and therefore the Ad Rank problem. - **Above the fold is doing no selling.** On a phone the first screen is: big logo → 5-star review → INQUIRE NOW button. The headline ("Let Your Love Bloom in a Secret Garden") and any mention of *Brooklyn*, capacity, or price sits below the fold. Someone who just searched "wedding venue brooklyn" gets no confirmation they're in the right place. - **The form is where leads die.** "Click – INQUIRE NOW" fired **~49 times** in 30 days vs **13.3 form submissions** — roughly **27% completion**. The wedding page still uses Tripleseat's older/corporate form: it asks **Company, Start Time, End Time, Event Description** plus a **visible reCAPTCHA checkbox** — on a phone that's a wall. The ceremony page already uses the shorter dynamic form (name, email, phone, date, guest count). Quickest win in the whole account: **put the short ceremony-style form on the wedding page too**, and cut fields to name / email / phone / date / guest count with everything else optional. - Nice-to-have: an anchored sticky "Inquire" button, price anchoring above the fold (the ceremony LP's $2,500/$3,500 works well; the wedding page hides $5,500 deep in the page), and a real thank-you page URL for cleaner conversion measurement. - Microsoft Clarity **is** installed on both pages — the heatmap Carmen mentioned on 8/13 is available; the form section is where I'd look first.  ### 2. The two campaigns are bidding against each other  **9 of the main campaign's 12 enabled keywords are also enabled in Ceremony Only**: `wedding venue Brooklyn`, `microwedding`, `micro wedding venue`, `small wedding venues`, `small wedding venues near me`, `outdoor wedding venue nyc`, `outdoor wedding venues near me`, `brooklyn botanic garden wedding`, `brooklyn botanical garden wedding`. Same geo, same time, separate $20 and $18 budgets. This was the exact thing checked at 7/9 office hours — the overlap crept back in.  Suggested shape: keep Ceremony Only to genuinely ceremony/elopement intent (`ceremony only`, `elopement`, `wedding ceremony`, `city hall wedding`, `intimate wedding`), leave the venue-shopping terms to the main campaign. Consolidating also gives Maximize Conversions one pool of ~14 conversions/mo instead of two thin ones — both campaigns are well under the volume smart bidding likes.  ### 3. Quality Score / Ad Rank, not budget  `wedding venue` (phrase) is **$418 — 38% of all spend — at Quality Score 3**. Six keywords sit at QS 1. Rank-lost impression share is 72–78% while budget-lost is only 14–20%, so **more budget mostly buys more expensive clicks** until LP experience and expected CTR improve. Also: `wedding venue` with no geo modifier is a national-intent term being held in place only by location targeting — tight ad-group-level relevance (or exact match) would help the QS.  **Waste worth negativing** (from the top 200 search terms, $475 of the $1,111):  | Cluster | Spend | Clicks | Conv | |---|---|---|---| | Brooklyn Botanic/Botanical Garden | $69 | 34 | 0 | | City hall / courthouse | $26 | 10 | 0 | | Airbnb / restaurant / hotel / chapel | $34 | 16 | 0 | | Named competitor venues | $67 | 23 | 1 |  BBG is the clearest one — it's even *added as a keyword* in both campaigns and has produced 0 leads. Competitor-venue traffic is a strategy call (it does convert occasionally, and it's cheap), but the two "botanic garden" keywords I'd pause and add as negatives.  ### 4. Tracking (this is Erin's question)  The Google Ads side is genuinely working: conversion ID **AW-10888872555** matches the tag on both LPs, GTM-WFFTPGLF + GA4 G-DKKG9NDSDH are present, **enhanced conversions for leads is ON** with data terms accepted, and only `Submit lead form (website)` is bid-eligible on both live campaigns — so bidding is optimizing to real leads, not junk.  What *is* broken is attribution downstream. The account-level tracking template is:  `{lpurl}?utm_source=googleads&amp;utm_medium={_adgroup}&amp;campaign_id={campaignid}&amp;campaign_name={campaign_name}&amp;utm_content={keyword}`  `{_adgroup}` is an undefined custom parameter and `{campaign_name}` isn't a real ValueTrack parameter. I loaded the LP with that exact query string and read Tripleseat's hidden fields — result: **source `googleads`, medium blank, campaign blank, term blank**, content = keyword, gclid captured. So every Google lead in Tripleseat is missing the campaign and keyword, and GA4 sees `googleads / (none)` instead of Paid Search.  Fix (a human has to do this in the UI — the field isn't writable via API): clear the tracking template and set an account-level **final URL suffix**:  `utm_source=google&amp;utm_medium=cpc&amp;utm_campaign={campaignid}&amp;utm_content={adgroupid}&amp;utm_term={keyword}&amp;utm_matchtype={matchtype}`  That's the same standard we put on Ridgefield and Press Record, and Tripleseat already has hidden fields waiting for those exact UTM names + gclid.  ### 5. Housekeeping  - **`Search | Leads | WIA Ad with Dynamic Forms` shows status Enabled but its serving status is ENDED** (past end date) — 0 impressions in 30 days, last spend was April ($132 / 3 conv). It also **shares the main campaign's budget** and has *outbound clicks* as a bid-eligible goal, so if anyone reactivates it, it'll split the $20/day and optimize toward INQUIRE-button clicks. Either give it new dates + its own budget + lead-form-only goals, or pause/archive it so the account reads honestly. - **Sitelinks:** Ceremony Only has none; the main campaign has exactly one ("Book a Tour Today"), and the four account-level sitelinks (Gallery, Contact, Virtual Tour, Book your next event) are all **paused**. Google needs 2–4+ to show them — free CTR/Ad Rank sitting on the table. Callouts and the call asset are fine. - **Conversion actions: 57 exist, 31 enabled**, including dead Universal Analytics goals (UA stopped collecting in 2023), Smart-campaign actions from the old 2022 campaigns, Local actions, Android app installs and a GA4 *purchase* action — all marked primary. They're not in the live campaigns' bid-eligible set, so they're not distorting bidding, but they make reporting unreadable. Worth archiving everything except the two live lead forms, calls from ads, and the INQUIRE-click (as secondary). - **Geo:** Brooklyn, Manhattan, Queens, Nassau County, Long Island City and "New York city" are all targeted — the last two are redundant inside the boroughs, and Nassau County is worth a conversion check. (There are also odd negative-location entries for China and Singapore — harmless, just leftovers.) - Main campaign optimization score is **44%**; Ceremony Only reports primary status **Limited**.  ### What I'd do, in order  1. **Short form + speed pass on both LPs** (biggest measurable upside — 27% form completion and a 23s mobile load). 2. **Dedupe the two keyword sets** so the campaigns stop bidding against each other. 3. **Fix the tracking template → final URL suffix** so Erin can finally see campaign/keyword on each Tripleseat lead. 4. **Negatives** for botanic garden / courthouse / airbnb-restaurant-hotel clusters; pause the two BBG keywords. 5. **Sitelinks + housekeeping** (ended campaign, stale conversion actions). 6. Only **then** revisit budget — once LP experience improves, budget-lost IS of 14–20% becomes worth buying.  One extra thought: the paused **May 2026 Demand Gen** campaign did $816 → **12 lead-form conversions ($68 CPL) at a $0.42 CPC** over May–July — slightly *better* CPL than Search right now. If lead quality held up, it's worth a retest after the landing page work rather than staying off.  Happy to draft the negative-keyword list, the sitelink set, or a prioritized "fix the LP" brief for Erin if that's useful — just say the word. @Whitney Hodges @Carmen Cruickshank
> **Carmen Cruickshank** · 2026-08-20 19:29 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1787254182091009)
> what conversion actions need to be fixed again @Viktor
> **Viktor** · 2026-08-20 19:31 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1787254282236599)
> @Carmen Cruickshank Just re-pulled it live so the IDs are current. Important framing first: **nothing here is actively breaking bidding.** I checked the biddable goals on both live campaigns and they're clean — only `Submit lead form (website)` is bid-eligible on `Search | Leads | WIA` and `Search | Ceremony Only`. So this is a reporting-hygiene cleanup, not an emergency. There are **31 enabled** conversion actions and realistically 3–4 should be.  **Keep (these are the real ones)**  | Action | ID | Last 90d | |---|---|---| | Submit Lead Form - LP | 7381089533 | 45 conv — the workhorse | | Ceremony Lead Form Submission | 7685679518 | 8 conv | | Submit corporate lead form | 7619365810 | 2 conv | | Calls from ads | 974798309 | 0 — but the call asset is live, worth keeping | | Click - INQUIRE NOW | 7389935228 | 142 — keep as **secondary** only (it already is) |  **Archive / turn off — stale, auto-created junk that's still flagged Primary**  | Group | IDs | |---|---| | Universal Analytics goals (UA stopped collecting in 2023, two are still Primary) | 945348655, 945348658, 945348661 | | Local actions — Directions, Website visits, Other engagements, **Menu views** | 946632893, 970331444, 971122014, 1064774368 | | Smart campaign leftovers (map clicks to call, ad clicks to call, map directions, tracked calls) | 947401363, 947472462, 947473107, 970288299 | | Clicks to call (Google-hosted duplicate of "Calls from ads") | 947401330 | | **Android installs (all other apps)** — Primary, and there's no app | 6466213365 | | **GA4 purchase** — Primary, on a venue account with no ecommerce | 6450598263 | | Dated duplicate call actions | 7120940638 (May 2025), 7145652426 (June 2025) | | GA4 pageview micro-events (contact_us, visit_how_to_book, visit_contact_us, homepage_to_how_to_book, submit_how_to_book_Jan2024) | 6568522494, 6568522497, 6568522500, 6630784968, 6735056141 |  Heads-up: the Google-hosted ones (Local actions / Smart campaign) often can't be deleted outright — flipping them to **Secondary** is enough to get them out of the Conversions column.  **Duplicate lead measurement** — these are already Secondary, so they're not touching bids, but they measure the *same* submissions a second time via thank-you pages, which is why "All conv." reads high: `Contact Form` 6736356440, `how-to-book` 6738757099 (10), `Lead - How To Book (Thank You Page)` 7327284641 (8), `Lead Form - Contact Us (Thank You Page)` 7327523026, `Lead - Corporate How to Book (Thank You Page)` 7382371159 (2). I'd pick one method per form and archive the other.  **Two things that actually change behavior, if you only do two:** 1. **`Search | Leads | WIA Ad with Dynamic Forms` (23607626822) has `Outbound click` as a bid-eligible goal** alongside lead forms. It's dormant right now (serving status ENDED), but if anyone switches it back on it'll optimize toward INQUIRE-NOW *button clicks* instead of submissions — and it shares the main campaign's budget. Worth stripping that goal now so it can't bite later. 2. **Calls aren't being optimized for.** `PHONE_CALL_LEAD` isn't in either live campaign's biddable set, so the (347) 201-1479 call asset is measured but never bid toward. If phone inquiries count as leads for Erin, adding calls as a campaign goal is a free source of conversion volume — which also helps the thin conversion counts I mentioned earlier.  One nuance so the numbers don't confuse anyone later: because campaign goals work at the *category* level, every enabled **Primary** lead-form action feeds bidding on both campaigns — including `Submit corporate lead form`. It's only 2 conversions in 90 days so the impact is tiny, but if you'd rather the wedding campaigns never chase corporate inquiries, campaign-level goals would separate them. Your call.
> **Carmen Cruickshank** · 2026-08-20 19:34 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1787254481132119)
> okay so fix a lot of the irrelevant conversion tracking to be in secondary? make sure the outbound click isnt a conversion goal in the campaign of one thats turned off? and phone call lead should be a conversion action becuase you see a phone number? they dont want that as a conversion action
> **Viktor** · 2026-08-20 19:35 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1787254538514049)
> Yes to the first two:  1. **Secondary is enough** for all the irrelevant ones — that pulls them out of the Conversions column and out of bidding, and you still see them under "All conv." if anyone ever wants the history. No need to hunt for a delete button on the Google-hosted ones. 2. **Correct** — `Search | Leads | WIA Ad with Dynamic Forms` (23607626822) is the switched-off one; drop `Outbound click` from its goals. Low urgency since it's not serving, but it shares the main campaign's budget, so worth doing while you're in there. 3. Good to know — scratch that one. I only suggested it because the call asset is live and calls were being measured but never optimized toward. If Erin doesn't want calls counted as a lead, then leave `Calls from ads` alone (or make it secondary too) and don't add it as a goal. That was me reading the setup, not a client request — your call wins.

**Carmen Cruickshank** · 2026-08-20 17:01 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1787245313130239)
thank you for asking that whitney ,ill email Erin to let her know things that can be fixed

**Carmen Cruickshank** · 2026-08-20 17:09 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1787245742917379)
@Gisselle Jiménez Hi! heres the summary: Carmen helped Shannon at Love Like Wild with keyword research to make sure she has the right targeting in place when launching her new ad group. As well as, talk about performance in general with how Google Ads affect Meta Ads.
📎 Google Ads Office Hours - Aug 20 2026.mp4 (mp4, **not downloaded** — over cap (80.6 MB), [fetch it](https://files.slack.com/files-pri/T03P5A3L1DK-F0BRK042UJJ/download/google_ads_office_hours_-_aug_20_2026.mp4))
> **Gisselle Jiménez** · 2026-08-21 16:14 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1787328882939599)
> Thank you, posted!!

**Gisselle Jiménez** · 2026-08-25 21:47 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1787694454594059)
Hi, @Carmen Cruickshank! Quick reminder to reply to Erin's recent email on Google Ads Changes Recommended. Thanks!!

**Carmen Cruickshank** · 2026-08-27 17:36 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1787852201682409)
@Gisselle Jiménez Hi! Here's the summary: Carmen helped Erin with checking negative keyword adjustments and assessing ad performance. And helped Shannon with checking her new elopement ad group has the right setup and is running properly.
📎 08.27.26- Google Ads Office Hours - Aug 27 2026.mp4 (mp4, **not downloaded** — over cap (162.2 MB), [fetch it](https://files.slack.com/files-pri/T03P5A3L1DK-F0BT2UBHZ3P/download/08.27.26-_google_ads_office_hours_-_aug_27_2026.mp4))
> **Gisselle Jiménez** · 2026-08-28 18:32 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1787941924363829)
> Ty! Postedd

**Carmen Cruickshank** · 2026-09-02 21:26 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1788384405997269)
@Whitney Hodges Hi! Is the VIP support call a google ads audit tmrw? im confused
> **Whitney Hodges** · 2026-09-02 21:29 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1788384541813599)
> @Carmen Cruickshank thank you for asking!! She had an audit with Christina previously. After, we gave her the option to join GSA which she declined but told her she could book a paid consultation at any point. I'll get you more context!

**Gisselle Jiménez** · 2026-09-04 15:03 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1788534212545189)
Hi @Carmen Cruickshank! Were there any attendees for office hours yesterday?

**Carmen Cruickshank** · 2026-09-04 15:43 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1788536589501339)
@Gisselle Jiménez No, no attendees for office hours yesturday, i forgot to mention
> **Gisselle Jiménez** · 2026-09-04 17:57 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1788544666054649)
> Oki, no worries! Thanks for letting me know

**Carmen Cruickshank** · 2026-09-10 17:23 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1789061039018009)
@Gisselle Jiménez Hi! Summary for todays office hours: Carmen helped Erin at Carroll Hall with checking up after 2 weeks on recent updates to the account to improve performance goals. Thing are improving with the recent keyword changes and bidding was adjusted to focus on mobile devices showing the ads more compared to desktop. They will revisit in 2 weeks to see recent changes on both campaigns and if anything should be paused or any budget allocated differently.
📎 Google Ads Office Hours - 09.10.26 - Sep 10 2026.mp4 (mp4, **not downloaded** — over cap (56.2 MB), [fetch it](https://files.slack.com/files-pri/T03P5A3L1DK-F0C0XJASPRC/download/google_ads_office_hours_-_09.10.26_-_sep_10_2026.mp4))
> **Gisselle Jiménez** · 2026-09-10 19:37 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1789069048606199)
> posted!

**Gisselle Jiménez** · 2026-09-10 20:07 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1789070866290999)
Hey @Carmen Cruickshank! Flagging that Shannon and Alexis are due for follow-up. Could you please send Shannon the 2-week DM and Alexis the 4-week email?

Here are some starting drafts, but feel free to modify as needed!

*DM to Shannon:*
Hey Shannon, how are things going with your ads? Just wanted to give you a heads up that office hours are coming up this week if you'd like to join for feedback on your account or to ask any questions. Hope to see you there!

*Email to Alexis:*
Subject: Following Up on Office Hours

Hi Alexis,
I hope you're doing well!
I haven't seen you at a session recently, and I want to make sure you're getting the support you need.
Office hours is where you get direct feedback and can ask questions in real time. Our next session is Thursday, September 17 at 11am CST.
Let me know if you have any questions!
Best,
Carmen

Thank you!

cc: @Whitney Hodges
> **Carmen Cruickshank** · 2026-09-11 17:36 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1789148189543339)
> done!

**Gisselle Jiménez** · 2026-09-14 19:18 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1789413514098449)
Hi @Carmen Cruickshank! Just making sure you saw this email from Lora:

&gt; Hi Carmen, I hope you're doing well! I'm trying to keep up with the Google Ad Analytics and have been working with someone for help on marketing. One thing she flagged for me is that conversion tracking in July seemed to have stopped. And also that the ad budget is mostly being spent on the broadest search terms -- wedding venue near me -- and not even getting to the specific things like "industrial wedding venue." You had mentioned the last office hours I attended that I could reach out with questions if I had them beyond the WIA access. I'm wondering, since you helped set the ad up, if you'd be able to help me figure out what's happening with the ad? I did, in August, lower the ad spend to $200 a month from $500.
&gt; -LeadLock
@Whitney Hodges Could you please provide guidance on this reply since she's no longer a client?
> **Whitney Hodges** · 2026-09-17 14:01 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1789653695263269)
> @Carmen Cruickshank @Gisselle Jiménez I think we can offer some complimentary assistance on this. Carmen, let me know what you see on your end. Let's just start with an email reply to her and go from there
> **Carmen Cruickshank** · 2026-09-17 16:03 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1789661023883459)
> @Whitney Hodges Hi! I replied to her yesturday saying this; _Hi Lora,_
> 
> _I hope you're doing well too!_ 
> 
> _I apologize for the late response, thank you for your patience!_
> 
> _A $200 per month budget drastically reduces the speed at which you can get data, potentially taking three months to see if any changes are working vs 1 month with $500. I believe that specific niche keywords, for which you want ads to appear, will have a much lower spend because fewer people are searching for them. In contrast, broader keywords like "wedding venue near me" get clicks because most people with high intent to book a wedding venue search those terms. I don't think that decreases the quality of clicks you're getting, though; you're still getting those high intent clicks. Although fixing conversion tracking is outside my scope, does the new person you're working with have experience setting it up?_ 
> 
> I can update her though that i could test the conversion tracking, although we were never actually tracking submissions when her ads were set up and running because of the issues we continually came across on her Wix site, but let me know what i should update her on in any further communication
> **Whitney Hodges** · 2026-09-17 19:13 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1789672428049359)
> @Carmen Cruickshank Thank you!! Given the fact that she had a lot of feedback on GSA not meeting her expectations (nothing you did wrong), I'd be ok with you offering her a complimentary consultation or audit this one time. Do we still have access to her ad account. Maybe we could just ask Viktor to do an audit and include some recommendations. What do you think?
> **Carmen Cruickshank** · 2026-09-17 21:43 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1789681432157489)
> @Whitney Hodges Hi! I don't mind giving a complimentary audit or having victor do it, i think she probably like the face to face call instead
> **Whitney Hodges** · 2026-09-17 21:53 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1789682002678069)
> @Carmen Cruickshank ok sounds good! You can just give her your link to schedule a strategy call with you. I'd just mention that it's normally $297 but we're happy to offer it complimentary this time. Feel free to have Viktor help you prep
> **Carmen Cruickshank** · 2026-09-18 19:03 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1789758182082659)
> @Whitney Hodges ok sounds good
> **Carmen Cruickshank** · 2026-09-18 19:09 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1789758564117309)
> email sent!

**Gisselle Jiménez** · 2026-09-15 16:12 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1789488777559789)
@Carmen Cruickshank I've scheduled Morgan's vip day call 2 for 3pm EST (3 hours later) and for 30 minutes. Feel free to reach out to her just to confirm her availability and I'll start working on including this in confirmation emails moving forward so the client is aware! Thank youu

cc: @Whitney Hodges
> **Carmen Cruickshank** · 2026-09-15 19:30 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1789500600159569)
> thank you! @Gisselle Jiménez

**Carmen Cruickshank** · 2026-09-17 21:42 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1789681338523399)
@Gisselle Jiménez Hi! No attendees for office hours today

**Carmen Cruickshank** · 2026-09-23 17:26 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1790184396288569)
@Whitney Hodges hi! just an update, Morgan was excited about her ads that started yesturday and todays ads audit went well with Liz and she felt much more assurance after the call

**Carmen Cruickshank** · 2026-09-24 17:01 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1790269279265139)
@Gisselle Jiménez Hi! Summary for today's office hours: Carmen helped Erin with accessing whether or not to pause an existing campaign focused on their ceremony offer. And how to prepare for engagement season coming up and get ahead before other venues.
📎 Google Ads Office Hours - 09.24.26 - Sep 24 2026.mp4 (mp4, **not downloaded** — over cap (135.5 MB), [fetch it](https://files.slack.com/files-pri/T03P5A3L1DK-F0C43V45JNR/download/google_ads_office_hours_-_09.24.26_-_sep_24_2026.mp4))
> **Gisselle Jiménez** · 2026-09-24 17:19 · [link](https://weddingindustryads.slack.com/archives/C09LQ656BPU/p1790270384110629)
> Thank you, published!
