# Slack corpus — index

6 channels in `corpus/slack/`, written by `corpus/fetch-slack.mjs`.
Last run touched 2: #metaadsaccelerator, #googlesearchaccelerator (2026-09-25).

**1,070 parent messages · 1,594 thread replies · 209 files downloaded.**

| Channel | Messages | Replies | Files | Covers |
|---|---|---|---|---|
| [#metaadsaccelerator](./metaadsaccelerator.md) | 347 | 514 | 60 (+37 skipped) | 2024-11-22 → 2026-09-24 |
| [#c_funktasticproductions_djhybrid](./c_funktasticproductions_djhybrid.md) | 248 | 371 | 43 | 2025-05-05 → 2026-09-24 |
| [#cfpfu_luxurytravelboutique](./cfpfu_luxurytravelboutique.md) | 188 | 245 | 32 | 2025-05-14 → 2026-09-04 |
| [#googlesearchaccelerator](./googlesearchaccelerator.md) | 152 | 221 | 21 (+26 skipped) | 2025-10-24 → 2026-09-24 |
| [#c_dogwoodreserve](./c_dogwoodreserve.md) | 103 | 208 | 21 | 2026-05-07 → 2026-09-24 |
| [#social-proof-and-results](./social-proof-and-results.md) | 32 | 35 | 32 | 2025-06-11 → 2026-08-14 |

## What is not here

**Over the size cap.** 63 files, 12.2 GB, almost all office-hours
recordings. Each is listed with its download URL in its own channel file. The
Atelier reads transcripts, not video, and 150 of those already came from Zoom.

**Hosted elsewhere.** 2 documents linked into a channel rather than uploaded, so no
Slack scope reaches them:

- **Dogwood Inquiry Sequences** — docs.google.com, in [#c_dogwoodreserve](./c_dogwoodreserve.md)
- **Dogwood Reserve | Landing Page Copy** — docs.google.com, in [#c_dogwoodreserve](./c_dogwoodreserve.md)

These need the Google Drive OAuth app. They are worth naming individually
because copy of this kind is exactly what the Atelier is for.

Retention is the real deadline. On the free plan Slack truncates history to
90 days, so what is in these files is the record — re-running this later
returns less, not more.

## Attribution

Slack resolves every author to a real user id, so unlike the Zoom VTTs these
quotes carry `attribution: "resolved"` — the name is Slack's, not an inference
from who else was in the room. Permalinks make each one checkable.
