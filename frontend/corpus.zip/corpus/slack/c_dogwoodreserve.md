# #c_dogwoodreserve

Private channel · `C0B245ATY03`
Pulled 2026-09-25 by `corpus/fetch-slack.mjs`.

103 parent messages · 208 thread replies · 21 files downloaded.
Covers 2026-05-07 → 2026-09-24.

Thread replies are indented with `>`. Every message links back to Slack, so a
candidate drawn from here carries its source the way a transcript quote carries
a timecode.

## Linked, not attached — needs Drive access

Shared into the channel as links, so the bytes never touched Slack and no
Slack scope reaches them. These want the Google Drive OAuth app. Named here
because copy like this is Atelier source material, and a link that is only
mentioned in passing in a thread is a link nobody finds again.

| Document | Host | Type | Link |
|---|---|---|---|
| Dogwood Reserve | Landing Page Copy | docs.google.com | gdrive | [open](https://docs.google.com/document/d/1Ch7Wul3-zVYYIHwocsAlIO9lj9Sj5ypJtCEH6no9ovA/edit?usp=sharing) |
| Dogwood Inquiry Sequences | docs.google.com | gdrive | [open](https://docs.google.com/document/d/1g5QHl0xWT4SpwCP0PCrptP4UmvxV36sEvdH60VbZIik/edit?tab=t.0#heading=h.nj3v9tqipi) |

---

**Gisselle Jiménez** · 2026-05-07 16:22 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1778170973074789)
Hi @Danielle McGinnis and @Tina Henares! Tirzah Caffee at Meriwether Manor has signed on for the Foolproof Follow-Up Advantage, and her kickoff call is scheduled for May 27th :partying_face:

Here's everything you need to get familiar with the account:
• <https://drive.google.com/drive/folders/1pJwadFky3EF-ISvUEKsyFX5xQp3pBdhc?usp=drive_link|Google Drive folder> and <https://app.clickup.com/9011165651/v/li/901113739151|Onboarding Checklist> are in the Bookmarks folder of this channel
• <https://docs.google.com/document/d/1cCXMhwykMo-apq3d-bfg0zs0bFtbLskoxjO0u8QoPDY/edit?usp=drive_link|LeadLock Kickoff Call Worksheet> is also included in the Google Drive folder
Things to note:
• Alina Stevens is Tirzah's client. Tirzah will handle the Kickoff call solo and is currently the main point of contact. 
• Tirzah has been referring almost all of our LeadLock clients, so it's very important for her onboarding to go smoothly!
• Included in her proposal is the creation of a Pricing Guide. (@Whitney Hodges Let me know if we will handle this between you and me)
• Their intake form has not been filled out completely, so we need to follow up before her kickoff call for more details. 
• *Website &amp; Development:* Ami and Jason (Celebrate Creative) are handling web development and SEO for Meriwether Manor. Staging site will be ready before May 27th kickoff call, but site won't launch until late June/early July. They have DNS access and will help with subdomain setup. Brand board finalization is happening this Friday, with font and color selections to follow. Google Workspace is recommended for professional email.
@Whitney Hodges Let us know if there are any other details to be aware of!

**Gisselle Jiménez** · 2026-05-07 16:23 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1778170999245939)
We are looking at this timeline for this project:

*Week 1 (May 27 – June 3)* Kickoff call to make initial tech connections and set up the necessary accounts, as well as getting access to branding assets, photos, and template emails.

*Week 2 (June 3 – June 10)* Start BTS tech setup (phone setup, DNS, A2P, snapshot) and design/copy work.

*Week 3 (June 10 – June 17)* Complete implementation and review design work.

*Week 4 (June 17 – June 24)* Launch implementation. Share assets with the client for feedback and schedule an onboarding call.

**Gisselle Jiménez** · 2026-05-13 14:58 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1778684282727509)
@Danielle McGinnis @Tina Henares Here is Tirzah's completed questionnaire! @Whitney Hodges, did we provide this document?
It says that assets were uploaded to a shared drive, but I don't see anything in her client folder. Let me know if we need to follow up

<https://docs.google.com/document/d/1Y1tNoznNzWZql8fx0uTlb4pl6semhFAPgn8MAVMxfzA/edit?tab=t.0>
> **Whitney Hodges** · 2026-05-13 15:19 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1778685582460409)
> @Gisselle Jiménez Tirzah created this doc. We may just need to ask for access to the shared drive

**Gisselle Jiménez** · 2026-05-14 16:02 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1778774572298729)
@Danielle McGinnis @Tina Henares EIN and brand assets have been uploaded to folder! I believe we're just missing brand photos and fonts which they will review tomorrow.

<https://drive.google.com/file/d/1Lw2o9LY4RMvVhlUE4ujU9eHh6OqfB3Y_/view?usp=drive_link|EIN>, <https://docs.google.com/document/d/1vlRrfcSDSlFdMFvyXPIIOWjbXJQHqXpqblCbaW_TFlU/edit?usp=drive_link|Pricing, ><https://drive.google.com/drive/folders/1H4PPrL1NnlicuJyJwoOdzKQy3Wez0FXo?usp=drive_link|Logos and photos>

Let me know if you need anything else!

**Whitney Hodges** · 2026-05-27 15:35 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1779896129503099)
@Danielle McGinnis Good morning! I'm planning to join just for the first few minutes of the kickoff call with Tirzah to welcome her and officially introduce the two of you. Thank you!

**Whitney Hodges** · 2026-05-27 16:12 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1779898361901749)
@Gisselle Jiménez Hi! I just hopped off the call with Tirzah and Danielle. Danielle mentioned that their LeadLock subaccount didn't exist yet. Can you please create that ASAP?
> **Gisselle Jiménez** · 2026-05-27 16:13 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1779898394614129)
> On it!

**Gisselle Jiménez** · 2026-05-27 16:16 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1779898580441999)
@Danielle McGinnis Subaccount has been created!

**Danielle McGinnis** · 2026-05-27 18:33 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1779906797821869)
@Whitney Hodges @Gisselle Jiménez <https://www.canva.com/login/?redirect=%2Fdesign%2FDAHKr4OOyF0%2Fshare%3Finvite%3DQZU4TnkEHPYOcMKJ4SZTLA%26accessToken%3DqM13NACUZyFKCzxK1Pasmg%26utm_campaign%3Ddesignshare%26utm_medium%3Demail%26utm_source%3DshareButton|here> is the pricing and inclusions info for the pricing guide.

**Danielle McGinnis** · 2026-05-27 18:34 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1779906851960539)
I also forwarded it to the hello@leadlock email in case this link doesn't work

**Danielle McGinnis** · 2026-05-27 18:47 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1779907677684179)
Hey @Tina Henares :wave::skin-tone-4: Merriwether Manor has completed their LeadLock kickoff call. Here's what I'm tracking that we need for them:

Here's the info I have from our call so far:

• <https://drive.google.com/drive/folders/1H4PPrL1NnlicuJyJwoOdzKQy3Wez0FXo?usp=drive_link|Brand Assets> - Heads up! They are likely changing the venue name to Dogwood Reserve. Tirzah will let us know by the end of the week. Colors will remain the same, but there will be a new logo provided.
• <https://meriwethermanor.com/|Website> - Heads up! They currently have new photos that will be taken (photoshoot scheduled for June 24th). They anticipate their new website not being live until the second week of July. 
Here's what I know that they'll need (so far):
Forms:
• Pricing Guide (Gisselle/Whitney creating this)
• <https://meriwethermanor.com/contact|Website Inquiry Form> 
Wedding Inquiry Emails:
• Nurture Sequence for wedding inquiries
• Post Tour Nurture Sequence (5)
• Tour Reminder Sequence
• Cancellation &amp; No Show Emails
Non-Wedding Inquiry Emails. They may be requesting the following (Tirzah to check with Alina):
• Nurture Sequence for non-wedding inquiries
• Post Tour Nurture Sequence (5)
• Tour Reminder Sequence
• Cancellation &amp; No Show Emails
Texts:
• Automated text messages:
    ◦ Tirzah would line an SMS inquiry workflow that mirrors the wedding inquiry email workflow 
    ◦ Note: Tirzah will likely be requesting the inquiry sequence be stretched to longer than 14 days. She may request additional emails, or, she may ask for more time between inquiry emails
Funnels:
• Tour Booking Calendar Funnel (1) - Weddings only (for now)
• Website inquiry thank you page
• Preferences Funnel
• A2P Compliance Website
• Zoom Landing Page
cc: @Gisselle Jiménez
> **Gisselle Jiménez** · 2026-06-25 16:10 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1782403822118419)
> Hi, @Danielle McGinnis! Have we received new brand assets for Dogwood Reserve?
> **Danielle McGinnis** · 2026-06-25 16:13 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1782404004476879)
> @Gisselle Jiménez just shared with you what Tirza sent me. She told me she had previously shared it with Whitney. Sorry for not sharing last week!
> **Tina Henares** · 2026-06-25 16:49 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1782406197345709)
> Hi @Danielle McGinnis! Could you share it with me as well?
> **Danielle McGinnis** · 2026-06-25 16:59 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1782406777048449)
> @Tina Henares sent!
> **Tina Henares** · 2026-06-25 17:00 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1782406847027289)
> @Danielle McGinnis thank you!
> **Gisselle Jiménez** · 2026-06-25 17:54 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1782410063389259)
> Hi, @Danielle McGinnis! Hmm, I haven't seen the new brand assets email shared with Whitney, and it seems like the I cannot see the attachments in the email you forwarded. :face_holding_back_tears: But those are the ones that I see uploaded to the drive right?
> **Danielle McGinnis** · 2026-06-25 18:34 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1782412478880729)
> Oh yes! There wasn't anything new sent. Sorry 

**Danielle McGinnis** · 2026-05-27 19:14 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1779909282125089)
Also just a heads up that Tirzah will be out with no access to email from 5/31 - 6/16 and we have a part 2 kickoff call with Alina scheduled for 6/17 at 12pm EST. Just wanted to add this as if there's anything we need from her, we'll need to get it by the end of this week or there my be a delay in responses (her assistant may be able to help).

**Gisselle Jiménez** · 2026-06-01 17:34 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1780335298422899)
has renamed the channel from "cfpfu_meriwethermanor" to "cfpfu_dogwoodreserve"

**Gisselle Jiménez** · 2026-06-01 17:36 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1780335365207899)
Hey @Tina Henares @Danielle McGinnis! Just a heads up that Meriwether Manor is now Dogwood Reserve. Alina purchased <http://www.dogwoodreserve.com|www.dogwoodreserve.com>, and a new logo should be coming in the next 7-10 days.

We'll hold off on the pricing guide design until we have the new logo, brand assets, and photos from their photo shoot.

Tirzah will be out of the country until June 17th. Her assistant Carolann (<mailto:hello@tirzahcaffee.com|hello@tirzahcaffee.com>) can help with anything in the meantime, and Alina has permission to contact Tirzah through Carolann for final logo approval while she's away.

cc: @Whitney Hodges

**Danielle McGinnis** · 2026-06-17 16:32 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1781713949753479)
Does anyone have access to the Dogwood domain?

**Danielle McGinnis** · 2026-06-17 16:33 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1781713985119409)
Tirzah said she thinks she shared it. No worries if not. She's connecting me with Amy

**Gisselle Jiménez** · 2026-06-17 16:58 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1781715482028039)
@Danielle McGinnis Tirzah mentioned:
Alina purchased <http://www.dogwoodreserve.com|www.dogwoodreserve.com>

**Danielle McGinnis** · 2026-06-17 17:52 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1781718722446199)
@Gisselle Jiménez yep I know but I meant did anyone receive access so I can go in and create the DNS records. All good!  Told Tirzah to share it with me

**Danielle McGinnis** · 2026-06-17 17:59 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1781719151061869)
<!channel> just FYI - The logo and brand guide for Dogwood have been added to their Brand Assets folder: <https://drive.google.com/drive/folders/1H4PPrL1NnlicuJyJwoOdzKQy3Wez0FXo?usp=drive_link>

**Danielle McGinnis** · 2026-06-17 18:26 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1781720798073329)
@Gisselle Jiménez @Whitney Hodges Hi! Can you send over the invoice for the additional non-event workflow to Alina at the following email address: <mailto:alinastevens1@aol.com|alinastevens1@aol.com>
Thank you!
> **Gisselle Jiménez** · 2026-06-17 20:16 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1781727373235509)
> @Danielle McGinnis @Whitney Hodges Sent!
> **Gisselle Jiménez** · 2026-06-25 15:49 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1782402546432229)
> @Danielle McGinnis @Whitney Hodges Should we follow up on this?
> **Danielle McGinnis** · 2026-06-25 15:57 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1782403059562529)
> @Gisselle Jiménez yes please. Can you loop Tirzah in on the follow up message?
> **Gisselle Jiménez** · 2026-06-25 15:58 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1782403127112649)
> Will do!

**Danielle McGinnis** · 2026-06-29 22:05 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1782770715417329)
@Whitney Hodges Dogwood has been submitted for A2P compliance.

**Danielle McGinnis** · 2026-07-01 18:52 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1782931967468029)
Hi <!channel> dropping the new Dogwood photos here for anyone who needs them: <https://www.dropbox.com/scl/fo/ne1k2je3vsxyupil76tvj/AC1Z1fpj1WDvx0em67UV1gs?rlkey=poql8i44g7j13563fy9rl48xe&amp;st=y0bfs2zg&amp;e=1&amp;dl=0|dropbox.com/scl/fo/ne1k2je3vsxyupil76tvj/…?rlkey=poql8i44g7j13563fy9r…&amp;st=y0bfs2zg&amp;…>
> **Gisselle Jiménez** · 2026-07-02 15:42 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1783006934927059)
> Thank you! Added to the bookmarks folder of this channel!

**Danielle McGinnis** · 2026-07-01 19:00 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1782932423290329)
@Whitney Hodges Dogwood has been approved for A2P compliance!:raised_hands::skin-tone-4:

**Gisselle Jiménez** · 2026-07-06 19:28 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1783366118765499)
Hi, @Tina Henares! Find Dogwood's pricing guide below! If you could please review it and make any design edits you feel are needed. :pray: This was mostly with information found on their current website and the pictures they shared, but they will probably need to add some info or let us know what they would like to include specifically. (They only shared the what's included section and the investment details)

<https://canva.link/4berpiaftfwwreh|canva.link/4berpiaftfwwreh>
> **Tina Henares** · 2026-07-09 14:17 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1783606653180729)
> Good morning @Gisselle Jiménez! I think the pricing guide looks great :slightly_smiling_face: I love how you used the little symbol in their logo to decorate the pages.
> **Gisselle Jiménez** · 2026-07-09 14:41 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1783608093054859)
> Great! Thank you, @Tina Henares :pray: @Danielle McGinnis Pricing guide should be good to include in the assets for review now. As mentioned, we would just need them to confirm the specific info they want us to include since I just took what they have on their current website, but here are things pending like the spaces and the new contact info. Thank you!

**Gisselle Jiménez** · 2026-07-06 19:28 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1783366128057289)
Thank you!

**Danielle McGinnis** · 2026-07-06 19:44 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1783367080396959)
Thank you @Gisselle Jiménez! I will be sure to have Tirzah review this and provide feedback when I send their assets over for review.

**Gisselle Jiménez** · 2026-07-07 16:26 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1783441604219449)
@Tina Henares, new images for Dogwood! I have included the link in the bookmarks folder of this channel!

<https://createdbydestiny.pixieset.com/dogwoodreserve/|createdbydestiny.pixieset.com/dogwoodreserve>

**Gisselle Jiménez** · 2026-07-07 16:33 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1783441992672719)
@Tina Henares I swapped some pictures in the investment guide but feel free to edit as needed if you think we should change any of them! Ty!!

**Danielle McGinnis** · 2026-07-10 12:00 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1783684806579129)
Good morning @Whitney Hodges! I've drafted the asset review email for Tirzah. Would you like to take a look at the asset review email or review the account in general before I send it over to her? Thanks!
> **Whitney Hodges** · 2026-07-10 16:15 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1783700138955259)
> @Danielle McGinnis Yes, I can take a look. Did you email it to me already?
> **Danielle McGinnis** · 2026-07-10 16:16 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1783700161678979)
> Perfect! Will forward now
> **Danielle McGinnis** · 2026-07-10 16:17 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1783700223280769)
> Sent!
> **Whitney Hodges** · 2026-07-10 16:44 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1783701850728349)
> @Danielle McGinnis I think this looks good!
> 
> I noticed on the investment guide that there isn't a description for the bride and groom suites. I'm guessing that is because we need that information from them, but I think it would be best to address this head on in the email, so it doesn't seem like we sent over something unfinished.
> 
> Also, I could foresee them asking for the thank you page image to be updated to be non-wedding specific since all types of inquiries will be routed to that page, so it may be good to get in front of that.
> 
> Additionally, I wouldn't be surprised if Tirzah asks for a doc that includes the email and text copy for her to be able to review and make edits, so just a heads up on that. I know she wants to see what our typical process is like, so we don't need to include it unless she asks.
> 
> Thank you!!
> 
> cc @Tina Henares
> **Danielle McGinnis** · 2026-07-10 16:47 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1783702065469209)
> @Whitney Hodges got it!
> 
> I will mention that we need additional info on the bride and groom suites and can fill that in once provided.
> 
>  @Tina Henares when you get  moment can you tweak the image on the thank you page?
> 
> And noted about the email copy doc. Will work with Tina to pull this together if Tirzah asks.  In the meantime, I'll get this sent over.
> **Danielle McGinnis** · 2026-07-10 16:47 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1783702070622869)
> Thank you!!!!
> **Tina Henares** · 2026-07-10 17:11 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1783703472503219)
> @Whitney Hodges @Danielle McGinnis changed the thank you page image to this one of their property!
> 📎 Screenshot 2026-07-10 130022.png (png, saved as `files/F0BGPAVGKQU-Screenshot_2026-07-10_130022.png`)

**Danielle McGinnis** · 2026-07-24 18:37 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1784918257343669)
@Gisselle Jiménez Hi! Tirzah sent over some pricing guide edits today. She made comments directly on the doc: <https://www.canva.com/design/DAHNtoRL2ig/3RkwWVWYizBZZGEQV-NBuA/edit|canva.com/design/…/edit>
> **Gisselle Jiménez** · 2026-07-24 18:38 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1784918286710779)
> Thank you!! Working on it!
> **Gisselle Jiménez** · 2026-07-27 20:03 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1785182598104769)
> @Danielle McGinnis Edits have been made!
> **Danielle McGinnis** · 2026-07-28 11:49 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1785239369857479)
> @Gisselle Jiménez thank you! I'll get this sent over to Tirzah!

**Danielle McGinnis** · 2026-07-24 18:40 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1784918438983669)
@Tina Henares Tirzah requested a document with all workflow copy so she can edit it all in once place, but wanted to flag that she wants to remove all references to "click the link and book a tour" from the email copy. I've already started to prepare <https://docs.google.com/document/d/1g5QHl0xWT4SpwCP0PCrptP4UmvxV36sEvdH60VbZIik/edit?usp=sharing|the document>. Can you tweak this language in the inquiry sequence?
> **Tina Henares** · 2026-07-30 19:02 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1785438138006629)
> @Danielle McGinnis I added all the sequences to the <https://docs.google.com/document/d/1g5QHl0xWT4SpwCP0PCrptP4UmvxV36sEvdH60VbZIik/edit?tab=t.0#heading=h.nj3v9tqipi|document>. The only copy I saw that referenced "click the link and book a tour" were in the missed tour sequence, so I removed them. Did Tirzah specifically say there was copy like that in the inquiry sequence? I can take another look if so!
> 📎 Dogwood Inquiry Sequences (gdoc, **hosted on docs.google.com** — not in Slack, [open](https://docs.google.com/document/d/1g5QHl0xWT4SpwCP0PCrptP4UmvxV36sEvdH60VbZIik/edit?tab=t.0#heading=h.nj3v9tqipi))
> **Danielle McGinnis** · 2026-07-30 19:08 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1785438494142369)
> @Tina Henares thanks! I think she's referring to this language in the inquiry emails:
> 
> "Ready for your complimentary private tour? We’d love to show you around.
> Book Your Private Tour [Button]"
> **Tina Henares** · 2026-07-30 19:10 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1785438653382589)
> @Danielle McGinnis Thanks for clarifying! Do you think we should redo the text on the button as well then? 
> **Tina Henares** · 2026-07-30 19:12 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1785438777058459)
> To something like “Schedule your visit” or “reserve your tour”?
> **Danielle McGinnis** · 2026-07-30 19:37 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1785440232218739)
> @Tina Henares here's what Tirzah's initial message said: "we will be manually making all the tours. As such, any of those links you send out to book on their own, can be removed."
> 
> I'm almost wondering if we change the language to "contact us to book a tour" or something to that affect.
> 
> She'll be sending us over edits on Monday as well, so she'll likely be updating the language to match their preference/process as well. I'd use the "contact us to book a tour" language for now and the we can see what Tirzah comes back with on Monday.

**Danielle McGinnis** · 2026-07-30 17:53 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1785434003211349)
Hey @Tina Henares just a quick heads up that I just sent some font and brand color updates your way from Tirzah.
> **Tina Henares** · 2026-07-30 18:59 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1785437946625269)
> @Danielle McGinnis Thanks for sending those over. I'll implement them in LeadLock. Excited to see what their new website looks like when it goes up!
> **Danielle McGinnis** · 2026-07-30 19:08 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1785438510690579)
> Thank you so much!

**Gisselle Jiménez** · 2026-08-03 18:06 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1785780396256699)
@Whitney Hodges @Danielle McGinnis

All titles have been updated to the Playfair display font!

<https://www.canva.com/design/DAHNtoRL2ig/3RkwWVWYizBZZGEQV-NBuA/edit|canva.com/design/DAHNtoRL2ig/3RkwWVWYizBZZGEQV-NBuA/edit>

**Danielle McGinnis** · 2026-08-04 12:00 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1785844810407669)
Morning @Gisselle Jiménez thank you so much for the update! Will let Tirzah know :-)

**Danielle McGinnis** · 2026-08-04 12:15 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1785845700358089)
@Tina Henares good morning! Just a quick note that Tirzah made edits to the <https://docs.google.com/document/d/1g5QHl0xWT4SpwCP0PCrptP4UmvxV36sEvdH60VbZIik/edit?tab=t.0|copy doc>. Given the turnaround time needed to make these updates, I went ahead and made them, but Tirzah would like 3 emails added to the events sequence for 45, 90, and 90 days from inquiry. Can you get those templates created sometime today so I can add them to the workflows? :pray::skin-tone-4: Tirzah is planning to launch tomorrow, so please let me know if you're unable to get to these to get them back to Tirzah by end of day. Thank so much!
> **Tina Henares** · 2026-08-04 15:49 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1785858560688069)
> Hi @Danielle McGinnis! I took a look at Tirzah's comments in the doc and I think she wants the 3 additional emails added to the wedding nurture sequence not the events sequence. I created the three extra templates (emails 8, 9, and 10) in the wedding inquiry sequence in LeadLock so they're ready to be added to the workflows. I also added them to the <https://docs.google.com/document/d/1g5QHl0xWT4SpwCP0PCrptP4UmvxV36sEvdH60VbZIik/edit?tab=t.0#heading=h.nj3v9tqipi|copy doc> so she can review them there as well. Thanks!!
> 📎 Dogwood Inquiry Sequences (gdoc, **hosted on docs.google.com** — not in Slack, [open](https://docs.google.com/document/d/1g5QHl0xWT4SpwCP0PCrptP4UmvxV36sEvdH60VbZIik/edit?tab=t.0#heading=h.nj3v9tqipi))
> **Danielle McGinnis** · 2026-08-04 17:19 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1785863988562399)
> @Tina Henares ok perfect! Thank you!

**Danielle McGinnis** · 2026-08-04 17:46 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1785865616728829)
<!channel> Circling back to confirm the final edits are now with Tirzah. We have made all of her requested edits and she has the remaining copy needed to modify accordingly (SMS, additional emails added, and 1 workflow question from me) for tomorrow's live launch of the website.

**Danielle McGinnis** · 2026-08-04 19:09 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1785870555610859)
@Whitney Hodges I just hopped off a call with Tirzah. Im finalizing a few edits and she requested a Post Tour Survey be added to the process) but the main thing I wanted to discuss was they intend to go live today or tomorrow which is before the onboarding call. I expressed to Tirzah the importace of the onboarding call but I wanted to also chat this out with you re: their subscription. When would the monthly subscription be started? Tirzah did state that she is willing to do a shortened onboarding call (minus Alina for now) but we're just not sure when exactly but it would definitely be after they go live with LeadLock/their website. Can you let me know you thoughts here on the LL subscription? Thanks!
> **Whitney Hodges** · 2026-08-04 19:21 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1785871291773459)
> @Danielle McGinnis I know the onboarding call is typically when the subscription kicks in as that is when the client starts actually utilizing LeadLock, but if Tirzah is wanting LeadLock to go live for them before an official onboarding call, I think we need to start charging their monthly subscription at the time that they actually start using it. I believe there is also still an outstanding invoice that Alina needs to pay for the additional workflow we created. @Gisselle Jiménez should be able to verify. I would want that payment to be taken care of before they go live, if possible. 
> 
> I like the idea of an abbreviated onboarding call for now. The good news is that Tirzah is very familiar with GHL and seems to be overseeing everything, so there shouldn't be the same initial learning curve.
> 
> Next time, I think if a client is requesting to go live on a certain date, we need to encourage them to book their onboarding call for that same date, if possible.
> 
> Let me know what you think and if you need any other support with this. Thank you!!
> **Danielle McGinnis** · 2026-08-04 19:38 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1785872291352019)
> @Whitney Hodges Ok noted about encouraging the onboarding call before going live. Honestly, I was under the impression that you were aware of the overall plan so I didn't know to flag this for you earlier especially since this is a non traditional account given that Tirzah is acting on behalf of Alina.
> 
> Regarding the open invoice, Tirzah just told me on the call today that she is having an extremely hard time communicating with Alina as she is extremely busy these days which I suspect is the reason for the delayed invoice.
> 
> @Gisselle Jiménez can you link the invoice? I'm wondering if I text it to Tirzah and she texts it to Alina if we can get this paid today. Tirzah said Alina is really pushing to launch everything so that may actually encourage her to move quicker if she knows this can potentially delay things further.
> 
> Lastly, regarding the LL subscription, I completely agree about starting the subscription as soon as the form is embedded on their website since that technically kicks off their beginning to using the system.
> **Danielle McGinnis** · 2026-08-04 19:50 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1785873056906979)
> @Whitney Hodges @Gisselle Jiménez I just re-forwarded the invoice as Tirzah wanted it at the top of Alina's inbox. Hopefully we can get that paid today.

**Danielle McGinnis** · 2026-08-04 19:58 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1785873505605639)
@Tina Henares FYI Tirzah is requesting a photo swap on the thank you page. Stay tuned. Will let you know when she sends it over 

**Danielle McGinnis** · 2026-08-04 20:09 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1785874194607959)
@Tina Henares also text message photo swaps incoming…

**Danielle McGinnis** · 2026-08-04 20:26 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1785875197171209)
@Tina Henares Tirzah is linking the photto be swapped in the Dogwood Inquiry sequence doc
> **Tina Henares** · 2026-08-04 20:34 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1785875671173049)
> I'll keep an eye out for the photo swaps :slightly_smiling_face:
> **Danielle McGinnis** · 2026-08-04 20:39 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1785875960503319)
> I think I saw she was linking photos already 
> **Tina Henares** · 2026-08-04 20:39 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1785875982070239)
> Yes implementing them right now
> **Tina Henares** · 2026-08-04 20:46 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1785876399592719)
> Here's what the updated website thank you page looks like
> 📎 Screenshot 2026-08-04 154219.png (png, saved as `files/F0BMXNH62AH-Screenshot_2026-08-04_154219.png`)
> **Tina Henares** · 2026-08-04 20:50 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1785876642952779)
> @Danielle McGinnis did Tirzah specify which text message she wanted to swap the photo for? In the doc, she put a new photo with the tour confirmation SMS for weddings, but then commented that that photo should be in the first text people get, so I wanted to clarify. Thanks!
> **Tina Henares** · 2026-08-04 20:56 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1785876994997619)
> @Danielle McGinnis update, I just swapped the photo in the first wedding inquiry SMS to the one she put in the doc. Let me know if there's any other edits I can help out with and I will also keep an eye on the shared doc in case she requests more photo swaps there!

**Danielle McGinnis** · 2026-08-04 22:24 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1785882264132239)
@Gisselle Jiménez @Whitney Hodges Tirzah just notified me that Alina just paid her past due invoice. 
> **Whitney Hodges** · 2026-08-04 22:32 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1785882769700389)
> Got it, thanks!!

**Danielle McGinnis** · 2026-08-05 15:18 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1785943094071199)
Morning @Whitney Hodges ! Just FYI Tirzah and I (and her assistant) will be doing an abbreviated onboarding call this afternoon!
> **Whitney Hodges** · 2026-08-05 15:22 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1785943327487769)
> Love to hear it!!

**Danielle McGinnis** · 2026-08-05 17:19 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1785950387197779)
@Whitney Hodges Tirzah Carolann and I just wrapped up our onboarding call. Ive sent over the embed codes to Ami and have activated the LeadLock subscription. 

@Tina Henares heads up, Tirzah will be sending over additional photos to swap out for the events texts. 

**Danielle McGinnis** · 2026-08-05 18:20 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1785954045861619)
@Tina Henares Tirzah just added more photos to the inquiry document to swap out in the events texts. 
> **Tina Henares** · 2026-08-06 13:26 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1786022786873889)
> Hi @Danielle McGinnis! Confirming I swapped in the photos she added to the inquiry doc!

**Danielle McGinnis** · 2026-08-06 16:31 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1786033861393109)
Hi @Gisselle Jiménez Tirzah wants this image swapped out in the investment guide. Here's her feedback as well: "Attached is the one to please use and keep the logo and text in the sky."
📎 Investment Guide Cover Photo-Dogwood.jpg (jpg, saved as `files/F0BNLAZ9PT3-Investment_Guide_Cover_Photo-Dogwood.jpg`)
> **Gisselle Jiménez** · 2026-08-06 19:26 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1786044391368959)
> @Danielle McGinnis Swapped!
> **Danielle McGinnis** · 2026-08-06 20:22 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1786047724908149)
> Thank you! Will let Tirzah know!

**Danielle McGinnis** · 2026-08-10 16:25 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1786379118670149)
@Whitney Hodges heads up. Just heard from Tirzah that the investment guide link wasn't working. ALL of their records have become unverified over the weekend. :weary: I have already sent the new records to Ami. Just wanted to keep you in the loop
> **Whitney Hodges** · 2026-08-10 16:27 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1786379270320349)
> Ok, thank you

**Danielle McGinnis** · 2026-08-10 16:28 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1786379315776929)
I also gave her the snippet for the pricing guide so they can send that out temporarily until the records are updated 

**Danielle McGinnis** · 2026-08-10 16:49 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1786380588526489)
@Whitney Hodges all records are reverified for Dogwood!

**Whitney Hodges** · 2026-08-12 18:53 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1786560785903199)
@Danielle McGinnis just a heads up that Tirzah texted me wanting me to have visibility into their "issues". Not sure what she's experiencing but feel free to fill me in and let me know how me and @Gisselle Jiménez can support!!
📎 Screenshot_20260812-134834.png (png, saved as `files/F0BPS844V4N-Screenshot_20260812-134834.png`)

**Danielle McGinnis** · 2026-08-12 18:58 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1786561133778729)
@Whitney Hodges sure! It been tons of tweaks needing to be made and I do feel its due to the quick kickoff with Dogwood. 

Some were tech glitches I could fix, some I had to hop on GHL for, sone were her nit understanding the way GHL works, and then additional requests continue to come through after they onboarded. 

She's been texting me daily. Ive been doing my best to keep up with the messages. 

Happy to hop on a call with you if that's better to give you a run through of everything. 
> **Whitney Hodges** · 2026-08-12 19:24 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1786562691910729)
> @Danielle McGinnis Thank you for handling all of that! I didn't realize she was texting you. Please don't ever feel obligated to give a client your phone number.
> **Danielle McGinnis** · 2026-08-12 19:27 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1786562821118129)
> @Whitney Hodges noted. She had sent an email a few weeks ago requesting a phone call and has been texting ever since. 
> **Whitney Hodges** · 2026-08-12 19:32 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1786563169505569)
> @Danielle McGinnis Ah gotcha! Just FYI we're already adding to our contracts that client calls are required to be over Zoom and they need to join from their laptop and be able to screenshare if necessary.
> 
> If she texts you again, I'd just ask if she could please send the information to you in an email, so it doesn't get lost.
> 
> When I spoke to Tirzah yesterday, she was very complimentary of you and said you are super responsive, so thank you so much for that.
> 
> She mentioned that things have felt "bumpy" though. I then pointed out that she chose to skip our official onboarding call and expedite her launch...
> **Danielle McGinnis** · 2026-08-12 19:42 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1786563726923219)
> Understood! I definitely don't like receiving texts lol but I was trying to be extra responsive to Tirzah especially since she's sending leads our way. 
> 
> I agree it has felt a bit bumpy. She assured me that she understood GHL and Im realizing that is not the case so the abbreviated call she requested was not a good idea. 
> 
> Also there are things that she assumed that we do that Hitched did that we dont do as a standard practice (for instance pre and post tour surveys) so Im still working with her on getting those things created as they were not requested on the call or prior to the launch. 
> **Whitney Hodges** · 2026-08-12 19:46 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1786564016634179)
> I really appreciate that. I have just now nicely told her not to text you anymore. If anything ever comes up in the future that makes you uncomfortable, please please let me know!

**Whitney Hodges** · 2026-08-12 19:26 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1786562785363309)
@Danielle McGinnis As far as the most recent email from Tirzah, I thought that we always set it up, so that if and when someone books a tour/consultation they are automatically removed from the inquiry nurture sequence. I thought this was already part of the workflows we have set up in the snapshots. Is that not the case?

**Danielle McGinnis** · 2026-08-12 19:42 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1786563743587569)
Its not @Whitney Hodges 

**Danielle McGinnis** · 2026-08-12 19:43 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1786563786128029)
Some clients want it on until they actually book, some want it off when they book a tour. Some want it to remain until the wedding gets booked
> **Whitney Hodges** · 2026-08-12 19:45 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1786563925714339)
> @Danielle McGinnis Ok, thank you for letting me know! I didn't realize this was the case. Do we have this as a step somewhere in the process to ask the client their specific preference?
> 
> I'm thinking the standard should be that someone is removed from the inquiry sequence unless the client specifies otherwise. Thoughts?
> 
> cc @Gisselle Jiménez
> **Danielle McGinnis** · 2026-08-12 19:47 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1786564071125129)
> I agree. I think it should be standard practice to remove from inquiry sequence once a tour is booked. 
> 
> As Im walking them through on the onboarding call I usually just ask. It's not listed anywhere though. I missed this with Tirzah given our 30 minute call. 
> **Whitney Hodges** · 2026-08-12 19:48 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1786564094734639)
> Makes sense!
> **Whitney Hodges** · 2026-08-12 19:48 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1786564138236759)
> @Danielle McGinnis When you have the opportunity, could you please update the snapshots accordingly?
> **Danielle McGinnis** · 2026-08-12 20:16 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1786565793218369)
> Of course!

**Danielle McGinnis** · 2026-08-19 22:36 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1787179010758299)
@Whitney Hodges @Gisselle Jiménez Tirzah has updates to the pricing guide. How do we want her to handle requests for edits? She said in the past with Hitched, they were to just edit their link and then tell them when they did so they could update the internal link on the Hitched side. 
> **Whitney Hodges** · 2026-08-19 22:46 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1787179590847879)
> @Danielle McGinnis I think that same process should work for us. But you can also show her how and where she can update it inside LeadLock, so she can do it herself without waiting on you. What do you think?
> **Danielle McGinnis** · 2026-08-20 13:00 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1787230800729719)
> @Whitney Hodges GM! She had already sent this over yesterday. The pricing guide is in Canva correct?
> **Whitney Hodges** · 2026-08-20 13:01 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1787230881100029)
> @Danielle McGinnis yes, I believe so. @Gisselle Jiménez should be able to help you locate it if needed
> **Danielle McGinnis** · 2026-08-20 17:18 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1787246301674819)
> @Whitney Hodges thanks. I think I was asking bc you stated for me to share her where she can update it inside LeadLock but the link is not changing, correct? She just wants the document itself updated.
> 
> @Gisselle Jiménez these were her edits.
> 📎 image005 (1).jpg (jpg, saved as `files/F0BRM02PG90-image005_1_.jpg`)
> **Whitney Hodges** · 2026-08-20 17:23 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1787246586290779)
> @Danielle McGinnis If we're linking directly to Canva, then you're right, the link shouldn't need to change. We can make the requested change, and the Canva link should still work and reflect the updates. However, I think we can give her edit access to the Canva design if we haven't already, so that if she wants to make changes in the future we can. Thoughts?
> **Danielle McGinnis** · 2026-08-20 17:46 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1787247975375919)
> @Whitney Hodges I definitely think it makes sense to give her edit access! How about we make this round (since I told her we would) and once the edits are made I will share the editable link with her?
> 
> cc: @Gisselle Jiménez
> **Whitney Hodges** · 2026-08-20 17:46 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1787247988782939)
> Perfect!
> **Danielle McGinnis** · 2026-08-21 14:19 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1787321953143269)
> @Gisselle Jiménez GM! Just wanted to check to see if these edits were made yet?
> **Gisselle Jiménez** · 2026-08-21 14:56 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1787324176177859)
> Hi, @Danielle McGinnis! Prices have been updated
> **Gisselle Jiménez** · 2026-09-02 19:27 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1788377268559359)
> Hi, @Danielle McGinnis! Were you able to share the editable link with Tirzah? Yesterday, she tagged Whitney on <https://docs.google.com/document/d/1vlRrfcSDSlFdMFvyXPIIOWjbXJQHqXpqblCbaW_TFlU/edit?disco=AAACGRWy5yI&amp;usp_dm=true&amp;tab=t.0|this pricing document >with changes, but they were the changes you requested last time. So we just want to be clear if she will handle edits, or request them to you or Whitney so we can be clear moving forward. Thanks!
> **Danielle McGinnis** · 2026-09-02 19:33 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1788377627251459)
> @Gisselle Jiménez <https://www.canva.com/design/DAHNtoRL2ig/3RkwWVWYizBZZGEQV-NBuA/edit|This is the link> Tirzah should have.

**Whitney Hodges** · 2026-08-21 13:40 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1787319640392669)
@Gisselle Jiménez we need to send the ELEVATE proposal to <mailto:alina@dogwoodreserve.co|alina@dogwoodreserve.co>m (please check to make sure that email is correct) more details in voice note
> **Whitney Hodges** · 2026-08-21 13:42 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1787319775720469)
> 📎 audio_clip_2026-08-21_08-40-47-061.m4a (m4a, saved as `files/F0BRN24KM6F-audio_clip_2026-08-21_08-40-47-061.m4a`)
> **Gisselle Jiménez** · 2026-08-21 15:37 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1787326677829809)
> Hi, @Whitney Hodges Email with ELEVATE (ads management only) has been drafted to Alina.
> 
> I was able to set up the email with the contract to be sent after proposal is completed.
> 
> It's looking like this:
> 
> I'll just adjust the spacing of the button
> 📎 image.png (png, saved as `files/F0BRV7BJUPL-image.png`)
> **Gisselle Jiménez** · 2026-08-21 15:38 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1787326696727499)
> I will also be on the lookout for duplicate project and archive them asap if it happens
> **Gisselle Jiménez** · 2026-08-21 15:38 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1787326734835189)
> I'll look into the questionnaire!

**Danielle McGinnis** · 2026-08-22 00:21 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1787358119891689)
@Viktor please check Dogwoods GHL funnels to make sure the landing pages aren't indexed. I just updated all codes.
> **Gisselle Jiménez** · 2026-08-22 15:53 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1787413997892709)
> @Viktor Please above
> **Viktor** · 2026-08-22 15:53 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1787414036018989)
> @Gisselle Jiménez @Danielle McGinnis — just re-checked `<http://info.dogwoodreserve.com|info.dogwoodreserve.com>` live (Aug 22). **All 5 live pages are correctly noindexed.**  | Page | Status | |---|---| | `/` (Thank You) | :white_check_mark: `name="robots"` noindex | | `/home` | :white_check_mark: | | `/contact` | :white_check_mark: | | `/privacy` | :white_check_mark: | | `/terms` | :white_check_mark: | | `/thank-you` | :white_check_mark: |  Other paths I probed (`/book-a-tour`, `/tour`, `/thank-you-wedding-inquiry`, `/thank-you-events`, `/wedding-inquiry`) return 404 — nothing live there. Danielle, if there's a funnel on this domain at a URL not listed above, send me the slug and I'll verify it too, since the header code is per funnel.  Two notes: - Each page shows both tags — the HighLevel SEO-field one (`property="Robots"`, which Google ignores) and the working header one (`name="robots"`). That's expected and harmless. - noindex only applies on Google's next crawl, so anything already indexed can take days to a few weeks to drop out. Forcing faster removal needs Search Console access on the domain.
> **Danielle McGinnis** · 2026-08-24 17:37 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1787593064514409)
> @Viktor not sure I understand your statement here: Other paths I probed (`/book-a-tour`, `/tour`, `/thank-you-wedding-inquiry`, `/thank-you-events`, `/wedding-inquiry`) return 404 — nothing live there. Danielle, if there's a funnel on this domain at a URL not listed above, send me the slug and I'll verify it too, since the header code is per funnel.
> 
> I have checked and these pages do not return a 404 error:
> • <https://info.ridgefieldweddings.com/tour-booking|info.ridgefieldweddings.com/tour-booking>
> • <https://info.ridgefieldweddings.com/thank-you|info.ridgefieldweddings.com/thank-you>
> • <https://info.ridgefieldweddings.com/thank-you-events-423349|info.ridgefieldweddings.com/thank-you-events-423349>
> **Viktor** · 2026-08-24 17:38 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1787593090871969)
> @Danielle McGinnis good catch on the confusion — my 404 list was about **Dogwood only** (`<http://info.dogwoodreserve.com/tour|info.dogwoodreserve.com/tour>`, `/book-a-tour`, etc.), not Ridgefield. Those Dogwood slugs genuinely don't exist; I just re-confirmed both still 404. The Ridgefield URLs you listed are a different domain, and they are live.  I re-checked your three Ridgefield pages just now — **all three are correctly noindexed**:  | Ridgefield page | Result | |---|---| | `/tour-booking` | 200 :white_check_mark: `name="robots"` noindex | | `/thank-you` | 200 :white_check_mark: | | `/thank-you-events-423349` | 200 :white_check_mark: |  So nothing is missing — Ridgefield and Dogwood are both fully covered. The only thing my probe can't do is guess funnel slugs, which is why I asked for any URL not in my list. If you have Dogwood pages live at slugs I haven't tried, send them and I'll verify.
> **Danielle McGinnis** · 2026-08-24 17:44 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1787593453878329)
> @Viktor
> • <https://info.dogwoodreserve.com/wedding-tour-booking-page|info.dogwoodreserve.com/wedding-tour-booking-page>
> • <https://info.dogwoodreserve.com/tour-booking-page|info.dogwoodreserve.com/tour-booking-page>
> • <https://info.dogwoodreserve.com/wedding-tour-confirmation|info.dogwoodreserve.com/wedding-tour-confirmation>
> • <https://info.dogwoodreserve.com/tour-confirmation|info.dogwoodreserve.com/tour-confirmation>
> 
> **Viktor** · 2026-08-24 17:44 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1787593475010529)
> @Danielle McGinnis checked all four — **all live (200) and all correctly noindexed** with `&lt;meta name="robots" content="noindex, nofollow"&gt;` in the header:  | Dogwood page | Title | Result | |---|---|---| | `/wedding-tour-booking-page` | Tour Booking Page | :white_check_mark: | | `/tour-booking-page` | Tour Booking Page | :white_check_mark: | | `/wedding-tour-confirmation` | Booked Tour | :white_check_mark: | | `/tour-confirmation` | Booked Tour | :white_check_mark: |  So Dogwood is now verified at 10 live pages, all clean. Thanks for the slugs — I've saved them so future checks cover them automatically instead of me guessing URLs.  (Only remaining caveat: noindex applies at Google's next crawl, so anything already indexed drops out over days–weeks.)

**Whitney Hodges** · 2026-08-28 17:54 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1787939673729829)
@Gisselle Jiménez We need her ads onboarding questionnaire before her kickoff call
> **Gisselle Jiménez** · 2026-08-28 18:33 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1787942037797789)
> @Whitney Hodges I didn't realize it was on Monday:face_holding_back_tears: Email follow up is drafted!

**Gisselle Jiménez** · 2026-08-28 20:27 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1787948844822769)
has renamed the channel from "cfpfu_dogwoodreserve" to "c_dogwoodreserve"

**Viktor** · 2026-08-31 12:37 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1788179868774469)
**Prep for today's 3:00pm Ads Kickoff with Alina Stevens + Tirzah Caffee** — @Whitney Hodges  1. **Nothing exists yet on the ads side**: no Dogwood Google Ads account under our MCC, and no Dogwood ad account visible in our Meta connection. This call's real job is access + owners + dates. 2. **The ads onboarding questionnaire still isn't in hand** (Gisselle's follow-up email drafted Friday) — plan to walk through the key questions live rather than wait. 3. **Relationship context matters more than metrics here**: the ELEVATE yes came with the "mitigate what Ami raised" condition, and Tirzah's LeadLock rollout has been high-touch. Setting expectations and a single point of contact is the win today.  Full brief in thread :point_down:
> **Viktor** · 2026-08-31 12:38 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1788179898973899)
> ### Dogwood Reserve — Ads Kickoff Call, Mon Aug 31, 3:00pm CT *Guests: Alina Stevens (<mailto:alina@dogwoodreserve.com|alina@dogwoodreserve.com>), Tirzah Caffee (<mailto:info@tirzahcaffee.com|info@tirzahcaffee.com>). All checks run live this morning.*  **The decision this call has to make:** who is giving us what access, by when — and what Alina should expect in weeks 1–6. No budget or targeting decisions here; those belong on the Ads Strategy call.  ### Asset status — verified live today | Item | Status | |---|---| | Google Ads account under MCC 5981440631 | **Does not exist** — no Dogwood account linked | | Meta ad account | **Not visible** in our Meta connection | | GA4 / GTM access | Not granted to WIA | | Ads traffic landing page | Not built (checklist untouched) | | LeadLock sub-account | Live since ~May, but **not readable from any of our HighLevel connections** — lead volume, pipeline and tour bookings could not be verified |  So there is no performance data to present, and that's fine — this is a setup call.  ### The three things to nail on the call **1. Expectations.** Ramp timeline, what "leads" will mean, that the first 2–3 weeks are learning, and how often we'll meet. Worth being explicit that ads results depend on the LeadLock follow-up already running.  **2. Access, with names and dates.** Ask Alina to create/share, in her own assets: Google Ads account (we link to the MCC), Meta ad account + page + pixel via Business Manager, GA4 property and GTM container. Note who actually holds these — the site sits with Celebrate Creative (Ami / Jason on DNS), so "Alina will send it" may really mean "Ami will send it." Get the right name on the call.  **3. Schedule the next two calls:** Messaging &amp; Positioning interview (feeds Tina's landing-page copy) and the Ads Strategy call (budget, targeting, offer).  ### Onboarding questionnaire You flagged Friday that we need it before this call; Gisselle drafted the follow-up email but it hadn't landed as of this morning. Suggest collecting the essentials verbally today — ideal client, what makes Dogwood different, top competitors, ballpark booking value, current inquiry volume and close rate — so Tina and Carmen aren't blocked.  ### Open items in ClickUp (folder: Dogwood Reserve, ELEVATE Clients) - **Google + Meta Onboarding — 83 open tasks**, none with due dates. Owners already assigned: Carmen (Launch Google Ads, Loom walkthrough), Jacqueline (build + launch campaigns, briefing Ivy), Ivy (creative), WIA Support (invoice, presentation, email updates). - **Ads Traffic Landing Page checklist — 18 open**: Tina owns copy/build/mobile, Carmen owns Google + Meta tracking installs, plus domain connection and funnel map. - **LeadLock Onboarding** list still has post-call/BTS items on Danielle, and Danielle also still has "work through Tirzah's three emails" from the Aug 17 team meeting. - Nothing has due dates — worth setting them off today's call so the 83-item list becomes a real plan.  ### Relationship context worth having in your head - Tirzah referred Dogwood; the ELEVATE green light on Aug 20 was conditioned on us "mitigating the things Ami brought to your attention." Best read of that is the handoff seam between Celebrate Creative (site/DNS/Cloudflare) and WIA (funnel/tracking) — the Ridgefield DNS deletion is the concrete incident behind it. - Dogwood launched LeadLock before the onboarding call, which produced a lot of after-the-fact tweaks and daily texts to Danielle. Proposing a single clear intake path and one weekly touchpoint for ads would land well. - Their DNS records went unverified once already in August (fixed same day).  ### Suggested talk track 1. Warm open, confirm what success looks like for Alina in the next 90 days (tours booked, not clicks). 2. Walk the ramp timeline; be honest that week 1–2 is build and access. 3. Run the access checklist live, assign a name and a date to each line. 4. Collect the questionnaire answers verbally. 5. Close by booking Messaging &amp; Positioning and Ads Strategy on the calendar before hanging up. 6. If Ami's concerns come up: one owner doc for DNS/tracking, a co-work session at cutover, and change notifications both ways.  ### What I could not verify - **Gmail is returning a 401 auth error this morning**, so I could not read the ELEVATE proposal thread, confirm whether the agreement is signed, whether the invoice/subscription start date is set, or whether the questionnaire came back overnight. Please check before the call. - **LeadLock CRM for Dogwood is not connected to us** — no lead counts, no pipeline, no booking numbers. - No Google or Meta data exists to verify (accounts not created). - GA4 skipped by design.

**Gisselle Jiménez** · 2026-08-31 15:45 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1788191133348519)
@Whitney Hodges Presentation: <https://canva.link/1tcbhny7bpx4pfn|canva.link/…>

I also drafted an email to alina just confirming logins to have ready!

**Gisselle Jiménez** · 2026-08-31 15:56 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1788191797731559)
<!channel> Hi team! Dogwood has officially signed on for ELEVATE! She is already a LeadLock client so we will now be setting up Google ads, Meta Ads, and creating an ads traffic landing page.

She has scheduled her Ads Kickoff Call for today. From there, we will schedule her Messaging & Positioning Interview and her Ads Strategy Call.

Sharing her onboarding resources below. These can also be found in the Bookmarks folder at the top of this channel.

• <https://drive.google.com/drive/folders/1pJwadFky3EF-ISvUEKsyFX5xQp3pBdhc?usp=drive_link|Client Folder>
• <https://portal.dubsado.com/public/form/view/6a8daa6631789f53e78e0bc8?|Google + Meta Onboarding Questionnaire>
• <https://app.clickup.com/9011165651/v/li/901114402417|Google + Meta Onboarding Checklist>
• <https://app.clickup.com/9011165651/v/li/901114402419|Ads Traffic Landing Page Checklist>
@Whitney Hodges Let us know of any other details that need to be shared for this client!

**Whitney Hodges** · 2026-08-31 21:28 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1788211691066239)
@Viktor I'm trying to invite Dogwood Reserve to our Google Ads Client Center. I can't because I don't have a passkey. When I tried to set up a passkey previously, it said I wasn't able to. See screenshot. What do I do from here?
> **Viktor** · 2026-08-31 21:29 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1788211745063019)
> @Whitney Hodges Heads up: the screenshot didn't come through to me, so I'm going off the error you described — if the exact wording differs, paste the text and I'll narrow it down.  **What's happening.** Google now gates "sensitive" Google Ads actions — linking/inviting accounts, user access, billing — behind a verification step, and it wants a passkey or 2-Step Verification on the Google account you're signed in with. Being an MCC admin isn't enough on its own. The "you can't set up a passkey" message almost always means one of three things:  1. **Workspace policy is blocking it.** If you're signed in as <mailto:hello@weddingindustryads.com|hello@weddingindustryads.com> (a Google Workspace account), an admin setting can disable passkey/security-key enrollment. Fix is in the Google Admin console: *Security → Authentication → Passwordless / 2-Step Verification*, allow passkeys. 2. **The device or browser can't hold one.** Passkeys need a device with a screen lock (Face ID / Touch ID / PIN) and a current Chrome/Safari. An older desktop with no screen lock will refuse. 3. **Multi-login confusion.** If several Google accounts are signed into the same browser, enrollment often fails silently. Try a fresh incognito window signed into only the one account.  **What I'd do right now, in order:**  - **Turn on 2-Step Verification instead of a passkey** — Google accepts either for this check. <http://myaccount.google.com|myaccount.google.com> → Security → 2-Step Verification → phone or Google Authenticator. This is usually the 5-minute unblock. - **Or have another MCC admin send it** — if Christina or Carmen already has 2SV/passkey on their login, they can send the link request from the Client Center today and you're unblocked immediately. - **Or flip the direction** — Dogwood can request us from their side: in their Google Ads account, *Admin → Access and security → Managers tab → +* → enter our manager ID **598-144-0631**, then we approve it in the Client Center. Same end result, no invite needed from you.  One caveat: they may not have a Google Ads account created yet — as of this morning there was no Dogwood account under our MCC and nothing in Meta either, and the onboarding questionnaire still isn't back. If Alina hasn't created the account, the invite has nowhere to land regardless of the passkey.  Want me to draft the note to Alina asking her to send the customer ID (or to add us as manager from her side)?

**Gisselle Jiménez** · 2026-08-31 22:16 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1788214611149579)
@Whitney Hodges Welcome email is drafted! The recording was processing:face_holding_back_tears:

**Whitney Hodges** · 2026-08-31 22:33 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1788215634873189)
@Carmen Cruickshank Are you able to approve my request to link the Dogwood Reserve to our Google Ads Client Center?
📎 image.png (png, saved as `files/F0BTZQR18P4-image.png`)
> **Carmen Cruickshank** · 2026-09-01 18:22 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1788286956029159)
> It should be approved, let me know! @Whitney Hodges
> **Whitney Hodges** · 2026-09-01 18:24 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1788287090057259)
> @Viktor can you check?
> **Viktor** · 2026-09-01 18:25 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1788287143066209)
> @Whitney Hodges Checked live in the MCC just now — the link is **still not active**.  - The link record for Dogwood **305-263-3701** exists under Wedding Industry Ads Client Center (598-144-0631) with status **PENDING** (manager link id 6653563139). - Dogwood does **not** appear in the MCC's client list (59 linked accounts, none of them Dogwood), so nothing has actually been accepted yet.  So whatever @Carmen Cruickshank clicked hasn't landed — the request is still sitting in the same "Pending admin review" state your screenshot shows. Two things to try:  1. Carmen (or another MCC admin) re-opens **Admin → Access and security → Multi-party approvals → Account linking requests** and approves that row explicitly — the row should disappear from "pending" once it's really done. 2. If the request has already cleared the MPA gate, the remaining step is on the **Dogwood side**: in the Dogwood Google Ads account, **Admin → Access and security → Managers tab → Accept → Grant access**. That's the step people usually miss (Users tab won't show it).  Want me to re-check in a couple of hours and ping the thread the moment it flips to active?
> **Carmen Cruickshank** · 2026-09-01 18:44 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1788288255155899)
> @Viktor i don't see the pending request anymore because i approved it, the second photo is the comfirmation that i clicked on approve, where else could i check if this is not the case
> 📎 Screenshot 2026-09-01 at 2.42.47 PM.png (png, saved as `files/F0BUC3LS3GU-Screenshot_2026-09-01_at_2.42.47_PM.png`)
> 📎 Screenshot 2026-09-01 at 2.21.14 PM.png (png, saved as `files/F0BU8CY0GP4-Screenshot_2026-09-01_at_2.21.14_PM.png`)
> **Viktor** · 2026-09-01 18:44 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1788288286417699)
> @Carmen Cruickshank Your approval definitely registered — thanks for the screenshots. But that step and "account is linked" are two different gates, which is why we're both right:  | Stage | Where | Status now | |---|---|---| | 1. Multi-party approval (internal, another MCC admin OKs the outgoing request) | MCC → Admin → Access and security → Multi-party approvals | :white_check_mark: Done by you, 2:42 PM | | 2. Client accepts the manager invitation | **Dogwood's own** Google Ads account (305-263-3701) → Admin → Access and security → **Managers** tab → Accept → Grant access | :hourglass_flowing_sand: Still pending |  I re-queried the MCC just now (2:45 PM CT): the link record `customers/5981440631/customerClientLinks/3052633701~6653563139` is still **PENDING**, and 305-263-3701 doesn't show up in the MCC's client list yet. Your MPA approval only released the request to be sent — Dogwood has to accept it on their end.  Where you can check yourself, no API needed: **MCC → Admin → Access and security → Managers/Accounts → "Sent link requests"** tab (or Accounts → sub-account settings). It'll sit there as pending until Dogwood accepts, then the account appears in the account list and you can rename it `FS - Dogwood Reserve`.  @Whitney Hodges so the ball is with Dogwood: they log into their Google Ads, gear/Admin → Access and security → **Managers** tab (not Users) → Accept the invite from Wedding Industry Ads Client Center 598-144-0631. Want me to check again in a few hours and ping the thread when it flips to active?

**Whitney Hodges** · 2026-08-31 22:42 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1788216145428149)
@Danielle McGinnis @Tina Henares FYI just sent the email below to Ami:

_Hi Ami!_

_I hope you're doing well!_

_I just had my first onboarding call with Alina from Dogwood Reserve. Tirzah mentioned that creating their ads traffic landing page is your preference. I know we've briefly touched base on this, but I'd love to continue the conversation. I'm happy to collaborate and want to discuss the best approach._

_Also, I know you sent some items Danielle's way that came to light with Ridgefield, so I wanted to ensure we're all on the same page there and help tie up any loose ends._

_Are you free for a call on Thursday afternoon? I'm available anytime after 2:30pm CST._

_Thank you,_
_Whitney_

cc @Gisselle Jiménez

**Viktor** · 2026-09-02 12:35 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1788352543342849)
**Prep for today's 9:15am Messaging &amp; Positioning Interview — Alina Stevens + Tirzah Caffee** — @Whitney Hodges  1. **The questionnaire came in on 8/31 and it's unusually thorough** — competitors, keywords, demographics and geo are all already answered (and clearly Tirzah-assisted). Don't re-ask them; use the hour to pressure-test the positioning and fill the real gaps: offer/pricing, seasonality, and what "legitimate lead" means. 2. **Still blocked on access: Alina has not approved the Google Ads MCC link invite** — no Dogwood account exists under our MCC as of this morning, and no Dogwood Meta ad account is visible in our Meta connection. GTM access was invited 8/31. 3. **Tirzah changed the pricing yesterday** (Sep 1 comment on the PRICING doc: Sat $8,500 / Fri+Sun $5,500 / Mon–Thu $4,000, bar $1,250, coordination $2,500) — that's the number Tina's landing page and ad copy will lean on, so confirm it live.  Full brief in thread :point_down:
> **Viktor** · 2026-09-02 12:36 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1788352588767799)
> ### Dogwood Reserve — Messaging &amp; Positioning Interview, Wed Sep 2, 9:15am CT *Guests: Alina Stevens, Tirzah Caffee (+ <mailto:alinastevens1@aol.com|alinastevens1@aol.com>). All checks run live this morning. Ads Strategy Call is already booked for Wed Sep 9, 9:15am.*  **The decision this call has to make:** lock the positioning, offer and audience that Tina's landing page copy and Carmen's Google build will be written from — and set a definition of "legitimate lead" you'll be measured against.  ### What's new since Monday's kickoff brief | Item | Status today | |---|---| | Ads onboarding questionnaire | **In hand** (submitted 8/31, in the client Drive folder) — was the big gap Monday | | Google Ads account under MCC 5981440631 | **Still does not exist.** Carmen approved the link request on our side 8/31; Alina has not accepted the invite | | Meta ad account | **Not visible** in our Meta connection; questionnaire says she has none, and her Facebook Business Page is *"currently messed up"* | | GA4 / GTM | GTM account "Dogwood Reserve" (managed by <mailto:info@dogwoodreserve.com|info@dogwoodreserve.com>) **invited 8/31**; a GA4:left_right_arrow:Google Ads link notification also landed 8/31 | | <http://dogwoodreserve.com|dogwoodreserve.com> tracking | **GTM-5G36SNFQ is live** on the site. No GA4 ID or Meta pixel in the page source — they may fire inside GTM, which I can't read until the invite is accepted | | Ads traffic landing page | Not built. Whitney is talking to Ami about who builds it | | ClickUp checklists | Now have **due dates** (were bare Monday): Google+Meta 16 open, LP 16 open | | LeadLock CRM | Live since May but **still not readable from any of our HighLevel connections** — lead volume, pipeline and tour bookings cannot be verified by me |  No performance table this time: there is no ad spend anywhere yet, so any number would be invented.  ### From the questionnaire (verified — I read the PDF, not a summary) - **Positioning:** private 250-acre equestrian/country estate, exclusive use (one event at a time), up to 275 guests, multiple ceremony sites, Grand Pavilion, honeymoon suite, horses, lake, ~45 min from Atlanta. - **Competitor set (10, tiered):** Murphy Lane (Newnan), Farm at Wolf Creek, Oakhurst Farm, Three Oaks Farm as closest direct; Towerhouse, Wild Daisy, Vinewood Stables as premium/rural; Estate at Elegant Occasions, The Parterre, Valentine Orchard local; Hidden Haven, Sunny D, Whiskey Bonding Barn as lower-price barns. - **Keywords she supplied:** luxury/estate/equestrian wedding venue near Atlanta, Georgia estate wedding venue, wedding venue with horses Georgia, destination wedding venue Georgia, plus corporate retreat venue Georgia. - **Audience:** engaged women 23–38, HHI $100k+, wedding budget $30k–$100k+, 75-mile radius with emphasis on north/west Atlanta suburbs, Newnan/PTC/Fayetteville/Senoia, LaGrange, Columbus GA and Auburn/Opelika AL; wants a broader Atlanta+Birmingham+Montgomery "getaway" test. - **Secondary audiences she wants eventually:** corporate retreats, milestone events, photo/film location rentals. - **Budget:** $1,001–2,000/mo ad spend. **Success in her words:** "more legitimate leads" — and "looking for a fast approach to marketing as we build our SEO."  ### Pricing (Tirzah updated it yesterday) Saturday $8,500 · Fri &amp; Sun $5,500 · Mon–Thu $4,000 · bar service $1,250 · in-house day-of coordination $2,500 · add-ons: extra getting-ready hour $250, extra event hour $1,000, honeymoon suite $500. Rental window 11am–11pm. Worth confirming this is final and whether it goes on the site/LP — with Ridgefield and Pecan Springs, hidden pricing is the #1 conversion drag, and here the price point is the qualifier for a $30k+ budget audience.  ### The gaps the questionnaire does *not* answer — ask these 1. **What is a "legitimate lead"?** Ideally: correct date range, budget above the Saturday minimum, inside driving distance, wants an on-site tour. Get her to say the number of *tours per month* that would make this a win. 2. **Seasonality &amp; inventory** — which 2027 dates are still open, and are we selling Saturdays or filling Fri/Sun/weekdays? That decides both budget pacing and which price we advertise. 3. **Objections she hears on tours** — 45 minutes from Atlanta, no in-house catering?, guest travel/lodging, gravel/outdoor logistics. Those become the LP's FAQ section. 4. **Proof assets** — real weddings shot at Dogwood (new photos exist in Dropbox), any reviews yet under the new name; the rebrand from Meriwether Manor means near-zero brand search volume, which is exactly why we lead with non-brand search + Meta. 5. **Voice/brand words to avoid** — she's precise about the "estate, not a barn" line; capture the exact phrases so Tina writes in her language. 6. **Corporate/private events** — in or out of scope for round one? Recommend out: one audience, one offer, then expand.  ### Open items with owners (ClickUp, ELEVATE Clients → Dogwood Reserve) - **Carmen Cruickshank** — build Google Ads, Google tracking setup, connect Google account to the LeadLock sub-account, Loom walkthrough for client approval (due Sep 8), Google + Meta tracking on the LP. - **Tina Henares** — watch this interview recording + review brand assets (due Sep 5), build the ads traffic LP (due Sep 9), edits after client feedback. - **WIA Support / Gisselle** — **"Set up Recurring Invoice" is overdue (was due Aug 30)**; also custom GPT, funnel map, domain connection, share LP with client. - **Jacqueline / Ivy** — Meta build + creative, blocked until a Meta ad account exists. - Contract signed 8/24 and the $1,997 ELEVATE invoice paid 8/24 (Dubsado), so the recurring invoice gap is the only billing loose end.  ### Suggested talk track 1. Thank her for the questionnaire and say plainly you're not re-asking it — that buys goodwill after a high-touch LeadLock rollout. 2. Play back the positioning in one sentence and let her correct it: *"A private 250-acre equestrian estate 45 minutes from Atlanta that you take over for the entire day — not a room, not a barn."* 3. Define the lead: date range, budget, distance, tour booked. Land on a target tours/month. 4. Walk objections and proof — capture quotes verbatim for Tina. 5. Close the two access items live: **accept the Google Ads MCC invite** and fix/confirm the Facebook Business Page + Meta ad account so Jacqueline isn't blocked before Sep 9. 6. Set expectations for the Sep 9 Strategy Call: budget split, geo, offer, and what the LP will say about pricing.  ### What I could not verify - **LeadLock/HighLevel for Dogwood is not connected to us** — no lead counts, pipeline or tour-booking data. - **Google Ads and Meta**: no accounts exist, so nothing to measure (in scope, just not live). - Whether GA4 and the Meta pixel are firing through GTM-5G36SNFQ — needs the GTM invite accepted. - Whether the pricing in Tirzah's doc is final/public-facing. - GA4 skipped by design.

**Whitney Hodges** · 2026-09-02 13:17 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1788355046486879)
@Viktor I need to know based on what they already answered in the questionnaire and what already exists on their website, what specific sections/questions of the messaging and positioning questionnaire should I focus on? <https://docs.google.com/document/d/1yvreO5aF_9GxjMaqK3lV7I7Zzn_qAE8EuDpVK_euk_Y/edit?usp=sharing|docs.google.com/document/d/1yvreO5aF_9G…/edit?usp=sharing>

Also, I'm seeing that you do have access to the Dogwood's LeadLock subaccount. Please confirm and let me know what you're seeing there as far as leads, tours, bookings, conversations
📎 image.png (png, saved as `files/F0BUHDAV08H-image.png`)
> **Viktor** · 2026-09-02 13:17 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1788355057706459)
> On it — pulling the M&amp;P questionnaire doc, re-checking their website, and digging into the Dogwood LeadLock sub-account for leads/tours/bookings/conversations. Back shortly.
> **Viktor** · 2026-09-02 13:20 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1788355200626839)
> **Confirmed — I can read Dogwood's LeadLock sub-account** (my 7:35am brief said I couldn't; that was wrong, apologies). Here's the headline before your 9:15:  **Dogwood already gets leads — what they don't get is tours.** 17 real website inquiries since Aug 6 (39 contacts added in August), **14 of 17 came straight off `/pricing-packages/`**, almost all organic search or direct. From all of that: **1 tour scheduled (cancelled 8/30), 1 tour completed (8/15, marked Lost), 0 bookings.** Every other opportunity is still sitting in *Inquired* — nobody has moved a single lead to *Chatting*, and 29 of 30 conversations end with an automated outbound message.  **So the questionnaire sections to actually spend the hour on:** *Problems/Solutions*, *Customer Insights (objections)*, and *Decision Making*. Skip Brand Story, Mission/Values and most of the Ideal Client block — the About page and the ads questionnaire already answer them nearly verbatim.  Full section-by-section + the LeadLock detail in thread :point_down: @Whitney Hodges
> **Viktor** · 2026-09-02 13:22 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1788355364885179)
> ### Part 1 — M&amp;P Questionnaire: what to skip, what to dig on  **SKIP / just confirm in one line (already answered):**  | Section | Where it's already answered | |---|---| | Origin Story, Mission &amp; Vision, Values | About page — Alina bought the farm so her dad could live and work there; "faith, family, hard work, appreciation for the land"; family-run with Savannah (coordinator) and Matt (ops). That's a finished brand story. | | Ideal Client Profile / demographics | Ads questionnaire: engaged women 23–38, HHI $100k+, $30k–$100k+ wedding budget, 75-mi radius, north/west Atlanta suburbs + Newnan/PTC/Senoia/LaGrange/Columbus. | | "What questions do you frequently get" | The FAQ page already covers location, 275 capacity, what's included, parking, lodging, how to book, 25% retainer. Don't burn time re-collecting these — ask only for the questions that come up *on tours*, which aren't on the site. | | Competitors (list) | Questionnaire has 10, tiered. What's missing is the *why we win* part — see Decision Making below. |  **FOCUS — in this order:**  **1. The Offer + Problem/Solution (whole block, highest value).** Nothing on <http://dogwoodreserve.com|dogwoodreserve.com> is written in the couple's voice — every page describes the property ("Grand Pavilion," "12-hour window," "Terrace coming soon"). There is not one sentence about what the couple is worried about or what they want the day to feel like. That's exactly the raw material Tina has none of. Push hard on: - *What are they worried about?* and *What would be a perfect scenario?* — get verbatim quotes, not summaries. - *How do they want the day to feel?* — the answer that separates "private estate" from "pretty barn." - *3–5 reasons to book* — these become the LP bullets. Make her rank them.  **2. Customer Insights → objections, and how she answers them.** Ground this in her real numbers (below): 17 inquiries, 1 tour. Ask directly: *"When someone downloads pricing and goes quiet, what do you think happened?"* Candidate objections to test out loud: the $8,500 Saturday, 45 min from Atlanta, no on-site lodging, outdoor/weather, "coming soon" Terrace, no reviews or real-wedding photos under the new name. Her answers become the LP FAQ.  **3. Decision Making (all three questions).** Especially *"choosing between yours and a similar service, what tips the scale?"* — run it against the actual competitor names (Murphy Lane, Three Oaks, Oakhurst, Farm at Wolf Creek). And capture her exact wording on "estate, not a barn" and the exclusive-use / one-event-at-a-time point — that's the only true differentiator I can see on the site.  **4. Ideal Client — one modified question only.** "Most satisfied clients" doesn't work yet (no weddings held under the new brand). Replace with: *"Of the inquiries you've gotten so far, which ones felt right — and which felt like a waste of a tour?"* That's how you land the definition of a legitimate lead. Note her split so far: 16 wedding leads vs 3 event/corporate leads.  ### Part 2 — What's in LeadLock right now (live read, this morning)  **Leads** - 43 contacts total, but only **17 are real website inquiries** (Aug 6 – Sep 2), plus 2 test/partner records (Danielle, Tirzah). - **19 contacts are junk**: unnamed 706-area callers tagged "couldn't find caller name," nearly all created 8/21–8/25 in a burst. Looks like call spam or a missed-call artifact, not demand — but 2 of them got voicemail auto-texts, so they're polluting her inbox and any "lead count" she quotes you. - Volume ramp: 3 contacts in July → 39 in August → 1 so far in Sept. August was the first real month.  **Where they come from** — `/pricing-packages/` is the entire funnel: 14 of 17 inquiries submitted from that page. Attribution: mostly Organic Search (Google) and Direct, 2 from Facebook (fbclid), 1 chat widget. **Zero paid.** That's a clean pre-ads baseline for the Sept 9 strategy call.  **Pipeline (Inquiry pipeline: Inquired → Chatting → Tour Scheduled → Tour Complete → Contract Pending → Won)**  | Stage | Count | |---|---| | Inquired | 15 | | Chatting | 0 | | Tour Scheduled | 1 (Delaney Padgett — booked 8/30, **cancelled**) | | Tour Complete | 3 (2 are Danielle's test + Tirzah; only **Elizabeth Mauriello** 8/15 is a real couple — marked **Lost**) | | Contract Pending / Won | 0 (one opp, Dakota Calvert, is flagged status "won" but never left Inquired — likely a mis-click worth asking about) |  **Tours**: 6 calendar events ever on "Book A Wedding Tour" — 3 cancelled, and only 2 involve actual prospects. The virtual-tour and events-tour calendars have **zero** bookings.  **Conversations**: 30 threads. **29 of 30 end with an outbound message, and almost all of those are automated.** 11 leads did reply to the SMS nurture (~65% reply rate — genuinely good), but the thread then dies in automation. Only a handful of manual replies exist, all sending the pricing pamphlet. Nobody is asking for the tour.  ### Part 3 — Three things this changes for the call  1. **Reframe "more legitimate leads."** She's getting ~17/month for free. Ads will add volume to a funnel that currently converts inquiry→tour at roughly 1-in-17. Set the success metric as **tours per month**, and get her to own the follow-up side of it — otherwise we buy leads that die in *Inquired* and the ELEVATE spend looks broken by November. 2. **The pricing page is the proven converter.** People inquire *after* seeing prices. That's a strong argument for the ads LP leading with the Saturday $8,500 tier rather than hiding it — opposite of the Ridgefield problem. 3. **Ask who works the pipeline** (Savannah?). Zero leads have been moved to Chatting and 3 of 6 tours cancelled. Worth 5 minutes — and it may be a LeadLock training gap on our side, not hers.  Still blocked and worth closing live: **Google Ads MCC invite (3052633701) not accepted**, no Meta ad account, GTM invite from 8/31 unaccepted.

**Whitney Hodges** · 2026-09-02 14:10 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1788358232387329)
@Viktor To kick off the call, I'll see if she received the Google Ads linking invitation and ask her to accept it. Inside her Google Ads account, would it be in the Admin section? If it's not there, how can I have her request to link to our MCC from inside her account?
> **Viktor** · 2026-09-02 14:10 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1788358236833369)
> You're out of credits, but your request is saved.
> **Viktor** · 2026-09-02 14:11 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1788358272980519)
> :white_check_mark: @Whitney Hodges upgraded this workspace to the *400k credits/month* plan. Viktor is back in business!
> **Viktor** · 2026-09-02 14:11 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1788358300552619)
> @Whitney Hodges Yes — **Admin** is the right place, but she needs the **Managers** tab, not Users. Link `3052633701 → 5981440631` was still **PENDING** as of this morning, so the invite is sitting there waiting on her.  **Accepting the invite (30 seconds):** 1. In her Google Ads account: gear/**Admin** at the bottom of the left nav → **Access and security** 2. Click the **Managers** tab (people miss this — Users is the default tab) 3. Find *Wedding Industry Ads Client Center (598-144-0631)* → **Accept** → **Grant access**  **If nothing shows in Managers**, she can request the link from her side instead: - Same screen: **Managers** tab → blue **+** button → enter our manager ID **598-144-0631** → Send request. We approve it on our end and it links the same way.  **Two gotchas:** - She must be signed in as the account's **admin-level** user, and in the right account — if she has multiple Google logins in one browser, the invite can look "missing" simply because she's in the wrong profile. Have her read back the 10-digit ID at the top of the screen: it should be **305-263-3701**. - Google gates this behind 2-Step Verification/passkey on some accounts. If she hits "you can't complete this action," it's 2SV — <http://myaccount.google.com|myaccount.google.com> → Security → 2-Step Verification, then retry.  Ping me right after the call and I'll re-query the MCC to confirm it flipped from PENDING to ACTIVE (and rename it with the tier prefix).

**Whitney Hodges** · 2026-09-02 15:59 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1788364743034959)
@Carmen Cruickshank Hi! Just invited you to the strategy call for the Dogwood next Wednesday. Hoping we can handle it just as we did for Pecan Springs Ranch. We should have access to their Google Ad account now! Thank you!!
> **Carmen Cruickshank** · 2026-09-02 21:47 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1788385651652229)
> good to know, thank you @Whitney Hodges!

**Whitney Hodges** · 2026-09-02 16:01 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1788364917688319)
@Tina Henares @Danielle McGinnis Random question - did Tirzah pick the photo of the bridal suite that is going out with the first SMS message sent to new leads?

**Danielle McGinnis** · 2026-09-02 19:34 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1788377640578779)
@Whitney Hodges yes Tirzah picked all the images :slightly_smiling_face:

**Gisselle Jiménez** · 2026-09-02 20:10 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1788379853585379)
@Tina Henares @Carmen Cruickshank @Jacqueline Hood

Hey team! The Messaging & Positioning Interview for Dogwood Reserve has been completed and the ChatGPT project is ready to go with all resources added.  Log in using the <mailto:hello@weddingindustryads.com|hello@weddingindustryads.com> Google credentials. If you run into any verification issues, tag Whitney!

Feel free to scroll through the existing conversations for Meta ads, Google Ads strategy, and landing page copy as a starting point. Please continue refining from there and push back where needed. We want the copy to feel genuine and on-brand, not templated.

Here are the recording assets from the Messaging & Positioning Interview for reference:
• <https://drive.google.com/file/d/1OksH9Yb69MCYHSFJd-26NcrwSgbBNyGe/view?usp=drive_link|Recording>
• <https://drive.google.com/file/d/12w2HQOYFhw5VJGHSRiDl61ty4imqSetZ/view?usp=drive_link|Transcript>
• <https://docs.google.com/document/d/1NIVBTKr-eUJ5ct4R9EEW-wxzIeVzfZUkzyqA_BUPKxQ/edit?usp=drive_link|Summary>
• <https://docs.google.com/document/d/1yvreO5aF_9GxjMaqK3lV7I7Zzn_qAE8EuDpVK_euk_Y/edit?usp=drive_link|Messaging & Positioning Questionnaire>
Due dates have been updated in ClickUp. Here are your checklists:
• <https://app.clickup.com/9011165651/v/li/901114402417|Google + Meta Onboarding Checklist>
• <https://app.clickup.com/9011165651/v/li/901114402419|Ads Traffic Landing Page Checklist>
cc: @Whitney Hodges

**Danielle McGinnis** · 2026-09-03 22:13 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1788473633932989)
@Whitney Hodges FYI-

This just came in from Tirzah and Im logged off for the day. 

I did not enable disable contact timezone bc Dogwood books virtual tours. 
📎 IMG_2367.jpg (jpg, saved as `files/F0BUS0CL8VB-IMG_2367.jpg`)
> **Whitney Hodges** · 2026-09-04 00:08 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1788480500061859)
> @Danielle McGinnis Ok. Are you able to respond in the morning?
> **Whitney Hodges** · 2026-09-04 00:11 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1788480680641209)
> @Danielle McGinnis if they are manually booking all tours at this point, do we just need to disable it at this point?
> **Danielle McGinnis** · 2026-09-04 11:15 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1788520500953259)
> Morning @Whitney Hodges yep, responded and disabled the feature.

**Whitney Hodges** · 2026-09-04 16:44 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1788540269273939)
@Viktor we're seeing some issues for the Dogwood when they book tours for clients, they are selecting the right time (they are in est) but then somehow it shows up in cst, and the contacts receive appointment reminders that are an hour off. Do you have any advice on this? Is there anything you can see in their subaccount that would be causing this?
> **Viktor** · 2026-09-04 16:44 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1788540281145739)
> On it — pulling Dogwood's HighLevel calendar + account timezone settings now to see where the hour is coming from.
> **Viktor** · 2026-09-04 16:46 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1788540419805909)
> @Whitney Hodges Found it, and it's a one-setting fix. Dogwood's sub-account timezone is set to **America/Cancun**, not Eastern. Cancun is UTC-5 and never observes daylight saving, so from March to November it sits exactly on Central Daylight Time — one hour behind Greenville, GA. Every appointment in the account is stamped `-05:00`, which is why right times go in and Central times come out. Fix: sub-account **Settings → Business Profile → Timezone → (GMT-4) America/New_York**. Details + one caution before flipping it in the reply below.
> **Viktor** · 2026-09-04 16:47 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1788540438857479)
> **What I verified live in the sub-account**  | Check | What I found | | --- | --- | | Account / business timezone | `America/Cancun` — UTC-5, no DST (business address is Greenville GA, so it should be `America/New_York`) | | All 8 tour appointments on file | every one stored with a `-05:00` offset, i.e. Central-equivalent right now | | Calendar-level timezone | no override returned on any of the 4 active tour calendars — they inherit the account setting | | Contact timezones | auto-detected per contact and not reliable: Lindsey and Elizabeth = `America/New_York`, Delaney (a 706 Georgia number) = `America/Chicago` |  **Why it looks like "the right time turns into CST"** Whoever set the account up picked Cancun from the dropdown, most likely because it shows as GMT-5 and Eastern *is* GMT-5 in winter. But Cancun doesn't spring forward, so between the second Sunday in March and the first Sunday in November the whole account runs an hour behind local Eastern time — booking widget slots, the calendar view Tirzah books from, appointment reminder merge fields, all of it. Left alone it would quietly look fixed after Nov 1 and break again Mar 8.  The contact-timezone piece is a second, smaller factor: reminders normally render in the contact's own detected timezone, and that detection is wrong on at least one contact. Danielle turning on "disable contact timezone" this morning pins contact-facing times to the account timezone, which is the right move — but it pins them to the *wrong* timezone until the account setting is corrected. Account timezone fixed + that toggle on = everyone sees the same Eastern time.  **One caution before flipping it** HighLevel stores appointments as real moments in time, not as "11:00 on the calendar." So after the switch, appointments already on the books will display one hour later than they do today. I checked: the only upcoming appointment right now is Danielle's 9/9 9:30am test on the Events Tour calendar (Lindsey Thompson's 9/5 onsite is cancelled), so there is nothing real to repair — which makes today the cheapest possible day to change it. Do it before the next real tour is booked.  **Suggested order (your call):** 1. Sub-account Settings → Business Profile → Timezone → `(GMT-04:00) America/New_York`, save. 2. Open each of the 4 active tour calendars → Availability tab → confirm timezone shows Eastern and not a custom override (the API can't see that field, so it needs eyes in the UI). 3. Settings → My Staff → check the profile timezone on both admins (Tirzah Caffee and The Dogwood Reserve Team) — a stale user timezone can still skew what they see when booking. 4. Book one throwaway tour after the change and confirm the confirmation SMS/email time matches what was picked.  I haven't changed anything. Say the word and I'll write the plain-English steps for Tirzah, or a short note to her explaining what was wrong and what we corrected.
> **Whitney Hodges** · 2026-09-04 16:49 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1788540596999909)
> @Danielle McGinnis see above..I'm hopeful that this is the fix. @Gisselle Jiménez fyi for you as well because I think the time zone is selected when actually creating the subaccount. Worth checking on this for Dos Palomas too
> **Viktor** · 2026-09-04 16:51 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1788540682050639)
> Checked — @Gisselle Jiménez you're right that it's set at sub-account creation. **Dos Palomas is fine** (`America/Chicago`, Boerne TX). I scanned all 58 sub-accounts while I was in there; these are the ones whose timezone doesn't match their address and are off by an hour *right now*:  | Sub-account | Set to | Should be | | --- | --- | --- | | Dogwood Reserve (Greenville GA) | America/Cancun | America/New_York | | Key Moment Films (West Palm Beach FL) | America/Cancun | America/New_York | | King Mansion (Harrisburg PA) | America/Cancun | America/New_York | | Bring on the Bash (Manheim PA) | America/Cancun | America/New_York | | Water's Edge (Centerport NY) | America/Cancun | America/New_York | | All Hands Detailing (Point Lookout NY) | America/Cancun | America/New_York | | Luxury Travel Boutique (Whitehouse OH) | America/Chicago | America/New_York | | About A Day (San Antonio TX) | America/Chihuahua | America/Chicago | | About Love (San Antonio TX) | America/Chihuahua | America/Chicago | | Rescue Equity (Liberty Hill TX) | America/Belize | America/Chicago |  All the same trap: Cancun, Chihuahua and Belize sit at the right offset but never observe daylight saving, so they only look correct Nov–Mar. Maria Bayer (Phoenix) is the reverse — set to America/Los_Angeles, which is fine in summer and an hour off in winter. Everyone else checks out.  Only the ones with live calendars and reminders actually hurt, so Dogwood is the urgent one. Happy to write Gisselle a one-line check for the onboarding checklist if that's useful.
> **Danielle McGinnis** · 2026-09-04 16:56 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1788540979496869)
> @Whitney Hodges I will change it right now. Tirzah provided this information at onboarding so Im pretty sure I set it to this instead of EDT which is the New York timezone.
> 📎 image.png (png, saved as `files/F0BUN36F49M-image.png`)
> **Viktor** · 2026-09-04 16:57 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1788541029507079)
> @Danielle McGinnis That makes total sense — Tirzah wrote "EST" and the dropdown option that looked like EST is the trap. `America/New_York` is the one to pick even though it says EDT right now: it's not a summer-only setting, it just shows EDT March–November and flips itself back to EST in the fall. Anything with "EST" baked in stays stuck an hour behind all summer.  One heads-up after you save: appointments already booked will show an hour later than they do now. I checked — the only one on the books is your 9/9 9:30am test on the Events Tour calendar, so nothing real to redo. Ping me after and I'll re-pull the calendars to confirm it took.
> **Danielle McGinnis** · 2026-09-04 16:57 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1788541057518339)
> that one from 9/9 is a test from me. I actually need to cancel that
> **Viktor** · 2026-09-04 16:58 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1788541101804799)
> Perfect — cancel it and the calendar is completely empty, so the timezone switch has zero side effects. Cleanest possible time to do it.
> **Danielle McGinnis** · 2026-09-04 17:07 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1788541642708379)
> Done!
> **Viktor** · 2026-09-04 17:08 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1788541703856169)
> Confirmed live — account timezone now reads `America/New_York` and new appointments are stamping `-04:00` (Eastern) instead of `-05:00`. Both old test appointments are cancelled, so the calendar is clean. Worth one real booking test from the widget to see the confirmation SMS time match, and it's also worth a glance at each of the 4 tour calendars' Availability tab plus your and Tirzah's profile timezones, since those can override the account setting and the API can't see them.
> **Danielle McGinnis** · 2026-09-04 18:10 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1788545459537129)
> @Viktor I just went into the account and see that Tirzah scheduled a test and they've also scheduled additional tours just now. Can you check those? I did check the availability tab and it shows edt
> **Viktor** · 2026-09-04 18:12 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1788545547293589)
> Checked — all three new bookings came in correct. EDT on the Availability tab is exactly what you want to see right now.  | Appointment | Booked for | Offset | Contact timezone | | --- | --- | --- | --- | | Tirzah Caffee (test) | Mon 9/7, 11:00am ET | -04:00 ✓ | America/New_York ✓ | | Courtney Battle | Mon 9/7, 1:30pm ET | -04:00 ✓ | America/New_York ✓ |  Both were created after your change (1:01pm and 1:06pm CT), both stamp Eastern, and both contacts are on New_York, so their reminders will read the same time the venue sees. Worth having Tirzah eyeball the confirmation text on her test to close the loop.  One thing still to watch: contact-level timezones are auto-guessed and not always right. Delaney Padgett (706 area code, so Georgia) is stamped `America/Chicago`. Her tour is cancelled so it's harmless today, but if she rebooks, her reminder would read an hour off even though the account is now correct. Two ways to handle it — fix that one contact's timezone, or turn on "disable contact timezone" so every reminder renders in venue time. You left that off for the virtual tours, which makes sense if you want out-of-state couples to see their own time; just flagging that it's the setting that decides which way those go.
> **Whitney Hodges** · 2026-09-04 18:14 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1788545688070319)
> @Danielle McGinnis I thought we had already talked about disabling contact timezones? Did that change not stick?
> **Viktor** · 2026-09-04 18:15 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1788545754855969)
> It did stick — and I need to correct myself: I just checked the live setting and Dogwood has `disableContactTimezone = true`, so contact timezones **are** disabled. My last message said it was off; I was going off Danielle's note from yesterday instead of reading the account. Sorry about that.  What that means in practice: every reminder renders in the venue's timezone, which is now Eastern, so the Delaney-type mis-stamped contact I flagged can't cause an off-by-an-hour reminder. Nothing more to do there — the account timezone was the only real problem, and it's fixed.

**Jacqueline Hood** · 2026-09-06 00:47 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1788655667876819)
@Ivy Ayala hi there! Here's the creative brief for the client attraction campaigns: <https://docs.google.com/document/d/1A9hBoLbGAuMU5zJ_eBJJiY3TpNipPEwQTMHq4CuYdjY/edit?usp=sharing|docs.google.com/document/d/1A9hBoLbGAuM…/edit?usp=sharing>

**Carmen Cruickshank** · 2026-09-08 20:13 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1788898403576139)
@Whitney Hodges just wanted to let you know, heres the strategy i customized for tommorrow including keywords: <https://docs.google.com/document/d/1WYPynmvUoSsA3PIV47vgeSTZVe8QedcllE5CL5Ory5k/edit?tab=t.0#heading=h.c43eumufnvxp|docs.google.com/document/d/1WYPynmvUoSs…/edit?tab=t.0#heading=h.c43eumufnvxp> just FYI
> **Whitney Hodges** · 2026-09-08 20:44 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1788900292983409)
> Thank you! I believe she is open to spending up to $2000/month on ads. Do you think we should start with a higher monthly Google Ads budget?
> **Carmen Cruickshank** · 2026-09-09 13:51 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1788961868959539)
> yes that'd be ideal to start, so are we thinking 1k for each platform?
> **Viktor** · 2026-09-09 14:11 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1788963090702339)
> @Carmen Cruickshank @Whitney Hodges — on "$1k each platform": if Alina confirms $2,000, I'd weight it **Google $1,200 / Meta $800** rather than a straight 50/50. Reason, from our own venue accounts (live pull, Aug 10 – Sep 8):  | Account | Daily budget | 30d spend | Clicks | Avg CPC | Conv | % impressions lost to budget | |---|---|---|---|---|---|---| | Ridgefield | $33.33 | $977.31 | 843 | $1.16 | 10 | 17% | | Diamond A | $16.66 | $481.96 | 581 | $0.83 | 3 | 20% | | Weinberg (general) | $15.66 | $466.85 | 373 | $1.25 | 33 | 21% |  Every one of them is losing impressions to budget, and the two running at ~$16/day are the ones losing the most. $500/mo Google = **$16.66/day**, which is that same capped tier — in metro Atlanta, where venue CPCs run above our small-market accounts, it buys roughly 12–15 clicks/day. That's thin for a launch where we also need conversion data fast for bidding.  Two practical points for the split: - **Meta can't spend on day one anyway** — there's still no Dogwood ad account shared with WIA and the FB page needs fixing, so partner access is the gate, not creative (Ivy already has Jacqueline's brief). Front-loading Google and stepping Meta up once access lands is the natural sequence. - **Google's launch is due Sep 14, our LP isn't live until Sep 17–18.** If we launch on `<http://dogwoodreserve.com/weddings/|dogwoodreserve.com/weddings/>`, the conversion tag has to go in first — the GTM container on that site is currently empty, so at $1,200/mo we'd be spending ~$40/day blind until tracking is installed.  So: Google $1,200 / Meta $800, Meta phased in as access opens — or hold at $1,000 total until tracking is live and step up. Happy to model the Atlanta keyword set against Carmen's list if you want a click/lead forecast before committing the number.

**Viktor** · 2026-09-09 12:43 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1788957783203369)
**Dogwood Reserve | Ads Strategy Call — 9:15am CT today** @Whitney Hodges @Carmen Cruickshank  - **Her Google Ads account is now live under our MCC** — `FS - Dogwood Reserve` (305-263-3701), billing approved, 0 campaigns. The 8/31 invite blocker is closed; we can build this week. - **Budget is the real decision today.** Carmen's plan is built at $1,000/mo split 50/50, but Alina is open to ~$2,000 — settle it now because the Google build is due Sep 14. - **Tracking is at zero and day-one landing page is undecided.** GTM-5G36SNFQ is on the site but the container holds no tags; the plan's LP (`<http://dogwoodreserve.com/weddings/`|dogwoodreserve.com/weddings/`>) and its conversion URL (`info.` funnel thank-you) don't match, and our own LP isn't live until Sep 17–18.  Full brief in thread :point_down:
> **Viktor** · 2026-09-09 12:43 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1788957784532049)
> **Dogwood Reserve — Ads Strategy Call prep · 9:15am CT** (Alina Stevens + Tirzah Caffee; Carmen on the invite)  ### 1. The decision this call has to make: what budget we build to Carmen's strategy doc (shared in here 9/8) is built at **$1,000/mo split evenly — Google $500 ($16.66/day), Meta $500 in two phases**. In this channel yesterday you said Alina is open to **up to $2,000/mo**, and her questionnaire answer was $1,001–2,000/mo. Carmen's Google build is due **Sep 14**, so the number has to be settled today, not after. At $16.66/day in metro Atlanta, Google Search will be thin — Dos Palomas and Diamond A both sit budget-capped at similar daily caps. If she confirms $2,000, the cleanest split is Google $1,000–1,200 (real coverage on Atlanta wedding-venue terms) and Meta the rest.  ### 2. Her Google Ads account is now live under our MCC — and completely empty Verified live this morning: **`FS - Dogwood Reserve` (CID 305-263-3701)**, status ENABLED, USD, America/New_York, **billing setup APPROVED** (payments account "Dogwood Reserve"). 0 campaigns, $0 spend, no ad history at all. So the MCC-invite blocker from 8/31 is closed — nothing stands between us and building. One catch: the account's **only conversion action is a GA4 import called "Form"**, already set as primary. A GA4-imported action reports nothing until GA4 exists and fires — see below.  ### 3. Tracking is at zero, and the landing page for day one is undecided - `<http://dogwoodreserve.com|dogwoodreserve.com>` carries **GTM-5G36SNFQ**, but I pulled the container itself: **it holds no tags** — no GA4, no Google Ads conversion tag, no Meta pixel. Nothing is measurable today on any channel. - The strategy doc's landing page is **`<http://dogwoodreserve.com/weddings/`**|dogwoodreserve.com/weddings/`**> (live, 200, and it embeds a LeadConnector/LeadLock form — so leads do reach the CRM), but the doc's conversion action is **`<http://info.dogwoodreserve.com/thank-you`**|info.dogwoodreserve.com/thank-you`**> (the LeadLock funnel, which does have `noindex, nofollow` — Danielle's fix held). Those two don't match. - Meanwhile our own ads-traffic LP isn't ready: **Tina's LP copy to Ami is due Sep 11, domain connect Sep 17, client approval Sep 18**. Google is due to launch before that. Pick one on the call: launch on `<http://dogwoodreserve.com/weddings/|dogwoodreserve.com/weddings/>` with tracking installed, or hold Google until our LP is live.  ### Performance (live pulls today) | Channel | Status | Last 30d | Prior 30d | | --- | --- | --- | --- | | Google Ads (305-263-3701) | account live, no campaigns | $0 · 0 clicks · 0 conv | $0 | | Meta | **no Dogwood ad account shared with WIA** (not visible in our list) | — | — | | LeadLock (`IAfZCWz2SlgOE6081j3F`) | live | 26 opps (11 in last 7d) | 28 opps in 60d, 29 in 90d |  LeadLock 30-day pipeline: 22 Inquired · 2 Tour Scheduled · 2 Tour Complete · 1 won · 1 lost. Healthy organic/site flow, but **25 of 26 sources are a bare `+`** (one `<http://chatgpt.com|chatgpt.com>`), i.e. no UTMs are being captured — so today we cannot attribute a single inquiry to a channel. That gets fixed by the same tracking work, and it's worth telling Alina now so the first monthly report isn't a surprise.  ### Tracking / config issues 1. GTM container on the main site is empty → GA4 + Google Ads conversion + Meta pixel all still to install (Carmen owns both "Install Google Ads tracking" and "Install Meta Ads tracking"). 2. Conversion action "Form" is a GA4 import — it will read 0 until GA4 exists. Recommend a direct Google Ads conversion on the LeadLock thank-you URL as the primary at launch. 3. No Meta ad account and, per her August note, the FB Business Page was "messed up" — Meta Phase 1 ($10/day client attraction) can't start until page + ad account + partner access exist. Ivy already has Jacqueline's creative brief (9/6), so creative isn't the blocker; access is. 4. Hidden-field UTMs on the LeadLock forms aren't populating (all sources `+`).  ### Open items &amp; owners (ClickUp folder 90117951715) - **Complete Ads Strategy Call** — due today. - **Connect Google account to LeadLock sub-account** — Carmen, due Sep 10. - **Build out Google Ads / Google tracking setup / Loom walkthrough** — Carmen, due Sep 14; **Send Loom for approval** — WIA Support, Sep 14. - **Draft LP copy to send Ami** — Tina, due Sep 11; **Connect domain** Sep 17; **Share for approval** Sep 18 (WIA Support). - **Conversion Ads setup** Oct 2 · **Retargeting** Oct 9 · Client Attraction ads + "Approve ads" no due date. - **Troubleshoot auto-populating form fields for the post-tour survey** — Danielle, was due Sep 2, still open. - Tour-time/timezone mismatch you raised 9/4 (EST bookings showing CST reminders) — Danielle disabled the contact-timezone feature 9/2; worth confirming reminders now land correctly before Alina raises it.  ### Suggested talk track 1. Good news first: account is live, billing approved, we can build this week. 2. "Before we finalise the plan — you mentioned up to $2,000/mo. Here's what $500 vs $1,000+ on Google actually buys in Atlanta." Land the number. 3. Walk the geo/targeting/keyword list from Carmen's doc; ask Alina to sanity-check the suburb list and whether West Georgia/Auburn is really in scope for her price point (Sat $8,500). 4. Set expectations on measurement: "For the first two weeks the numbers you see in LeadLock won't be attributable to a channel yet — we're installing tracking as part of the build." Then confirm who can add tags (Ami/Celebrate own the site). 5. Confirm the Meta path: who fixes the business page, and get partner access to Business ID 543099017224748 as a homework item. 6. Close with dates: Google live week of Sep 14, LP Sep 17–18, Meta phase 1 once access lands.  ### What I could not verify - **Meta**: no Dogwood ad account is shared with WIA, so nothing on the Meta side is checkable — including whether a pixel exists. - **GA4**: not pulled (needs an approval step), so I can't say whether a property exists at all; the empty GTM container suggests no. - Whether the tour-reminder timezone bug is actually resolved (no way to see reminder timestamps from the API).

**Gisselle Jiménez** · 2026-09-09 16:01 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1788969696684529)
@Whitney Hodges Ads Strategy recap draft is ready for dogwood! This is from a new template we had worked on with Fallon where we include expectations for ads launch dates, but let me know if we feel comfortable sharing specific dates with clients.
> **Whitney Hodges** · 2026-09-10 16:46 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1789058772619989)
> @Gisselle Jiménez No, I don't want to share dates with the client. Also, per the contract, I don't think this timeline is tight enough. Based on the date of their ads kickoff call, this is what I'm seeing it should be on our end.
> 
> Google Ads launched somewhere within the range of September 7-13 (which would mean that we would want to send over the walkthrough even sooner)
> 
> Client attraction ads launched within the range of September 14-20
> 
> Conversion ads launched within the range of September 21-27
> 
> Retargeting ads launched within the range of September 28-October 4
> 
> So I would want the approvals to be sent to the client at the beginning of those date ranges
> **Gisselle Jiménez** · 2026-09-10 17:22 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1789060974891279)
> @Whitney Hodges Email draft has been modified! I can ask Carmen to send us the Google ads loom for tomorrow. For future reference this would be 2 days after the ads stratregy call, is that okay moving forward?
> 
> For the meta ads launched, I took into account that Ivy is off this week from the 7-10 (today) and that we were going to give her a week to complete the creative. Does it work for her to have it ready by Tuesday then giving Jacqueline a day to review and give feedback so we can present on Wednesday Sep 16?
> **Whitney Hodges** · 2026-09-10 17:24 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1789061097548259)
> @Gisselle Jiménez Yes, I think if we can have the Google video walkthrough ready within 2 business days of the ads strategy call that is perfect and will better align with client expectations.
> 
> Thank you for the reminder about Ivy's OOO. Those dates should work.

**Tina Henares** · 2026-09-09 16:25 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1788971153790359)
@Whitney Hodges @Gisselle Jiménez The LeadLock Support email account received these requests from Tirzah yesterday. Do either of you have experience with auto populating surveys with client info (her first request)? Her 2nd + 3rd requests are completed. I'm looking into it right now and it says I need to enable "Sticky Contact" in the survey's settings and then use URL parameters. Please let me know, thanks!
📎 Screenshot 2026-09-09 114455.png (png, saved as `files/F0C077ARMM5-Screenshot_2026-09-09_114455.png`)
> **Tina Henares** · 2026-09-09 16:26 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1788971215905339)
> @Viktor can you offer support on this?
> **Viktor** · 2026-09-09 16:27 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1788971262020079)
> On it @Tina Henares — pulling Dogwood's post-tour survey config and checking how prefill actually behaves in HighLevel before I give you a recipe.
> **Viktor** · 2026-09-09 16:31 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1788971462091879)
> @Tina Henares Found it — I tested all three Dogwood surveys live in a browser.  **Prefill via URL params already works.** The blocker is the trigger link: `Tour Results Survey Link Updated` (id `azT6hMH6TsNgmsyzIoa7`) points to `…/widget/survey/LlATb4umCgqmBnIcD4jm?first_name={{contact.first_name}}&amp;last_name={{contact.last_name}}&amp;email={{contact.email}}&amp;phone={{contact.phone}}`. Trigger-link redirects are static — the `{{contact.*}}` merge fields never get rendered, so the survey receives the literal text `{{contact.first_name}}`. I reproduced exactly that: the name field loaded showing the braces. Merge fields only render inside an email/SMS **body**, not inside a trigger link's destination URL.  **Fix:** stop using the trigger link for the survey and paste the full URL straight into the workflow email/SMS body. Confirmed working keys (tested with real values — phone even auto-formats to `<tel:(706)555-0123|(706) 555-0123>`): `first_name`, `last_name`, `email`, `phone`, plus `organization` on the Events pre-tour.  Ready to paste:  - Tour Results (post-tour): `<https://link.dogwoodreserve.com/widget/survey/LlATb4umCgqmBnIcD4jm?first_name={{contact.first_name}}&amp;last_name={{contact.last_name}}&amp;email={{contact.email}}&amp;phone={{contact.phone}}>` - Pre-Tour (Weddings): `<https://link.dogwoodreserve.com/widget/survey/ReKdX09V0V2cIQQcvAc3?first_name={{contact.first_name}}&amp;last_name={{contact.last_name}}&amp;email={{contact.email}}&amp;phone={{contact.phone}}>` - Pre-Tour (Events): `<https://link.dogwoodreserve.com/widget/survey/RbD8xpWLGr7TSUuNDG24?first_name={{contact.first_name}}&amp;last_name={{contact.last_name}}&amp;email={{contact.email}}&amp;phone={{contact.phone}}>`  **On Sticky Contact:** turn it on if you like (Sites → Surveys → builder → Settings/Options), but it won't solve this. It's cookie-based, same browser + same domain only, so it fails for anyone who opens the link on a different device or has cleared cookies. URL params are the reliable path; Sticky Contact is just a backup. One warning if you ever fill a survey on a lead's behalf: use incognito, or the previous lead's data populates.  **Testing note:** dotted keys (`contact.first_name`) do NOT work — I tested those too and they came back empty. And test with a real contact from a real workflow send, then check the sent message in their conversation to confirm the URL rendered actual values, not braces.  One thing I couldn't verify: the API only exposes workflow names, not steps, so I can't see which workflow step currently holds that trigger link. Worth a quick eyeball in the tour/post-tour workflows — if the same merge-field-inside-trigger-link pattern is used in any other client sub-account, it's broken there too and I'm happy to check.
> **Whitney Hodges** · 2026-09-09 16:33 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1788971589072139)
> @Tina Henares Thank you for the update! Please try Viktor's suggestions and then test it
> **Tina Henares** · 2026-09-10 15:26 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1789053982378319)
> @Whitney Hodges Tested it and it worked. Emailing Tirzah now!
> **Tina Henares** · 2026-09-10 15:29 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1789054189156189)
> @Whitney Hodges should I email her to confirm the changes were maid from the LeadLock support email or my <mailto:tina@weddingindustryads.com|tina@weddingindustryads.com> email?
> **Whitney Hodges** · 2026-09-10 15:47 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1789055257552799)
> @Tina Henares I think the support email is fine, thank you!!
> **Tina Henares** · 2026-09-10 15:56 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1789055782986899)
> @Whitney Hodges done!

**Jacqueline Hood** · 2026-09-09 18:42 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1788979320764549)
*Client Attraction Ads:* 
Brief for Ivy: <https://docs.google.com/document/d/1A9hBoLbGAuMU5zJ_eBJJiY3TpNipPEwQTMHq4CuYdjY/edit?usp=sharing|docs.google.com/document/d/1A9hBoLbGAuM…/edit?usp=sharing>
Ad Copy: <https://docs.google.com/document/d/1650pPEq2_gYO0xMZ8ix0peI-VNaGu7aNzUr6BiU9hVA/edit?usp=sharing|docs.google.com/document/d/1650pPEq2_gY…/edit?usp=sharing>

@Ivy Ayala @Gisselle Jiménez
> **Ivy Ayala** · 2026-09-15 20:42 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1789504935211479)
> Hi there!
> **Ivy Ayala** · 2026-09-15 20:46 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1789505190303189)
> <https://canva.link/ttcvdz07cnq4d1d|Reel 1> <https://canva.link/09q3i3enxx79rvy|Reel 2> Good afternoon! I hope you’re all doing well! :blush:
> Here are the first two Reels. It’s been a bit of a challenge creating the content since there isn’t a lot of material to work with, but I’ve tried to make the most of what we have.
> For Reel 3, the concept focuses more heavily on couples. I know they haven’t hosted any weddings yet, but would it be possible for the client to share any photos they may have from photoshoots? The photos currently on Instagram have quite a bit of text over them, and personally, I’d recommend keeping the images more clean and letting the venue itself be the focus. I think the space is nice, and too much text can take away from that.
> Let me know what you think of the direction I’ve taken with the videos, and if you have any feedback or ideas for adjustments! :blush:
> **Ivy Ayala** · 2026-09-15 20:49 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1789505342122139)
> Also here´s some content inspo for the client, maybe they could focuse a little bit more on that huge green space and make it stand out more <https://vt.tiktok.com/ZSq43mRAp/|vt.tiktok.com/ZSq43mRAp> <https://vt.tiktok.com/ZSq43VCRW/|vt.tiktok.com/ZSq43VCRW> <https://vt.tiktok.com/ZSq435pJ5/|vt.tiktok.com/…>
> **Ivy Ayala** · 2026-09-15 20:49 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1789505394504959)
> @Jacqueline Hood @Gisselle Jiménez
> **Gisselle Jiménez** · 2026-09-17 15:45 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1789659945685449)
> Thank you, @Ivy Ayala! @Jacqueline Hood We're planning on sending it for the client to review today! Could you please let me know if these are good to go?:)
> **Gisselle Jiménez** · 2026-09-17 20:23 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1789676586808299)
> Hey @Ivy Ayala! Could you please share reel 3?
> **Gisselle Jiménez** · 2026-09-17 20:33 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1789677211632969)
> @Ivy Ayala Sorry, I just read your message again! Were you requesting more pictures to create reel 3?
> **Gisselle Jiménez** · 2026-09-17 20:35 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1789677313796839)
> <https://www.dropbox.com/scl/fo/ne1k2je3vsxyupil76tvj/AC1Z1fpj1WDvx0em67UV1gs?rlkey=poql8i44g7j13563fy9rl48xe&amp;st=6c5j6mek&amp;e=3&amp;dl=0|This is the first album> that they shared and <https://createdbydestiny.pixieset.com/dogwoodreserve/|these are the newest pictures>!
> **Gisselle Jiménez** · 2026-09-17 21:51 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1789681891477769)
> @Ivy Ayala Could you please create that third reel with these new pictures tomorrow so we can meet timeline? Thank you!!
> **Ivy Ayala** · 2026-09-17 22:58 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1789685889665239)
> Hi! yes, here's the creative @Gisselle Jiménez <https://canva.link/p84es6nrxgw86nh|canva.link/…>

**Gisselle Jiménez** · 2026-09-10 18:25 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1789064751138109)
@Jacqueline Hood @Carmen Cruickshank @Ivy Ayala

Hi team! Please see below updated deadlines for Dogwood reserve. These have all been updated in ClickUp. :raised_hands:

*Dogwood Reserve — Due Dates*

*Google Ads*
• Loom walkthrough (Google Ads setup) — Carmen | Fri Sep 11
*Meta Client Attraction Ads*
• Complete Client Attraction creative — Ivy | Tue Sep 15
• Review creative + Share ad copy — Jacqueline | Wed Sep 16
• Create review doc + present to client — Gisselle | Wed Sep 16-17
*Meta Conversion Ads*
• Brief Ivy on Conversion Ads — Jacqueline | Tue Sep 15
• Complete Conversion creative — Ivy | Mon Sep 21
• Review creative + Share Ad Copy— Jacqueline | Tue Sep 22
• Create review doc + present to client — Gisselle | Tue Sep 22-23
*Meta Retargeting Ads*
• Brief Ivy on Retargeting Ads — Jacqueline | Mon Sep 21
• Complete Retargeting creative — Ivy | Mon Sep 28
• Review creative + Share ad copy — Jacqueline | Tue Sep 29
• Create review doc + present to client — Gisselle | Tue Sep 29-30
*Note:* Strive to brief Ivy on the next ad set the same day she completes the current creative, so she can get started right away without delays between phases.

cc: @Whitney Hodges
> **Gisselle Jiménez** · 2026-09-10 19:38 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1789069136274919)
> Hi, @Carmen Cruickshank! Would you be able to send us the loom walkthrough for dogwood tomorrow?
> **Whitney Hodges** · 2026-09-10 19:42 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1789069360955079)
> I know it's last minute, so if it has to be Monday, that's ok @Carmen Cruickshank
> **Carmen Cruickshank** · 2026-09-11 19:47 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1789156038106219)
> thank you for your patience! @Whitney Hodges @Gisselle Jiménez I created the loom video here: <https://www.loom.com/share/ac726829e704440d8b836a9e8f64ed76|loom.com/share/…>
> **Gisselle Jiménez** · 2026-09-11 19:56 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1789156586587439)
> @Carmen Cruickshank great, tysm! @Whitney Hodges Email to alina and tirzah is drafted!
> **Whitney Hodges** · 2026-09-11 20:25 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1789158338010899)
> @Carmen Cruickshank @Gisselle Jiménez Amazing! Thank you both!!

**Gisselle Jiménez** · 2026-09-10 21:19 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1789075160305799)
@Whitney Hodges @Tina Henares Hi! I just saw Tirzah's email about the investment guide for Stacy Covin. I did a weddings test submission and I was able to get the guide and open it. However, based on Stacy's email thread and the emails sent to her, it seems that she opted in for Events, and I don't see an investment guide link anywhere in that sequence.
> **Whitney Hodges** · 2026-09-10 21:26 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1789075616481539)
> @Gisselle Jiménez Ok, please draft a reply to Tirzah explaining that. I assume that the investment guide isn't included in the Events sequence because it is a Wedding Investment Guide. I would ask her if she wants the sequence updated to include the existing guide or if she wants to create an Events version of the guide
> **Gisselle Jiménez** · 2026-09-10 21:31 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1789075869805749)
> Drafted!

**Tina Henares** · 2026-09-11 13:41 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1789134104007889)
@Gisselle Jiménez @Whitney Hodges Here is a link to a Google Doc with drafted Landing Page Copy that is ready to share with their team. I also uploaded it into the client's folder in Google Drive.
<https://docs.google.com/document/d/1Ch7Wul3-zVYYIHwocsAlIO9lj9Sj5ypJtCEH6no9ovA/edit?usp=sharing|Dogwood Reserve | Landing Page Copy>
📎 Dogwood Reserve | Landing Page Copy (gdoc, **hosted on docs.google.com** — not in Slack, [open](https://docs.google.com/document/d/1Ch7Wul3-zVYYIHwocsAlIO9lj9Sj5ypJtCEH6no9ovA/edit?usp=sharing))
> **Gisselle Jiménez** · 2026-09-11 15:04 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1789139077066609)
> @Tina Henares Thank you! @Whitney Hodges Email to Ami is drafted!
> **Whitney Hodges** · 2026-09-11 19:00 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1789153234163539)
> @Tina Henares Great job! I've sent this to Ami

**Jacqueline Hood** · 2026-09-11 18:42 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1789152145605939)
*Conversion Ads:* 
<https://docs.google.com/document/d/187nv3Zf4uxIzoIKY2A06YrwBrCAjHK_g1tOdz2jJj-E/edit?usp=sharing|Brief for Ivy> @Ivy Ayala
<https://docs.google.com/document/d/1AQIqohn-9kfQFLr-3_g3y3Lxse_JYNYNCY-V59AxikQ/edit?usp=sharing|Ad Copy>

All are in <https://drive.google.com/drive/folders/1iEMR-ngqx91eAPDuMiHaKpgkJhBN4A3V?usp=drive_link|this folder>!
> **Ivy Ayala** · 2026-09-22 00:51 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1790038315476399)
> Hi!  @Gisselle Jiménez @Jacqueline Hood <https://canva.link/caqmf1zzj6eshx3|Reel 1 > <https://canva.link/7kkp595h7t1lykq|Collages > <https://canva.link/46i9oc53zj17xbm|Reel 2> Hi, team! I hope you're all doing well. Here are the creatives for this client. I'm running out of content options for the client (Reels), so for Reel 2, I mixed photos and videos in a different way. Let me know what you think! Have a great evening.
> **Gisselle Jiménez** · 2026-09-22 18:07 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1790100425775339)
> Thank you @Ivy Ayala! The only thing I'm seeing in the third creative is this text overlap:
> 📎 image.png (png, saved as `files/F0C3HKRM73M-image.png`)
> **Gisselle Jiménez** · 2026-09-22 18:07 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1790100472304459)
> @Jacqueline Hood Let us know if there are any other changes to be made, thanks!
> 
> cc: @Whitney Hodges
> **Whitney Hodges** · 2026-09-24 22:12 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1790287976686109)
> @Gisselle Jiménez anything else we are waiting on here? I'd love to send this to them for review tomorrow if possible
> **Jacqueline Hood** · 2026-09-24 22:23 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1790288603988359)
> @Ivy Ayala I'd just love the collages to have more photos to visualize and see what actual weddings look like there - more ceremony set ups, decor, reception images, etc.
> **Whitney Hodges** · 2026-09-24 22:25 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1790288700704719)
> It's my understanding that we're working with really limited content since they've never actually held a wedding there yet
> **Jacqueline Hood** · 2026-09-24 22:26 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1790288766681649)
> ahh right! Makes sense. These are great as is then!
> **Jacqueline Hood** · 2026-09-24 22:26 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1790288782825819)
> Unless they have any other "mock up" photos that aren't from real weddings we can utilize

**Carmen Cruickshank** · 2026-09-14 18:45 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1789411514484929)
@Viktor do you see google tag amanger connected with this thank you page: <https://info.dogwoodreserve.com/thank-you|info.dogwoodreserve.com/thank-you> for dogwood reserve?
> **Viktor** · 2026-09-14 18:46 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1789411606784219)
> @Carmen Cruickshank No — **there is no GTM on that thank-you page.** Checked both the raw HTML and a real browser render just now (2026-09-14).  **<http://info.dogwoodreserve.com/thank-you**|info.dogwoodreserve.com/thank-you**> (HighLevel funnel page): - Scripts loading: only the LeadConnector app bundle + Cloudflare's beacon. Nothing else. - No `<http://googletagmanager.com|googletagmanager.com>` request, no `google_tag_manager` object, no `dataLayer`, no `gtag`, no Meta pixel (funnel pixel field is empty, tracking-providers list is empty). - Funnel header/footer code: empty. The only global head code on the funnel is `&lt;meta name="robots" content="noindex, nofollow"&gt;`. - Same story on the funnel's landing step (<http://info.dogwoodreserve.com|info.dogwoodreserve.com> root) — no tags there either.  **But:** their main site **<http://dogwoodreserve.com|dogwoodreserve.com> does have GTM installed — container `GTM-5G36SNFQ`.** So the container exists; it just was never added to the HighLevel funnel where the actual form + thank-you page live.  That lines up with the zero-conversion-tracking flag I raised in #google-ads this morning ahead of the Fri 9/18 launch. Cheapest fix: paste the `GTM-5G36SNFQ` head + body snippets into the funnel's **Settings → Tracking Code** (global, so it covers every step), then fire the conversion on the /thank-you pageview. Want me to draft the exact snippets and the GTM trigger/tag setup for whoever has access to their container?
> **Carmen Cruickshank** · 2026-09-14 18:51 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1789411881903859)
> so put the `GTM-5G36SNFQ in both the header and body code area? are these not good to put either? i put the code nad saved it and its not tracking for some reason`
> 📎 Screenshot 2026-09-14 at 2.50.53 PM.png (png, saved as `files/F0C1U9J1H9P-Screenshot_2026-09-14_at_2.50.53_PM.png`)
> **Viktor** · 2026-09-14 18:53 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1789411982073009)
> Yes, head + body is right, and the snippets in your screenshot look correct. But I just re-pulled the live page (2:53pm) and **the GTM code still isn't on it** — the head code serving <http://info.dogwoodreserve.com/thank-you|info.dogwoodreserve.com/thank-you> is still only `&lt;meta name="robots" content="noindex, nofollow"&gt;`, body code empty.  My bet: you saved it on a different funnel. The thank-you page lives in the funnel named **"Website Inquiry Confirmation Page"** (domain `<http://info.dogwoodreserve.com|info.dogwoodreserve.com>`, path `/thank-you`). Tell-tale sign: that funnel's Head tracking code box should already contain the noindex meta line — your screenshot's box has only GTM, so it's probably a different one.  So: open that funnel → Settings → Tracking &amp; scripts, and paste the GTM head snippet **under** the existing noindex meta (keep that line — it's what keeps client funnels out of Google), body snippet in Body. Then save and hard-refresh. Ping me and I'll re-verify the live page in seconds.  One more thing so you don't chase a ghost: GTM firing ≠ conversion recorded. Once the container loads, it still needs a tag in `GTM-5G36SNFQ` (Google Ads conversion, trigger = pageview on URL contains `/thank-you`) and that conversion action created in the Dogwood Google Ads account. Happy to spec both once the container is live on the page.

**Carmen Cruickshank** · 2026-09-14 18:56 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1789412202999839)
@Whitney Hodges @Gisselle Jiménez Hi! just launched her ads and conversion tracking is all set up, only thing on her end is to get advertiser verification complete to display bussiness name and logo
> **Gisselle Jiménez** · 2026-09-14 19:16 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1789413394036639)
> Great!:partying_face: @Whitney Hodges Email drafted!

**Gisselle Jiménez** · 2026-09-14 19:28 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1789414110038899)
@Whitney Hodges Hi! Email to Tirzah is draft in the LeadLock inbox. Let me know if this is something we could do and she would need to provide the  info for events pricing guide
> **Whitney Hodges** · 2026-09-14 20:25 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1789417500362189)
> @Gisselle Jiménez Yes, I'm fine with it
> **Gisselle Jiménez** · 2026-09-14 20:25 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1789417536952899)
> @Whitney Hodges Oki, let me know if this is good to send:
> 📎 image.png (png, saved as `files/F0C1R5CKD1U-image.png`)
> **Whitney Hodges** · 2026-09-14 20:30 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1789417817926339)
> @Gisselle Jiménez Looks good, please send
> **Gisselle Jiménez** · 2026-09-14 20:36 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1789418164404689)
> Sent!

**Viktor** · 2026-09-15 14:24 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1789482275582909)
@Carmen Cruickshank @Gisselle Jiménez @Whitney Hodges — Dogwood's Google campaign went live yesterday :tada: I checked the first day against live data this morning. Good news up front: the ad is **approved**, and **4 sitelinks + 4 callouts + a snippet are all linked at launch** — and because the ads point at `<http://dogwoodreserve.com/weddings/|dogwoodreserve.com/weddings/>` (which carries GTM-5G36SNFQ), the HighLevel funnel tag gap I'd flagged earlier no longer blocks anything.  **Day 1–2:** 263 impressions / 19 clicks / $37.85 / **0 conversions**.  Three things worth closing in week one — detail in the thread :thread: — the most important being that the conversion action is a *click-based* one and I can't verify from outside that it's actually wired to the form. A single test submission would settle it; happy to run it today if you'd like.
> **Viktor** · 2026-09-15 14:24 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1789482293824799)
> ## Dogwood Reserve — day-1 check, campaign `24247841488` All read live from Google Ads + a crawl of the site this morning (Tue 9/15, ~9:15am CT). Nothing changed by me.  | | Impressions | Clicks | Cost | Conversions | |---|---:|---:|---:|---:| | Mon 9/14 | 203 | 16 | $32.44 | 0 | | Tue 9/15 (partial) | 60 | 3 | $5.41 | 0 |  Settings as built: Maximize clicks, $16.66/day, 100-mile proximity radius, 8 phrase keywords, one RSA (approved), final URL `<http://dogwoodreserve.com/weddings/|dogwoodreserve.com/weddings/>`.  ### 1. The conversion action is click-based and I can't confirm it's wired `Submit lead form` (id `7767391670`) is type **WEBPAGE_ONCLICK**, ONE_PER_CLICK, tag **AW-18420835725**. That type fires from an event snippet attached to the form's submit action. In the live page source of `/weddings/` and `/contact/` there is **no `AW-` id and no `gtag_report_conversion` function** — and the form is Gravity Forms with an AJAX confirmation, so there's no thank-you URL a page-load rule could catch either.  Important caveat: if the conversion was deployed **inside GTM-5G36SNFQ**, it would be invisible from outside the container — so this is "unverified", not "broken". The only way to settle it is one real submission through the form while watching the account. I can do that this morning and report back within the hour, or Carmen can check the tag inside GTM — whichever is easier.  ### 2. No negative keywords yet The account has **0 negatives**, and one keyword is the bare phrase `wedding venue`. Day-one paid clicks already include:  | Search term | Clicks | Cost | |---|---:|---:| | the dogwood midtown atlanta | 1 | $1.77 | | wedding venues in warner robins georgia | 2 | $3.64 | | west ga wedding venues | 1 | $2.09 | | wedding venues in dahlonega ga | 1 | $2.08 | | summit farm ellijay ga | 1 | $1.70 |  That's roughly **29% of the first day's spend** on searches outside the service area or aimed at other venues — including "the dogwood midtown atlanta", a completely different venue whose name overlaps. The 100-mile radius is set correctly; this is *query intent*, not geo targeting. Happy to draft a starter negative list (out-of-range city names, `midtown atlanta`, and research terms like `cost` / `photos`) for Carmen to review — just say the word and I'll post it here rather than touching the account.  ### 3. No Final URL suffix The campaign has no Final URL suffix, so our standard UTM string isn't on the ads and LeadLock/GA4 will only ever see a gclid. Worth adding at campaign level before the Meta phases start, so all channels report the same way. (Reminder that this belongs in *Final URL suffix*, not Tracking template — and a campaign-level value silently overrides the account-level one.)

**Whitney Hodges** · 2026-09-15 15:25 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1789485900501529)
@Gisselle Jiménez Hi! Just want to make sure you'll be heading up the non-weddings investment guide for Dogwood Reserve. Tirzah said pricing will be the same as for weddings and we need to pick from photos she's already shared with us
> **Gisselle Jiménez** · 2026-09-15 15:39 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1789486795084219)
> @Whitney Hodges Yes! Okay, noted. I'll get started on it:saluting_face:

**Whitney Hodges** · 2026-09-15 16:46 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1789490777362179)
@Danielle McGinnis Can you please respond to Tirzah on the spam calls and look into it?

**Danielle McGinnis** · 2026-09-15 19:00 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1789498842607929)
@Whitney Hodges Just hopped off with GHL, but before I respond to Tirzah would like to run my response by you first..

**Danielle McGinnis** · 2026-09-15 19:06 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1789499191810769)
@Whitney Hodges here are the recommendations from my call with GHL.

I was given <https://help.gohighlevel.com/support/solutions/articles/155000007360-how-to-reduce-inbound-spam-calls|this article> as a reference. It was explained to me that we cannot do anything to prevent spam calls especially since all phone numbers are recycled, we don't know who had the phone number previously, who still has the phone number saved etc.

A few suggestions that were made are:
• Enable number intelligence (already enabled on the account)
• Set up IVR (a phone tree) in hopes that those making the spam call do not listen to the options on the phone tree and will hang up
• Create a spam call disposition. Tirzah and Carolann would need to select Spam Call disposition when they end any spam calls and we can set up a workflow to automatically dnd that number for all channels which would prevent future calls.
@Viktor are there any other options to reduce spam calls in GHL that you know of?
> **Viktor** · 2026-09-15 19:07 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1789499226288979)
> On it @Danielle McGinnis — reading that GHL article and pulling Dogwood's actual call/contact data so the suggestions are grounded in what's really hitting their number. Back shortly.
> **Viktor** · 2026-09-15 19:10 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1789499445491289)
> @Danielle McGinnis @Whitney Hodges Yes — a few more options, plus one thing to fix in the GHL plan. I pulled Dogwood's live call data first, and it's worse than it probably looks from the inbox: **49 of their 93 CRM contacts are spam calls** (tag `couldn't find caller name`), and **30 of those came in since Friday** — 9 on 9/11, 9 on 9/14, 12 today.  Two things that change the plan:  - **The DND-per-number idea will barely help.** Those 49 spam calls came from **49 different numbers — only 2 ever called twice**, and 48 of 49 are 706 numbers (their own local area = classic neighbor spoofing). A block list catches ~4% of it, and it depends on Tirzah/Carolann tagging every call. - **Their own automation is texting the spammers.** Missed Call Text Back fired on these and sent **19 outbound texts to spam numbers in the last 5 days** — wasted SMS, and it's the same number they text real couples from, so it's a deliverability risk.  Good news for Tirzah: **not one spam call created an opportunity**, so no leads are being lost or polluted in the pipeline — it's ringing phones and inbox noise.  Full detail + the 6 options ranked, in the reply below :point_down:
> **Viktor** · 2026-09-15 19:11 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1789499473335559)
> ### What's actually happening in Dogwood's account (live pull, just now)  | Check | Finding | |---|---| | Spam contacts | **49 of 93 total contacts** carry the `couldn't find caller name` tag | | When | 8/16–8/25: 19 · then quiet · **9/11: 9 · 9/14: 9 · 9/15: 12 (so far)** — burst pattern, i.e. auto-dialers sweeping a block of numbers | | Numbers | **49 unique numbers, only 2 repeat callers.** 48 of 49 are area code 706 | | Call outcomes | 19 no-answer · 15 voicemail · **5 actually answered** | | Missed Call Text Back | tag `mctb 1` on 25 contacts; **19 outbound texts sent to spam numbers** | | Pipeline damage | **zero** — no spam contact created an opportunity | | Working correctly | 7 real callers got named via Number Intelligence (`name via lookup`) — the lookup *is* earning its keep |  So the spam signal we can automate on already exists: **no name from lookup = almost certainly spam.**  ### On the three GHL suggestions  1. **Number Intelligence** — correct, already on, and it's the piece that makes everything below possible. Leave it. 2. **IVR** — agree, this is the single strongest lever. Robodialers hang up rather than press a key. Two notes: it's built as a **workflow** (Phone IVR trigger) and then assigned on the number under *Configure → Call Forwarding → IVR*; and keep it to **one option** ("press 1 for weddings and tours") so real couples aren't put through a phone tree, with voicemail as the fallback. 3. **Spam disposition + DND workflow** — worth building, but set expectations: 47 of 49 numbers called once and never again, so it only helps against repeat offenders. **And please ask GHL to confirm one thing:** does contact-level DND actually stop an inbound call from *ringing*? Documented DND behaviour is that it blocks *outbound* SMS/automation. If it doesn't block the ring, this suggestion mostly just stops the auto-texts — which we can do more reliably in #4 below.  ### Four more options, in the order I'd do them  **a) Filter Missed Call Text Back so it skips spam** — do this today, zero client effort. In *Missed Call Text Back Workflow*, add an If/Else at the top: if the contact has the tag `couldn't find caller name`, exit. That kills the 19-texts-in-5-days waste and protects the sending reputation of the number they text real leads from.  **b) Auto-tag and quarantine spam instead of relying on dispositions** — a workflow on the **Call Details** trigger (direction = incoming, status = no-answer/voicemail) with a condition on that same tag → add tag `spam call`, set DND all channels. That does automatically what the disposition plan asks Tirzah and Carolann to do by hand; keep the manual disposition as the backup for spam that actually gets answered.  **c) Clean up what they see** — more than half their contact list and conversation inbox is now noise. Bulk-tag the existing 49, then give them a saved conversation filter / smart list that hides the spam tag. This is the change they will *feel* the most, even though it doesn't reduce ringing.  **d) Business-hours routing** — make sure calls outside their hours go straight to voicemail rather than ringing anyone. Several of these landed early morning and evening.  **Then, only if a–d plus the IVR don't calm it down: replace the number.** HighLevel's own guidance is that a recycled/flagged number is usually faster to trash and replace than to remediate. Before doing that we'd need to know everywhere it's published — website, Google Business Profile, the investment guides, email signatures, any Google Ads call asset — and keep the old one live on voicemail for a few weeks. Not a first move, but a real one.  **Unrelated but same settings screen, worth doing while we're in there:** register the number for **Voice Integrity + CNAM** (US, needs their EIN) so *their outbound* callbacks show "Dogwood Reserve" and don't get flagged "Spam Likely". Different problem from inbound spam, but it hits answer rates on the leads our ads are about to send them.  ### What I couldn't verify - Whether DND blocks an inbound ring (the question for GHL above). - The number's provisioning/recycling history — our API access to Dogwood doesn't include the phone-system endpoints, so that has to come from GHL support or the UI.  Happy to write the plain-English version for Tirzah — something like "here's what we're changing on our end, here's the one thing we need from you" — and I can spec the exact IVR workflow steps and the MCTB filter for whoever builds them. Just say go.
> **Danielle McGinnis** · 2026-09-15 19:17 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1789499843504149)
> @Whitney Hodges just looking for some insight on what to pitch to Tirzah. I have a strong feeling she will not want to set up the IVR, so just curious as to your thoughts here...the other options are certainly helpful, but they won't prevent the calls...
> **Viktor** · 2026-09-15 19:18 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1789499895778609)
> You're right, and that's the honest pitch: only two things actually stop the phone from ringing — a keypress gate, or a new number. Everything else just cleans up the mess afterward.  If "IVR" is the word she'll balk at, don't sell it as a phone tree. It doesn't have to be a menu — it can be one line: *"Thanks for calling Dogwood Reserve — press 1 to reach us."* Press 1 and it rings Tirzah and Carolann exactly like today. That's ~2 seconds for a real couple, and auto-dialers don't press anything, so most of those 10-12 calls a day never ring. Framed that way it's a doorbell, not a phone tree.  If she still says no, the honest answer is: then we can't stop the ringing on this number, and the only remaining fix is swapping the number (which costs her updating it wherever it's published). Worth having that as the explicit alternative so she's choosing between two real options rather than turning down the only one.  Want me to write it up that way for Tirzah — 2 seconds vs. a new number, plus the cleanup we're doing on our side regardless?
> **Danielle McGinnis** · 2026-09-15 19:20 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1789500053764809)
> Yes please @Viktor . @Whitney Hodges still will await your feedback before sending to Tirzah. 
> **Viktor** · 2026-09-15 19:21 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1789500089146269)
> Here you go @Danielle McGinnis — paste-ready for Tirzah once @Whitney Hodges signs off. It leads with what we're doing for her (no work on her end), then gives her the one choice. Notes for you two are under the draft.  ---  **Subject: The spam calls — what we found and how we can quiet them down**  Hi Tirzah,  We dug into the spam calls, and first the reassuring part: they aren't costing you any leads. Every one of them lands as a junk contact and stops there. Not one has ever turned into a real inquiry or a tour, so nothing in your pipeline has been touched.  Here's what we're seeing:  • About **49 spam calls since mid-August**, and they come in waves — the last few days have been the worst, around 10 to 12 a day. • They come from **49 different numbers**, almost all with your local 706 area code. That's a robo-dialer working its way through a block of numbers, not one person who keeps calling back. • Because the numbers are almost never repeats, blocking them one at a time won't get us anywhere. We'd be blocking numbers that were never going to call twice.  What we're taking care of on our side, no action needed from you:  1. Stopping the automatic "sorry we missed you" text from going out to spam callers. Right now it's texting them, which we'd rather not do. 2. Tagging spam calls automatically so they get filed away instead of cluttering up your and Carolann's inbox. You'll only see real couples. 3. Making sure calls outside your business hours go to voicemail rather than ringing your phones.  That cleans up the noise, but we want to be straight with you about the ringing itself. There are only two ways to actually stop the phones from ringing, and we'd love your thoughts on which you'd prefer:  **Option 1: A quick "press 1" greeting.** When someone calls, they hear one short line — "Thanks for calling Dogwood Reserve, press 1 to reach us" — and pressing 1 rings you exactly like it does today. It's about two seconds for a real couple. Robo-dialers don't press anything, so most of those calls would never reach your phone. This is the option we'd recommend, and it's not a long phone menu with departments and options. Just one step.  **Option 2: A new phone number.** Phone numbers get recycled, so it's likely yours had a previous life that put it on some dialing lists. A fresh number would come with a clean slate. The tradeoff is that it would need updating anywhere the current number is listed — your website, your Google listing, your guides, email signatures — and we'd keep the old one on voicemail for a few weeks so nothing gets missed.  Just let us know which direction feels right and we'll set it up. Either way, we're getting the cleanup done this week so your inbox looks like it should.  Thanks, Whitney  ---  **Notes for you two:** - I left out the disposition/DND idea on purpose. It asks Tirzah and Carolann to click something on every spam call and, given only 2 of 49 numbers ever called twice, it buys almost nothing. Easy to add back if Whitney wants it in. - The email says the cleanup happens this week — pull that line if we're not building the MCTB filter and auto-tagging that fast. - No promise about who builds the "press 1" greeting or when, so nothing is committed until Whitney decides. - @Whitney Hodges if you want it shorter, the three cleanup items can collapse into one sentence — happy to trim.
> **Whitney Hodges** · 2026-09-15 19:40 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1789501241708729)
> @Danielle McGinnis I wouldn't use this email draft. We haven't trained Viktor on our email voice, and it screams AI. He also tends to share far more information than needed.
> 
> As Viktor suggested, please do #3, steps A-D, Voice Integrity + CNAM.
> 
> I also think IVR is the best solution, and the way Viktor described setting it up sounds good to me. I'm not sure why Tirzah would have an issue with it
> **Danielle McGinnis** · 2026-09-15 19:41 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1789501289718119)
> Noted @Whitney Hodges 
> **Viktor** · 2026-09-15 19:41 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1789501299432219)
> Understood @Whitney Hodges, scrapping that draft — too long and too much internal detail. I've saved the note: client emails stay short, no options laundry list, no explaining our reasoning to them. If you ever want to paste in one of your own sent emails to Tirzah, I'll match it much closer next time.  On the build — @Danielle McGinnis, want me to write you the click-by-click for the IVR workflow, the Missed Call Text Back filter, and the auto-tag workflow? Numbered steps, screen by screen, so you're not reverse-engineering my bullet points.
> **Danielle McGinnis** · 2026-09-15 20:56 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1789505800843209)
> @Viktor instead of ddrafting an email, please give me some bullet points explaining #3, steps A-D, Voice Integrity + CNAM and IVR. I will then put it in my own words
> **Viktor** · 2026-09-15 20:57 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1789505842497219)
> Sure @Danielle McGinnis — plain-language bullets, one block per item. Each has what it is, what it does for Tirzah, and whether it needs anything from her.  **#3 — Spam call disposition + auto-block** • What it is: a "Spam Call" button Tirzah and Carolann tap when they hang up on a spam call. That number then gets marked do-not-contact automatically. • What it does: stops us ever texting or calling that number again. • Needs from her: yes — her and Carolann tagging spam calls as they happen. • Honest expectation to set: only 2 of the 49 spam numbers have ever called twice, so this catches very little of the ringing. It's tidiness, not a fix.  **A — Stop the auto-text going to spam callers** • What it is: their "Sorry we missed your call" text currently goes out on every missed call, including spam. We add a rule so it skips spam. • What it does: stops 19-ish pointless texts a week going to robo-dialers, and protects the reputation of the number they text real couples from. • Needs from her: nothing. We do it.  **B — Auto-tag spam calls** • What it is: when a call comes in and the system can't find a name for the number, we tag it as spam automatically and mark it do-not-contact. • What it does: the same thing as #3, without anyone having to remember to press a button. • Needs from her: nothing.  **C — Clean up their inbox and contact list** • What it is: we tag the 49 junk contacts already in there and set up their inbox view so spam is hidden. • What it does: right now more than half their contacts are junk. After this they only see real couples. This is the change they'll actually notice day to day. • Needs from her: nothing.  **D — After-hours voicemail** • What it is: outside their business hours, calls go straight to voicemail instead of ringing phones. • What it does: cuts the early-morning and evening spam rings. • Needs from her: their actual office hours confirmed.  **Voice Integrity + CNAM (this one is about their outgoing calls, not spam coming in)** • What it is: registering their number with the caller-ID companies so it shows "Dogwood Reserve" when they call out, and doesn't get labelled "Spam Likely." • What it does: more couples answer when Tirzah or Carolann call them back. Worth doing now that ads are sending leads in. • Needs from her: their EIN (business tax ID).  **IVR — the "press 1" greeting** • What it is: a caller hears one short line, "Thanks for calling Dogwood Reserve, press 1 to reach us." Press 1 and it rings exactly like today. • What it does: robo-dialers don't press buttons, so most spam calls never ring their phones. This is the only one of these that actually stops the ringing. • Worth saying out loud: it is not a long phone menu with departments. One line, one button, about two seconds for a real couple. Anyone who doesn't press goes to voicemail, so nothing gets lost. • Needs from her: a yes, and the wording she wants in the greeting.  If she says no to the greeting, the only remaining way to stop the ringing is a new phone number — clean slate, but it has to be updated on her website, Google listing, guides and signatures. Worth having in your back pocket so she's choosing between two things rather than declining the only one.
> **Danielle McGinnis** · 2026-09-15 21:15 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1789506910154899)
> @Whitney Hodges can you please put eyes on this before I send it to Tirzah:
> 
> Hi Tirzah,
> 
> I just wanted to circle back regarding our findings and recommendations regarding the spam calls you're receiving.
> First, I did speak to GHL today and they mentioned that unfortunately we can't fully prevent spam calls, but we can do our best to limit them.
> 
> Here are the recommendations and a small explanation about each:
> 
> *IVR* 
> • When someone calls the Dogwood number, a caller hears one short line, "Thanks for calling Dogwood Reserve, press 1 to reach us." Press 1 and it rings to the appropriate user.
> • We are hoping that since robo-dialers don't press buttons, most of these spam calls will never ring to your phones.
> 
>  *Spam call disposition + auto-block*
> • At the end of every call, you'll have the option to set the call disposition. That number will then be marked DND automatically.
> *Auto-tag spam calls*
> • When a call comes in and the system can't find a name for the number, we tag it as spam automatically and mark it DND.
> • This is in addition to the spam call disposition mentioned above.
> *Stop the auto-text going to spam callers*
> • Our Missed Call Text Back workflow is set to send a text to every missed call, including spam. We can add a rule so it skips spam and so that texts no longer send to robo-dialers and the phone number's reputation is protected.
> *After-hours voicemail*
> • Outside of Dogwood's normal business hours (please confirm what you'd like these to be), we'll send calls straight to voicemail instead of ringing phones. This should eliminate the early-morning and evening spam rings.
> *Clean up Dogwood's inbox and contact list*
> • It's recommended that we tag the contacts that are likely identified as spam so spam is hidden and you're only viewing real leads.
> *Voice Integrity + CNAM* 
> • To ensure Dogwood's number is not showing up as spam when calling out, it's recommended we register the phone number with the caller-ID companies so it shows "Dogwood Reserve" when you call out, and doesn't get labelled "Spam Likely."
> Please let us know if you'd like us to proceed with the IVR setup, and other recommendations listed here.
> 
> Thanks so much!
> **Viktor** · 2026-09-15 21:16 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1789506962575109)
> Reads well @Danielle McGinnis — leaving the voice call to @Whitney Hodges, but two things worth catching before it goes:  • **You need two things back from her that the email doesn't ask for:** their confirmed business hours (for the after-hours voicemail) and their EIN (for Voice Integrity/CNAM). Otherwise you'll be chasing both in a second email. • **"Clean up their inbox and contact list"** — should be *your* inbox.  Small typos: "explaination" → explanation, "will then gets marked" → will then be marked, "skips spam. so that" → one sentence, "Dogwood'snormal" missing a space, "ideintified" → identified.
> **Danielle McGinnis** · 2026-09-15 21:19 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1789507193625159)
> Typos corrected and business hours added in. We already have their EIN @Viktor
> **Viktor** · 2026-09-15 21:20 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1789507209484339)
> Perfect — noted that we already have the EIN, so nothing needed from her on CNAM. One leftover: "add a rule so it skips spam. so that texts no longer send" is still two sentences stuck together. Otherwise good to go once Whitney blesses it.
> **Whitney Hodges** · 2026-09-15 21:45 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1789508703035899)
> @Danielle McGinnis Thanks for this! Let's leave out the part about voice integrity + CNAM and just do it on our own on the back end. I don't want this to raise the question of why wasn't it already done.
> 
> I also made some tweaks to the email to make sure we're coming across as confident, authoritative, and proactive. Here's what I would suggest:
> 
> Hi Tirzah,
> 
> I wanted to follow up on the recent increase in spam calls coming through the Dogwood Reserve LeadLock number.
> 
> We reviewed the call activity and confirmed an unusually high volume over the past few days. While spam calls can occur with phone numbers provisioned through GHL, this level of activity is not typical of what we see across our LeadLock accounts.
> 
> Dogwood already has GHL’s Number Intelligence enabled, which screens unknown incoming numbers and identifies those that are likely to be spam. Given the unusual volume you’ve experienced, we also escalated this directly to GHL support to review the activity and confirm we were taking advantage of every available safeguard on their platform.
> 
> Based on that review, there isn’t a way to completely prevent unsolicited calls from reaching a phone number, but there are additional layers of protection we can implement to more aggressively screen and manage them.
> 
> Here’s the plan we recommend:
> 
> *1. Add an IVR prompt before calls ring through*
> 
> Instead of immediately routing every incoming call to your phones, callers will hear a short prompt:
> 
> _“Thanks for calling Dogwood Reserve. Press 1 to reach us.”_
> 
> Legitimate callers can simply press 1 to continue.
> 
> This creates an additional barrier for automated robocalls, many of which will not interact with the prompt and therefore won’t ring through to your phones.
> 
> *2. Identify and block repeat spam callers*
> 
> We’ll add a spam call disposition so unwanted calls can be marked as spam directly after the call. Once marked, the associated number will automatically be placed on inbound DND so repeat calls from that number are blocked.
> 
> This works alongside the Number Intelligence already enabled on the account to give us an additional layer of protection against repeat spam callers.
> 
> *3. Prevent missed-call texts from being sent to suspected spam callers*
> 
> Right now, the Missed Call Text Back workflow can respond to any missed call, including a robocall.
> 
> We’ll update the workflow so contacts identified as spam are excluded. This keeps unnecessary texts from being sent to spam numbers and helps protect the reputation of Dogwood’s LeadLock phone number.
> 
> *4. Route after-hours calls directly to voicemail*
> 
> We can also prevent calls from ringing through outside of Dogwood’s normal business hours and route them directly to voicemail instead.
> 
> This should help eliminate the early-morning and evening interruptions you’ve been experiencing. Just confirm the hours you’d like us to use for incoming calls, and we’ll configure the routing accordingly.
> 
> *5. Clean up the existing spam activity*
> 
> We’ll also clean up the recent spam contacts and conversations so they aren’t cluttering the inbox or making it harder to see legitimate leads.
> 
> Our priority here is reducing the number of spam calls that actually reach you while making sure the activity doesn’t interfere with legitimate inquiries or create unnecessary clutter inside LeadLock.
> 
> We can move forward with the backend spam protections and cleanup on our end. For the IVR, please confirm that you’re comfortable adding the “Press 1” prompt. And for the after-hours routing, just send us the business hours you’d like us to use.
> 
> We’ll take care of the rest.
> 
> Thank you,
> Danielle
> **Viktor** · 2026-09-15 21:46 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1789508778599869)
> That version is much better @Whitney Hodges — I've saved it as my reference for this kind of email, including the CNAM point about not surfacing something that invites "why wasn't this already done."  One thing to be sure of before it goes: item 2 promises DND blocks repeat calls from ringing. GHL's article says that, but their documented DND behaviour is blocking *outbound* texts and automation, and I couldn't verify the inbound-ring part. @Danielle McGinnis, did GHL confirm that on your call? If not, softening it to "so we can automatically screen and suppress activity from that number" keeps the promise safe — and it barely matters here anyway, since only 2 of the 49 spam numbers ever called twice. The IVR is what does the real work.
> **Danielle McGinnis** · 2026-09-15 23:15 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1789514145272649)
> @Whitney Hodges this has been sent.
> **Viktor** · 2026-09-15 23:16 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1789514190137249)
> Nice work @Danielle McGinnis. The three backend items don't need Tirzah's reply, so they can start now: the Missed Call Text Back exclusion, the auto-tag rule, and tagging the 49 spam contacts already in there. Want the click-by-click for those, or would you rather I take a pass at building them and you check my work? Only the IVR and the after-hours hours are waiting on her.
> **Danielle McGinnis** · 2026-09-15 23:24 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1789514695895539)
> Yes, click by click please @Viktor
> **Viktor** · 2026-09-15 23:26 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1789514771858809)
> Here you go @Danielle McGinnis — all in the Dogwood Reserve sub-account. Four builds, roughly 25 minutes total. Do them in this order, because #2 uses what you make in #1.  **Good news first:** I checked HighLevel's own docs and I was wrong to hedge earlier — **inbound DND does block incoming calls and SMS**, and they specifically recommend it for spam callers. So Whitney's item 2 is accurate as written. Nothing to change in the email.  ### 1. Create the "Spam Call" disposition (2 min) 1. Settings (gear, bottom of the left menu) → **Phone System** 2. Scroll to the **Voice** section → **Call Dispositions** 3. Click **Add** → name it exactly `Spam Call` → Save  *Two things to know:* max 10 dispositions per sub-account, and the post-call disposition picker currently only pops up in the **web dialer**, not the mobile app. If Tirzah and Carolann take calls on their phones, they won't see it — which is why build #2 below has a second trigger that doesn't depend on anyone pressing anything.  ### 2. Auto-block workflow (8 min) Automation → **Workflows** → **+ Create Workflow** → **Start from Scratch**. Name it `Spam Call - Tag + Inbound Block`.  **Trigger 1** — + Add New Trigger → search **Call Details** 1. Name: `Marked as spam by user` 2. Add filter → **Call Direction** = `Incoming` 3. Add filter → **Custom Disposition** = `Spam Call`  **Trigger 2** — + Add New Trigger → search **Contact Tag** 1. Name: `Number Intelligence found no caller name` 2. Set it to **Added** 3. Tag: `couldn't find caller name` (that's the exact existing tag Number Intelligence applies — pick it from the list, don't retype it)  **Actions** — click the **+** under the triggers 1. Search **Add Contact Tag** → tag `spam` → Save 2. Click **+** again → search **Enable/Disable DND** → DND Direction: **Inbound** → **Enable** → **All Channels** → Save 3. Top right: **Publish** toggle ON → **Save**  In Settings (the gear inside the workflow builder), leave **Allow Re-entry** off. Nothing else to change.  ### 3. Stop the missed-call text going to spam (5 min) 1. Automation → Workflows → open **Missed Call Text Back Workflow** 2. Click the **+** directly *above* the SMS action, before the text goes out → search **If/Else** 3. Name the condition `Not spam` 4. Condition row: **Contact Tag** → **is not** → `couldn't find caller name` 5. Add a second row with **AND**: **Contact Tag** → **is not** → `spam` 6. Drag the existing SMS action (and the internal notification, if you want it quiet too) into the **Yes / true** branch. Leave the **No** branch empty — spam callers then get nothing. 7. **Save**, and confirm the Publish toggle is still ON  Worth doing while you're in there: the existing wait step should stay *before* the If/Else so the tag has landed by the time the condition is checked. If the wait is only a few seconds, bump it to 1 minute.  ### 4. Clean up the 49 junk contacts (5 min) 1. **Contacts** → **Filters** 2. Filter: **Tags** → **is** → `couldn't find caller name` → Apply (you should see 49) 3. Tick the header checkbox to select all → click the **tag** icon in the action bar → Action name `Spam cleanup` → tag `spam` → **Add Tags** 4. With them still selected, use the **DND** bulk action → Inbound → All channels, so the existing ones are blocked too 5. Back in Filters, click **Save as Smart List** → name it `Spam - hidden`. Then create a second smart list with **Tags → is not → spam** named `Real leads` and tell Tirzah and Carolann to work from that one  I'd leave the contacts in place rather than deleting them — if they're deleted, the same number calling again just creates a fresh contact with no DND on it.  ### Then verify Easiest check: from your own phone, call the Dogwood number. You should ring through normally. Then in the web dialer, mark that call `Spam Call`, look at your contact record, and you should see the `spam` tag plus inbound DND on. Call again and it should not ring. Undo the DND on yourself afterwards.  The after-hours voicemail and the IVR both need Tirzah's reply first — send me a shout when she answers and I'll write those up the same way.

**Viktor** · 2026-09-16 14:13 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1789567985522979)
@Carmen Cruickshank — Dogwood's first three days are in, and there's one fix worth doing today. Live pull this morning:  **505 impressions / 30 clicks / $56.24 / 0 conversions** (9/14, 9/15, and a partial 9/16).  The spend pattern is the story: the campaign still has **zero negative keywords**, and its only geo target is a **single 100-mile proximity radius** around Greenville. Of the $28.17 of clicked spend Google actually reveals to us, **~$19.25 went to other markets or competitors' brand names** — Warner Robins, Rome, Dahlonega, even Jekyll Island, plus "the dogwood midtown atlanta" (a completely different venue).  Two fixes: a negative keyword list (I can build and link it via the API in one pass — say go and it's done), and switching the location option from *presence or interest* to **Presence only**, which is a UI change I'll give you the click path for. Term-by-term detail in the thread :point_down:
> **Viktor** · 2026-09-16 14:13 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1789568006729369)
> **Campaign `Search | Leads | WIA` (24247841488), Maximize clicks, $16.66/day — verified live 9/16.**  | Day | Impr | Clicks | Cost | Conv | |---|---|---|---|---| | Mon 9/14 | 203 | 16 | $32.44 | 0 | | Tue 9/15 | 250 | 13 | $22.00 | 0 | | Wed 9/16 (partial) | 52 | 1 | $1.80 | 0 | | **Total** | **505** | **30** | **$56.24** | **0** |  **Caveat first:** Google only reveals search terms for 15 of the 30 clicks ($28.17 of the $56.24) — the rest are withheld as low-volume. So the waste share below is directional for the visible half, not an exact account-wide number.  | Search term | Clicks | Cost | Issue | |---|---|---|---| | wedding venues in warner robins georgia | 2 | $3.64 | different market | | wedding venues rome ga | 2 | $2.94 | ~110 mi, NW GA | | wedding venues in dahlonega ga | 1 | $2.08 | NE GA mountains | | jekyll island wedding venues | 1 | $2.02 | coast, ~250 mi | | adams estate prices | 1 | $2.07 | competitor brand | | flint hill by wedgewood weddings photos | 1 | $2.02 | competitor brand | | summit farm ellijay ga | 1 | $1.70 | competitor brand | | the dogwood midtown atlanta | 1 | $1.77 | name confusion | | backyard wedding | 1 | $1.90 | no venue intent |  On-target in the visible set: `west ga wedding venues`, `wedding venues in georgia`, `wedding venues in northwest ga` (borderline), `indian wedding venues atlanta` (in radius, different segment). All 30 clicks came from just 5 keywords, and the phrase keyword **`wedding venue` alone took 26 clicks / $48.83** — that's the broad door everything walks through.  **Proposed negative list** (phrase match unless noted): • *Competitors / name confusion:* the dogwood, dogwood midtown, adams estate, wedgewood, flint hill, summit farm, atrium on eighty, ashven estate, bennett farms, blackberry ridge, butterfly pavilion • *Out of market:* warner robins, rome ga, dahlonega, jekyll island, savannah, gatlinburg, ellijay, blue ridge, helen ga, athens ga, augusta, charlotte, northwest ga, tennessee • *Wrong intent:* backyard wedding  Happy to create these as a shared negative list and link it, or add them at campaign level — your call on which you'd rather maintain.  **Location setting:** the campaign's single criterion is a 100-mile PROXIMITY radius. On Google's default *Presence or interest*, that shows ads to people merely researching other Georgia towns, which matches exactly what we're seeing. Click path: Campaign → Settings → Locations → Location options → Target: **"Presence: People in or regularly in your targeted locations."** It's not writable through the API, so it needs your click — I'll re-verify after.  **One open question, separate from the waste:** the conversion action `Submit lead form` is click-based (AW-18420835725) and I can't see the AW tag or `gtag_report_conversion` in the page source of `<http://dogwoodreserve.com/weddings/|dogwoodreserve.com/weddings/>` — it may well be inside GTM-5G36SNFQ, which page source won't show. Three days at 0 conversions is equally consistent with "no inquiries yet" and "the tag never fires," and only one test form submit distinguishes them. Want me to run that submit so we know before week two?
> **Carmen Cruickshank** · 2026-09-16 19:23 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1789586620822089)
> i have negative keywords its in a list called "base negative" and i only have locations set to presence, and i added backyard wedding, i want to keep he competitors to see if theyre worth targeting
> **Viktor** · 2026-09-16 19:25 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1789586753197989)
> Verified both live just now — `base negatives` (24 phrase terms, incl. `backyard`) is attached to *Search | Leads | WIA*, and the campaign is PRESENCE on both positive and negative geo targeting. :+1: Keeping competitors as a test is fair — that's real intent, just worth a decision point (say $75 of competitor spend or 2 weeks, then keep only what converted, or split them into their own ad group so they don't eat the core budget).  The gap neither change covers is **other-city searches**: presence-only fixes where the searcher *is*, not what they type, so someone inside the 100-mi radius searching another town still clicks. Of the $31.57 of clicked spend Google reveals for 9/14–16, ~$14.80 is exactly that:  | term | clicks | cost | |---|---|---| | wedding venues in warner robins georgia | 2 | $3.64 | | wedding venues rome ga | 2 | $2.94 | | wedding venues in northwest ga | 1 | $2.09 | | west ga wedding venues | 1 | $2.09 | | wedding venues in dahlonega ga | 1 | $2.08 | | jekyll island wedding venues | 1 | $2.02 |  Plus $3.51 on `the dogwood midtown atlanta` + `the dogwood at westside paper` — that's a different venue with our name, not a competitor worth testing.  Suggested adds to `base negatives` (phrase): `warner robins`, `rome ga`, `dahlonega`, `jekyll island`, `savannah`, `macon`, `columbus ga`, `milledgeville`, `helen ga`, `blue ridge`, `northwest ga`, `north georgia`, `gatlinburg`, `tennessee`, `alabama`, `midtown`, `westside paper`. I'd leave Atlanta itself alone — metro-Atlanta couples are the buyers; it's the in-Atlanta venue names that waste.  Want me to push those? Negative-keyword writes go live instantly on my end (no approval step), so just say go — and I can pull any back out the same way.

**Gisselle Jiménez** · 2026-09-21 15:58 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1790006303282779)
Hi @Jacqueline Hood! Dogwood Reserve has _officially approved the Client Attraction ad copy and all three creatives._ :meow_party: They’re really eager to get their Meta Ads live, so you’re good to move forward with building and launching the campaign. Please let us know once everything is live so we can send them a final update. Thank you!

→ *<https://docs.google.com/document/d/1VH1toF8368Yg7nw7CNXJAqXilIfQYD4WuvjJroeGqLA/edit?tab=t.0#heading=h.vbwrwhzcofad|Dogwood Client attraction approval form>*

cc: @Ivy Ayala @Whitney Hodges

**Gisselle Jiménez** · 2026-09-21 21:14 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1790025281871239)
@Whitney Hodges Events investment guide for review!
<https://canva.link/uhznz39ir6r5lly|canva.link/…>
> **Whitney Hodges** · 2026-09-22 13:22 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1790083343965529)
> @Gisselle Jiménez can you please update the cover photo? I'm thinking a reception photo of the pavilion may be better
> **Gisselle Jiménez** · 2026-09-22 14:07 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1790086068116469)
> @Whitney Hodges Something like this?:eyes:
> 📎 barn-wedding-ceremony-aisle-florals-dogwood-reserve-georgia.webp (webp, saved as `files/F0C3FADS2PM-barn-wedding-ceremony-aisle-florals-dogwood-reserve-georgia.webp`)
> 📎 barn-reception-hall-draped-ceiling-dogwood-reserve-georgia.webp (webp, saved as `files/F0C3R721Z1A-barn-reception-hall-draped-ceiling-dogwood-reserve-georgia.webp`)
> **Whitney Hodges** · 2026-09-22 14:09 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1790086142565919)
> @Gisselle Jiménez probably the second photo..maybe zoomed in in a way where you can see the ceremony altar
> **Gisselle Jiménez** · 2026-09-22 14:17 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1790086654105049)
> @Whitney Hodges :eyes:
> 📎 Dogwood Reserve Events  Investment Guide.png (png, saved as `files/F0C3GM48V61-Dogwood_Reserve_Events_Investment_Guide.png`)
> **Whitney Hodges** · 2026-09-22 15:41 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1790091692015349)
> @Gisselle Jiménez Thank you! I think that should work
> **Gisselle Jiménez** · 2026-09-22 15:58 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1790092731823009)
> @Whitney Hodges Great! Email to tirzah is drafted in LeadLock inbox

**Viktor** · 2026-09-22 17:51 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1790099516929449)
@Carmen Cruickshank — Dogwood week-two read, and first the good news: **conversion tracking is confirmed working.** The `Submit lead form` action fired on 9/17, and I matched it in LeadLock to a real inquiry carrying our campaign's click ID. So no tag problem, and your `base negatives` + presence-only setup is doing its job.  Where we stand 9/14–9/22: **$179.08 / 1,383 impressions / 115 clicks / 8.3% CTR / $1.56 CPC / 1 conversion.** The CTR and CPC are healthy — this is a conversion and traffic-mix story, not a click-cost one.  Three things I'd suggest looking at (all your call): the **competitor test now has data**, one phrase keyword is taking **85% of spend**, and we're still losing **36% of impression share to budget**. Detail and numbers in the thread. :thread:
> **Viktor** · 2026-09-22 17:52 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1790099539343029)
> **Campaign `Search | Leads | WIA` (24247841488), Maximize clicks, $16.66/day — live pull 9/22.**  | Metric | 9/14–9/22 | | --- | --- | | Cost | $179.08 | | Impressions | 1,383 | | Clicks | 115 (8.3% CTR, $1.56 CPC) | | Conversions | 1 (9/17) | | Search impr. share | 10% — 58% lost to rank, 36% lost to budget |  **1. Tracking is verified, so the 1 is real.** I cross-checked LeadLock: Dogwood took 16 inquiries 9/13–9/22, and exactly one carries a `gclid` with `gad_campaignid=24247841488` (9/17). The other 15 were organic, Facebook, direct, a HereComesTheGuide referral, and chat. Good news inside that: the venue has real inquiry flow (~1.6/day), so demand isn't the question — our share of it is.  **2. The competitor test has its answer.** You wanted to see if competitor terms were worth targeting — fair call, and now there's data. Of the spend Google reveals search terms for ($91.20 of the $179.08), **~$16 went to other venues' brand names with 0 conversions**: `the dogwood at westside paper`, `the dogwood midtown atlanta`, `flint hill by wedgewood`, `montaluce`, `summit farm ellijay`, `adams estate prices`. My read: the two "dogwood" ones aren't a competitor test at all, they're name confusion with an Atlanta venue — worth blocking regardless. The rest I'd either negative out or split into their own ad group so they stop drawing from the core budget.  **3. One keyword is the whole account.** Phrase `wedding venue` = **98 of 115 clicks and 85% of spend**, with 1 conversion. That produced **477 distinct search terms for 115 clicks** — nearly every click a different one-off query, which is why so much lands off-target. Of the visible spend, **~28% is other markets** (Athens, Dahlonega, Rome, Warner Robins, Jekyll Island, one Puerto Rico). Presence-only fixes where the searcher is, not what they type, so these still slip through — the city negatives I listed on 9/17 are still the fix, whenever you want them pushed. Live instantly on my end, and reversible the same way.  **4. Geo + budget.** One 100-mile radius on $500/mo is thin — 36% of impression share lost to budget says we're spread across more map than the money covers. Suggestion: tighten the radius to ~60 miles and, since metro-Atlanta couples are genuinely the buyers, add Atlanta metro as its own target so it can be seen and bid separately instead of paid for blind.  **5. Landing page — in progress, and not a criticism of the account.** Ads currently land on `<http://dogwoodreserve.com/weddings/|dogwoodreserve.com/weddings/>`, which has no inquiry form on it; couples have to click again to reach one. Whitney has a dedicated ads landing page in motion with their web designer using our copy, and that's the real fix. I'm not suggesting we swap the destination to the pricing page in the meantime — it has the form but thin context for cold traffic, so it's not an obvious win.  **Sequencing I'd recommend:** negatives + geo now, landing page when it's ready, then switch to Maximize conversions once we're around 15 conversions. That's the same order that took Ridgefield from $78 to $39 CPL. On 9 days and 115 clicks it's still genuinely early — at a normal 3–5% rate we'd have expected 3–6 leads, so 1 is soft but not yet damning. Nothing changed in the account, all of this is your call.

**Gisselle Jiménez** · 2026-09-22 18:14 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1790100851125179)
@Whitney Hodges Hi! Did you see videos coming through from Judy? I checked the folder but I could only see photos included
> **Whitney Hodges** · 2026-09-22 18:17 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1790101065421249)
> No, I just responded to her

**Jacqueline Hood** · 2026-09-23 05:57 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1790143062058919)
@Whitney Hodges @Gisselle Jiménez client attraction ads are ready to publish but there isn't a payment method on file attached to the ad account :slightly_smiling_face:

Also I'm not seeing a pixel; do they have one created or should I create one for them?
> **Whitney Hodges** · 2026-09-23 12:34 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1790166873158119)
> @Jacqueline Hood Payment method has been added, and yes, it's a brand new ad account, so we'll need to create the pixel for her
> **Jacqueline Hood** · 2026-09-23 13:47 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1790171236830869)
> okay! I'll turn the ads on and create the pixel :slightly_smiling_face:

**Gisselle Jiménez** · 2026-09-23 13:59 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1790171988277409)
@Danielle McGinnis @Tina Henares Hi! We have created the events investment guide and it has been approved by Tirzah, here is the sharing link:
<https://canva.link/dogwood-reserve-events-investment-guide|canva.link/dogwood-reserve-events-investment-guide>

Could you please implement it in the events workflow? The issue we had is that in their website client's click "get pricing" and see "click below to see detailed investment guide" but when enrolled in the events workflow we didn't have an investment guide in place so a client emailed Tirzah that they weren't able to get the guide.

Just to confirm, any event type they select besides weddings enrolls them in the events workflow right?
📎 image.png (png, saved as `files/F0C3S53M6P7-image.png`)
> **Tina Henares** · 2026-09-23 15:29 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1790177348092609)
> Thank you @Gisselle Jiménez! I've added a "Investment Guide} button to the initial email in the events workflow, mirroring the weddings workflow.
> 
> I believe that selecting any event type besides weddings would enroll them in the events workflow. But @Danielle McGinnis should be able to confirm that for us :slightly_smiling_face:
> **Danielle McGinnis** · 2026-09-23 18:04 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1790186660659259)
> Thank you @Tina Henares and @Gisselle Jiménez ! Yes correct. Anything selected other than weddings puts them in the events workflow. 
> **Gisselle Jiménez** · 2026-09-23 18:36 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1790188601426109)
> @Danielle McGinnis Okay, great! @Whitney Hodges I've replied to Tirzah confirming this is now in place:raised_hands:

**Jacqueline Hood** · 2026-09-23 14:16 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1790172981876609)
Client attraction ads are LIVE! :partying_face:
> **Gisselle Jiménez** · 2026-09-23 17:59 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1790186372882579)
> @Whitney Hodges Email is drafted!

**Jacqueline Hood** · 2026-09-23 14:16 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1790172993354039)
Meta Pixel has been created. I added it to the Ads Inquiry funnel in Leadlock. I'll attach the full code in the thread below.
> **Jacqueline Hood** · 2026-09-23 14:18 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1790173081190999)
> &lt;!-- Meta Pixel Code --&gt;
> &lt;script&gt;
> !function(f,b,e,v,n,t,s)
> {if(f.fbq)return;n=f.fbq=function(){n.callMethod?
> n.callMethod.apply(n,arguments):n.queue.push(arguments)};
> if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
> n.queue=[];t=b.createElement(e);t.async=!0;
> t.src=v;s=b.getElementsByTagName(e)[0];
> s.parentNode.insertBefore(t,s)}(window, document,'script',
> '<https://connect.facebook.net/en_US/fbevents.js|connect.facebook.net/en_US/fbevents.js>');
> fbq('init', '4662747973969456');
> fbq('track', 'PageView');
> &lt;/script&gt;
> &lt;noscript&gt;&lt;img height="1" width="1" style="display:none"
> src="<https://www.facebook.com/tr?id=4662747973969456&amp;ev=PageView&amp;noscript=1|facebook.com/tr?ev=PageView&amp;noscript=1&amp;…>"
> /&gt;&lt;/noscript&gt;
> &lt;!-- End Meta Pixel Code --&gt;

**Whitney Hodges** · 2026-09-24 14:24 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1790259846962529)
@Jacqueline Hood Thank you! We aren't using LeadLock pages for this client, so the pixel needs to be installed on their main site. Can we do this through GTM @Carmen Cruickshank?
> **Carmen Cruickshank** · 2026-09-24 16:55 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1790268957702599)
> i can try @Whitney Hodges

**Carmen Cruickshank** · 2026-09-24 19:18 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1790277537458959)
meta pixel added! @Gisselle Jiménez @Whitney Hodges

**Jacqueline Hood** · 2026-09-24 21:26 · [link](https://weddingindustryads.slack.com/archives/C0B245ATY03/p1790285209639769)
thanks Carmen!!
