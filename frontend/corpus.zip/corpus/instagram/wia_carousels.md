# WIA carousels — the last 12 months

Every carousel published on [@weddingindustryads](https://www.instagram.com/weddingindustryads/)
between **23 September 2025 and 23 September 2026**, slide by slide, with the
caption verbatim and the publish date.

**18 carousels · 159 slides · 6,328 words of slide copy · 3,775 words of caption.**

Scraped 23 September 2026 from the logged-in profile. This is the carousel
layer of the Content Atelier's voice corpus — see `Content_Atelier.md` §3.4
and `corpus/canva-descript-access.md`. How it was built, and the transcription
conventions, are at the end under [Method](#method).

---

## Ledger

| # | Published | Post | Cover line | Slides | Voice | CTA | Email sibling |
|---|---|---|---|---|---|---|---|
| 1 | 19 Aug 2026 | [`DcOTSPFDlVS`](https://www.instagram.com/p/DcOTSPFDlVS/) | You don't need another reminder to “show up consistently.” | 12 | First person — Whitney | DM “ADS” | 20 Aug · She didn't post on Instagram for 10 weeks 😱 |
| 2 | 5 Aug 2026 | [`DbqNlbxDoaN`](https://www.instagram.com/p/DbqNlbxDoaN/) | She invested $22,000 in ads during the first half of last year. | 9 | Team | DM “ADS” | 31 Jul · *"I honestly have no idea if this is working."* **and** 6 Aug · You can't optimize what you can't measure |
| 3 | 19 Jun 2026 | [`DZxgMoFjjPF`](https://www.instagram.com/p/DZxgMoFjjPF/) | We generated $90,000 in booked revenue from ads for a venue client in the first 90 days. | 9 | Team | DM “ROI” — caption only | None found |
| 4 | 10 Jun 2026 | [`DZa_FogmSp6`](https://www.instagram.com/p/DZa_FogmSp6/) | We ask this question to every new client. | 10 | Team, opened in first person | DM “ADS” | 10 Jun · The question we ask every new client |
| 5 | 4 Jun 2026 | [`DZKeR0gDitC`](https://www.instagram.com/p/DZKeR0gDitC/) | Visibility isn't something you just earn. It's something you *build*. | 7 | Team | Link in bio → free training | 4 Jun · Visibility isn't just something you earn. |
| 6 | 14 May 2026 | [`DYUpKBqDjc7`](https://www.instagram.com/p/DYUpKBqDjc7/) | The wedding pros kicking butt in 2026 are building predictable marketing systems… | 10 | Team | Link in bio → ways to work with us | 13 May · Predictable marketing > viral marketing |
| 7 | 11 May 2026 | [`DYN3dEPGZjB`](https://www.instagram.com/p/DYN3dEPGZjB/) | You're not getting in front of the right couples consistently | 7 | Team | Link in bio → ACCELERATE | 5 May · A smarter way to get in front of the right clients |
| 8 | 8 Apr 2026 | [`DW4rBAlj746`](https://www.instagram.com/p/DW4rBAlj746/) | If your ads are generating leads… you have a *conversion problem*. | 10 | Team | DM “ADS” | 31 Mar · If your ads aren't turning into bookings, read this |
| 9 | 5 Feb 2026 | [`DUYGqO6jvcX`](https://www.instagram.com/p/DUYGqO6jvcX/) | GIVEAWAY — for wedding pros ready to run ads with confidence | 10 | Team | Apply via link in bio · like, share, follow | 5 Feb · 💝 Google & Meta Ads Giveaway 💝 |
| 10 | 14 Jan 2026 | [`DTgMh1qj84d`](https://www.instagram.com/p/DTgMh1qj84d/) | Being good isn't enough if couples can't find you. | 8 | Split — caption Whitney, slides team | DM “Google” | 6 Jan (slides) **and** 13 Jan (caption) |
| 11 | 31 Dec 2025 | [`DS7zCbljuhy`](https://www.instagram.com/p/DS7zCbljuhy/) | Today's Couples Don't Inquire After One Click. | 10 | Team | DM “Meta Ads” | None found |
| 12 | 23 Nov 2025 | [`DRZ4motDhML`](https://www.instagram.com/p/DRZ4motDhML/) | Why Wedding Ads Fail… (Even When You Have a Stellar Brand) | 9 | Team, signed “XO Whitney” · collab | Link in bio, or DM | None found |
| 13 | 20 Nov 2025 | [`DRR5U1zDn67`](https://www.instagram.com/p/DRR5U1zDn67/) | How to Know Your Ads Are Actually Working (for Wedding Pros + Venues) | 10 | Team, signed “Daniela + Whitney” | DM “WEDDING ADS”, or link in bio | 19 Nov · The moment you know your ads are working… |
| 14 | 31 Oct 2025 | [`DQei1cAjtbY`](https://www.instagram.com/p/DQei1cAjtbY/) | Slay Google Ads — no tricks, just treats! | 8 · 1 video | Team | Link in bio → 5 Nov info session | 31 Oct · Slay Google Ads 💀 |
| 15 | 30 Oct 2025 | [`DQcDr8nDofx`](https://www.instagram.com/p/DQcDr8nDofx/) | Ready to Show Up *First* When Couples Search on Google? | 7 | Team | Link in bio, or DM | 30 Oct · Double your visibility on Google |
| 16 | 24 Oct 2025 | [`DQMPIGCjgzF`](https://www.instagram.com/p/DQMPIGCjgzF/) | Our *Google Ads VIP Day* is getting a serious glow-up | 7 · 1 video | Team | Save + follow — no link | 24 Oct · Google Ads Glow Up 👀 |
| 17 | 23 Oct 2025 | [`DQJyc63jiFH`](https://www.instagram.com/p/DQJyc63jiFH/) | What Wedding Pros Need to Know About Google Ads *Broad Match* | 8 | Team | Stay tuned — no link | None found |
| 18 | 1 Oct 2025 | [`DPQ_LnMjou2`](https://www.instagram.com/p/DPQ_LnMjou2/) | Still Waiting for *Engagement* Season to Save Your Bookings? | 8 | Team · collab | DM «»GOOGLE ADS»», or link in bio | 1 Oct · It's time for a reality check |

Dates are UTC, from Instagram's own `taken_at`. Every email sibling above is
**confirmed by phrases shared in the email body**, not inferred from subject or
date — the evidence sits in each entry below. “Collab” means co-authored with
Whitney's personal account, @whitneymhodges.

---

## What the eighteen have in common — and where they split

Drawn from these eighteen posts only. Read it as the shape of the voice over
one year, not as rules.

### Two eras, with a clean break

| | Q4 2025 · #12–#18 | Dec 2025 onward · #1–#11 |
|---|---|---|
| **Template** | Older: the `@WEDDINGINDUSTRYADS` handle on every slide, “SWIPE” tags, periwinkle accents, photo-backed text cards | Current: WIA roundel logo on the cover, letter-spaced sans on flat navy or off-white, a founders photo to close |
| **Job** | Launch and promo assets — all seven sell a named offer, and six attach a date or a scarcity line (#15 is the exception) | Teaching and client-story pieces; the offer moves to the caption or the last slide |
| **Caption emoji** | Every caption, 2–8 each | Essentially none — 9 of 11 have zero; #6 uses ✖️ as list markers and #9 is the giveaway |
| **DM keyword** | Offer-specific — “WEDDING ADS”, “GOOGLE ADS” | Topic keywords at the turn of the year (“Meta Ads”, “Google”), then **“ADS”** from April on, with one “ROI” |

The break falls between #12 (23 Nov) and #11 (31 Dec). It matches what
`corpus/emails/_INDEX.md` found in the email corpus — 2025 mixed and
promotional, 2026 the founder-voice motion — so the exemplar set for voice work
should lean on #1–#11 and treat #12–#18 the way the 2024–25 emails are treated:
as the register the voice moved away from.

### Q4 2025, told in carousels

The one worked example in the year of carousels running a campaign. The Google
Search Accelerator launch sits in the middle, bracketed by two full-service
pushes:

| Date | Carousel | Job |
|---|---|---|
| 1 Oct | #18 | Seasonal urgency + full-service promo (“just 3 spots”) |
| 23 Oct | #17 | Broad Match explainer → Accelerator “coming soon… this November” |
| 24 Oct | #16 | The VIP Day “glow-up” → “launching next week” |
| 28 Oct | *(emails only)* | “Google Search Accelerator drops today” / “…is here” |
| 30 Oct | #15 | “INTRODUCING… THE GOOGLE SEARCH ACCELERATOR” |
| 31 Oct | #14 | Halloween tips → 5 Nov live info session |
| 20–23 Nov | #13, #12 | Full-service push — “only two spots left… before the end of the year” |

Four launch carousels in nine days; three of them (#14, #15, #16) went out the
same day as a matching email. #17's explainer has no email sibling.

### What holds across both eras

**One build.** 7–12 slides, median 9. A serif-headline cover that is a hook,
never a title; body slides carrying one idea each, with bold marking the line
that carries the slide; and 15 of 18 close on a photo of one or both founders.
Body slides run 7–160 words (the 160 is #15's testimonial collage).

**Whitney's framework.** Hook → problem → solution → transformation → how we
help → CTA (`Content_Atelier.md` §3.3) shows up in most of them, most clearly in
the client stories and teaching pieces; the two launch teasers (#16, #17)
follow it least. #2 is the cleanest: hook (1), problem
(2–4), solution (5), transformation (6–7), how we help (8), CTA (9).

**“We” is the default.** First person appears when the source is Whitney's own
conversation or opinion: #1 (caption signed “-Whitney”) and #10 (caption signed
“XO, Whitney”, while its slides stay team voice), plus single lines in #4 and in
#13's caption (“DM me”). Two carousels are signed on the slide itself — #12
(“XO Whitney”) and #13 (“Daniela + Whitney”) — and two are collabs with
@whitneymhodges (#12, #18).

**Client stories are always anonymous, and always specific.** Seven carousels
carry client results or quotes (#1, #2, #3, #9, #13, #15, #18). None names a
client — #15 redacts a business name inside a screenshot. The figures are
stated plainly. For open decision #5 in `Content_Atelier.md`: on carousels, the
published default for the whole year is **anonymous and specific**.

**Captions retell; they don't repeat.** 113–344 words. The caption restates the
argument in looser prose, often opening on a different line than the cover.
**No hashtags in any of the 18**, and **none of the 159 slides has alt text** —
`accessibility_caption` is empty throughout.

> Corrections this implies for the Atelier's output spec, which asks for
> hashtags and alt text on every caption: WIA's carousels carry **no hashtags**
> and **no alt text**, and emoji belong to the older promotional register — the
> current voice doesn't use them.

### CTAs and offers

| CTA shape | Carousels |
|---|---|
| DM keyword only | #1 · #2 · #3 · #4 · #8 · #10 · #11 |
| Link in bio only | #5 · #6 · #7 · #9 · #14 |
| Both | #12 · #13 · #15 · #18 |
| No ask — launch teasers | #16 · #17 |

DM keywords: “ADS” ×4, and “ROI”, “Google”, “Meta Ads”, “WEDDING ADS”,
“GOOGLE ADS” once each.

Offers named: the **Google Search Accelerator** (#14–#17); the **Ads
Accelerators** (#4, #6, #7, #8) and the **Ads Accelerator Bundle** (#9);
**ELEVATE** by name (#4, #6), and full-service management without the name
(#12, #13, #18); the **Google Ads VIP Day** (#16, #18); **The Visibility
Blueprint** (#5). Five name nothing (#1, #2, #3, #10, #11) — including all
three pure results posts, which is where Whitney's “1:1 results → ELEVATE”
rule would have predicted an offer.

### Two claims to check before anything reuses them

- **#3's “$90,000 in booked revenue”** is **9 bookings × a ~$10,000 average
  booking**, not a revenue figure the client reported. The message sent to the
  client framed the $10,000 as a condition (*“If your average booking is
  $10,000…”*, #15 slide 5); Whitney's own reel about the same venue says
  *“average value was about 10K each”* and *“nine or ten”* bookings
  (`corpus/docs/founder-voice-knowledge-base.md`). A defensible estimate — but
  an estimate, and the 3,667% ROAS is computed from it.
- **#18's slide 4** gives one planner both “drinking from a firehose” and a
  doubled revenue; its caption attributes those to two different pros.

Both are exactly what the Atelier's third operating rule — every claim traces to
its source — exists to catch.

### Either format can lead — the record shows both

14 of 18 carousels have an email that shares their phrases word for word, and
the order runs both ways:

| Order | Carousels |
|---|---|
| Email first | #10 (8 days for the slides, 1 for the caption) · #8 (8 days) · #7 (6 days) · #2 (31 Jul, 5 days) · #6 (1 day) · #13 (1 day) |
| Same day | #4 · #5 · #9 · #14 · #15 · #16 · #18 |
| Carousel first | #1 (1 day) · #2 (6 Aug, 1 day) |

That is Whitney's *“either have it give me a script for reels first, or we work
on a marketing email first”*, visible in what actually went out. #10 is the most
instructive case — its slides follow one email and its caption another. These
pairings fill `instagram_sibling` for 16 of the 126 email files in
`corpus/emails/`, where the field is currently blank in every one.

---

## 1 · “You don't need another reminder to ‘show up consistently.’”

| | |
|---|---|
| **Published** | 19 Aug 2026 · `2026-08-19T13:31:37Z` |
| **Permalink** | <https://www.instagram.com/p/DcOTSPFDlVS/> |
| **Shortcode** | `DcOTSPFDlVS` |
| **Slides** | 12 · all static images · 1080×1350 (4:5) |
| **Engagement at scrape** | 6 likes · 0 comments |
| **Voice** | First person — Whitney, about a 1:1 client conversation |
| **CTA** | DM “ADS” |
| **Email sibling** — *confirmed in body text* | 20 Aug 2026 “She didn't post on Instagram for 10 weeks 😱” · Reply CTA · carries “10 weeks” and “I couldn't do it all” · the carousel went out **one day earlier** |
| **Reel sibling** — *probable* | `DcTt2gkuh39`, the next post on the grid — its caption opens on slide 11's idea: “There's a difference between wanting to do less marketing and wanting your marketing to depend less on you.” |

### Slides

**Slide 1** — *photo: woman working at a laptop, flowers and coffee on the table; WIA roundel logo, bottom centre*

> You don't need another reminder to “show up consistently.”
>
> You need a marketing strategy that accounts for the fact that sometimes, you can't.

**Slide 2** — *navy text slide*

> One of our wedding planning clients is a *really* good marketer.
>
> She creates great content. She's invested in her website. And throughout most of our time working together, she's been incredibly consistent about showing up on social media.
>
> **Then this summer, she didn't post on Instagram for almost 10 weeks.**

**Slide 3** — *navy text slide*

> The coolest part about that:
>
> **She knew she could take her foot off the gas for a while because her ads were still running.**
>
> While she focused on serving clients, investing in education, leveraging AI, refining her systems, and growing her team, paid advertising was still consistently putting her business in front of potential clients.
>
> It gave her permission to let Instagram sit for a minute.
>
> And some much-needed breathing room.

**Slide 4** — *navy text slide*

> During our most recent strategy call, she thanked us for continuing to manage her ads and generate new leads while her attention was elsewhere.
>
> In her words:
>
> **“I couldn't do it all.”**
>
> I felt that in my bones.

**Slide 5** — *navy text slide*

> Because this is the part of “consistent marketing” we don't talk about enough:
>
> **Consistency requires capacity.**
>
> And your capacity as a business owner is going to change.
>
> Wedding season happens.
> Hiring happens.
> Growth happens.
> Life happens.

**Slide 6** — *navy text slide*

> So instead of constantly asking:
>
> **“How can I keep up with all of my marketing?”**
>
> Think about it this way:
>
> **“How much of my marketing still requires me to keep it moving?”**

**Slide 7** — *navy text slide*

> That's where paid advertising can create real leverage.
>
> Your marketing isn't falling to the wayside every time you get slammed.
>
> Your ads can continue reaching potential clients, driving qualified traffic, and generating new opportunities while you handle the parts of the business that need you most.

**Slide 8** — *navy text slide*

> And there's an important distinction here:
>
> **Paid ads weren't making up for a lack of marketing.**
>
> They were building on years of it.
>
> A strong brand.
> Great content.
> A thoughtful website.
> Clear positioning.
> An established reputation.
>
> She'd already built the foundation.

**Slide 9** — *navy text slide*

> And when she has the capacity to show up consistently *and* her ads are running?
>
> Even better.
>
> We often see organic and paid create a compounding effect.
>
> **Organic builds trust. Paid expands the opportunity to be discovered.**
>
> They work beautifully together.

**Slide 10** — *navy text slide*

> But I keep coming back to what she said:
>
> **“I couldn't do it all.”**
>
> And maybe, at this stage of business, you shouldn't have to either.
>
> Your marketing can be doing its job without every piece of it requiring your attention every week.

**Slide 11** — *navy text slide*

> There's a big difference between:
>
> **wanting to stop marketing**
>
> and
>
> **wanting your marketing to stop depending so heavily on you.**
>
> We're interested in helping with the second.

**Slide 12** — *photo: a single-founder portrait, seated in a cream armchair (the post is Whitney's — signed “-Whitney”); text over the darkened left side; WIA roundel logo, bottom right*

> If you're already investing in your marketing, showing up, and doing the work…
>
> but you're feeling the weight of how much still depends on your time and energy
>
> **DM me “ADS”**
>
> Let's talk about whether paid advertising could give your business a little more breathing room.

### Caption

*Verbatim. The opening line has a closing quote mark with no opening one — that is how it was published.*

```text
I couldn’t do it all.”

I don’t know a single business owner who hasn’t felt that at some point. I certainly have.

And that’s why this conversation with one of our clients stuck with me.

She’s a great marketer. She’s spent years building a strong brand, creating content, investing in her website, and showing up consistently.
But this summer, she needed to put her energy elsewhere.

Knowing her ads were still running (and still consistently putting her business in front of potential clients) gave her the breathing room to let Instagram go quiet for almost 10 weeks.

That’s the part I want established wedding pros to hear.

You’ve already built so much. You’re already doing the work. The next stage of growth doesn’t necessarily need to mean finding more hours in the day to keep doing all of it yourself.

Sometimes it means building more support around what’s already working.

If you’re feeling that tension in your own business right now, DM me “ADS.”

I’d love to hear what’s taking up your bandwidth and talk about whether paid advertising could take a little of the marketing weight off your shoulders.

-Whitney
```

---

## 2 · “She invested $22,000 in ads during the first half of last year.”

| | |
|---|---|
| **Published** | 5 Aug 2026 · `2026-08-05T13:09:09Z` |
| **Permalink** | <https://www.instagram.com/p/DbqNlbxDoaN/> |
| **Shortcode** | `DbqNlbxDoaN` |
| **Slides** | 9 · all static images · 1080×1350 (4:5) |
| **Engagement at scrape** | 5 likes · 2 comments |
| **Voice** | Team — “we” / “us”, a client story told in third person |
| **CTA** | DM “ADS” |
| **Email siblings** — *confirmed in body text* | **31 Jul 2026** *"I honestly have no idea if this is working."* · Ads Accelerator Reply CTA · carries both $22,000 and $70,000 — the same client story, told **five days before** the carousel. **6 Aug 2026** “You can't optimize what you can't measure” · Reply CTA · carries $22,000 and opens on the caption's first line · **one day after** |
| **Reel sibling** — *probable* | `DbdX3phuClE` — its caption opens “I honestly have no idea if any of this is working” and names an Ads Accelerator client |

### Slides

**Slide 1** — *off-white slide, navy serif type, centred; WIA roundel logo, bottom centre*

> **She invested $22,000 in ads during the first half of last year.**
>
> Yet she was seriously questioning whether any of it was worth it.
>
> Because she couldn't answer one simple question:
>
> **Were the ads actually working?**

**Slide 2** — *off-white text slide*

> Every month, she received reports full of marketing metrics.
>
> -Impressions.
> -Clicks.
> -Click-through rate.
> -Cost per click.
>
> But she was still left trying to piece everything together herself.
>
> She couldn't tell whether any of it was leading to inquiries or bookings.

**Slide 3** — *off-white text slide*

> The problem wasn't necessarily that the ads weren't working.
>
> The problem was that there wasn't the right tracking in place to show whether they were generating inquiries or bookings.
>
> Beyond clicks, there was no way to measure the return on her advertising investment.

**Slide 4** — *off-white text slide*

> When you don't know what you don't know, it's hard to know what questions to ask.
>
> She found herself having to hand-hold the very agency she'd hired to guide her.
>
> Eventually, she reached a breaking point.
>
> She didn't want someone to do everything for her while keeping her in the dark.
>
> She fired her agency and tried to manage the ads herself.
>
> That's when she realized she didn't need someone to simply run her ads.
>
> She needed someone to help her understand what was and wasn't working—and why.

**Slide 5** — *off-white text slide*

> Together, we rebuilt the foundation.
>
> • We launched fresh campaigns.
> • We installed the right conversion tracking.
> • We helped her create a landing page designed specifically for paid traffic.
>
> For the first time, she could clearly see exactly what her advertising investment was producing.

**Slide 6** — *off-white text slide, two headed blocks*

> **First Half of Last Year**
>
> -$22,000 invested
> -No clear way to measure results.
>
> **First Half of This Year**
>
> -$6,000 invested
> -Nearly $70,000 in wedding bookings directly attributable to her ads.

**Slide 7** — *off-white text slide*

> The $70K is great, but honestly, that's not even the point.
>
> **The real win is that she no longer had to guess whether her advertising was actually working.**
>
> **She knew.**
>
> No assumptions.
>
> Just clear data.

**Slide 8** — *off-white text slide*

> We believe every wedding business deserves that kind of clarity.
>
> Whether you hire an agency or manage your ads yourself…
>
> You should always know what's working.
>
> Because that's how you make better marketing decisions.

**Slide 9** — *photo: the two founders standing together, darkened, text centred over it*

> If you're investing in advertising but still feel like you're in the dark…
>
> You don't have to navigate it alone.
>
> Whether you're looking for someone to manage your ads…
>
> Or you're hoping to learn how to manage them yourself…
>
> **DM us “ADS,” and let's talk about what the right support looks like for your business.**

### Caption

*Verbatim.*

```text
You can’t optimize what you can’t measure.

It sounds obvious.

But every week, we talk to wedding business owners who are spending thousands of dollars on advertising without a clear way to connect that investment to inquiries and bookings.

And that’s an expensive problem.

Most people assume the solution is better ads.

Sometimes it is.

But often, the first problem to solve isn’t the ads themselves.

It could be your tracking, landing page, messaging, positioning, or follow-up.

More often than not, it’s a combination of all of them.

It’s about building the right systems to understand what’s actually happening after someone clicks.

To know with certainty which inquiries came from your ads.

To confidently connect bookings back to your advertising investment.

To understand what’s working... and just as importantly, what isn’t.

That’s the clarity we give to our clients.

Not just a bunch of data in a report.

The knowledge to understand it.

The confidence to know what’s working.

We believe every wedding business deserves that level of clarity.

If you’re investing in advertising but still feel like you’re in the dark, send us a DM with “ADS”.

We’d love to learn more about your business and help you figure out what the right support looks like for you.
```

---

## 3 · “We generated $90,000 in booked revenue from ads for a venue client in the first 90 days.”

| | |
|---|---|
| **Published** | 19 Jun 2026 · `2026-06-19T16:03:41Z` |
| **Permalink** | <https://www.instagram.com/p/DZxgMoFjjPF/> |
| **Shortcode** | `DZxgMoFjjPF` |
| **Slides** | 9 · all static images · 1440×1800 (4:5) |
| **Engagement at scrape** | 6 likes · 0 comments |
| **Voice** | Team — “we”, an anonymised venue case study |
| **CTA** | DM “ROI” — **caption only**; the closing slide carries no ask |
| **Source note** | The same result appears eight months earlier on **#15**'s slide 5, as the message sent to the client: *“In 90 days, your ads brought in 59 Leads and 9 bookings for only $2,454. If your average booking is $10,000, that gives you a Return on Ad Spend (ROAS) of 3,667%!”* Whitney's reel on the same venue (voice knowledge base) says *“average value was about 10K each”*. So the **$90,000 is 9 bookings × a ~$10,000 average booking** — an estimate Whitney stands behind, not reported revenue — and the 3,667% is computed from it. This carousel states it as “$90,000 in booked revenue” |
| **Email sibling** | **None found.** Neither “$90,000” nor “3,667%” appears in any 2026 email. It went out in the run-up to the 23 Jun workshop with Emily Foster (“Building a Brand That Supports Premium Lead Generation”) and shares its foundation-first argument, but its CTA is DM “ROI”, not Register |

### Slides

**Slide 1** — *navy slide, serif headline, sans subline; WIA roundel logo, bottom centre*

> We generated $90,000 in booked revenue from ads for a venue client in the first 90 days.
>
> Let's break it down.

**Slide 2** — *navy text slide*

> Results like this don't happen by accident.
>
> They happen when **great ad strategy** is paired with *the right foundation*.

**Slide 3** — *navy text slide*

> Because ads can drive traffic.
>
> But your brand, website, systems, and follow-up determine what happens next.

**Slide 4** — *navy text slide, check-mark list*

> At Wedding Industry Ads, we focus on these five foundations for success with ads:
>
> ✓ Brand Positioning
> ✓ Landing Page Experience
> ✓ Lead Nurturing & Systems
> ✓ Conversion Tracking
> ✓ Mindset & Data-Driven Decisions

**Slide 5** — *navy text slide*

> When you get those foundations right…
>
> Ads aren't a gamble.
>
> They're an **amplifier**.

**Slide 6** — *navy text slide, bulleted results*

> For this venue owner, those foundations were already in place.
>
> So when we turned on ads, it was fuel to the fire.
>
> The results from ads:
>
> • 59 leads
> • 9 bookings
> • $90,000 in booked revenue
> • 3,667% Return On Ad Spend

**Slide 7** — *navy text slide, cross-mark list*

> When ads fall flat, it usually isn't because the platform doesn't work.
>
> It's because one of the foundations is weak.
>
> ✗ The message
> ✗ The website
> ✗ The follow-up
> ✗ The tracking
> ✗ The strategy

**Slide 8** — *navy text slide*

> That's why our goal isn't just to help you run ads.
>
> It's to help you build a business that's ready for visibility.
>
> Because when the right foundations are in place, ads become one of the fastest ways to accelerate growth.

**Slide 9** — *photo: the two founders seated together, text over the darkened left side; WIA roundel logo*

> Visibility is powerful.
>
> But visibility without the right foundation is wasted opportunity.
>
> That's why we focus on both.

### Caption

*Verbatim. “into seriously profitable lead gen system” is missing an article — that is how it was published.*

```text
The strongest ad campaigns aren't built on great ads alone. They're built on businesses that are ready for visibility.

That's exactly what happened with this venue owner.

Before we launched Google Ads, the business had the right foundation in place. Once we layered visibility on top of that foundation, the result was:

• 59 leads
• 9 bookings
• $90,000 in booked revenue
• 3,667% Return On Ad Spend

If you're tired of watching ad spend charges hit your credit card every month without seeing a clear ROI, we should talk.

DM us "ROI", and we'll help you identify the missing pieces that will turn your ads into seriously profitable lead gen system.
```

---

## 4 · “We ask this question to every new client.”

| | |
|---|---|
| **Published** | 10 Jun 2026 · `2026-06-10T22:11:04Z` |
| **Permalink** | <https://www.instagram.com/p/DZa_FogmSp6/> |
| **Shortcode** | `DZa_FogmSp6` |
| **Slides** | 10 · all static images · 1440×1800 (4:5) |
| **Engagement at scrape** | 3 likes · 0 comments |
| **Voice** | Team “we”, opened in first person — slide 1 reads “And I'm always surprised by the answer” |
| **CTA** | DM “ADS” |
| **Offers named** | Both, **on the slides** — **Ads Accelerators** (“we teach”) and **ELEVATE** (“we do it for you”), slide 8. The only carousel in the year whose slides name both tracks; #6 names both in its caption only |
| **Email sibling** — *confirmed in body text* | 10 Jun 2026 “The question we ask every new client” · Reply CTA · **same day** · carries the “surveyed your clients” question |

### Slides

**Slide 1** — *off-white slide, navy serif type, centred; WIA roundel logo, bottom centre*

> We ask this question to every new client.
>
> And I'm always surprised by the answer.

**Slide 2** — *off-white text slide*

> When we onboard a new advertising client for ELEVATE, our full-service advertising management program, we spend a lot of time getting to know their wedding business.
>
> We ask about their differentiators, services, and goals.
>
> And typically, they provide great information.
>
> They know their ideal clients well.

**Slide 3** — *off-white text slide*

> But then we ask a question that almost always catches people off guard:
>
> ***“Have you ever surveyed your clients to find out why they actually booked?”***

**Slide 4** — *off-white text slide*

> From there, the answer usually goes something like this:
>
> “*No, but we have lots of reviews.*”
>
> And that's where the disconnect happens.

**Slide 5** — *off-white text slide*

> **Reviews are great.**
> **But they aren't market research.**
>
> Wedding businesses are generally pretty good at asking for reviews.
>
> But very few are collecting feedback about the buying decision itself.

**Slide 6** — *off-white text slide*

> This matters because most wedding businesses are making marketing decisions based on assumptions.
>
> They think they know why clients hire them.
>
> They think they know what couples care most about.
>
> But they've never actually collected the data, which means they don't have the full picture.

**Slide 7** — *off-white text slide, two bulleted lists*

> When you survey clients shortly after they book, you uncover:
>
> • Objections you overcame
> • Their decision-making process
> • What criteria mattered most
> • The exact language they use
>
> And that becomes the foundation for:
>
> • Better messaging.
> • Better ad copy.
> • Better landing pages.
> • Better sales conversations.

**Slide 8** — *off-white text slide*

> This is exactly why we've built market research into our process.
>
> Inside our **Ads Accelerators**, we teach wedding pros how to uncover these insights and apply them to their advertising.
>
> Inside **ELEVATE**, *we do it for you*.
>
> We'll design and build a custom market research survey you can send to every new client with the click of a button.
>
> You'll receive the responses, and so will we.

**Slide 9** — *off-white text slide — the densest in the set; copy runs edge to edge*

> We use those insights to continuously refine your messaging, improve your advertising, and better understand what actually influences booking decisions.
>
> **This is how ads bring in bookings, not just leads.**
>
> And it's what makes our process different.
>
> Most agencies jump straight into targeting, creatives, and campaign setup.
>
> We go deeper.
> We start with the foundations.
>
> Because before you can create effective advertising, you need to understand the people you're trying to reach.

**Slide 10** — *photo: the two founders seated on a cream sofa, darkened, text over the upper half*

> The better you understand your buyers, the easier it becomes to create marketing that converts.
>
> If you're tired of guessing how to make ads work and want an advertising strategy built around real buyer behavior instead of assumptions,
>
> **DM us “ADS.”**

### Caption

*Verbatim.*

```text
One of the biggest differences between our approach and most advertising agencies isn't how we build campaigns.

It's where we start.

Most agencies start with targeting.
Creatives.
Campaign setup.
Optimization.

Of course, we do all of those things too.

But before any of that happens, we're focused on the foundations that make advertising successful in the first place.

Effective advertising doesn't start inside Ads Manager.

It starts long before a campaign is ever launched.

Messaging and positioning.
Landing pages.
Nurture funnels.
The customer journey.
Insights into what actually influences booking decisions.

Because when those foundations are weak, even great advertising struggles to perform.

That's why our process goes far beyond launching campaigns.

The goal isn't simply to generate leads.

The goal is to generate more of the right leads, improve conversion rates, and build a marketing system that becomes more effective over time.

That's the philosophy behind everything we do.

For wedding pros who want to learn how to think and execute like an advertising strategist, that's exactly why we created the Ads Accelerators.

The Ads Accelerators are designed for venues and wedding professionals who want to manage their own advertising but want expert guidance, proven frameworks, and a clear roadmap for what actually works.

For businesses that would rather have an experienced team manage the entire process, that's where ELEVATE comes in.

ELEVATE is our full-service advertising management program for wedding businesses that are ready to hand off the day-to-day execution and partner with a team that's committed to continuous improvement, strategic refinement, and long-term growth.

The end goal is the same: advertising that actually delivers results.

It's just different levels of support to get there.

Great advertising doesn't come from finding a magic tactic.

It comes from building a strong foundation, making informed decisions, and consistently refining what's working.

If that sounds like the kind of approach you've been looking for, DM us ADS, and let's talk.
```

---

## 5 · “Visibility isn't something you just earn. It's something you build.”

| | |
|---|---|
| **Published** | 4 Jun 2026 · `2026-06-04T12:16:32Z` |
| **Permalink** | <https://www.instagram.com/p/DZKeR0gDitC/> |
| **Shortcode** | `DZKeR0gDitC` |
| **Slides** | 7 · all static images · 1440×1800 (4:5) |
| **Engagement at scrape** | 5 likes · 0 comments |
| **Voice** | Team — “we're breaking down”; a teaching piece, no client story |
| **CTA** | **Link in bio → watch the free training** (*The Visibility Blueprint*) |
| **Email sibling** — *confirmed in body text* | 4 Jun 2026 “Visibility isn't just something you earn.” · Watch CTA · **same day** · names The Visibility Blueprint; its CTA resolves to `weddingindustryads.com/visibility-blueprint` in the offer map |

### Slides

**Slide 1** — *black-and-white photo: the two founders seated on a sofa; serif headline over the top; WIA roundel logo, bottom left*

> Visibility isn't something you just earn.
>
> It's something you *build*.

**Slide 2** — *off-white text slide*

> Many wedding pros believe visibility is the reward for doing great work.
>
> If you're talented enough…
> Consistent enough…
> Established enough…
>
> Couples will find you.

**Slide 3** — *off-white text slide*

> But the smartest wedding pros don't leave discovery to chance.
>
> They create intentional pathways for couples to find them.
>
> Again and again.

**Slide 4** — *off-white text slide*

> They show up in the right places at the right moments.
>
> When couples are actively searching.
>
> When they're comparing options.
>
> When they're getting closer and closer to deciding who they'll trust with one of the biggest days of their lives.

**Slide 5** — *off-white text slide*

> The savviest wedding business owners aren't replacing referrals, content, SEO, or networking.
>
> **They're amplifying them.**

**Slide 6** — *off-white text slide*

> They're building marketing systems that expand their reach beyond the people who already know they exist.
>
> Good marketing gets you discovered.
>
> Advertising increases the number of opportunities to be discovered.

**Slide 7** — *white slide, serif body, bold sans CTA; WIA roundel logo, bottom centre*

> Inside **The Visibility Blueprint**, we're breaking down how top wedding pros are using paid ads to amplify their marketing and grow with confidence.
>
> **Head to the link in our bio to watch the free training.**

### Caption

*Verbatim.*

```text
Many wedding pros think consistent visibility is something that happens after you've put in enough time.

And while great work absolutely matters, the wedding businesses thriving right now aren't sitting around waiting for visibility from dream fit clients to happen.

They're creating it.

They're building intentional pathways for couples to discover them.

Because growth-minded business owners understand that momentum is easier to create when more of the right people know you exist.

Good marketing gets you discovered.
Advertising increases that discoverability.

The venues and wedding pros we work with aren't replacing what's already working.
They're amplifying it.

Inside The Visibility Blueprint, we're breaking down how top wedding pros are using paid ads to amplify their marketing and grow with confidence.

You'll learn:
• What's actually driving growth right now in the wedding industry
• How paid ads fit into a full client journey
• What needs to be in place before ads can actually work

If you're ready to think more strategically about visibility and growth, you can watch the free training at the link in our bio.
```

---

## 6 · “The wedding pros kicking butt in 2026 are building predictable marketing systems…”

| | |
|---|---|
| **Published** | 14 May 2026 · `2026-05-14T14:32:36Z` |
| **Permalink** | <https://www.instagram.com/p/DYUpKBqDjc7/> |
| **Shortcode** | `DYUpKBqDjc7` |
| **Slides** | 10 · all static images · 1440×1800 (4:5) |
| **Engagement at scrape** | 3 likes · 0 comments |
| **Voice** | Team — “we”, “us”; a positioning piece, no client story |
| **CTA** | **Link in bio** — “Explore the ways to work with us” |
| **Offers named** | Both, **in the caption only** — Ads Accelerators and Elevate (“a couple spots may be opening soon”). The slides gesture at both (“hands-on support or a proven strategy you can implement with guidance”) without naming either |
| **Email sibling** — *confirmed in body text* | 13 May 2026 “Predictable marketing > viral marketing” · Link in Bio CTA · **one day earlier** · carries “kicking butt” and “points of entry” verbatim. Thematic follow-up: 20 May 2026 “The goal isn't going viral” (Reply) |

### Slides

**Slide 1** — *off-white slide, navy serif type, centred; WIA roundel logo, bottom centre*

> The wedding pros kicking butt in 2026 are building predictable marketing systems that consistently put them in front of the *right* couples.

**Slide 2** — *off-white text slide, arrow list*

> Sure, it's fun when:
>
> → a reel goes viral
> → a blog post pops off
> → you get a dream client referral
>
> But none of those create real stability in your business.

**Slide 3** — *off-white text slide*

> Because you don't have enough control to recreate those results consistently.
>
> That's exactly where paid ads change the game.

**Slide 4** — *off-white text slide*

> Not because you need to market harder.
>
> But because strategic ads give you more control over your points of entry.

**Slide 5** — *off-white text slide*

> **Google Ads** help you show up when high-intent couples are actively searching for a venue or vendor like you.
>
> **Meta Ads** help you stay visible after they leave your website.

**Slide 6** — *off-white text slide, arrow list*

> **The result?**
>
> → More consistent inquiries
> → Better quality leads
> → A marketing strategy that actually feels sustainable long-term

**Slide 7** — *off-white text slide, three italic quotes*

> Some of the most common things we hear from wedding pros before they work with us are:
>
> *“I don't want my ads to feel generic.”*
>
> *“I want to know the leads coming in are actually aligned.”*
>
> *“I just want to feel confident I'm making a smart investment.”*

**Slide 8** — *off-white text slide, arrow list*

> And honestly, those concerns make complete sense.
>
> There are too many agencies promising more leads without understanding:
>
> → positioning
> → buyer psychology
> → what actually turns inquiries into booked clients

**Slide 9** — *off-white text slide, arrow list*

> That's why our approach is built differently.
>
> We focus on:
>
> → profitable lead generation
> → long-term brand alignment
> → quality over vanity metrics
> → strategy backed by data
> → support and guidance every step of the way

**Slide 10** — *photo: the two founders seated on a cream sofa, darkened, text over it*

> Because running ads isn't the goal.
>
> Building a wedding business that feels stable, scalable, and profitable is.
>
> Whether you want hands-on support or a proven strategy you can implement with guidance, we have options designed for different stages of business growth.
>
> **Explore the ways to work with us at the LINK IN BIO.**

### Caption

*Verbatim.*

```text
The wedding pros growing the fastest right now aren’t necessarily the ones posting the most content.

They’re the ones who’ve built marketing systems that consistently bring the right people into their world.

Because while organic marketing absolutely matters, it’s hard to build a stable business when your inquiries depend entirely on:
→ referrals
→ Instagram reach
→ seasonal traffic spikes
→ or hoping the algorithm cooperates

That’s why paid ads have become such an important piece of sustainable growth for wedding pros.

Not as a replacement for a strong brand.
Not as a shortcut.
Not as a gimmicky tactic.

As an amplifier.
A way to create more consistency around lead generation and stay visible throughout the decision-making process.

And honestly, we know investing in ads can feel intimidating.

Most wedding pros don’t want:
✖️ generic ads
✖️ low-quality leads
✖️ cookie-cutter marketing
✖️ another strategy that overpromises and underdelivers

They want marketing that actually feels aligned with their brand and generates real ROI.

That’s exactly the work we do with our clients.

If you want to learn how to confidently run ads yourself (without wasting months DIYing in the dark) our Ads Accelerators are designed to give you the strategy, setup, and support to make ads actually work for your business.

If you’re looking for a high-touch, done-for-you partner to manage your ads, funnels, strategy, and optimization for you, Elevate was built for that. We only take a limited number of clients at a time, and a couple spots may be opening soon.

No matter which path makes the most sense for you, the goal is the same:

→ more aligned inquiries
→ more predictability
→ more confidence in your marketing
→ and a business that feels far less reactive

If you're ready to build a smarter, more sustainable approach to lead generation, you can explore both options at the link in bio.
```

---

## 7 · “You're not getting in front of the right couples consistently”

| | |
|---|---|
| **Published** | 11 May 2026 · `2026-05-11T23:22:51Z` |
| **Permalink** | <https://www.instagram.com/p/DYN3dEPGZjB/> |
| **Shortcode** | `DYN3dEPGZjB` |
| **Slides** | 7 · all static images · 1440×1800 (4:5) |
| **Engagement at scrape** | 3 likes · 0 comments |
| **Voice** | Team — “we help you figure out”; second person throughout the slides |
| **CTA** | **Link in bio** — slide: “Click ACCELERATE from our link in bio”; caption: “applications for our Ads Accelerators are open” |
| **Offers named** | Ads Accelerators only (caption). Slide 7 points at the ACCELERATE button, which the offer map resolves to `weddingindustryads.com/accelerate` |
| **Email sibling** — *confirmed in body text* | 5 May 2026 “A smarter way to get in front of the right clients” · no CTA in the campaign name · **six days earlier** · carries “roadblock”, “never find you” and “Google? Meta?” verbatim |

### Slides

**Slide 1** — *navy slide, serif type, centred; WIA roundel logo, bottom centre*

> You're not getting in front of the right couples consistently

*(No closing full stop on the slide — transcribed as published.)*

**Slide 2** — *navy text slide*

> It's not that you aren't getting inquiries.
>
> It's that you're not getting in front of enough of the right people, consistently.
>
> And that changes everything.

**Slide 3** — *navy text slide*

> Because once your visibility is consistent, your inquiries can be too.
>
> You have more control over when (and how) your inquiries come in.

**Slide 4** — *navy text slide*

> No matter how strong your work is…you can't book clients who never find you.
>
> That's the real roadblock.
>
> Not your talent. Not your offer.

**Slide 5** — *navy text slide*

> Just not enough consistent visibility in front of the right audience.
>
> That's why so many wedding pros start looking into ads.

**Slide 6** — *navy text slide*

> But then they get stuck:
>
> *Where do you even start?*
> *Google? Meta? Both?*

**Slide 7** — *photo: the two founders seated on a cream sofa, darkened, text over it*

> That's exactly what we help you figure out.
>
> **Click ACCELERATE from our link in bio**
>
> and we'll guide you to the smartest path forward.

### Caption

*Verbatim. “-top relying entirely on organic reach” is missing its leading “S”, and the first list uses bare asterisks as bullets — both as published.*

```text
Getting views from other vendors, past clients, friends, and random followers doesn’t necessarily translate into inquiries.

And it’s frustrating.

Because you can spend hours creating content, posting consistently, staying active on Instagram…and still feel like you’re not consistently getting in front of the couples who are actually ready to book.

And it’s not about your work or your brand not being good enough.

It’s that organic marketing alone was never designed to give you predictable growth.

Sure, organic social media can create visibility…but not necessarily the right visibility.

The same goes for organic search.

Just because your website exists doesn’t mean couples are finding it when they’re actively searching for vendors in your market.

Most wedding pros are relying on:
*Instagram algorithms they can’t control
*SEO timelines that take months (or years)
*and inconsistent word-of-mouth referrals

And we’re not saying those things aren’t important. Because they are.

But when you’ve been there, done that, and you’re still hitting a wall...

something has to change.

The wedding businesses growing most consistently are building strategies that intentionally put them in front of the right couples at the right time.

This is where paid traffic comes in.

Inside our Ads Accelerators, we help wedding pros learn how to use ads strategically so they can:

-Reach couples who are actively searching and ready to book
-top relying entirely on organic reach and referrals
-Generate more consistent, qualified inquiries
-Build a marketing system that supports long-term growth

And the transformation isn’t just more visibility.

It’s:
→ more qualified inquiries
→ more consistency
→ more confidence in where your next booking is coming from
→ and a wedding lead generation system you get to control

Because there comes a point when organic marketing and referrals alone just aren’t enough to support the level of growth you want.

If you’re ready to build a more scalable marketing strategy for your wedding business, applications for our Ads Accelerators are open.

Visit the link in our bio to learn more.
```

---

## 8 · “If your ads are generating leads… you have a conversion problem.”

| | |
|---|---|
| **Published** | 8 Apr 2026 · `2026-04-08T21:18:43Z` |
| **Permalink** | <https://www.instagram.com/p/DW4rBAlj746/> |
| **Shortcode** | `DW4rBAlj746` |
| **Slides** | 10 · all static images · 1440×1800 (4:5) |
| **Engagement at scrape** | 4 likes · 0 comments |
| **Voice** | Team — “we help our clients”; second person, instructional |
| **Format** | A numbered six-step framework (Steps 1–6 across slides 3–8) |
| **CTA** | DM “ADS” |
| **Offers named** | Ads Accelerators only — slides and caption |
| **Email sibling** — *confirmed in body text* | 31 Mar 2026 “If your ads aren't turning into bookings, read this” · no CTA in the campaign name · **eight days earlier** · opens on the same line (“If your ads are generating leads… but you're not booking consultations or tours”) and shares the caption's second paragraph almost word for word |

### Slides

**Slide 1** — *off-white slide, navy serif headline, letter-spaced sans below; WIA roundel logo, bottom centre*

> If your ads are generating leads…
> but you're not booking consultations or clients,
>
> you don't have a traffic problem.
>
> You have a ***conversion problem***.

**Slide 2** — *off-white text slide, arrow list*

> Here's what most people do next:
>
> → change targeting
> → increase budget
> → test new creatives
>
> But if leads are already coming in,
>
> **none of those fix the real issue.**

**Slide 3** — *off-white text slide*

> **Step 1: Look at your funnel like a system**
>
> Not just your ads.
>
> You need to understand:
>
> → Are people clicking?
> → Are they landing?
> → Are they inquiring?
> → Are they booking?
>
> Somewhere in that chain, things are breaking.

**Slide 4** — *off-white text slide*

> **Step 2: Identify the exact drop-off point**
>
> Examples:
>
> → High clicks, low inquiries = landing page issue
> → Inquiries, but no bookings = messaging/alignment issue
> → Low clicks = ad or targeting issue
>
> Your data will tell you this…if you're looking at it correctly.

**Slide 5** — *off-white text slide*

> **Step 3: Understand this (this is where most wedding pros get stuck)**
>
> Identifying the problem does NOT tell you how to fix it.
>
> Because there isn't always a direct, obvious answer.
>
> This is where ***marketing foundations + critical thinking*** comes in.

**Slide 6** — *off-white text slide*

> **Step 4: Revisit your messaging**
>
> Ask yourself:
>
> → Who am I actually attracting right now?
> → Are they aligned with my ideal couples?
> → What are they responding to (or not responding to)?
>
> Your leads will tell you a lot—if you pay attention.

**Slide 7** — *off-white text slide*

> **Step 5: Look at alignment across your funnel**
>
> Your ads, website, and content should all be saying the same thing.
>
> If your ad promises one experience, but your website delivers another,
>
> *conversion drops immediately*.

**Slide 8** — *off-white text slide*

> **Step 6: Adjust intentionally**
>
> This isn't about random testing.
>
> It's about making informed changes based on:
>
> → your data
> → your messaging
> → your sales conversations (or lack thereof) with potential clients
>
> **Small shifts here can completely change your results.**

**Slide 9** — *off-white text slide*

> This is why ads feel frustrating for so many wedding business owners.
>
> It's not just about “running ads.”
>
> It's about building and optimizing a full system that works together.

**Slide 10** — *photo: the two founders seated on a cream sofa, darkened, text over it*

> This is exactly what we help our clients build inside our **Ads Accelerators**
>
> → Google Ads (high intent traffic)
> → Meta Ads (visibility + retargeting)
> → Funnel + messaging optimization
>
> If you're ready for that level of strategy and support
> **DM us “ADS” to learn more.**

### Caption

*Verbatim.*

```text
If your ads are generating leads, but you’re not seeing those leads turn into booked clients, this is one of the most common (and most misunderstood) problems.

Because at a certain point, it’s not about getting more traffic.

It’s about understanding what’s happening after someone enters your funnel. And what actually needs to be adjusted to convert those inquiries into bookings.

The challenge is that most wedding pros can identify when something is off…
but don’t know what to do next.

Because they're not sure how to pinpoint the issue much less fix it.

It’s usually a combination of messaging, alignment, and how your ads, funnel, and offer are working together.

This is the level of work we focus on inside our Ads Accelerators - helping our clients not just generate leads, but build a system that consistently converts the right inquiries into booked clients.

If that’s what you’re working toward, DM us "ADS" to learn more.
```

---

## 9 · “GIVEAWAY — for wedding pros ready to run ads with confidence”

| | |
|---|---|
| **Published** | 5 Feb 2026 · `2026-02-05T12:42:33Z` |
| **Permalink** | <https://www.instagram.com/p/DUYGqO6jvcX/> |
| **Shortcode** | `DUYGqO6jvcX` |
| **Slides** | 10 · all static images · 1440×1800 (4:5) |
| **Engagement at scrape** | **86 likes · 23 comments** — the highest in the set by far, as a like-share-follow giveaway would be |
| **Voice** | Team — “we're gifting”, “our team of experts” |
| **Format** | A Valentine's Day giveaway: prize, fit, testimonials, entry mechanics, deadline |
| **CTA** | **Apply via the link in bio** — plus like, share, and follow @weddingindustryads and @leadlockpro. Applications closed 12 Feb, 11:59pm CST |
| **Offers named** | The **Ads Accelerator Bundle** — Google Search Accelerator, Meta Ads Accelerator, six months of guided support (office hours, VAULT access), done-for-you launches. Stated value **$3,694**. Also cross-promotes the sister brand **@leadlockpro** |
| **Email sibling** — *confirmed in body text* | 5 Feb 2026 “💝 Google & Meta Ads Giveaway 💝” · **same day** · carries the $3,694 value, the Accelerator Bundle and the Valentine's framing. Followed by 12 Feb “Last chance to enter!” and 20 Feb “Your giveaway application (and what's next)”, sent to the 24 applicants |

### Slides

**Slide 1** — *photo: the two founders, one standing behind the other in an armchair; oversized navy serif “GIVEAWAY” across the top; WIA roundel logo, bottom right*

> GIVEAWAY
>
> for wedding pros ready to run ads with confidence

**Slide 2** — *off-white slide; navy serif headline, then letter-spaced sans beside a vertical rule; “more intentionally.” reversed out of a navy bar*

> The wedding businesses growing most consistently right now aren't doing more marketing.
>
> They're doing it **more intentionally.**
>
> They already have:
> • Strong brands
> • Solid websites
> • Organic momentum
>
> Paid ads aren't replacing that foundation.
> They're **amplifying it.**

**Slide 3** — *off-white slide; bold centred heading; the two options set as numbered blue circles*

> **When you know you're ready to run ads for your business, there are typically two options:**
>
> ① **Hire someone to do it for you**
> ***OR***
> ② **Figure it out yourself**
>
> But here's the thing: Outsourcing what you don't understand is risky. And not all wedding pros who are ready for ads are also in a position to pay an ongoing monthly retainer.
>
> So they go it alone. But DIY will only take you so far.
>
> At a certain point, watching tutorials, testing things in isolation, and guessing your way forward stops being productive — even if your brand is solid and your business is strong.
>
> **That's the gap this giveaway is designed to support.**

**Slide 4** — *off-white slide; “ADS ACCELERATOR” reversed out of a navy bar over a serif “GIVEAWAY”*

> **ADS ACCELERATOR**
> **GIVEAWAY**
>
> We're gifting **one established wedding professional** our:
>
> **Ads Accelerator Bundle** including:
> • Google Search Accelerator
> • Meta Ads Accelerator
>
> **Six months of hands-on support**
> plus **done-for-you campaign launches**
>
> **Total value: $3,694**

**Slide 5** — *off-white slide; serif intro, then a two-column not / is comparison*

> This is for the marketing-savvy wedding pro who wants to go from DIYing their ads without direction to confidently running successful campaigns set up by our team of experts.
>
> ✗ This is **not**:
> × A magic bullet to save your business
> × A DIY course
> × Full-service ads management
>
> ✓ This ***is***:
> ✓ Strategic setup
> ✓ Expert guidance
> ✓ A hybrid approach. You provide the content. We launch the ads.
>
> Built for businesses who want to run ads with **clarity, structure, and confidence** — not guesswork
>
> So they can enhance what's already working in their existing marketing.

**Slide 6** — *off-white slide; serif heading; the two Accelerators reversed out of navy bars*

> Inside the Ads Accelerator Bundle:
>
> ✓ **Google Search Accelerator**
> Capture high-intent couples actively searching for your services
>
> ✓ **Meta Ads Accelerator**
> Create brand awareness, generate leads, and strategically retarget on Instagram + Facebook
>
> ✓ **6 Months of Guided Support**
> Office hours, VAULT access, and expert feedback
>
> **Done-for-you campaign launches.**
> **Done-with-you support.**

**Slide 7** — *off-white slide; serif heading and closing line*

> This giveaway is for wedding pros who:
>
> • Put real effort into their organic marketing
> • Want predictability beyond referrals
> • Believe ads are a *growth tool*, not a last resort
> • Want to understand their ads — not outsource blindly
>
> **If that's you, this was built with you in mind.**

**Slide 8** — *off-white slide; three unattributed client quotes in serif, each with two supporting bullets*

> What mastering ads for your business feels like:
>
> “Everything with ads is *finally starting to click* for me!”
> • Real-time answers in Office Hours
> • Valuable, no-fluff curriculum, templates & frameworks
>
> “I have learned that as much as I would love to hand everything over to someone else to manage and create ads I am *actually capable* of doing it myself!”
> • Confidence running ads independently
> • Less guessing, more informed decisions
>
> “Not only did they set up my ads but they *educated* me.”
> • Expert setup to skip straight to what works
> • Clear explanations of the how and why
>
> **This is what support looks like when it's built with intention, specifically for wedding businesses.**

**Slide 9** — *a navy band carrying a fourth client quote, then the entry steps with icons; two embedded screenshots of the @weddingindustryads and @leadlockpro profile headers, each with a Follow button*

> “My goal was to have an expert set up ads for our business (so it was finally done correctly instead of me DIY-ing it myself and hoping for good results). 100% worth it.”
>
> How to Enter to Win the Giveaway
>
> ♡ Like this post
> ➤ Share this post with a wedding pro who'd benefit
> 🔗 **Complete the short application (link in bio)**
> ⊕ Follow our accounts
>
> *[profile-header screenshots: @weddingindustryads and @leadlockpro]*
>
> **Applications close on Feb. 12 at 11:59pm CST.**
> **Winner accounced Feb. 13.**

*(“accounced” is on the slide — transcribed as published.)*

**Slide 10** — *off-white slide; letter-spaced sans, closing on a navy serif line*

> One wedding business.
>
> One intentional next step.
>
> One Valentine's gift designed to last longer than flowers.
>
> If you're ready to amplify your marketing through paid advertising, we'd love to see your application.
>
> Apply via the link in bio.

### Caption

*Verbatim. “help you bring you clarity” is as published.*

```text
The wedding businesses growing most consistently right now aren’t doing more marketing.

They’re doing it more intentionally.

They’ve already put in the work:
 • A strong brand
 • A solid website
 • Organic momentum

Paid ads aren’t meant to replace that foundation.
They’re meant to amplify it.

And yet this is where so many wedding pros get stuck.

You know ads could help you grow beyond relying on referrals.
You’re not ready (or willing) to hand everything off blindly.
DIY isn’t getting you where you want to go anymore.

That gap (between guessing and scaling) is exactly why we built the Ads Accelerator Bundle.

This Valentine’s Day, we’re gifting one established wedding professional a very special giveaway, including:
 • Google Search Accelerator
 • Meta Ads Accelerator
 • 6 months of guided support
 • Done-for-you campaign launches
 • Done-with-you education so you actually understand your ads

We’ve seen what works...and where most ads support breaks down.

This is not a magic bullet.
This is not a DIY course.
This is not full-service ads management.

This is strategic setup, expert guidance, and a hybrid approach built for wedding businesses who want clarity, structure, and confidence - not guesswork.

If you believe ads are a growth tool, not a shiny object,
and you want predictability without outsourcing blindly,
this was built with you in mind.

How to enter:
♥️ Like this post
↗️ Share it with a wedding pro who’d benefit
🔗 Complete the short application (link in bio)
👆 Follow our accounts @weddingindustryads and @leadlockpro

Not sure if the Ads Accelerators are the right fit for your business stage?
Feel free to DM us, and we’re happy to help you bring you clarity before applying.

⌛Applications close Feb 12 at 11:59pm CST.
🎉 Winner announced Feb 13.

One business.
One intentional next step.
One Valentine’s gift designed to last longer than flowers. 💝

Apply via the link in bio before applications close.

PS — This is our biggest giveaway ever, and it would mean the world to us if you help us spread the word. 💛
```

---

## 10 · “Being good isn't enough if couples can't find you.”

| | |
|---|---|
| **Published** | 14 Jan 2026 · `2026-01-14T19:36:21Z` |
| **Permalink** | <https://www.instagram.com/p/DTgMh1qj84d/> |
| **Shortcode** | `DTgMh1qj84d` |
| **Slides** | 8 · all static images · 1440×1800 (4:5) |
| **Engagement at scrape** | 5 likes · 0 comments |
| **Voice** | **Split** — the caption is first person, signed “XO, Whitney”; the slides are team voice (“We see this too often”, “DM us”) |
| **CTA** | DM “Google” |
| **Offers named** | None — a Google Ads argument with no program named |
| **Email siblings** — *confirmed in body text* | **Two emails, one per layer.** The **slides** follow 6 Jan 2026 “Being good isn't enough if couples can't find you” — its subject is the cover line, and it carries the page-one and SEO argument (**8 days earlier**). The **caption** follows 13 Jan 2026 “How couples actually use Google when booking wedding vendors” — it carries “wedding photographer Austin”, “protecting ego”, “resource allocation” and “desperation” word for word (**1 day earlier**) |

### Slides

**Slide 1** — *navy slide, serif headline, letter-spaced sans below; WIA roundel logo, bottom centre*

> Being good isn't enough if couples can't find you.
>
> You can be incredibly talented,
> highly experienced,
> deeply respected…
>
> …and still be ***overlooked.***

**Slide 2** — *navy text slide*

> In Google search results, it's not uncommon for less qualified vendors to appear above more experienced, more established businesses.
>
> Meanwhile, some of the most talented wedding pros **don't show up on page one at all.**
>
> *We see this too often.*

**Slide 3** — *navy text slide, bulleted list*

> **Google search results aren't ranked purely by talent or experience.**
>
> *They're influenced by signals like:*
>
> • relevance to the exact search term
> • location and proximity
> • website structure and clarity
> • authority signals Google can easily read
> • how well your content matches search intent
>
> Some of these can be improved with time and effort.
>
> Others move slowly —
> even when your work is exceptional.

**Slide 4** — *navy text slide*

> **Today's couples do research.**
>
> Many compare options, explore multiple sites, and look beyond a single result.
>
> **But where you appear first still matters.**
>
> The businesses that show up at the top gain immediate visibility —
> and with it, perceived credibility and authority.
>
> ***Being seen early shapes who gets evaluated more closely.***

**Slide 5** — *navy text slide*

> **SEO absolutely matters.**
>
> Strong SEO work does influence how and where you show up over time.
>
> But even great SEO is a longer play.
>
> It's shaped by competition, geography, authority signals, and timelines that aren't always fast or predictable.
>
> For established wedding businesses who have already invested in their work…
>
> the challenge is often ***control.***

**Slide 6** — *navy text slide*

> **Google Ads change the equation.**
>
> Instead of waiting to rise organically, you can *intentionally* show up for specific, high-intent searches.
>
> You choose the keywords.
> You shape the message couples see.
> You decide when visibility matters most.
>
> And when Google Ads are layered on top of a strong SEO foundation?
>
> Couples can see you *twice* in the same search experience.
>
> That repetition builds trust before they ever click.

**Slide 7** — *navy text slide*

> This isn't about gaming the system.
>
> And it's not about replacing everything else you're doing.
>
> It's about **being intentional in moments of high intent** —
> when couples are actively deciding who to contact.
>
> Search visibility influences
> who gets considered first,
> who gets compared more closely,
> and who gets contacted at all.

**Slide 8** — *photo: a single-founder portrait, navy velvet dress, cream armchair; text over the darkened left side; WIA roundel logo*

> If you're ready to take control of how your business shows up in Google searches…
>
> **DM us “Google.”**

### Caption

*Verbatim.*

```text
Something I’ve been hearing lately in conversations about Google goes something like this:

“I just don’t think my ideal couples are really searching ‘wedding photographer Austin’ or ‘wedding planner Nashville.’”

But they are.
Of course they are.

What’s interesting to me is what tends to sit beneath statements like this.

In almost every case, that belief shows up when someone already suspects their visibility in search isn’t strong. It’s less about actual buyer behavior, and more about protecting ego.

Because if your business isn’t showing up well in search, that’s uncomfortable to sit with.
It’s easier to believe the behavior doesn’t exist than to acknowledge the visibility gap.

Here’s the reality:
Couples do search. A lot. Especially early on. And when they do, they don’t arrive with insider knowledge about who’s “actually” the best in their market.

They don’t know whose work is stronger.
Whose process is more refined.
Or who has deeper experience behind the scenes.

All they know is what they see first.

The businesses that appear first gain immediate visibility (and with it, credibility) before talent, style, or experience ever enter the picture. Not because they’re better…but because they’re easier to find.

This is part of why advertising is so misunderstood in the wedding industry.

There’s a lingering belief that paying for visibility means something must not be working. In practice, we see the opposite. The businesses investing in search visibility tend to be the ones who understand their numbers, have healthy margins, and make intentional decisions about where they show up.

Paid visibility isn’t desperation.
It’s a resource allocation choice.

If you’re ready to take control of how your business shows up in Google search, DM “Google.”

XO,
Whitney
```

---

## 11 · “Today's Couples Don't Inquire After One Click.”

| | |
|---|---|
| **Published** | 31 Dec 2025 · `2025-12-31T16:20:57Z` |
| **Permalink** | <https://www.instagram.com/p/DS7zCbljuhy/> |
| **Shortcode** | `DS7zCbljuhy` |
| **Slides** | 10 · all static images · 1440×1800 (4:5) |
| **Engagement at scrape** | 3 likes · 0 comments |
| **Voice** | Team — “We can't tell you how many times someone has asked us” |
| **CTA** | DM “Meta Ads” |
| **Offers named** | None — a Meta Ads retargeting argument with no program named |
| **Email sibling** | **None found.** Nearest neighbour: 30 Dec 2025 “Where most wedding pros get stuck with Meta ads”, a day earlier — also Meta Ads, and it mentions retargeting website visitors, but it argues boosting-vs-real-advertising and shares none of this carousel's phrasing |

### Slides

**Slide 1** — *off-white slide; title-case serif headline, letter-spaced sans subhead, body below; WIA roundel logo, bottom centre*

> Today's Couples Don't Inquire After One Click.
>
> And That's Exactly Why Your Strategy Needs to Evolve.
>
> Couples are researching during lunch breaks, scrolling late at night, planning during stolen moments in between work and real life.
>
> They're comparing options.
>
> They're collecting ideas.
>
> They're building trust…slowly.
>
> And most of them aren't ready to reach out yet.

**Slide 2** — *off-white text slide*

> **Maybe they land on your website and feel a connection.**
>
> They like your style.
> Your words resonate.
> They're curious.
>
> But then a Slack ping comes in from their boss.
>
> Or they remember they have 10 minutes left to order DoorDash in time for dinner.
>
> Or their fiancé asks them to check something out on Zillow.
>
> *Distraction won.*
>
> And just like that…you were gone from view.

**Slide 3** — *off-white text slide*

> **Or maybe they make it to your Instagram.**
>
> Scroll your grid.
> Watch a few Reels.
> Think, “Ooh, this is good.”
>
> But they don't follow.
> Not because they don't want to,
> but because another tab calls their name.
>
> And they think, “I'll remember this and come back.”
>
> But with the amount of content they're seeing…and how unpredictable the algorithm is…
>
> remembering you isn't a guarantee.

**Slide 4** — *off-white text slide*

> **If couples don't see you again, they're not likely to inquire.**
>
> Not because you didn't make a good impression in the moment.
>
> But because you weren't visible enough times to be remembered.
>
> In a world where attention is short and content is endless,
>
> **conversion requires repetition.**

**Slide 5** — *off-white text slide*

> **This is where most venues and wedding pros are missing the mark.**
>
> They post.
> They optimize their website.
> They make a great first impression.
>
> And then…they wait.
>
> **Hoping couples will remember them and come back when they're ready.**
>
> **But memory isn't a reliable marketing strategy.**

**Slide 6** — *off-white text slide*

> **The most strategic wedding businesses don't just show up once.**
> They stay present — by design.
>
> Because they're not counting on one click to do all the work.
>
> They're showing up again and again — with intention, with consistency, with strategy.
>
> And they're doing it in a way that makes couples feel:
> *“I keep seeing them…and I really like what I'm seeing.”*

**Slide 7** — *off-white text slide — among the densest in the set*

> **Because repetition isn't annoying. It's reassuring.**
>
> Familiarity builds trust.
> Trust builds comfort.
> Comfort leads to action.
>
> But here's the problem:
> **The organic algorithm wasn't built for repetition.**
> It was built for engagement.
>
> It doesn't prioritize showing the same content (or the same brand) to the same user repeatedly - unless they engage over and over again.
>
> And even then, it's inconsistent.
>
> You can show up once (maybe twice) if you're lucky. After that, it's out of your hands.
>
> **UNLESS you have a system that puts you back in front of them - on purpose.**

**Slide 8** — *off-white text slide*

> **That's exactly what a smart paid strategy is built to do.**
>
> It allows you to retarget
> which means reconnecting with the people
> who already visited your site,
> engaged with your content,
> or viewed your profile.
>
> Not just once.
> But over and over again
> with messaging designed to build trust.
>
> No guessing.
> No hoping the algorithm does it for you.
>
> Just strategic follow-up
> with the exact people already showing interest.

**Slide 9** — *off-white text slide*

> **This is what Meta Ads make possible.**
>
> You can re-engage couples
> who visited your website,
> watched your Reels,
> or clicked through your profile…
> even if they never hit follow.
>
> You can build trust with real content:
> love stories, testimonials, behind-the-scenes moments…
> delivered with intention, not left to chance.
>
> No more waiting on the algorithm.
> No more hoping they circle back.
>
> **You get to stay in front of the couples who already showed interest - on repeat.**

**Slide 10** — *photo: the two founders, one perched on the arm of a cream armchair, one seated in it; text over the darkened right side; WIA roundel logo*

> You don't need more content.
>
> You need a system that follows up for you.
>
> If you want this for your wedding business,
> **DM “Meta Ads” and let's talk.**

### Caption

*Verbatim — including the trailing spaces on many lines and the leading space before “We can't tell you”.*

```text
You spend hours creating a Reel. 
Pick the perfect audio. 
Write a thoughtful caption. 
Post it at just the right time. 

It gets some traction.
A couple of vendor friends comment. 
And then? 

It disappears from the feed.
Just like that. 

The algorithm moves on. 
And so do the people who saw it (maybe even paused to watch all the way through)
but didn’t follow. 

You have no way of knowing who they were. 
No way to reach them again. 
No way to follow up. 

Unless you build a system that does. 

That’s what Meta Ads make possible. Helping you stay in front of the people who already showed interest - after the algorithm forgets about them.

 We can’t tell you how many times someone has asked us: “How do I make it so couples see my ad after visiting my website? I notice it happens to me all the time! I just don’t know how to do it myself.” 

The answer is retargeting. 

It’s how you stay in front of the right people (on purpose) long after the algorithm has moved on. 

And with Meta Ads, retargeting isn't just for big brands. 
It’s accessible, strategic, and built for the way people actually make decisions. 

If you want to make your content go farther, 
DM us “Meta Ads”
```

---

## 12 · “Why Wedding Ads Fail… (Even When You Have a Stellar Brand)”

| | |
|---|---|
| **Published** | 23 Nov 2025 · `2025-11-23T15:44:01Z` |
| **Permalink** | <https://www.instagram.com/p/DRZ4motDhML/> |
| **Shortcode** | `DRZ4motDhML` |
| **Slides** | 9 · all static images · 1080×1350 (4:5) |
| **Engagement at scrape** | 2 likes · 0 comments |
| **Collab** | Co-authored with **@whitneymhodges** — Whitney's personal account |
| **Voice** | Team in the copy (“our full-service ad management”); the closing slide is signed in script, “XO Whitney” |
| **Format** | A numbered five-failure listicle, in the **older template** — periwinkle serif headings, the `@WEDDINGINDUSTRYADS` handle at the top of every slide, and a “SHARE THIS / SAVE THIS” footer |
| **CTA** | **Link in bio, or DM** — for full-service ad management |
| **Offers named** | Full-service ad management (ELEVATE's category, not named as such), with scarcity: “only two spots left for new full-service clients before the end of the year” |
| **Email sibling** | **None found.** None of its distinctive lines (“optimized signals”, “living systems”, “media buying”, “the missing journey”, “the ecosystem did”) appears in any email from Nov 2025 to Feb 2026 |

### Slides

*Slides 2–8 carry the `@WEDDINGINDUSTRYADS` handle at the top and a “SHARE THIS” (paper-plane icon) / “SAVE THIS” (bookmark icon) footer; neither is repeated below.*

**Slide 1** — *photo: Whitney at a laptop beside white hydrangeas; white serif headline with a rule; letter-spaced caps subline; a periwinkle “SWIPE” tag, bottom right*

> @WEDDINGINDUSTRYADS
>
> **Why Wedding Ads Fail…** (Even When You Have a Stellar Brand)
>
> SAVE THIS.. ESPECIALLY IF YOUR ORGANIC MARKETING IS STRONG.
>
> [SWIPE]

*(“SAVE THIS..” has two full stops on the slide — transcribed as published.)*

**Slide 2** — *periwinkle serif heading, black sans body*

> This is for the wedding pros who've already done the foundational work:
>
> • You know your ideal couple.
> • Your website converts.
> • Your brand feels aligned.
> • You get DMs, saves, and shares from the right people.
>
> Couples find you through IG, referrals, and Google.
>
> SO IF YOUR BRAND IS RESONATING ALREADY…WHY AREN'T YOUR ADS DOING THE SAME?

**Slide 3**

> **Failure #1:**
> Great creative placed into the wrong campaign structure.
>
> Meta and Google don't reward great brands.
>
> They reward optimized signals.
>
> When your stunning creative is paired with the wrong objectives, delivery, or setup…
>
> it can't win — even if it should.

**Slide 4**

> **Failure #2:**
> No full-funnel pathway supporting the click.
>
> Your organic audience already knows you.
>
> Your paid audience doesn't.
> Most ads fail because there's no warm-up…
>
> no retargeting…
> no progression.
>
> Just a beautiful ad expecting instant conversion from a cold couple.
>
> It's not the brand. It's the missing journey.

**Slide 5**

> **Failure #3:**
> Budget is allocated in ways the platforms can't optimize.
>
> Strong brands still need ad budgets that match the strategy.
>
> **But most wedding pros either:**
> → put too much money in the wrong place
> → or not enough money in the right place
>
> The issue isn't your content.
>
> It's the distribution.

**Slide 6**

> **Failure #4:**
> No data interpretation or ongoing optimization.
>
> Good ads aren't “set it and forget it.”
>
> They're living systems.
>
> And even the best creative still needs:
> • pacing
> • pruning
> • audience refinement
> • testing
> • scaling decisions
> • behavior pattern reading
>
> This is media buying — a completely different skill than organic marketing.

**Slide 7**

> **Failure #5:**
> The backend can't support the front-end momentum.
>
> Amazing ads → clicks → excitement
>
> **But without:**
> • clean tracking
> • fast follow-up
> • a simple next step
> …momentum dies.
>
> THE ADS DIDN'T FAIL. THE ECOSYSTEM DID.

**Slide 8**

> **The Real Truth…**
>
> Wedding ads don't fail because you don't have a strong brand.
>
> They fail because ads require a strategy your organic marketing can't replicate on its own.
>
> **When your brand is already strong?**
>
> Ads aren't a fix — they're an amplifier.
>
> Only if the system behind them exists.

**Slide 9** — *split slide: the slide-1 photo across the top half with a script signature; serif body below; a navy “LINK IN BIO” button*

> @WEDDINGINDUSTRYADS
>
> *XO Whitney*
> CO-FOUNDERS OF WEDDING INDUSTRY ADS
>
> If your brand is solid and you want ads that amplify what's already *working* — this is exactly what our full-service ad management is built for.
>
> [LINK IN BIO]
>
> DM us or click the link in bio to see how we can help.

### Caption

*Verbatim, including the trailing space after the first sentence.*

```text
If you’ve ever wondered why your ads aren’t delivering results, even though everything else in your business is strong, you’re not alone. 

Many wedding pros with great brands and solid marketing still find that ads don’t match the momentum they already have.

That’s because ads operate on a completely different system than organic marketing.

Strong brands don’t automatically create strong ads.
Strong strategy does.

Most wedding pros struggle with ads because:
✨ Great creative gets dropped into the wrong campaign structure
✨ Cold audiences aren’t warmed up
✨ Budgets aren’t optimized
✨ There’s no ongoing analysis
✨ The backend can’t support the front-end momentum

None of this is a branding or content issue. Ads are simply a different discipline. When your brand is already strong, ads don’t fix problems, they amplify momentum — but only when the system behind them is built correctly.

💎If you’re ready for ads that finally match the strength of your brand, click the link in bio to see how we can help, or DM us and we’ll send over details about our full-service ad management.

👉PS: We currently have only two spots left for new full-service clients before the end of the year. Onboarding reopens in January.
```

---

## 13 · “How to Know Your Ads Are Actually Working (for Wedding Pros + Venues)”

| | |
|---|---|
| **Published** | 20 Nov 2025 · `2025-11-20T13:16:24Z` |
| **Permalink** | <https://www.instagram.com/p/DRR5U1zDn67/> |
| **Shortcode** | `DRR5U1zDn67` |
| **Slides** | 10 · all static images · 1080×1350 (4:5) |
| **Engagement at scrape** | 6 likes · 0 comments |
| **Voice** | Team on the slides (“the system we build”), signed in script “Daniela + Whitney”; the caption closes in first person — “DM me WEDDING ADS” |
| **Format** | **Older template** — a white text card over a darkened photo of the founders, the `@WEDDINGINDUSTRYADS` handle, and a “SWIPE” tag on every slide |
| **CTA** | DM “WEDDING ADS”, or the link in bio |
| **Offers named** | Full-service ads management, with the same scarcity line as #12: “only two spots left for new full-service clients between now and the end of the year” |
| **Email sibling** — *confirmed in body text* | 19 Nov 2025 “The moment you know your ads are working…” · **1 day earlier** · carries the client quote (“found us through an ad — and that it was really good”), “stopped their scroll”, “Wedding content is everywhere” and the two-spots line. The email tells it in first person (“I hear something from a client”); the carousel turns it into team voice |

### Slides

*Slides 2–9 are a white card over the same darkened photo, with the `@WEDDINGINDUSTRYADS` handle top left and a “SWIPE” tag bottom right; neither is repeated below.*

**Slide 1** — *split slide: navy serif headline with an italic tail and a periwinkle caps subline on off-white; below, a photo of the two founders at a table with hydrangeas and a laptop; periwinkle “SWIPE” tag*

> @WEDDINGINDUSTRYADS
>
> How to Know Your Ads Are Actually Working *(for Wedding Pros + Venues)*
>
> (SAVE THIS IF INQUIRIES MATTER TO YOU)
>
> [SWIPE]

**Slide 2**

> **You know your ads are working when a couple says:**
>
> *“We found you through an ad — and it was really good.”*
>
> This moment is powerful because couples are overwhelmed with choices. For your ad to stand out, multiple layers of strategy were working together.
>
> LET'S BREAK DOWN WHAT ACTUALLY HAPPENED.

**Slide 3**

> **You stopped the scroll — not with randomness, but with relevance.**
>
> Wedding content is everywhere. Couples are constantly being marketed to.

**Slide 4**

> **The only reason they pause for your ad is because:**
>
> • your imagery reflects the aesthetic they want
> • your message speaks to their priorities
> • your ad feels like it “gets” the kind of wedding they're planning
>
> For wedding pros, scroll-stopping creative isn't about being flashy.
> It's about instantly signaling:
>
> ***“We are the right fit for your vision.”***

**Slide 5**

> **You achieved visibility that builds trust — not noise.**
>
> Couples might see 100+ vendors during their planning journey. Most blend together.
>
> But when your brand gets real visibility, it means:
>
> • they can instantly recall your venue or service
> • they understand your style and capacity
> • you've separated yourself from the crowd in their mind

**Slide 6**

> Visibility that creates recognition leads to venue tours, florist inquiries, planner discovery calls, and more.
>
> In the wedding space, recognition = revenue.

**Slide 7**

> **Traffic Turned Into an Inquiry**
>
> They didn't just click — they took the next step wedding pros are desperate for: an inquiry.
>
> That means:
>
> • your pricing or offer felt aligned with their budget
> • your website experience didn't overwhelm or confuse
> • your CTA felt comfortable for where they are in planning (not too much, not too little)
>
> When traffic consistently becomes inquiries, your ads aren't just working — they're helping couples feel confident choosing you.

**Slide 8**

> **Brand Memory + Emotional Resonance**
>
> **They remembered your ad — and brought it up to you. This means:**
>
> • your brand voice felt warm, personal, and trustworthy
> • your visuals conveyed your unique experience (ambiance, service, expertise, aesthetic)
> • the couple felt emotionally connected to what you offer
>
> When your ads evoke the feeling your brand creates on someone's wedding day — you win before the sales conversation even starts.

**Slide 9**

> **Strategy Over Serendipity (Your Brand Deserves This)**
>
> This isn't luck — it's a strategic, intentional advertising ecosystem built for how couples plan weddings.
>
> When messaging, creative, audience targeting, and your offer all speak the same language?
>
> Your ads stop feeling like ads…and start feeling like “the vendor we've been searching for.”
>
> **That's exactly the system we build for venues and wedding pros.**

**Slide 10** — *white card over the photo: a circular portrait of the two founders, a script signature, and a periwinkle button*

> *Daniela + Whitney*
> @WEDDINGINDUSTRYADS
>
> If you're ready for ads that *bring in aligned leads* who already feel connected to your brand — let's talk.
>
> [DM “WEDDING ADS”]
>
> or tap the link in bio.

### Caption

*Verbatim — including the stray leading and trailing spaces, the asterisk in “you,*and”, and the caption ending on “or learn more” with nothing after it.*

```text
You know your ads are working when a couple says:

 “We actually found you through an ad — and it was really good.” 

That moment tells you so much more than “my ads are running.”

It tells you:
Your visuals matched the aesthetic they’re dreaming about
Your messaging reflected what actually matters to them
Your offer felt clear, aligned, and reachable
Your brand stood out in a sea of venues, planners, florists, and photographers

Most wedding pros think ads are only “working” when the dashboard shows good metrics.

 But the real magic is when a couple remembers your ad, brings it up to you,*and already feels like they know you before the consult even starts.

That’s the power of an aligned ad strategy built specifically for how couples plan, browse, and book.
If you’re a venue or wedding pro who’s ready for:

- more qualified inquiries
- couples who already feel connected to your brand
- ads that generate real momentum (not just clicks)
…our full-service ads management might be the perfect fit.

⭐️👉We have only two spots left for new full-service clients between now and the end of the year — and once they’re filled, onboarding won’t reopen until January.

💎DM me WEDDING ADS or learn more
```

---

## 14 · “Slay Google Ads — no tricks, just treats!”

| | |
|---|---|
| **Published** | 31 Oct 2025 · `2025-10-31T14:38:37Z` |
| **Permalink** | <https://www.instagram.com/p/DQei1cAjtbY/> |
| **Shortcode** | `DQei1cAjtbY` |
| **Slides** | 8 · **7 images + 1 video** (slide 2) · images 1080×1350 (4:5); the video's source is 360×450 |
| **Engagement at scrape** | 1 like · 0 comments |
| **Voice** | Team — “We love a good scary movie”, “our Live Info Session” |
| **Format** | A seasonal (Halloween) tips post in the **older template** — `@WEDDINGINDUSTRYADS` handle, “SWIPE” tags, a small arrow marking each heading |
| **CTA** | **Link in bio** — register for the **Live Info Session on 5 November** |
| **Offers named** | **Google Search Accelerator** (via the info session) |
| **Email sibling** — *confirmed in body text* | 31 Oct 2025 “Slay Google Ads 💀” · **same day** · carries “horror”, “treats” and the “destination URL” tip |

### Slides

*Every slide carries the `@WEDDINGINDUSTRYADS` handle at the top; slides 1–7 also carry a “SWIPE” tag. Neither is repeated below.*

**Slide 1** — *navy slide; a periwinkle rule; serif headline with “Slay” in italic; periwinkle caps subline*

> *Slay* Google Ads
>
> NO TRICKS, JUST TREATS!

**Slide 2** — ***video slide*** *— transcribed from its cover frame. Off-white template text above an embedded horror-film clip of a screaming woman, subtitled “Help me!!!”. The clip's motion is not captured; the template text is static.*

> We love a classic scary movie…
>
> But your Google Ads account? Not the place for a horror show.
>
> *[embedded film clip — subtitle: “Help me!!!”]*

**Slide 3** — *off-white slide; letter-spaced sans, closing on a periwinkle caps line*

> When it comes to your marketing, the only thing that should give you chills…is the excitement of new bookings rolling in.
>
> NOT BURNING THROUGH YOUR AD BUDGET

**Slide 4** — *off-white slide; serif heading, sans body*

> **Start with the right foundation**
>
> Your campaign is only as strong as your destination URL.
>
> Make sure your website or landing page is built to convert.

**Slide 5**

> **Have a seamless follow-up system**
>
> Inquiries are good—bookings are better.
>
> Responding within minutes can dramatically increase conversions.
>
> Automation helps, but personalization seals the deal.

**Slide 6**

> **Build your campaigns the right way**
>
> You don't need a massive budget—just a smart strategy.
>
> Keyword research and campaign structure matter more than you think.

**Slide 7**

> **Know what to look for**
>
> Data is your lifeline.
>
> Learn to read it, respond to it, and refine your ads for performance.

**Slide 8** — *photo: the two founders at a café table, darkened; serif headline with “Kill it” in italic; a periwinkle “LINK IN BIO” button*

> *Kill it* with Google Ads with a trusted guide by your side.
>
> You're in for a treat.
> Join our Live Info Session November 5th to learn about the Google Search Accelerator.
>
> [LINK IN BIO]

### Caption

*Verbatim.*

```text
🎃 SLAY Google Ads — no tricks, just treats!

We love a good scary movie… but your Google Ads account? 👻

Not the place for a horror show.

This Halloween, make sure the only thing giving you chills is the excitement of new bookings — not wasted ad spend.

✨ Here’s how to make your ads killer (in the best way):
✅ Build a strong foundation with a high-converting landing page
✅ Respond to inquiries fast — personalization seals the deal
✅ Set up smart campaigns with the right keywords and structure
✅ Track your data like your business depends on it (because it does)

Ready to kill it with Google Ads — with a trusted guide by your side?

Join our Live Info Session on November 5th to learn all about the Google Search Accelerator.

🔗 Link in bio — you’re in for a treat!
```

---

## 15 · “Ready to Show Up First When Couples Search on Google?”

| | |
|---|---|
| **Published** | 30 Oct 2025 · `2025-10-30T15:27:57Z` |
| **Permalink** | <https://www.instagram.com/p/DQcDr8nDofx/> |
| **Shortcode** | `DQcDr8nDofx` |
| **Slides** | 7 · all static images · 1080×1350 (4:5) |
| **Engagement at scrape** | 3 likes · 0 comments |
| **Voice** | Team — “we'll build and launch your search campaign” |
| **Format** | A product launch (“INTRODUCING…”) in the **older template**, with a testimonial-screenshot collage and a device mock-up |
| **CTA** | **Link in bio** — join the Google Search Accelerator — or DM |
| **Offers named** | **Google Search Accelerator** — done-for-you (“yet collaborative”) setup, curriculum, office hours |
| **Source note** | Slide 5 carries the client message behind **#3**'s figures: 59 leads and 9 bookings on **$2,454** of spend, with the 3,667% ROAS worked out on a **$10,000 average booking** — framed there as a condition (“If your average booking is…”), and described by Whitney in a later reel as “about 10K each”. #3, eight months later, states the resulting $90,000 as booked revenue |
| **Email sibling** — *confirmed in body text* | 30 Oct 2025 “Double your visibility on Google” · **same day** · the only email to call the Accelerator a “proven Google Ads launch experience” with support “every step of the way” — the caption's exact phrasing. The launch emails themselves went out 28 Oct (“Google Search Accelerator drops today” / “…is here”) |

### Slides

*Every slide carries the `@WEDDINGINDUSTRYADS` handle at the top; slides 1–6 also carry a “SWIPE” tag. Neither is repeated below.*

**Slide 1** — *split slide: navy serif headline with “First” in italic and a caps subline on off-white; below, a laptop and white hydrangeas, with the launch line set over the photo*

> Ready to Show Up *First* When Couples Search on Google?
>
> BE THE VENUE OR WEDDING PRO THEY FIND FIRST, NOT LAST!
>
> **INTRODUCING…**
> THE GOOGLE SEARCH ACCELERATOR

**Slide 2** — *off-white slide; serif heading with an italic aside; a small arrow at the heading*

> **A Done-For-You *(yet collaborative)* Google Ads Setup**
>
> With your input, we'll build and launch your search campaign. No guesswork, no time or money wasted.

**Slide 3**

> **Be Seen Where It Matters Most**
>
> GOOGLE SEARCH = HIGH-INTENT COUPLES ACTIVELY PLANNING.
>
> ✓ Show up on page 1 for your top keywords.
> ✓ Drive quality traffic and real inquiries.

**Slide 4**

> **Ongoing Support**
>
> ✓ Curriculum to deepen your understanding
> ✓ Get your questions answered as they come up
> ✓ Get expert eyes on your account when needed
> ✓ Meet with our team during group office hours

**Slide 5** — *navy slide; serif heading over a collage of cropped client-message screenshots, one with the business name redacted by a bar; one snippet is cut off at the slide edge*

> **Here's what you can expect…**
>
> “In 90 days, your ads brought in 59 Leads and 9 bookings for only $2,454. If your average booking is $10,000, that gives you a Return on Ad Spend (ROAS) of 3,667%! 🥳 Congratulations!”
>
> “The leads have been LIT! I'm not kidding!”
>
> “Yes!!! I'm so thrilled with how it's gone, you all gave fabulous recommendations! I couldn't have done it without you. 🙏”
>
> “I've been thrilled with the results so far”
>
> “Working with your team has been nothing short of exceptional.”
>
> “It was great working with you for the launch of your Google Ads campaign for [redacted]. In only 2 weeks, your ads have brought you 9 new Leads at $34 per lead and a 12% CTR 🎉”
>
> “I'm super excited about the growth we're already seeing!”
>
> “Thank you, again, for all of your wisdom and support.”
>
> “I'm so excited at where we're headed and I couldn't have done it without you all. THANK YOU!”

**Slide 6** — *off-white slide; a device mock-up — a phone showing “Book Your Google Search Accelerator Discovery Call” (30 mins) beside a laptop showing the Accelerator landing page, headed “Your Couples Are Searching On Google. Let's Make Sure They Find You”*

> **Built for venues and wedding pros** who want to actually understand Google Ads.
>
> Or train a team member to run them with confidence 🚀

**Slide 7** — *photo: the two founders standing together, darkened; serif headline; a periwinkle “LINK IN BIO” button*

> **Show Up First.**
> **Get Found Fast.**
> **Book More Couples.**
>
> Let's put your business in front of the right couples this engagement season.
>
> [LINK IN BIO]

### Caption

*Verbatim.*

```text
Ready to Show Up First When Couples Search on Google?

✨ It’s time to be the venue or wedding pro couples find first — not last.

The Google Search Accelerator is a proven Google Ads launch experience designed to help you:

✅ Build and launch your first campaign (no guesswork, no wasted budget)
✅ Be seen on page 1 by high-intent couples actively planning
✅ Drive real traffic, real inquiries, and real bookings
✅ Get ongoing expert support and guidance every step of the way

Show up first. Get found fast. Book more couples.
This engagement season, let’s put your business exactly where your dream clients are searching. 💍

👉 Learn more and join the Google Search Accelerator today — link in bio. Or let’s chat for more details — DM us and we’ll help you see if it’s the right fit. 💬
```

---

## 16 · “Our Google Ads VIP Day is getting a serious glow-up”

| | |
|---|---|
| **Published** | 24 Oct 2025 · `2025-10-24T12:00:00Z` — on the hour to the second, so almost certainly scheduled |
| **Permalink** | <https://www.instagram.com/p/DQMPIGCjgzF/> |
| **Shortcode** | `DQMPIGCjgzF` |
| **Slides** | 7 · **6 images + 1 video** (slide 6) · images 1080×1440 — **3:4**, one of only two carousels in the year (#16, #17) not cut at 4:5; the video's cover frame is 720×960 |
| **Engagement at scrape** | 7 likes · 0 comments |
| **Voice** | Team — “our most popular offer”, “we build your entire campaign” |
| **Format** | A launch teaser in the **older template** — navy over a chandelier-crystal texture, the `@WEDDINGINDUSTRYADS` handle, a “SWIPE” tag, caps-heavy body copy |
| **CTA** | **Save this post + follow along** for the launch — no link, no DM |
| **Offers named** | The **Google Ads VIP Day** (one-day done-for-you setup), announced as evolving into the **Google Search Accelerator**, “launching next week” |
| **Email sibling** — *confirmed in body text* | 24 Oct 2025 “Google Ads Glow Up 👀” · **same day** · carries the glow-up framing, the VIP Day and the “next week” launch |

### Slides

*Every slide carries the `@WEDDINGINDUSTRYADS` handle at the top; slides 1–6 also carry a “SWIPE” tag. Neither is repeated below.*

**Slide 1** — *navy over a chandelier-crystal texture; serif headline with the offer name in italic; letter-spaced caps subline*

> Our *Google Ads VIP Day* is getting a serious glow-up
>
> OUR MOST POPULAR OFFER IS **EVOLVING**. HERE'S WHAT YOU NEED TO KNOW.

**Slide 2**

> **You know couples are searching on Google…**
>
> AND WITH ENGAGEMENT SEASON AROUND THE CORNER, THAT TRAFFIC IS ABOUT TO EXPLODE.
>
> **BUT FIGURING OUT *HOW* TO RUN PROFITABLE GOOGLE ADS?**
>
> TOTALLY OVERWHELMING.

**Slide 3**

> **That's why we created our Google Ads VIP Day —**
>
> A ONE-DAY, DONE-FOR-YOU SERVICE WHERE WE BUILD YOUR ENTIRE CAMPAIGN, WRITE YOUR COPY, INSTALL TRACKING, AND LAUNCH IT ALL FOR YOU.
>
> **FAST. FOCUSED. NO GUESSWORK.**

**Slide 4**

> **And NOW?**
>
> THIS OFFER IS GETTING A MAJOR **UPGRADE**.
>
> **MORE STRATEGY. MORE SUPPORT. MORE CLARITY** AROUND WHAT'S WORKING (AND HOW TO SCALE IT).

**Slide 5** — *adds a cropped email-inbox screenshot, circled by hand, beside a small serif aside*

> **Launching next week:**
>
> **THE GOOGLE SEARCH ACCELERATOR**
>
> SAME EXPERT-LED CAMPAIGN BUILD — NOW WITH FOUNDATIONAL CURRICULUM AND ONGOING COACHING TO HELP YOU GROW.
>
> *[inbox screenshot: “Google Search Accelerator — Thank you so much!!!! I can't wait for this…”, with a PDF attached, “WIA | Google Se…”]*
>
> *Doors aren't yet open…but the excitement is building!*

**Slide 6** — ***video slide*** *— transcribed from its cover frame: an embedded film clip of a before-and-after makeover reveal above caps text. The clip's motion is not captured.*

> *[embedded film clip — a before-and-after makeover reveal]*
>
> BECAUSE WE LOVE A GOOD TRANSFORMATION.
>
> AND THIS ONE'S BUILT TO CONVERT.

**Slide 7** — *no “SWIPE” tag; save and share icons beneath the ask*

> DETAILS DROP NEXT WEEK — AND YOU WON'T WANT TO MISS THIS.
>
> **Ready to finally master Google Ads?**
>
> SAVE THIS POST + FOLLOW ALONG FOR THE LAUNCH

### Caption

*Verbatim.*

```text
Our Google Ads VIP Day offer is getting a major glow-up. ✨

Swipe through all the slides for the full details!

If you’ve been thinking about finally setting up your Google Ads (or revamping what’s already running)… this is your moment.

Engagement season is around the corner, search traffic is about to skyrocket, and your ideal couples are already typing exactly what you offer into Google.
But figuring out how to actually run profitable campaigns? That’s where most pros get stuck.

That’s why we created our Google Ads VIP Day — our done-for-you, one-day setup experience.

And now…it’s evolving.

The Google Search Accelerator launches next week🚀
→ Same expert-led setup
→ More strategy + ongoing support
→ Clear data insights so you can actually scale

Stay tuned for all the details soon…
Save this post so you don’t miss out!
```

---

## 17 · “What Wedding Pros Need to Know About Google Ads Broad Match”

| | |
|---|---|
| **Published** | 23 Oct 2025 · `2025-10-23T13:11:01Z` |
| **Permalink** | <https://www.instagram.com/p/DQJyc63jiFH/> |
| **Shortcode** | `DQJyc63jiFH` |
| **Slides** | 8 · all static images · 1080×1440 (3:4) |
| **Engagement at scrape** | 9 likes · 0 comments |
| **Voice** | Team — “We've got you covered”, “our Google Search Accelerator” |
| **Format** | A pure teaching explainer — definition, three behaviours with worked examples, the benefit — then a launch teaser. **Older template**: a black-and-white photo of the founders darkened behind every text slide, the `@WEDDINGINDUSTRYADS` handle, a “SWIPE” tag |
| **CTA** | **Stay tuned** for the November launch — no link, no DM. Slide 7 says “save your seat now” without saying how |
| **Offers named** | **Google Search Accelerator**, “launching this November”, “spots are limited” |
| **Email sibling** | **None found.** “Broad match” appears in no email in the corpus. The 23 Oct 2025 send, “Keep your Meta accounts protected”, is unrelated |

### Slides

*Every slide carries the `@WEDDINGINDUSTRYADS` handle at the top; slides 1–7 also carry a “SWIPE” tag. Neither is repeated below.*

**Slide 1** — *split slide: a black-and-white photo of the two founders laughing on stone steps; below, a serif headline with “Broad Match” in italic and a periwinkle brush-stroke underline*

> What Wedding Pros Need to Know About Google Ads *Broad Match*

**Slide 2** — *the same photo, darkened, behind white serif heading and letter-spaced sans body*

> **What is Broad Match?**
>
> Broad Match is a type of keyword match option within a Google Ads Search Campaign that allows your ads to show for search queries that are related to your keywords, even if they don't exactly match the specific terms you're bidding on.
>
> What does that mean for wedding professionals?

**Slide 3**

> **Related Searches**
>
> Your ads can appear for searches that are similar or relevant to your keyword.
>
> For example, if your broad match keyword is “wedding photography”, your ad might show up for queries like “best wedding photos”, “photography for weddings”, or “wedding photo ideas”.

**Slide 4**

> **Synonyms and Variants**
>
> Your ad may show up for varying terms, increasing your ad's reach.
>
> For example, a broad match for “bridal gown” could trigger searches for “wedding dresses” or “gowns for brides”.

**Slide 5**

> **Misspellings and Close Variants**
>
> Google can match your ads to queries that include misspellings, singular/plural forms, or other close variants of your keywords.
>
> **For example,** the broad match term “wedding coordinator” could trigger ads for searches like “wedding planners” or “bridal coordinator”.

**Slide 6**

> **The Benefits Include**
>
> Broad Match does exactly that — it broadens your ad's reach. Instead of managing these particulars and bidding on variations, Broad Match handles it for you.
>
> MORE AUTOMATION.
> LESS MANAGEMENT.

**Slide 7** — *closes on a serif line*

> **For Wedding Pros…**
>
> If you're ready to dive deeper and truly understand how Google Ads work — our **Google Search Accelerator** was created just for wedding professionals like you.
>
> You'll learn how to read your data, run ads strategically, and attract the right couples.
>
> ⚡We're launching the program this November, and spots are limited — save your seat now before it fills up!

**Slide 8** — *split slide: the photo across the top with a white serif line; periwinkle caps and serif below*

> **Want to learn more?**
>
> THE GOOGLE SEARCH ACCELERATOR IS COMING SOON…
>
> Designed just for *venues & wedding pros.*
> Stay tuned for the official launch **this November**!

### Caption

*Verbatim.*

```text
What is Google Broad Match and how can you utilize it as a wedding professional running ads?! 🌿✨

👉We’ve got you covered in this slide!

Broad Match helps your ads reach couples searching in different ways — even if they don’t use your exact keywords. It’s one of the most powerful tools for expanding your visibility and attracting high-quality leads when used strategically. 💍

If you’d like to dive deeper and truly understand how to run your Google Ads the right way — our Google Search Accelerator was created just for wedding professionals.
You’ll learn how to read your data, structure campaigns that convert, and stop wasting money on random clicks.

The Google Search Accelerator is coming soon…🔥

Designed just for venues and wedding pros.
👉Stay tuned for the official launch this November!
```

---

## 18 · “Still Waiting for Engagement Season to Save Your Bookings?”

| | |
|---|---|
| **Published** | 1 Oct 2025 · `2025-10-01T11:45:33Z` |
| **Permalink** | <https://www.instagram.com/p/DPQ_LnMjou2/> |
| **Shortcode** | `DPQ_LnMjou2` |
| **Slides** | 8 · all static images · 1080×1350 (4:5) |
| **Engagement at scrape** | 7 likes · 1 comment |
| **Collab** | Co-authored with **@whitneymhodges** |
| **Voice** | Team — “our clients are proving you don't have to” |
| **Format** | Three anonymised client examples, then the seasonal argument. **Older template** — a darkened photo of Whitney at a laptop behind every text slide, the `@WEDDINGINDUSTRYADS` handle, a “SWIPE” tag |
| **CTA** | DM «»GOOGLE ADS»» or the link in bio — the closing slide says only “CHECK THE CAPTION FOR DETAILS” |
| **Offers named** | **Full-Service Google Ads Management** promo — “just 3 spots”, no onboarding fee, no long-term commitment, preferred pricing. Slide 3 also names the **Google Ads VIP Day** |
| **Claim note** | Slide 4 gives one planner both results — “drinking from a firehose” *and* doubled revenue. The caption splits them across two pros (“A planner doubled her revenue…” / “Another pro said… ‘drinking from a firehose’”) |
| **Email sibling** — *confirmed in body text* | 1 Oct 2025 “It's time for a reality check” · **same day** · carries “firehose”, the 183 leads, “3 spots” and “no onboarding fee” |

### Slides

*Every slide carries the `@WEDDINGINDUSTRYADS` handle at the top; slides 1–7 also carry a “SWIPE” tag. Neither is repeated below.*

**Slide 1** — *split slide: serif headline with “Engagement” in italic and a caps subline on off-white; below, a photo of Whitney at a laptop beside white hydrangeas*

> Still Waiting for *Engagement* Season to Save Your Bookings?
>
> IT'S TIME FOR A WAKE UP CALL

**Slide 2** — *the same photo, darkened, behind white serif and caps text*

> **You've probably heard (or said):**
>
> • “SUMMER IS JUST SLOW.”
> • “THINGS WILL PICK UP AFTER THE HOLIDAYS.”
>
> But here's the thing… that doesn't have to be your reality.

**Slide 3**

> **Client Example #1: The Venue**
>
> One of our venue clients booked a Google Ads VIP Day back in the spring. *She told us:*
>
> “INQUIRIES ARE UP. TOURS ARE UP. BOOKINGS ARE UP.”
>
> Her summer used to feel slow. **This year?** Completely different. And she knows it's because of ads.

**Slide 4**

> **Client Example #2: The Planner**
>
> A wedding planner we work with said:
>
> “I'M GETTING SO MANY LEADS IT FEELS LIKE DRINKING FROM A FIREHOSE.”
>
> She's heard vendors in her area complain about low inquiries. But she *doubled* her revenue—thanks to strategic ads.

**Slide 5** — *lavender check marks*

> **Client Example #3: Hard Data**
>
> Another venue client?
>
> ✓ **183 LEADS** IN A SINGLE MONTH
> ✓ THAT'S 85 **MORE LEADS** THAN THE SAME TIME LAST YEAR.
>
> **And the best part?**
>
> They didn't increase their ad spend.
> But they are seeing better results year after year.

**Slide 6**

> **What do all these pros have in common?**
>
> ✓ THEY STOPPED WAITING AROUND FOR A SEASON TO BOOST SALES.
> ✓ THEY BUILT LEAD GEN SYSTEMS THAT WORK ALL DAY, EVERY DAY.

**Slide 7** — *centred serif, two lavender brush-stroke markers*

> Google Ads are the fastest way to get in front of couples who are *actively searching* for your services.
>
> And from November to February, that search volume skyrockets.

**Slide 8** — *centred serif with “start” in italic; a hand-drawn arrow pointing down to the caption*

> This is your sign to stop waiting—and *start* building momentum!
>
> CHECK THE CAPTION FOR DETAILS.

### Caption

*Verbatim — including the «»GOOGLE ADS»» punctuation.*

```text
Q4 is here—and while many wedding pros wait for engagement season to boost their sales, our clients are proving you don’t have to.

✨ A planner doubled her revenue this summer while others complained about slow bookings.
✨ A venue hit 183 leads in a single month—without increasing ad spend.
✨ Another pro said the inquiries and bookings feel like “drinking from a firehose.”

The difference? They’re not waiting around. They’ve built ad systems that run 24/7 and consistently bring in dream clients.

👉 Google Ads put you in front of couples actively searching for venues and planners—and search volume is about to skyrocket from November to February.

We’re opening just 3 spots for Full-Service Google Ads Management under a special promo:
✅ No onboarding fee
✅ No long-term commitment
✅ Preferred pricing

DM us «»GOOGLE ADS»» or tap the link in bio to get the details.
```

---

## Method

How this was built, so it can be checked or re-run.

1. **Finding the carousels.** The profile grid was scrolled until it reached
   31 July 2025 — two months past the cutoff — enumerating 96 posts. Each tile's
   type was read from its icon's `aria-label` (`Carousel`, `Clip` for a reel, or
   `Pinned post icon`) and its date from the tile image's alt text.
2. **Closing the gaps.** Five tiles inside the window carried no type label: the
   pinned post (5 Jan 2026) and four unlabelled tiles (9 Jan 2026; 2 Nov, 27 Oct
   and 15 Oct 2025). Each was opened and its type read from the post's own data —
   all five are single images (`media_type` 1), so none is a carousel. After #18
   (1 Oct 2025), the next carousel on the grid is 16 Sep 2025, outside the window.
3. **Date, caption and counts.** Read from each post page's embedded data
   (`taken_at`, `carousel_media_count`, `caption.text`, `like_count`,
   `comment_count`, `coauthor_producers`) rather than from the rendered page. The
   captions here are exactly what Instagram holds, typos included.
4. **Slide text.** Each slide was opened on its own at full resolution —
   1080×1350 (#1, #2, #12–#15, #18), 1440×1800 (#3–#11) or 1080×1440 (#16, #17) —
   and transcribed by eye, one slide at a time. Instagram holds no text for these
   slides at all: `accessibility_caption` is empty on all 159.
5. **Video slides.** Two of the 159 are video: #14 slide 2 and #16 slide 6. Both
   are the slide template with an embedded film clip. They are transcribed from
   their cover frames; the clip's motion is not captured, and the post data
   carries no duration or audio flag for either.
6. **Email siblings.** Each carousel's most distinctive phrases were searched
   for across the emails in `corpus/emails/` (126 sends, April 2024 → September
   2026). A sibling is listed as *confirmed* only where those phrases appear in
   the email's body. The two reel siblings (#1, #2) are marked *probable* — the
   reels were not opened, and the match rests on the caption text shown on the
   grid.

## Exclusions and limits

- **The pinned post** (`DTI2bdrjsX8`, 5 Jan 2026) is WIA's introduction post —
  *“Hi! We're Daniela & Whitney, co-founders of Wedding Industry Ads…”* — and a
  single image, so it is excluded.
- **Reels and single-image posts are out of scope.** This ledger is carousels
  only.
- **Stories** are not on the grid and are not captured.
- **Engagement counts** are as of 23 Sep 2026 and will drift.
- **“The founders”** in the slide descriptions means **Daniela and Whitney**,
  co-founders — per WIA's own pinned post and #13's signed slide. The
  16 September call transcript spells the name “Danielle”; that is a
  transcription error, and `Content_Atelier.md` §4 repeats it.

### Transcription conventions

- Line wraps forced by the slide width are reflowed into paragraphs;
  deliberate breaks — stacked lines, lists — are kept.
- Bold and italic are kept wherever the slide sets them.
- Quote marks are normalised to curly quotes and ellipses to “…” in slide text.
  At this resolution the images do not reliably distinguish straight from curly
  quotes, or three full stops from an ellipsis character. The words themselves,
  and the slides' own capitalisation and typos, are exact.
- Screenshots and mock-ups embedded in slides — #9's profile headers, #15's
  device mock-up, #16's inbox — are described in brackets with their key text,
  not transcribed in full. The two embedded film clips are described
  generically.
- Repeated template furniture — the handle, “SWIPE” tags, “SHARE THIS / SAVE
  THIS” footers — is noted once per carousel rather than on every slide.
- Captions are not normalised in any way.
- **Canva is still the exact-text source.** All 159 slides were read one by one,
  but Canva holds the copy as it was typed. See `corpus/canva-descript-access.md`.
