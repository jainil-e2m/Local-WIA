---
campaign_name: "Marketing Email 1.26.26"
subject: "You’re invited: the 2026 Planners Workshop (it’s free this year!!)"
cta_from_name: ""
sent: 2026-01-26
recipients: 64
delivered: 63
failed: 0
sending_domain: ""
last_edited_by: "Whitney Hodges"
tracking: on
schedule_id: "69776b9cb002d858ff2e3fab"
template_id: "689c8291ba28b0d2b23050f0"
raw_html: "raw/69776b9cb002d858ff2e3fab.html"
cta_urls:
  - https://margauxfraise.mykajabi.com/a/2148205566/DAEHLMAk
# Only Whitney or Giselle can fill these two.
source_session: ""
instagram_sibling: ""
---

## Body

Hi {{contact.first_name}},
I’m excited to share something a little different — and honestly, something I’m really proud to be part of.
I’ll be speaking live this Wednesday at the 2026 Planners Workshop. This virtual summit officially kicks off today! (It’s happening January 26–28, 2026) And for the first time ever, the event is completely free for wedding planners.
I’ve attended Wedding Summit Series events before, and I know how practical and planner-focused they are.
What stood out to me (and why I’m excited to be involved) is how focused this workshop is on the actual skills planners are being asked to step into right now.
This year’s workshop centers around:
Wedding Design (in a way that makes sense for planners)
Full Wedding Weekends and multi-day celebrations
Marketing that helps planners clearly communicate their value (that's where I come in!)
I’ll be teaching a live session on:
How Marketing-Savvy Wedding Planners Are Rising to the Top of Their Markets (and Beyond!) with Strategic Digital Advertising
In my session, we’ll cover:
Why Google and Meta Ads are the most effective marketing tools planners aren’t fully leveraging yet
How to turn your best content into ads that convert (without starting from scratch)
The campaign types and budgets that generate real ROI
What goes into a full-funnel ad strategy (and how to know when you're ready for it)
If you’re a planner who wants to feel more confident in your role, book better-aligned clients, and head into 2026 with clearer direction, this workshop is absolutely worth your time.
👉You can grab your free ticket here
I’d love to see you there, and I can’t wait to share what I’m teaching.
Whitney
P.S. There is an optional All Access Pass if you want lifetime access and bonuses, but the free ticket alone still gives you access to the core education.
Copyright © {{right_now.year}} {{location.name}}, All rights reserved.
Our mailing address is:
{{location.email}}
Want to change how you receive these emails?
You can unsubscribe from this list .
