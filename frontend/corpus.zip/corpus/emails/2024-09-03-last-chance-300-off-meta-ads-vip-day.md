---
campaign_name: "Labor Day Flash Sale: Meta VIP Day 2"
subject: "LAST CHANCE!!! $300 Off Meta Ads VIP Day"
cta_from_name: ""
sent: 2024-09-03
recipients: 324
delivered: 
failed: 4
sending_domain: ""
last_edited_by: "Whitney Hodges"
tracking: on
schedule_id: "66ce5c45cac7731ac4a6573c"
template_id: ""
raw_html: "raw/66ce5c45cac7731ac4a6573c.html"
cta_urls:
  - https://www.weddingindustryads.com/vip-day
# Only Whitney or Giselle can fill these two.
source_session: ""
instagram_sibling: ""
---

## Body

This offer ends tonight!
View this email in browser
Last day to save $300!
Hi {{contact.first_name}},
Hope you are having a fabulous day!! We wanted to send you a quick reminder about our exclusive flash sale on our Meta Ads VIP Day, happening now!
Let me tell you a quick story about Maryam, a Bridal Boutique Owner based in Fort Lauderdale. Despite her stunning portfolio, Maryam found herself competing in a crowded market, with her message getting lost in the noise.
Before signing up for a VIP Day with us, Maryam was struggling with visibility in her marketing. Even though she was posting every day on social media, her efforts were not turning into any inquiries for her business… She is a new business owner with a brand new website and brand new Instagram account, and she wanted to make her organic efforts go further, faster.
After her Meta Ads VIP Day, she started seeing results almost immediately!! More clicks to her website, more engagement from qualified leads on her content, and best of all - more consultations on her calendar!
You have less than 24 hours left to take advantage of this incredible offer and receive $300 off your first month of ad spend when you apply for your Meta Ads VIP Day.
Don't let this opportunity slip away. Elevate your advertising game and get your best content in front of your most engaged followers with our expert guidance and support.
Apply Now and Save $300
We're here to help you every step of the way. Don't hesitate to reach out if you have any questions or need assistance with your application.
Thank you for considering working with us. We can't wait to see you succeed!
Best,
Whitney + Daniela
Wedding Industry Ads Team
