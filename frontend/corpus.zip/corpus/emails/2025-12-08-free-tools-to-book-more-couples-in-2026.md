---
campaign_name: "Marketing Email 12.8.25 (11 am) "
subject: "🎯 Free tools to book more couples in 2026"
cta_from_name: ""
sent: 2025-12-08
recipients: 679
delivered: 674
failed: 2
sending_domain: ""
last_edited_by: "Yulia Burris"
tracking: on
schedule_id: "6936e261d19e66bb0d6e6ad0"
template_id: "689c8291ba28b0d2b23050f0"
raw_html: "raw/6936e261d19e66bb0d6e6ad0.html"
cta_urls:
  - https://www.byemilyjane.com/gift-exchange
  - https://www.byemilyjane.com/gift-exchange/#optin
# Only Whitney or Giselle can fill these two.
source_session: ""
instagram_sibling: ""
---

## Body

Wedding Pro Gift Exchange is here!
Hi {{contact.first_name}},
Have you heard about the Wedding Pro Gift Exchange ?
We are so thrilled to be a part of this limited-time collaboration where 30+ top wedding industry experts (us included!) are gifting premium business resources to help you finish 2025 strong and set the stage for a successful 2026.
This bundle is packed with guides, trainings, templates, and workshops. And they’re all designed specifically for wedding professionals.
It’s completely free but for much longer! The Wedding Pro Gift Exchange officially ends on Tuesday, December 9th at 11:59 PM CT.
Inside you’ll find game-changing gifts from some of our industry favorites like:
✨ 1 Hour SEO from Sara Does SEO
✨ Ghosted Lead Booking Wizard from Heidi Thompson
✨ The Stand-Out Brand Launch Checklist from Emily Foster Creative ✨ Irresistible Selling Starter Pack from Maria Bayer
… and so much more!
🎁 Our gift to you?
The Ultimate Advertising Power Couple Masterclass: our signature training that walks you through how to use Google Ads + Meta Ads together to consistently get high-quality leads on autopilot. If you’re tired of algorithms changing and SEO delays, this is your roadmap to showing up right now in front of couples who are ready to book.
💡 Whether you’re brand new to ads or ready to scale, this training will help you:
✔ Attract better-fit clients
✔ Maximize your marketing ROI
✔ Ditch the guesswork with paid advertising
👉 Here's how to grab your free bundle:
Visit the Gift Exchange page
Enter your email
Browse and download the resources that align with your 2026 business goals
No pressure to grab everything. Just take what’s helpful and leave the rest.
Ready to invest a little time now to make next year your best one yet?
[Access the Wedding Pro Gift Exchange Here]
We hope this gives you clarity, confidence, and a clear path forward.
Wishing you the most wonderful time of the year,
Daniela & Whitney
Wedding Industry Ads
P.S. Know another wedding pro who would love this? Forward them this email and spread the joy!
Copyright © {{right_now.year}} {{location.name}}, All rights reserved.
Our mailing address is:
{{location.email}}
Want to change how you receive these emails?
You can unsubscribe from this list .
