---
campaign_name: "Flash Sale: Meta VIP Day 1"
subject: "[TIME SENSITIVE] Flash Sale: Elevate Your Advertising Game with $300 Off!"
cta_from_name: ""
sent: 2024-04-08
recipients: 291
delivered: 
failed: 153
sending_domain: ""
last_edited_by: ""
tracking: off
schedule_id: "6613f9239d8932c6f97fe173"
template_id: ""
raw_html: "raw/6613f9239d8932c6f97fe173.html"
cta_urls:
  - https://www.weddingindustryads.com/vip-day
# Only Whitney or Giselle can fill these two.
source_session: ""
instagram_sibling: ""
---

## Body

View this email in browser
Start from scratch
Dear {{contact.first_name}},
Exciting news! For the next 48 hours, we're offering an exclusive flash sale on our Meta Ads VIP Day – the ultimate opportunity to supercharge your advertising efforts and maximize your results.
Apply for your Meta Ads VIP Day within the next 48 hours, and you'll receive $300 off (basically, your first month of ad spend is on us!) This is your chance to work closely with our expert team and harness the power of Meta Ads to drive more leads and bookings for your wedding business.
We KNOW how powerful this could be for your business - that’s why it’s our mission to make ads more accessible to service pros in the wedding industry.
Don't miss out on this limited-time offer. Apply now and take the first step towards unlocking the full potential of your advertising strategy.
Apply Now and Save $300!
We'll see you on the path to advertising success!
Warm regards,
Whitney + Daniela
Wedding Industry Ads Team
