---
campaign_name: "Marketing Email 2.5.26"
subject: "💝 Google & Meta Ads Giveaway 💝"
cta_from_name: ""
sent: 2026-02-05
recipients: 796
delivered: 796
failed: 0
sending_domain: ""
last_edited_by: "Whitney Hodges"
tracking: on
schedule_id: "69810be9047450599d4615ec"
template_id: "689c8291ba28b0d2b23050f0"
raw_html: "raw/69810be9047450599d4615ec.html"
cta_urls:
  - https://weddingindustryads.com/giveaway
# Only Whitney or Giselle can fill these two.
source_session: ""
instagram_sibling: ""
---

## Body

A Valentine’s Gift for Wedding Pros ready to scale what's already working
Hi {{contact.first_name}},
The wedding businesses growing most consistently right now aren’t doing more marketing. They’re doing it more intentionally.
They already have strong brands, solid websites, and organic momentum. Paid ads aren’t replacing that foundation. They’re amplifying it.
Last week, we sponsored and spoke live at the Wedding Summit Series 2026 Planners Workshop. It reinforced what we see every day. The businesses pulling ahead are the ones treating digital advertising as a strategic growth tool, not a last-ditch fix.
The level of collaboration and openness we saw left us feeling inspired. With Valentine’s Day around the corner, we want to share the love in our own way.
💝 Wedding Industry Ads Giveaway
We’re giving one wedding professional the opportunity to win our Ads Accelerator Bundle at no cost, which includes:
✨ Google Search Accelerator
✨ Meta Ads Accelerator
This bundle includes six months of hands-on advertising support, including done-for-you campaign launches. It's a $3,694 value, free for one deserving winner. It’s designed for business owners who already have a strong foundation and are ready to scale with structure, clarity, and intention.
At Wedding Industry Ads, we don’t believe in ads as a magic bullet. Our Accelerator programs are built for established wedding professionals who understand that marketing fundamentals matter and want paid ads to multiply what’s already working, not compensate for what isn’t.
How to Enter
1️⃣ Visit @weddingindustryads on Instagram
2️⃣ Follow the account if you aren’t already
3️⃣ Find our pinned Giveaway post
4️⃣ Like the post
5️⃣ Share it with a fellow wedding professional who could benefit
6️⃣ Complete the short application linked in our bio
7️⃣ Follow our sister brand @leadlockpro on Instagram
Dates You Need to Know
🗓 Giveaway Closes: February 12 at 11:59pm CST
🎉Giveaway Winner Announced: February 13
If you’ve already put real care into your brand and marketing and are ready to amplify that work more predictably, we’d love to see your application.
XO,
Daniela & Whitney
Co-Founders, Wedding Industry Ads
Copyright © {{right_now.year}} {{location.name}}, All rights reserved.
Our mailing address is:
{{location.email}}
Want to change how you receive these emails?
You can unsubscribe from this list .
