---
campaign_name: "WSS Tech & AI Email #7"
subject: "Join us live today at 2PM CST"
cta_from_name: ""
sent: 2026-04-22
recipients: 789
delivered: 777
failed: 10
sending_domain: ""
last_edited_by: "LeadLock Team"
tracking: on
schedule_id: "69d68367e54535d5e6fe88f0"
template_id: "694b2a04c384d6817120dc5d"
raw_html: "raw/69d68367e54535d5e6fe88f0.html"
cta_urls:
  - https://margauxfraise.mykajabi.com/wss-tech-ai-registration?ref=https%3A%2F%2Fmargauxfraise.mykajabi.com%2Fa%2F2148253283%2FDAEHLMAk
# Only Whitney or Giselle can fill these two.
source_session: ""
instagram_sibling: ""
---

## Body

Hey {{contact.first_name}},
We wanted to personally let you know that our session for the Wedding Summit Series: Tech & AI Edition is happening live today at 2PM CST.
We’re teaching Speed to Lead: How automations give your leads the instant gratification they crave, bring more structure to your business, and lighten your mental load.
We created this because we keep seeing the same thing across wedding businesses:
Leads are coming in… but there’s no consistent system for what happens next.
Responses are delayed.
Follow-ups fall through.
And strong inquiries go cold simply because there isn’t a clear process in place.
In this session, we’ll cover:
The exact automated email and text workflows that turn inquiries into booked tours and consultations
Where most inquiry funnels break down (and the opportunity almost no one is leveraging right now)
How to balance automation with personalization so your brand still feels like you
Our goal is simple: to help you respond faster, create a stronger first impression, and convert more of the leads you already have…so you can book more weddings without adding more to your plate.
If you haven’t registered yet, you can still grab a free ticket here
We’d love for you to join us live,
— Daniela & Whitney
Copyright © {{right_now.year}} {{location.name}}, All rights reserved.
Our mailing address is:
{{location.email}}
Want to change how you receive these emails?
You can unsubscribe from this list .
