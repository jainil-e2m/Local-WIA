---
campaign_name: "WPCEO - Invite to Power Couple Demo"
subject: "hey there, ceo!"
cta_from_name: ""
sent: 2024-06-17
recipients: 66
delivered: 
failed: 0
sending_domain: ""
last_edited_by: ""
tracking: on
schedule_id: "6670accdb3842d63867a06e0"
template_id: ""
raw_html: "raw/6670accdb3842d63867a06e0.html"
cta_urls:
  - https://weddingindustryads.com/power-couple
# Only Whitney or Giselle can fill these two.
source_session: ""
instagram_sibling: ""
---

## Body

Greetings from Wedding Industry Ads
View this email in browser
Hi {{contact.first_name}},
Take us back to the Wedding Pro CEO Summit!!! We're counting down the days until next year! ⏰
In case you're burning to learn more about paid ads for your biz, we wanted to reach out to you...
We're spilling the tea! Our clients who are achieving the best lead generation results for their wedding businesses are all doing this same thing…
They are running evergreen ads on both Google AND Meta!
Each of these ad platforms are powerful in their own right, but when we create a holistic strategy that leverages what Google & Meta can do together, the results are dynamite 💥
It's why we lovingly refer to Google Ads + Meta Ads as The Ultimate Advertising Power Couple 🥰
And for a limited time, we have a special training that takes you behind the scenes and explains just how these two platforms work together.
If you want to take a peek at how you can leverage this dynamic ad strategy in your own wedding business, this training is a must watch.
You’ll learn how to harness the unique strengths of both platforms to reach more couples, generate more leads, and grow your business like never before!
Simply click the link and unlock instant access to the video. We can't wait to show you what's possible.
> The Ultimate Advertising Power Couple for Wedding Business Owners <
See you inside!
Whitney + Daniela
Wedding Industry Ads Team
