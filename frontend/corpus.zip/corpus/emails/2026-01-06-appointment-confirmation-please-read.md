---
campaign_name: "Ads Consultation - Email #1 (Confirmation Email)"
subject: "Appointment Confirmation! Please read :)"
cta_from_name: ""
sent: 2026-01-06
recipients: 1
delivered: 1
failed: 0
sending_domain: ""
last_edited_by: "Whitney Hodges"
tracking: off
schedule_id: "695d74faea10b165b24a5e2a"
template_id: "695d311da8d9cc4411315823"
raw_html: "raw/695d74faea10b165b24a5e2a.html"
cta_urls:
  - https://www.weddingindustryads.com/zoom
# Only Whitney or Giselle can fill these two.
source_session: ""
instagram_sibling: ""
---

## Body

Hi {{contact.first_name}},
Yes! Your call is booked! You’ve just made such a great decision for your business.
Here's a quick recap of your booking:
Date & Time: {{appointment.only_start_date}} {{appointment.only_start_time}}
Location: Whitney's Zoom Room
I’m going to send over a few emails before we meet, and I want to start by sharing a little preview of what can feel like when you start working with us. We'd love for your business to be our next success story!
Here's what some of our clients have said:
📣 “Since we started running ads on Google & Meta, our lead volume has increased by 75%!” – Parker R.
📣 “Hi! Wanted to give you feedback that since doing Meta Ads in addition to website leads we are getting more DM inquiries than ever before!” – Nina A.
📣 "I am very happy with all your work and I feel happy and grateful I found you” – Adriana D.
I’m excited to dive into the details with you when we meet. Looking forward to connecting soon!
Best,
Whitney
Need to make a change?
Click here to reschedule.
Click here to cancel.
Copyright {{right_now.year}} {{location.name}}, All rights reserved.
Our mailing address is:
{{location.email}}
Want to change how you receive these emails?
You can unsubscribe from this list .
