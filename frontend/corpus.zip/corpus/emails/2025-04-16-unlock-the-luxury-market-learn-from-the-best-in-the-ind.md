---
campaign_name: "Announcement:  Your Invitation to the Luxury Market"
subject: "Unlock the Luxury Market—Learn from the Best in the Industry"
cta_from_name: ""
sent: 2025-04-16
recipients: 591
delivered: 584
failed: 1
sending_domain: ""
last_edited_by: "Whitney Hodges"
tracking: on
schedule_id: "680000827d77f93213220e22"
template_id: ""
raw_html: "raw/680000827d77f93213220e22.html"
cta_urls:
  - https://margauxfraise.mykajabi.com/wss-lux-registration?ref=https%3A%2F%2Fmargauxfraise.mykajabi.com%2Fa%2F2148086627%2FDAEHLMAk
# Only Whitney or Giselle can fill these two.
source_session: ""
instagram_sibling: ""
---

## Body

Hey {{contact.first_name}},
You’ve seen the glamorous editorials. You’ve admired the stunning high-budget weddings. Maybe you’ve even wondered how those pros really landed those dream clients. Now, it’s time to get the answers.
The Wedding Summit Series: Luxury Edition is your exclusive backstage pass to learning exactly what it takes to book luxury weddings—straight from the industry’s top experts, planners, and networking powerhouses.
💡 Wondering where to even start in luxury? We’ve got you. 💡 Not sure how to market to high-end clients? That’s covered. 💡 Want to know the networking strategies that actually work? This is where you’ll find them.
👉Join us here
For over four years, the Wedding Summit Series has brought together the best minds in the wedding industry, helping over 15,000 wedding pros elevate their businesses. With over 300 expert speakers featured across past events, this series has built a reputation for delivering real, actionable education—not just inspiration.
This Luxury Edition continues that legacy, bringing you 25+ luxury wedding experts who will share exclusive insights on branding, pricing, and attracting high-end clients. Plus, we’re featuring candid interviews with real luxury wedding professionals—giving you an inside look at how they broke into the high-end market and what it really takes to thrive there.
And here’s the best part—your ticket is 100% free. No gatekeeping. No fluff. Just real strategies that can help you start elevating your brand, refining your pricing, and booking high-end weddings that actually align with your expertise.
📅 Mark your calendar: April 21-24, 2025
📍 Where: Online (attend from anywhere!)
💰 Cost: FREE when you register today
Grab your free ticket now
Can’t wait to see you there!
Whitney & Daniela
