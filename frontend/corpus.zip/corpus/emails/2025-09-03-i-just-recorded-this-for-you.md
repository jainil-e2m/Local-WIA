---
campaign_name: "Weekly Marketing Email 9.3.25"
subject: " I just recorded this for you…"
cta_from_name: ""
sent: 2025-09-03
recipients: 661
delivered: 652
failed: 2
sending_domain: ""
last_edited_by: "Whitney Hodges"
tracking: on
schedule_id: "68b75eb1f7069b68e4b57dbf"
template_id: "689c8291ba28b0d2b23050f0"
raw_html: "raw/68b75eb1f7069b68e4b57dbf.html"
cta_urls: []
# Only Whitney or Giselle can fill these two.
source_session: ""
instagram_sibling: ""
---

## Body

{{contact.first_name}}, if you’ve ever wondered what kind of real results wedding planners are seeing with paid ads, I just finished putting together two case studies that break this down.
We’re talking actual lead counts and year over year analytics, so you can see true before & afters of how Google Ads & Meta Ads can transform your business.
I recorded a quick 10 minute video to walk you through it. No fluff or fancy jargon, just real receipts.
Want me to send it to you? Just hit reply and say “send it over!” and I’ll send the video straight to your inbox.
Talk soon,
Whitney
Co-Founder, Wedding Industry Ads
Copyright © {{right_now.year}} {{location.name}}, All rights reserved.
Our mailing address is:
{{location.email}}
Want to change how you receive these emails?
You can unsubscribe from this list .
