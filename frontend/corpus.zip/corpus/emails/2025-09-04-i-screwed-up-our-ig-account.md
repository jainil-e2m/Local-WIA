---
campaign_name: "Weekly Marketing Email 9.4.25"
subject: "I screwed up our IG account"
cta_from_name: ""
sent: 2025-09-04
recipients: 655
delivered: 649
failed: 0
sending_domain: ""
last_edited_by: "Whitney Hodges"
tracking: on
schedule_id: "68b8d84ad441163a1f5d234e"
template_id: "689c8291ba28b0d2b23050f0"
raw_html: "raw/68b8d84ad441163a1f5d234e.html"
cta_urls: []
# Only Whitney or Giselle can fill these two.
source_session: ""
instagram_sibling: ""
---

## Body

Here’s how I fixed it
{{contact.first_name}}, I have a confession to make.
This spring, we went dark on Instagram. And it was totally my fault. I didn’t prioritize like I should have.
No posts for nearly two months 😱
We were in deep: onboarding new clients, training new team members, and building like crazy behind the scenes.
It was a season of growth for sure, but our own marketing? It completely stalled.
In the moment, I told myself it was ok. We were doing the work that mattered.
But when the dust settled, I felt it. Hard.
→ Organic reach? Almost nonexistent.
→ New leads? So slow.
→ Brand visibility? Basically gone.
We were spending hours on quality content that wasn’t getting seen — and honestly, I was tired of feeling like we were shouting into the void.
So I did what we’ve helped dozens of wedding pros do.
I turned on ads.
And in just a month, here’s what happened:
✨ 121 new followers
✨ 75 inquiries
✨ 13 booked calls
And suddenly our organic IG stats are better than ever before, too.
All from a modest ad budget.
It worked because we paired the right strategy with the right message, not because we threw a bunch of money at it.
If you’ve been putting off your own marketing because client work always comes first (trust me, I get it), this is your gentle nudge: turning on ads doesn’t have to be overwhelming. It can actually be the thing that gives you breathing room again.
We just released a new video walkthrough of recent client case studies showing you exactly what kind of results are possible when you get strategic with ads.
Want access?
Just hit reply to this email, type “I want the video”, and hit send.
Then I’ll shoot the 10-minute video your way. Easy peasy!
Here’s to a new season of visibility, growth, and dream bookings.
xo,
Whitney
Co-Founder, Wedding Industry Ads
Copyright © {{right_now.year}} {{location.name}}, All rights reserved.
Our mailing address is:
{{location.email}}
Want to change how you receive these emails?
You can unsubscribe from this list .
