---
campaign_name: "Marketing Email 11.28.25 (11 am) |  Black Friday"
subject: "Black Friday: Launch Your Google Search Campaign for Less"
cta_from_name: ""
sent: 2025-11-28
recipients: 667
delivered: 666
failed: 0
sending_domain: ""
last_edited_by: "Yulia Burris"
tracking: on
schedule_id: "6929c5fd0e35822c16147c69"
template_id: "689c8291ba28b0d2b23050f0"
raw_html: "raw/6929c5fd0e35822c16147c69.html"
cta_urls:
  - https://weddingindustryads.com/google-search-accelerator
  - https://portal.weddingindustryads.com/public/form/view/68f91878a9a586fcdf4c0566?_gl=1*1uji4l3*_gcl_au*MTcxNTQ4Mjc0LjE3NjE5MzQyMjA
# Only Whitney or Giselle can fill these two.
source_session: ""
instagram_sibling: ""
---

## Body

$200 Off Our Most Popular Google Ads Setup
Hi {{contact.first_name}},
Happy Black Friday!
Today, you can lock in $200 off the Google Search Accelerator , our expert-built Google Ads campaign designed to put you in front of couples actively searching for your services.
This is not a course or a template. It’s a fully done-for-you service that gives you:
🔹 A custom Google Search campaign tailored to your business
🔹 Keyword + copy strategy to attract high-intent leads
🔹 Tracking setup + clear conversion goals
🔹 A live walkthrough of your campaign
🔹 3 months of expert support after launch
Some of our recent clients saw inquiries within days of launching. One even heard from a dream couple in a new market they’d been trying to serve.
Whether you want to launch now or in early 2026, you can purchase today and schedule later.
👉 Get $200 Off the Google Search Accelerator
This Black Friday offer runs through December 1, but why wait? If you're ready for a smarter way to generate inquiries, now's your moment.
Daniela & Whitney
Wedding Industry Ads
P.S. Paid search is where couples go when they’re ready to book. We’ll help you meet them there with strategy, precision, and zero guesswork.
Copyright © {{right_now.year}} {{location.name}}, All rights reserved.
Our mailing address is:
{{location.email}}
Want to change how you receive these emails?
You can unsubscribe from this list .
