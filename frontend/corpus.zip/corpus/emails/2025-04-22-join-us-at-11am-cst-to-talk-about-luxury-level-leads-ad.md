---
campaign_name: "Our Live Session"
subject: "Join us at 11am CST to talk about  Luxury-Level Leads: Ads That Convert High-End!"
cta_from_name: ""
sent: 2025-04-22
recipients: 584
delivered: 581
failed: 0
sending_domain: ""
last_edited_by: "Whitney Hodges"
tracking: on
schedule_id: "680006e57d77f945fe22128e"
template_id: ""
raw_html: "raw/680006e57d77f945fe22128e.html"
cta_urls:
  - https://margauxfraise.mykajabi.com/wss-lux-registration?ref=https%3A%2F%2Fmargauxfraise.mykajabi.com%2Fa%2F2148086627%2FDAEHLMAk
  - https://margauxfraise.mykajabi.com/wss-lux-aap-regular
# Only Whitney or Giselle can fill these two.
source_session: ""
instagram_sibling: ""
---

## Body

Hey {{contact.first_name}},
We’re popping in this morning to let you know that our live session is TODAY at 11am CST. We’ll be talking all about Luxury-Level Leads: Ads That Convert High-End for the Wedding Summit Series: LUXURY Edition!
We’ll be going over:
✅ Must-have foundational branding elements if you want to run successful ad campaigns
✅ The key elements of crafting ads that resonate with luxury clientele
✅ Targeting tactics to reach a high-intent, quality audience
Our goal is to break down exactly what you need to know to leverage paid advertising for your wedding business.
If you haven’t grabbed your free ticket to the summit yet, you can do that here . There are so many other amazing presentations for you to access inside!
See you soon!
Whitney & Daniela
p.s. If you’re seeing this too late, you can grab the All-Access Pass to get lifetime access to all the replays!
