---
campaign_name: "WSS Welcome Email Campaign"
subject: "Welcome to Wedding Industry Ads! Let's Grow Together"
cta_from_name: ""
sent: 2024-04-04
recipients: 104
delivered: 
failed: 0
sending_domain: ""
last_edited_by: ""
tracking: off
schedule_id: "660efc54a373311eeab79dc8"
template_id: ""
raw_html: "raw/660efc54a373311eeab79dc8.html"
cta_urls:
  - https://www.weddingindustryads.com/vip-day
# Only Whitney or Giselle can fill these two.
source_session: ""
instagram_sibling: ""
---

## Body

View this email in browser
W E L C O M E
Dear {{contact.first_name}},
Welcome! We wanted to take a moment to extend a warm hello and express our gratitude for connecting with us at the Wedding Series Summit: Sales Edition. It was a pleasure having you attend our presentation on "How to Nurture Leads with $1/day Instagram Ads."
Your interest and engagement mean the world to us, and we're thrilled to have you as part of our community. We're constantly striving to provide valuable insights and resources to support you on your journey towards success in the wedding industry.
If you have any feedback or questions regarding setting up your own DIY $1/day nurture ads, please don't hesitate to reach out. We're here to help and provide guidance every step of the way.
We are all about helping you leverage your existing content and making it go further with ads behind it. If you're interested in taking your advertising efforts to the next level, consider applying for our Meta Ads VIP Day. This is one of our best-selling offers where our team will work closely with you to set up and optimize your Meta Ads campaigns for you, all for just $10/day in ad spend!!
Learn more about our Meta Ads VIP Day here.
Thank you once again for joining us at the summit. We look forward to supporting you on your path to success!
Best,
Whitney + Daniela
Wedding Industry Ads Team
