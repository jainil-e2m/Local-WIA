---
campaign_name: "Weekly Marketing Email 1.5.26"
subject: "Your 2026 Ads Investment Guide is Here 🎉"
cta_from_name: ""
sent: 2026-01-05
recipients: 550
delivered: 547
failed: 2
sending_domain: ""
last_edited_by: "Whitney Hodges"
tracking: on
schedule_id: "695b418d1fc888e853e67452"
template_id: ""
raw_html: "raw/695b418d1fc888e853e67452.html"
cta_urls:
  - https://weddingindustryads.com
# Only Whitney or Giselle can fill these two.
source_session: ""
instagram_sibling: ""
---

## Body

Hi {{contact.first_name}},
If you’re ready to attract more of your ideal clients this year, you’re going to love this.
We just released our brand-new Ads Investment Guide. It’s your shortcut to understanding what’s working right now with Google Ads and Meta Ads for wedding businesses.
Here’s what you’ll find inside:
✅ A breakdown of Google Ads vs Meta Ads (and how to use both strategically)
✅ What kind of budget actually works in today’s market
✅ The key questions to ask before spending another dollar on ads
✅ Real results from wedding pros who’ve doubled inquiries with the right strategy
✅ A peek inside our Accelerator programs—done-for-you campaigns with no ongoing retainer
If you’ve been wondering how to finally get ads working for you, this guide will show you the exact steps to take next.
👉 Grab your copy here – we’ll send it straight to your inbox.
And if you have any questions after reading, hit reply. We’re always just an email away.
Cheers,
Daniela & Whitney
Wedding Industry Ads
