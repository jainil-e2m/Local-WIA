---
campaign_name: "Weekly Marketing Email 10.21.25 "
subject: "Happening TODAY: Sales Q&A with Maria Bayer"
cta_from_name: ""
sent: 2025-10-21
recipients: 735
delivered: 733
failed: 1
sending_domain: ""
last_edited_by: "Yulia Burris"
tracking: on
schedule_id: "68f2895fb519898a740750e2"
template_id: "689c8291ba28b0d2b23050f0"
raw_html: "raw/68f2895fb519898a740750e2.html"
cta_urls:
  - https://mariabayer.lpages.co/booking-season-wia/
# Only Whitney or Giselle can fill these two.
source_session: ""
instagram_sibling: ""
---

## Body

If you’ve got sales questions, today’s the day to get answers.
Hi {{contact.first_name}},
Our LIVE Sales Q&A with Maria Bayer is happening today!
⏰ 9am PT | 11am CT | 12pm ET
📍 Grab your seat here before we go live
Whether your calendar is too quiet or your leads are ghosting, Maria’s here to help you fix it.
This is real coaching. Not a sales pitch. Not a snoozy slideshow.
Just you, your questions, and one of the most respected sales strategists in the wedding industry.
You’ve still got time to join us—click here to register now .
See you soon,
Daniela & Whitney
Copyright © {{right_now.year}} {{location.name}}, All rights reserved.
Our mailing address is:
{{location.email}}
Want to change how you receive these emails?
You can unsubscribe from this list .
