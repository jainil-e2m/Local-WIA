---
campaign_name: "Marketing Email 2.3.26"
subject: "The shift that changed her ad results"
cta_from_name: ""
sent: 2026-02-03
recipients: 804
delivered: 803
failed: 0
sending_domain: ""
last_edited_by: "Whitney Hodges"
tracking: on
schedule_id: "6980b3d270808c4613b36900"
template_id: "689c8291ba28b0d2b23050f0"
raw_html: "raw/6980b3d270808c4613b36900.html"
cta_urls: []
# Only Whitney or Giselle can fill these two.
source_session: ""
instagram_sibling: ""
---

## Body

Hi {{contact.first_name}},
For many wedding businesses, a simple improvement to their advertising strategy can make a meaningful difference. We see it again and again.
What we’ve been seeing inside the ad account of a destination wedding planner we work with has only reinforced that belief.
For a few months, she’d been running Meta Ads on a modest budget. Leads were coming in slowly — enough to feel encouraged by the possibilities, but not enough to feel confident or consistent.
She already had a strong brand.
A solid website.
And she believed ads could work for her business.
So she made a strategic shift.
Knowing search activity was high, she launched Google Ads alongside her Meta campaigns and doubled her overall ad spend.
And when we reviewed how her results changed within a single month, we were excited — but not surprised:
– Her cost per lead dropped by over 66%
– Her lead volume increased 6X
– And now, the calls she’s having with those leads are turning into signed wedding contracts
Nothing else changed.
No rebrand.
No new website.
No overhaul of her messaging.
The shift wasn’t just about increasing ad spend.
It was about diversifying her advertising strategy — and giving each platform a clear role to play.
If you believe ads should work for your business but haven’t been able to crack consistent results yet, we have a special giveaway coming later this week you won’t want to miss.
More soon!
Daniela & Whitney
Co-Founders, Wedding Industry Ads
Copyright © {{right_now.year}} {{location.name}}, All rights reserved.
Our mailing address is:
{{location.email}}
Want to change how you receive these emails?
You can unsubscribe from this list .
