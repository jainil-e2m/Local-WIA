---
campaign_name: "Weekly Marketing Email 10.28.25 (12PM)"
subject: "📣Google Search Accelerator is here"
cta_from_name: ""
sent: 2025-10-28
recipients: 701
delivered: 699
failed: 0
sending_domain: ""
last_edited_by: "Yulia Burris"
tracking: on
schedule_id: "68ffe044d5454d5b33b76712"
template_id: "689c8291ba28b0d2b23050f0"
raw_html: "raw/68ffe044d5454d5b33b76712.html"
cta_urls:
  - https://weddingindustryads.com/google-search-accelerator
# Only Whitney or Giselle can fill these two.
source_session: ""
instagram_sibling: ""
---

## Body

Lock in founding member perks (just 10 spots)
Hi {{contact.first_name}},
The Google Search Accelerator is officially open for enrollment. 🎉
This program is built for wedding pros who are ready to run profitable Google Ads without the overwhelm. If you've been wanting a clear, expert-led path to get found by your dream clients on Google, this is it.
Inside the Google Search Accelerator, you’ll get:
✅ A fully done-for-you Google Ads campaign (we write, build, and launch it for you)
✅ Foundational curriculum to help you create a high-converting funnel
✅ 3 months of consultative support, office hours, and ongoing coaching
✅ The clarity and confidence to know exactly how your ads are working — and how to scale them
We’re inviting just 10 founding members to join us first.
As a founding member, you’ll receive:
💥 Introductory pricing
💥 An extra month of support inside the VAULT (for a total of 4 months)
💥 First access to everything launching November 3
👉 Click here to secure your spot now
Let’s get your ads working before engagement season kicks into high gear.
To your success,
Daniela & Whitney
Copyright © {{right_now.year}} {{location.name}}, All rights reserved.
Our mailing address is:
{{location.email}}
Want to change how you receive these emails?
You can unsubscribe from this list .
