---
campaign_name: "Labor Day Flash Sale: Meta VIP Day 1 "
subject: "FLASH SALE!!! $300 Off Meta Ads VIP Day"
cta_from_name: ""
sent: 2024-09-02
recipients: 324
delivered: 
failed: 0
sending_domain: ""
last_edited_by: "Whitney Hodges"
tracking: on
schedule_id: "66ce5b16ddd4089ec814a198"
template_id: ""
raw_html: "raw/66ce5b16ddd4089ec814a198.html"
cta_urls:
  - https://www.weddingindustryads.com/vip-day
# Only Whitney or Giselle can fill these two.
source_session: ""
instagram_sibling: ""
---

## Body

Your first month of ad spend is on us!
View this email in browser
Hi {{contact.first_name}},
Exciting news! For the next 48 hours, we're offering an exclusive flash sale on our Meta Ads VIP Day – the ultimate opportunity to supercharge your advertising efforts and maximize your results.
Apply for your Meta Ads VIP Day before midnight on September 3rd, and you'll receive $300 off (basically, your first month of ad spend is on us!) This is your chance to work closely with our expert team and harness the power of Meta Ads to drive more leads and bookings for your wedding business.
We KNOW how powerful this could be for your business - that’s why it’s our mission to make ads more accessible to service pros in the wedding industry.
Don't miss out on this limited-time offer. Apply now and take the first step towards unlocking the full potential of your advertising strategy.
Apply Now and Save $300!
We'll see you on the path to advertising success!
Cheers,
Whitney + Daniela
Wedding Industry Ads Team
