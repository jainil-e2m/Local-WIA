---
campaign_name: "CEO Summit - Start Monday"
subject: "The key to running killer ad campaigns"
cta_from_name: ""
sent: 2025-02-17
recipients: 521
delivered: 
failed: 0
sending_domain: ""
last_edited_by: "Whitney Hodges"
tracking: on
schedule_id: "67b378e2e845a70b193f4562"
template_id: ""
raw_html: "raw/67b378e2e845a70b193f4562.html"
cta_urls:
  - https://weddingbusinessceosummit.com/registration/?aff=84
# Only Whitney or Giselle can fill these two.
source_session: ""
instagram_sibling: ""
---

## Body

Hey {{contact.first_name}},
The Wedding Business CEO Summit kicks off TODAY Monday, February 17th, and we’re so excited to be part of it!
We’ll be speaking alongside amazing experts, sharing our tips on how you can harness the power of text & email to nurture automations to increase conversions and book more weddings with ease.
Wondering why we’re focusing on automations instead of ads?
Here’s the deal: a strong sales funnel is key to your success — even if you’re not using ads just yet. But when you do, ads don’t work in isolation. You need systems in place to nurture those leads before you start pouring money into visibility and traffic.
We’ll show you exact workflows we’ve set up for our clients to boost conversions and get better results, whether you’re running ads or focusing on organic marketing.
Plus, we’ll talk about how responding within the first minute can increase your sales conversions by up to 391% — so if you’re still manually handling leads, this is going to be a game-changer for you.
And here’s something special…
We’re launching an exciting new offer when our presentation goes live on Thursday — trust us, you won’t want to miss it!
Get your free ticket here and join us!
We can’t wait to see you there and help you start booking more weddings with ease.
Best,
Whitney & Daniela
