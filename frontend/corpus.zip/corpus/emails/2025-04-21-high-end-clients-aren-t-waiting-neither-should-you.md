---
campaign_name: "Starting Today"
subject: "High-end clients aren’t waiting—neither should you."
cta_from_name: ""
sent: 2025-04-21
recipients: 588
delivered: 584
failed: 1
sending_domain: ""
last_edited_by: "Whitney Hodges"
tracking: on
schedule_id: "680005c17db732d2d29a3415"
template_id: ""
raw_html: "raw/680005c17db732d2d29a3415.html"
cta_urls:
  - https://margauxfraise.mykajabi.com/wss-lux-registration?ref=https%3A%2F%2Fmargauxfraise.mykajabi.com%2Fa%2F2148086627%2FDAEHLMAk
# Only Whitney or Giselle can fill these two.
source_session: ""
instagram_sibling: ""
---

## Body

Hello {{contact.first_name}},
For the inbox skimmers out there, I’ll keep this short—this is your final chance to join The Wedding Summit Series: Luxury Edition before it kicks off TODAY!
This free event is packed with 25+ luxury wedding experts sharing real, no-fluff strategies for booking high-end clients, refining your brand, and mastering the luxury service experience.
If you’ve ever wondered what actually goes into breaking into the high-end wedding market, this is where you’ll get the answers—straight from the experts who have done it.
Starting TODAY, you’ll get access to:
💎 Daily presentations from top luxury experts—free for 24 hours.
💎 Live sessions & expert Q&As to answer your biggest questions.
💎 Insider conversations with high-end wedding pros sharing their real experiences.
💎 The truth about luxury—what works, what doesn’t, and how to position yourself for success.
This is not a collection of vague, recycled advice—it’s actionable education designed to help you take the next steps toward booking high-end clients.
👉Haven’t grabbed your free ticket yet? Now’s the time.
You’ll want to jump inside ASAP—because these strategies and insights can make 2025 your biggest year yet.
Grab your free ticket now
Best,
Whitney & Daniela
