---
campaign_name: "Weekly Marketing Email 10.27.25 "
subject: "Something new drops tomorrow ✨"
cta_from_name: ""
sent: 2025-10-27
recipients: 704
delivered: 689
failed: 1
sending_domain: ""
last_edited_by: "Whitney Hodges"
tracking: on
schedule_id: "68fe7a23a25cb8c2fde2be08"
template_id: "689c8291ba28b0d2b23050f0"
raw_html: "raw/68fe7a23a25cb8c2fde2be08.html"
cta_urls: []
# Only Whitney or Giselle can fill these two.
source_session: ""
instagram_sibling: ""
---

## Body

The countdown is on…
Hi {{contact.first_name}},
Tomorrow, we’re unveiling something brand new. And it’s built for wedding pros who are done guessing when it comes to Google Ads.
The Google Search Accelerator combines everything our VIP Day clients already love — the hands-on campaign build, the expert strategy — plus new tools, curriculum, and coaching to help you stay profitable long after launch day.
If Google Ads have felt overwhelming or hit-or-miss, this is your opportunity to finally feel confident, strategic, and in control.
✨ Stay tuned to make sure you’re in the know.
xo,
Daniela & Whitney
Copyright © {{right_now.year}} {{location.name}}, All rights reserved.
Our mailing address is:
{{location.email}}
Want to change how you receive these emails?
You can unsubscribe from this list .
