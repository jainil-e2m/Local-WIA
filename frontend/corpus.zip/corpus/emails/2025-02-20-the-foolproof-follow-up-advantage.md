---
campaign_name: "The Foolproof Follow-Up Advantage\n\n\n"
subject: "The Foolproof Follow-Up Advantage"
cta_from_name: ""
sent: 2025-02-20
recipients: 511
delivered: 
failed: 1
sending_domain: ""
last_edited_by: "Whitney Hodges"
tracking: on
schedule_id: "67b4e79704964f58671f41a8"
template_id: ""
raw_html: "raw/67b4e79704964f58671f41a8.html"
cta_urls:
  - https://leadlockpro.com/
# Only Whitney or Giselle can fill these two.
source_session: ""
instagram_sibling: ""
---

## Body

Hi {{contact.first_name}},
We’re rolling out our brand new offer! It’s called The Foolproof Follow-Up Advantage.
This program is a done-for-you service that gets your business’ automated inquiry follow-up system built inside our lead management software, LeadLock .
We’re looking for 10 people who want to join.
We’re so excited to be bringing this to our community because up until now, LeadLock has only been available to our full-service ads management clients.
So if you…
Are a business owner in the wedding industry who knows you could be doing a better job following up with and nurturing your leads
Have great testimonials or reviews from past couples
Know your unique selling proposition
Understand your ideal clients and their desires
Have a professional website and email address
Use Google Workspace or Outlook for your email and calendar
Are friendly and open-minded
And you want to embrace email and text automations
If that’s you, hit reply and let me know you’d like to learn more. Then I’ll get you all the details.
Whitney
