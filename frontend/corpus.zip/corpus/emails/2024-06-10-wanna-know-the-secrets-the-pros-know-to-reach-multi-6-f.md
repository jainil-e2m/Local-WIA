---
campaign_name: "Irresistible Selling Masterclass Invite (Affiliate Email for Maria)"
subject: "Wanna know the secrets the pros know to reach multi 6-figures?"
cta_from_name: ""
sent: 2024-06-10
recipients: 474
delivered: 
failed: 303
sending_domain: ""
last_edited_by: ""
tracking: off
schedule_id: "66672fe34212c39ebbd2927d"
template_id: ""
raw_html: "raw/66672fe34212c39ebbd2927d.html"
cta_urls:
  - https://mariabayer.lpages.co/multi-6-figure-year/
# Only Whitney or Giselle can fill these two.
source_session: ""
instagram_sibling: ""
---

## Body

(FREE training inside)
View this email in browser
Hi {{contact.first_name}},
If you're determined to make THIS the year you book high-ticket clients, work smarter, and elevate your business and income, then I have something super exciting for you.
The OG of sales strategy and wedding industry expert Maria Bayer, is offering a totally free, no-strings-attached sales strategy training session on June 12th and trust me - you really want to be there.
She’s dishing her top 3 secrets to a multi 6-figure year! And the best part? She teaches you how to achieve it without exhaustion and burnout.
Are you in?!
📅 Here are all the deets:
What: 3 Secrets to an Easy Multi 6-Figure Year
When: June 12th at 12 PM PST / 3 PM EST
Where: Click HERE to save your seat
In the session, Maria will teach you:
How to sell in a way that feels so natural, it won’t feel like selling at all.
The secret strategy she used to triple her income in less than a year... and go on to book over $25 million in sales.
How to level up fast and book high-end clients on repeat. This is the secret that no one is talking about.
I’m SO excited for you to hear from Maria and take a step towards your best year ever. Trust me, Maria and her strategies are the real deal, friends.
Let’s do this!
Whitney + Daniela
