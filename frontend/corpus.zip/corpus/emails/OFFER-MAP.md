# Offer map — CTA destinations

Recovered from each campaign's `templateDataDownloadUrl` (the MJML editor
payload). The rendered HTML only carries link.msgsndr.com click-redirects, so
these are the hrefs as originally written.

This is the gap `prompts/marketing-email.md` §6 records as blocking: the
engine could name a CTA but not link it.

Grouped by origin + path, so the same page arriving with `_gl`, `utm_source`
or affiliate params is one row. Links appearing in 50+ of the
126 emails are treated as footer chrome and excluded — otherwise the
homepage collects every CTA label and means nothing.

## WIA-owned

| Destination | Labelled CTA | Emails |
|---|---|---|
| http://weddingindustryads.com | Ads Accelerators Sales Page · Reply · Ads Accelerator Reply | 4 |
| http://leadlockpro.com | Ads Accelerators Sales Page · Reply · Ads Accelerator Reply | 4 |
| https://weddingindustryads.com/accelerate | Ads Accelerators Sales Page · Ads Accelerator Reply | 3 |
| https://weddingindustryads.com/premiumleadgeneration-workshop | Register | 3 |
| https://weddingindustryads.com/full-service-ads-management-waitlist | Join the ELEVATE waitlist | 1 |
| https://weddingindustryads.com/visibility-blueprint | Watch | 1 |
| https://weddingindustryads.com/link-in-bio | Link in Bio | 1 |
| https://weddingindustryads.com/google-search-accelerator | — | 13 |
| https://portal.weddingindustryads.com/public/form/view/68f91878a9a586fcdf4c0566 | — | 7 |
| https://weddingindustryads.com/gsa-info-session-11-5 | — | 7 |
| https://weddingindustryads.com/ads-consultation1 | — | 6 |
| https://weddingindustryads.com/meta-ads-immersive-experience-scheduler | — | 6 |
| https://www.weddingindustryads.com/vip-day | — | 5 |
| https://weddingindustryads.com/stop-boosting-posts-guide | — | 4 |
| https://weddingindustryads.com/giveaway | — | 3 |
| https://weddingindustryads.com | — | 3 |
| https://weddingindustryads.com/calendar-page-645042 | — | 3 |
| https://weddingindustryads.com/google-vip-day1 | — | 3 |
| https://leadlockpro.com | — | 2 |
| https://weddingindustryads.com/investment-guide | — | 2 |
| https://weddingindustryads.com/google-audit | — | 2 |
| https://weddingindustryads.com/power-couple | — | 2 |
| https://weddingindustryads.com/apply | — | 1 |
| https://leadlockpro.com/speed-to-lead-opt-in-page | — | 1 |
| https://weddingindustryads.com/ads-clarity-call | — | 1 |
| https://www.weddingindustryads.com/zoom | — | 1 |
| https://weddingindustryads.com/gsa-replay | — | 1 |
| https://weddingindustryads.com/annual-page | — | 1 |
| https://weddingindustryads.com/google-vip-calendar | — | 1 |
| https://weddingindustryads.com/waitlist | — | 1 |
| https://weddingindustryads.com/funnel-map-optin1 | — | 1 |
| https://weddingindustryads.com/case-study | — | 1 |
| https://weddingindustryads.com/scheduler | — | 1 |
| https://weddingindustryads.com/meta-workshop | — | 1 |

## Third party and affiliate

Partner promotions and affiliate links. Not WIA offers — listed so nobody
mistakes one for a destination the engine may use.

| Destination | Labelled CTA | Emails |
|---|---|---|
| https://lh3.googleusercontent.com/d/18agv_tzqipv0ijinpa0akellaxwi1nkd | Ads Accelerators Sales Page · Reply · Ads Accelerator Reply | 4 |
| https://margauxfraise.mykajabi.com/wss-lux-registration | — | 4 |
| https://weddingbusinessceosummit.com/registration | — | 4 |
| https://margauxfraise.mykajabi.com/wss-tech-ai-registration | — | 3 |
| https://margauxfraise.mykajabi.com/a/2148205566/daehlmak | — | 3 |
| https://zoom.us/j/95428361024 | — | 3 |
| https://mariabayer.lpages.co/booking-season-wia | — | 3 |
| https://www.byemilyjane.com/gift-exchange | — | 2 |
| https://weddingbusinessceosummit.com | — | 2 |
| https://go.theweddingbusinesscollective.com/dec2024roundtable | — | 2 |
| https://brandeegaar.com/wedding-business-ads-with-daniela-and-whitney | — | 2 |
| https://brandeegaar.com/summit | — | 2 |
| https://emilyfostercreative.com/engage-your-brand-podcast | — | 1 |
| https://margauxfraise.mykajabi.com/wss-lux-aap-regular | — | 1 |
| https://brandeegaar.com/do-paid-ads-work-for-wedding-planners | — | 1 |
| https://mariabayer.lpages.co/multi-6-figure-year | — | 1 |

---

21 of 126 emails carry no destination at all, which is consistent
with reply-bait being the most-used CTA in the 2026 set.
