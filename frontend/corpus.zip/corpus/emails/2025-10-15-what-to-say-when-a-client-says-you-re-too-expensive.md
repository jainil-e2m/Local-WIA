---
campaign_name: "Weekly Marketing Email 10.15.25"
subject: "What to say when a client says “You’re too expensive”"
cta_from_name: ""
sent: 2025-10-15
recipients: 735
delivered: 733
failed: 1
sending_domain: ""
last_edited_by: "Yulia Burris"
tracking: on
schedule_id: "68efbee5a7f659c51f9156d5"
template_id: "689c8291ba28b0d2b23050f0"
raw_html: "raw/68efbee5a7f659c51f9156d5.html"
cta_urls:
  - https://mariabayer.lpages.co/booking-season-wia/
# Only Whitney or Giselle can fill these two.
source_session: ""
instagram_sibling: ""
---

## Body

A live sales coaching session with Maria Bayer
Hi {{contact.first_name}},
Ever wish someone would just tell you what to say when a client hits you with, “You’re too expensive”?
Same.
That’s why we’re bringing in Maria Bayer (sales strategist to the wedding industry’s top 1% and creator of Irresistible Selling) for a special LIVE Sales Q&A just for our community.
🗓️ Monday, October 21
⏰ 9am PT | 11am CT | 12pm ET
📍Live on Zoom
This isn’t a webinar. It’s interactive coaching. Real answers to your real sales questions—on the spot.
✅ Not getting inquiries?
✅ Getting ghosted after consults?
✅ Wondering if it’s time to raise your rates?
Bring it all.
Maria’s helped hundreds of wedding pros turn “I’ll think about it” into paid-in-full bookings, and now it’s your turn.
👉Save your seat here before it fills up.
See you there,
Daniela & Whitney
Copyright © {{right_now.year}} {{location.name}}, All rights reserved.
Our mailing address is:
{{location.email}}
Want to change how you receive these emails?
You can unsubscribe from this list .
