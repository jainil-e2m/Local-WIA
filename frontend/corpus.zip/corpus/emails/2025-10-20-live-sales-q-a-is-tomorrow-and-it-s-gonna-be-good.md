---
campaign_name: "Weekly Marketing Email 10.20.25"
subject: "LIVE Sales Q&A is tomorrow (and it’s gonna be GOOD)"
cta_from_name: ""
sent: 2025-10-20
recipients: 736
delivered: 733
failed: 1
sending_domain: ""
last_edited_by: "Yulia Burris"
tracking: on
schedule_id: "68f278da0157f62545360595"
template_id: "689c8291ba28b0d2b23050f0"
raw_html: "raw/68f278da0157f62545360595.html"
cta_urls:
  - https://mariabayer.lpages.co/booking-season-wia/
# Only Whitney or Giselle can fill these two.
source_session: ""
instagram_sibling: ""
---

## Body

Bring your questions. Maria Bayer’s bringing the answers.
Hi {{contact.first_name}},
Just a quick reminder—our LIVE Sales Q&A with Maria Bayer is happening tomorrow!
🗓️ Tuesday, October 21
⏰ 9am PT | 11am CT | 12pm ET
📍 Zoom link will be sent to all registered attendees
This is not another generic webinar.
It’s interactive. It’s personalized. And it’s designed to help you turn slow seasons into sold-out ones—with expert sales coaching from one of the best in the business.
Got a tricky objection you keep hearing?
Struggling to close consults?
Thinking your prices might be off?
Maria will coach you live—no fluff, no scripts, just smart, strategic advice.
👉 Grab your spot now (you’ll be glad you did).
Let’s make this your best booking season yet,
Daniela & Whitney
Copyright © {{right_now.year}} {{location.name}}, All rights reserved.
Our mailing address is:
{{location.email}}
Want to change how you receive these emails?
You can unsubscribe from this list .
