---
campaign_name: "Workshop Reminder 6.23.26 | Register CTA"
subject: "LIVE today at 11am CST"
cta_from_name: "Register"
sent: 2026-06-23
recipients: 803
delivered: 799
failed: 1
sending_domain: "reply.weddingindustryads.com"
last_edited_by: "Whitney Hodges"
tracking: on
schedule_id: "6a399e1dd4cbb29f136351a3"
template_id: "694b2a04c384d6817120dc5d"
raw_html: "raw/6a399e1dd4cbb29f136351a3.html"
cta_urls:
  - https://weddingindustryads.com/premiumleadgeneration-workshop
# Only Whitney or Giselle can fill these two.
source_session: ""
instagram_sibling: ""
---

## Body

it's not too late to register
Hi {{contact.first_name}},
If you haven't already heard, our workshop with brand and website designer Emily Foster is happening today:
Building a Brand That Supports Premium Lead Generation
What happens after someone discovers your business matters.
Your brand.
Your website.
The trust you create.
The consistency of the experience.
The ease of taking the next step.
That's exactly what we'll be discussing during today's workshop.
Emily will be sharing practical insights on:
How brand perception impacts the quality of leads you attract
How your website can support—or weaken—trust
Common friction points that keep visibility from turning into inquiries
How to create more consistency across your marketing ecosystem
How to position your brand experience to support premium lead generation
If you're investing in marketing and want to improve what happens after someone clicks, we'd love to have you join us.
REGISTER HERE
See you soon,
Whitney
Copyright © {{right_now.year}} {{location.name}}, All rights reserved.
Our mailing address is:
{{location.email}}
Want to change how you receive these emails?
You can unsubscribe from this list .
