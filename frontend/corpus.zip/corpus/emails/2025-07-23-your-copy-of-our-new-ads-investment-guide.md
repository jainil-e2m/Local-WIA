---
campaign_name: "Weekly Marketing Email 7.23.25\n\n (clone)"
subject: "Your copy of our new Ads Investment Guide"
cta_from_name: ""
sent: 2025-07-23
recipients: 52
delivered: 50
failed: 2
sending_domain: ""
last_edited_by: "Whitney Hodges"
tracking: on
schedule_id: "68801abbcd1408173aca4361"
template_id: ""
raw_html: "raw/68801abbcd1408173aca4361.html"
cta_urls:
  - https://weddingindustryads.com/investment-guide
  - https://weddingindustryads.com/ads-consultation1
# Only Whitney or Giselle can fill these two.
source_session: ""
instagram_sibling: ""
---

## Body

Hi {{contact.first_name}},
We just released our brand-new Ads Investment Guide. It’s your shortcut to understanding what’s working right now with Google Ads and Meta Ads for wedding businesses.
👉 Here's your copy! (no opt-in required!)
Inside you'll find:
✅ How to get started with ads (without committing to an ongoing monthly retainer)
✅ A peek at our newest offer…done-with-you Meta Ad creatives + done-for-you tracking and campaign builds
✅ The easiest way to use email & text automations to respond to inquiries faster (and book more of them!)
✅ Real client results from wedding pros who are doubling inquiries with ads
Check it out! And if you have any questions after reading, hit reply. We’re always just an email away.
Cheers,
Daniela & Whitney
Wedding Industry Ads
P.S. If you’re ready to skip the learning curve and get ads running for you now, let’s chat.
Book a consultation here and we’ll map out the best strategy for your business.
