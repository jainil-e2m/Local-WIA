---
campaign_name: " Our Session - Preview"
subject: "Attract luxury-level leads…"
cta_from_name: ""
sent: 2025-04-17
recipients: 587
delivered: 583
failed: 1
sending_domain: ""
last_edited_by: "Whitney Hodges"
tracking: on
schedule_id: "68000381a7f0405714f50c4e"
template_id: ""
raw_html: "raw/68000381a7f0405714f50c4e.html"
cta_urls:
  - https://margauxfraise.mykajabi.com/wss-lux-registration?ref=https%3A%2F%2Fmargauxfraise.mykajabi.com%2Fa%2F2148086627%2FDAEHLMAk
# Only Whitney or Giselle can fill these two.
source_session: ""
instagram_sibling: ""
---

## Body

Hey {{contact.first_name}},
If you’ve ever wondered how to use paid ads to attract luxury-level leads, you don’t want to miss our live session inside The Wedding Summit Series: Luxury Edition!
We’ll be going LIVE sharing Luxury-Level Leads: Ads That Convert High-End, where we’ll be breaking down:
✅ Must-have foundational branding elements if you want to run successful ad campaigns
✅ The key elements of crafting ads that resonate with luxury clientele
✅ Targeting tactics to reach a high-intent, quality audience
Whether you’re just getting started in the luxury market or looking to refine your high-end strategy, this session will give you what you need to know to leverage paid advertising for your wedding business.
The Wedding Summit Series: Luxury Edition is packed with 25+ expert sessions, live interviews, and exclusive insights—and it’s completely free to attend!
📅 Our session happens LIVE on Tuesday, April 22 at 11:00am CST
Don’t miss this opportunity to gain real luxury wedding strategies—grab your free ticket now!
Register for free & join our live session
See you there!
Whitney & Daniela
