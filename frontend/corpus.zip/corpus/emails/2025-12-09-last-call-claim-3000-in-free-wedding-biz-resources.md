---
campaign_name: "Marketing Email 12.9.25 (1 PM)"
subject: "Last call: Claim $3000+ in free wedding biz resources"
cta_from_name: ""
sent: 2025-12-09
recipients: 676
delivered: 674
failed: 2
sending_domain: ""
last_edited_by: "Yulia Burris"
tracking: on
schedule_id: "6938685794fd36d7493be4f1"
template_id: "689c8291ba28b0d2b23050f0"
raw_html: "raw/6938685794fd36d7493be4f1.html"
cta_urls:
  - https://www.byemilyjane.com/gift-exchange
  - https://www.byemilyjane.com/gift-exchange/#optin
# Only Whitney or Giselle can fill these two.
source_session: ""
instagram_sibling: ""
---

## Body

Wedding Pro Gift Exchange ends TONIGHT!
Hi {{contact.first_name}},
The Wedding Pro Gift Exchange is coming to a close, and we’d hate for you to miss out!
Here’s the quick rundown:
✨ It’s a curated bundle of 30+ free resources for wedding pros
✨ You’ll find expert-led trainings, templates, and tools to help you prep for an amazing 2026
✨ Our contribution? The Ultimate Advertising Power Couple training—your behind-the-scenes playbook for using Google Ads + Meta Ads to bring in more qualified leads on repeat
This is your chance to grab powerful tools without spending a dime but only until TONIGHT at 11:59 PM CT.
👉 [Click here to access the Gift Exchange now]
Remember, you don’t need everything. Just choose what aligns with your goals and your business vision for 2026.
Got a favorite so far? Or one you're eyeing? Hit reply and let us know!
To your best year yet,
Daniela & Whitney
Wedding Industry Ads
P.S. After tonight, this bundle disappears, and all those freebies go back to full price. Don’t wait!
Copyright © {{right_now.year}} {{location.name}}, All rights reserved.
Our mailing address is:
{{location.email}}
Want to change how you receive these emails?
You can unsubscribe from this list .
