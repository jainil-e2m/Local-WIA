---
campaign_name: "GSA Info Session (for registered attendees) 11.5.25 (10 AM) "
subject: "LIVE in 1 hr: Google Ads made simple (and effective)"
cta_from_name: ""
sent: 2025-11-05
recipients: 26
delivered: 25
failed: 1
sending_domain: ""
last_edited_by: "Yulia Burris"
tracking: on
schedule_id: "690a874409abc670b2d197a6"
template_id: "689c8291ba28b0d2b23050f0"
raw_html: "raw/690a874409abc670b2d197a6.html"
cta_urls:
  - https://zoom.us/j/95428361024?pwd=b35vscCYt2CaixB5o0d4dpxPzyLTle.1&jst=2￼
  - https://zoom.us/j/95428361024?pwd=b35vscCYt2CaixB5o0d4dpxPzyLTle.1&jst=2
# Only Whitney or Giselle can fill these two.
source_session: ""
instagram_sibling: ""
---

## Body

Hi {{contact.first_name}},
We’re going live in just about an hour - and this session is packed with insights you won’t want to miss.
If Google Ads have ever felt confusing, expensive, or like a total mystery… this is your chance to finally understand what works (and what doesn’t).
This is your chance to get clarity on:
✨ How Google Ads fit into your overall marketing funnel
✨ The mistakes costing wedding pros thousands in wasted spend
✨ The step-by-step process we use inside the Google Search Accelerator
Plus, we’ll be taking questions live - so if you’ve ever wanted expert eyes on your ads strategy, this is the time to ask.
🎥 Join us here: https://zoom.us/j/95428361024?pwd=b35vscCYt2CaixB5o0d4dpxPzyLTle.1&jst=2
(We’ll be starting right on time!)
See you inside,
Daniela & Whitney
Copyright © {{right_now.year}} {{location.name}}, All rights reserved.
Our mailing address is:
{{location.email}}
Want to change how you receive these emails?
You can unsubscribe from this list .
