---
campaign_name: "Marketing Email 12.01.25|  4PM  | Black Friday"
subject: "Last Day: Save $200 on Your Google Search Campaign"
cta_from_name: ""
sent: 2025-12-01
recipients: 664
delivered: 664
failed: 0
sending_domain: ""
last_edited_by: "Yulia Burris"
tracking: on
schedule_id: "692dedf6b2703455db9ea231"
template_id: "689c8291ba28b0d2b23050f0"
raw_html: "raw/692dedf6b2703455db9ea231.html"
cta_urls:
  - https://weddingindustryads.com/google-search-accelerator
  - https://portal.weddingindustryads.com/public/form/view/68f91878a9a586fcdf4c0566?_gl=1*1uji4l3*_gcl_au*MTcxNTQ4Mjc0LjE3NjE5MzQyMjA
# Only Whitney or Giselle can fill these two.
source_session: ""
instagram_sibling: ""
---

## Body

Black Friday Pricing Ends at Midnight
Hi {{contact.first_name}},
This is your final reminder: our Black Friday pricing on the Google Search Accelerator ends at midnight tonight.
If you’ve been thinking about running Google Ads in 2026, this is your moment to lock in our most in-demand campaign setup for just $1,497 (normally $1,697).
This is a fully built, expert-designed Google Search campaign tailored to your business goals and designed to get you in front of high-intent couples exactly when they’re searching for vendors like you.
Already, clients have seen inquiries within days of launching. One pro landed an ideal-fit couple in a new city. Another messaged us three days post-launch, saying:
“The last few days have been insane with bookings… I’m fairly certain my Google Ads are already bringing in an influx of inquiries!? I’m like what is this voodoo magic?!”
We know the holidays can get crazy, but if you know you want ideal clients to find you on Google in 2026 this is for you.
Sign on now to secure the best pricing. You don't have to schedule the launch of your Google Ads until you're ready. The ongoing access to us for support doesn't kick in until after your campaign is live.
👉 Book Now to Lock in $200 Off
Offer closes at 11:59pm CST tonight, December 1.
Let’s make 2026 your best year yet,
Daniela & Whitney
Wedding Industry Ads
P.S. This isn’t just about ads. It’s about showing up, being found, and filling your calendar with ease. Let’s build that momentum together.
Copyright © {{right_now.year}} {{location.name}}, All rights reserved.
Our mailing address is:
{{location.email}}
Want to change how you receive these emails?
You can unsubscribe from this list .
