---
campaign_name: "Roundtable Live Event"
subject: "🚀 Get More Perfect-Fit Leads This Engagement Season"
cta_from_name: ""
sent: 2024-12-04
recipients: 887
delivered: 
failed: 535
sending_domain: ""
last_edited_by: "Nicole Bautista"
tracking: on
schedule_id: "674df320b6a70009ea930a6f"
template_id: ""
raw_html: "raw/674df320b6a70009ea930a6f.html"
cta_urls:
  - https://go.theweddingbusinesscollective.com/dec2024roundtable
# Only Whitney or Giselle can fill these two.
source_session: ""
instagram_sibling: ""
---

## Body

Hi {{contact.first_name}},
Exciting news! We’re thrilled to invite you to GET MORE PERFECT FIT LEADS: A Live Roundtable for Wedding Pros, happening on December 17th from 12 PM–1:30 PM PT / 3 PM–4:30 PM ET.
This live event is packed with actionable insights from 5 wedding business experts (including us!) to help you attract your dream clients this engagement season.
Here’s what we’ll be diving into:
✨ How to define your perfect-fit lead
✨ Practical steps you can take today to attract those clients
✨ Insights on what’s working now versus what used to work
✨ Strategies for slower lead times
You’ll walk away with fresh strategies and real advice that you can immediately apply to your business.
Your panel of experts:
🌟 Heidi Thompson – Wedding Business & Marketing Strategist, Evolve Your Wedding Business
🌟 Whitney Hodges & Daniela Justus – Digital Advertising & Funnel Strategists, Wedding Industry Ads
🌟 Becca Pountney – Wedding Industry Marketing Expert
🌟 Marc McIntosh – Wedding Marketing Consultant, Team Wedding
This roundtable is perfect for wedding professionals ready to attract the right clients and book their calendars with confidence.
🎉 Reserve your spot now! REGISTER NOW
We’d love for you to join us—it’s going to be an inspiring and actionable conversation that you won’t want to miss.
See you there!
Whitney & Daniela
