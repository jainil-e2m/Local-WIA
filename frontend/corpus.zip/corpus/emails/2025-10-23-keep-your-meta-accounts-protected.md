---
campaign_name: "Weekly Marketing Email 10.23.25"
subject: " Keep your Meta accounts protected"
cta_from_name: ""
sent: 2025-10-23
recipients: 727
delivered: 724
failed: 2
sending_domain: ""
last_edited_by: "Yulia Burris"
tracking: on
schedule_id: "68f96453b5a7c637ab8843b7"
template_id: "689c8291ba28b0d2b23050f0"
raw_html: "raw/68f96453b5a7c637ab8843b7.html"
cta_urls: []
# Only Whitney or Giselle can fill these two.
source_session: ""
instagram_sibling: ""
---

## Body

Heads up, {{contact.first_name}}! There’s a new scam making the rounds, and we want to make sure you’re in the know.
Some businesses have received an invitation to join a “Meta Media Agency” business portfolio. The email comes from Meta, and the link itself is legit — but the intent behind the invite isn’t.
The portfolio was created by a third party trying to gain access to Facebook Pages and ad accounts. They’re fraudulently using “Meta” in their business name to mislead unsuspecting business owners.
What to do: If you get an invite from a business portfolio you don’t recognize, don’t click the link in the email. Instead, log into your Meta Business Manager directly, check for any suspicious requests, and decline anything that feels off.
Stay vigilant,
Daniela & Whitney
Copyright © {{right_now.year}} {{location.name}}, All rights reserved.
Our mailing address is:
{{location.email}}
Want to change how you receive these emails?
You can unsubscribe from this list .
