---
campaign_name: "Beta Meta Ads Workshop Invitation"
subject: "Stop boosting posts on Instagram!!"
cta_from_name: ""
sent: 2024-04-18
recipients: 339
delivered: 
failed: 197
sending_domain: ""
last_edited_by: ""
tracking: off
schedule_id: "662177efdec239451ccd60b5"
template_id: ""
raw_html: "raw/662177efdec239451ccd60b5.html"
cta_urls:
  - https://weddingindustryads.com/meta-workshop
# Only Whitney or Giselle can fill these two.
source_session: ""
instagram_sibling: ""
---

## Body

There's a better way - and we want to show you how
View this email in browser
Hi {{contact.first_name}},
By now you know that we are super passionate about making ads more accessible for wedding businesses. We see a huge education gap when it comes to advertising for wedding vendors, venues and service providers.
We need y'all to know that boosting posts is not your only option for advertising on Instagram!
That’s why we've been hard at work putting together a special workshop to show you the best way to use paid ads on Instagram.
You see - platforms like Instagram make it so easy to hit that “boost” button, but what they don’t tell you is that there are major limitations when you boost content within the app. We're here to tell you that there is a better way! A way that gives you more control over who sees your content and shows you better insights and more data.
Here at Wedding Industry Ads, friends don’t let friends boost posts!
As such, we are hosting an intimate workshop next month where we are going to walk participants through step-by-step how to build a traffic campaign (and hopefully keep you from ever hitting that “boost” button again!)
In this live, no-fluff 90-minute virtual workshop, you’ll learn…
Why boosting posts is not the best way to get qualified leads in your pipeline (and what to do instead)
The limitations of boosting posts (and the better way to put a little money behind your content)
The simple Meta Ad campaign strategy to give you back control over your targeting and your data (so you can make your content go further and align your ads to your goals)
And a full walkthrough showing you step-by-step exactly how to promote your content using the Meta Ads Manager so that you can get better results from your ads
If you are already posting on social media, want to make your content go further with ads, and are tired of boosting posts and getting bummed from the results...
This is for you!
Our goal is for you to walk away with an expertly set-up traffic campaign ready to launch! 🤩
The best part? The workshop is completely free! (At least for now.)
The catch? We only have 5 spots open (in order to ensure everyone can reach this outcome and get our hands-on support within the 90-minute timeframe).
We also want to make sure that everyone who participates is a great fit for this strategy. That’s why we are here now, inviting you to apply to attend .
This is an intimate LIVE virtual 90-minute workshop
happening Wednesday, May 8th at 10am CST.
DEADLINE TO APPLY IS WEDNESDAY, APRIL 24, 2024
If you want one of those 5 spots to be yours, click here to submit your application!
Qualified applicants will fill the spots on a first-come, first-serve basis (and we already have a couple of applications on deck - so don’t wait on this!)
Have questions? Reply to this email and we will get back to you. Otherwise, click here to apply. We can’t wait to review your application!
Best,
Whitney + Daniela
