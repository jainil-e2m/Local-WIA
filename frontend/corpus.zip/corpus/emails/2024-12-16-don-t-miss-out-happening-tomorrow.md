---
campaign_name: "Roundtable Event Reminder"
subject: "🚨 Don’t Miss Out—Happening Tomorrow!"
cta_from_name: ""
sent: 2024-12-16
recipients: 887
delivered: 
failed: 537
sending_domain: ""
last_edited_by: "Nicole Bautista"
tracking: on
schedule_id: "674df92381a85d5c9a7603d9"
template_id: ""
raw_html: "raw/674df92381a85d5c9a7603d9.html"
cta_urls:
  - https://go.theweddingbusinesscollective.com/dec2024roundtable
# Only Whitney or Giselle can fill these two.
source_session: ""
instagram_sibling: ""
---

## Body

Hi {{contact.first_name}},
This is your last chance to join us for GET MORE PERFECT FIT LEADS: A Live Roundtable for Wedding Pros tomorrow!
📅 When: December 17th
⏰ Time: 12 PM–1:30 PM PT / 3 PM–4:30 PM ET
You’ll learn practical tips from 5 wedding industry experts (including us!) to help you book more dream clients this engagement season.
🎯 Register here before it’s too late: REGISTER NOW
We’d love to see you there!
Cheers,
Whitney & Daniela
