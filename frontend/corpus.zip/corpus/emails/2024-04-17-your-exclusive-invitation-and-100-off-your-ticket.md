---
campaign_name: "Announce Wedding Pro CEO Summit - Austin 2024"
subject: "Your Exclusive Invitation!! (and $100 off your ticket 👀)"
cta_from_name: ""
sent: 2024-04-17
recipients: 332
delivered: 
failed: 189
sending_domain: ""
last_edited_by: ""
tracking: off
schedule_id: "66200d822cbe09134ecbcc0e"
template_id: ""
raw_html: "raw/66200d822cbe09134ecbcc0e.html"
cta_urls:
  - https://brandeegaar.com/wedding-business-ads-with-daniela-and-whitney/
  - https://brandeegaar.com/summit?affiliate=wia
# Only Whitney or Giselle can fill these two.
source_session: ""
instagram_sibling: ""
---

## Body

The Wedding Pro CEO Summit 2024 is happening in ATX
View this email in browser
Hi {{contact.first_name}}!
In case you missed it, yesterday we shared with you an exclusive podcast episode with Brandee Gaar, the host of the summit event this summer (here's the link to listen ).
Today, we're thrilled to announce that we'll be presenting at The Wedding Pro CEO Summit in Austin, TX in June!
It's going to be an incredible in-person event filled with inspiration, education, and networking opportunities for wedding pros like yourself.
We are so excited to be included among the speakers at the event, and have been working hard behind the scenes on developing an interactive Meta Ads workshop all about how to stay present on social media during wedding season without having to post something new every day.
Our goal is for you to walk away with ads that are ready to launch (and have been set up properly based on our expertise), so your campaigns drive more qualified traffic to your website.
But our presentation is just the tip of the iceberg - inspired by higher education, The Wedding Pro CEO Summit 2024 is a one-of-a-kind educational conference designed specifically for wedding industry business owners.
After 3 full days of high-impact learning and authentic inter-industry connecting, you’ll leave feeling inspired, educated, and empowered like never before.
Plus, as a special bonus for being part of our community, you can use our exclusive code "WIA" to get $100 off your ticket!
Click here to learn more about The Wedding Pro CEO Summit 2024 🥳
Don't miss out on this incredible opportunity to learn, connect, and grow with some of the best in the industry. Secure your spot today and get ready for an unforgettable experience!
We hope to see you there,
Whitney + Daniela
