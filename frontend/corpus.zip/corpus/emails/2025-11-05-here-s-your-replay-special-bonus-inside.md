---
campaign_name: "GSA Info Session (for registered attendees) 11.5.25 PM"
subject: "Here’s your replay + special bonus inside 👇"
cta_from_name: ""
sent: 2025-11-05
recipients: 34
delivered: 34
failed: 0
sending_domain: ""
last_edited_by: "Yulia Burris"
tracking: on
schedule_id: "690bd3f241945525c0dc48a8"
template_id: "689c8291ba28b0d2b23050f0"
raw_html: "raw/690bd3f241945525c0dc48a8.html"
cta_urls:
  - https://weddingindustryads.com/gsa-replay
  - https://portal.weddingindustryads.com/public/form/view/68f91878a9a586fcdf4c0566
# Only Whitney or Giselle can fill these two.
source_session: ""
instagram_sibling: ""
---

## Body

Hi {{contact.first_name}},
If you joined us live today - thank you! And if you couldn’t make it, we’ve got you covered.
The replay of our Google Search Accelerator Info Session is now available
👉 Watch the Replay Here
Inside, we break down exactly how we help wedding pros create consistent, qualified leads through Google Ads…without wasting thousands on clicks that don’t convert.
Here’s what we covered:
✅ The three foundations that make or break every Google Ads campaign
✅ Why most “set it and forget it” strategies fail in the wedding industry
✅ The step-by-step roadmap inside the Google Search Accelerator designed to help you launch, optimize, and grow with Google Ads.
As a thank-you for attending (or registering), you get first dibs on our introductory pricing and bonus support, valid through Tuesday, November 12th.
After that, pricing will increase for future enrollments.
💡This is your fast track to successful Google Ads for wedding pros.
Enrollments are rolling in, and the action takers are already getting their Google Ads launch sessions scheduled.
Ready to book your done-for-you, done-in-day Google Ads launch?
👉 View the Proposal & Secure Your Spot
See you inside,
Daniela & Whitney
Copyright © {{right_now.year}} {{location.name}}, All rights reserved.
Our mailing address is:
{{location.email}}
Want to change how you receive these emails?
You can unsubscribe from this list .
