---
campaign_name: "CEO Summit Announcement "
subject: "Want to Book More Weddings? Don’t Miss this Event!"
cta_from_name: ""
sent: 2025-01-30
recipients: 537
delivered: 
failed: 10
sending_domain: ""
last_edited_by: "Whitney Hodges"
tracking: on
schedule_id: "679bad99b5f40fe81a5db556"
template_id: ""
raw_html: "raw/679bad99b5f40fe81a5db556.html"
cta_urls:
  - https://weddingbusinessceosummit.com/registration/?aff=84
# Only Whitney or Giselle can fill these two.
source_session: ""
instagram_sibling: ""
---

## Body

Hey {{contact.first_name}},
Have you ever felt like your wedding business is on fire and you’re being pulled in a million different directions? I know I have! The overwhelm that comes with that leaves you feeling like everything is chaotic and having to work crazy hours.
That’s exactly why we’re so excited to share the Wedding Business CEO Summit with you!
This summit is all about helping you take control of your time, book more weddings, and ditch the overwhelm. Over 5 days, from February 17th-21st, Heidi Thompson of Evolve Your Wedding Business is bringing in 45 industry experts (including us!) to share strategies for working smarter, not harder.
We’re talking about everything from using AI to streamline your business, perfecting your follow-up strategy to book more weddings, setting better boundaries, and so much more!
We’ll be sharing our tips on The Power of Text & Email Nurture Automations To Increase Conversions and Book More Weddings. You won’t want to miss it!
We’ll be showing you how YOU can harness the power of text & email nurture automations to increase conversions and book more weddings with ease. You’ll also hear from some amazing experts, including:
Courtney Donilon
Tami Santini
Emily Foster
And more!
And the best part? It’s completely free to attend!
We could go on and on about how awesome this summit is, but we’ll let you check out all the details for yourself.
Get your ticket for the Wedding Business CEO Summit today!
Can’t wait to see you there!
Best,
Whitney & Daniela
