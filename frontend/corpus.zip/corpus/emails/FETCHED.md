# Email corpus — fetched

Pulled from LeadLock on 2026-09-22 by
`corpus/fetch-emails.mjs`. 126 sent campaigns.

Body text is extracted from `nonTrackingDownloadUrl`; raw HTML is kept beside
each one under `raw/`. Note that the links **inside the body** are
link.msgsndr.com click-redirects — both rendered variants carry them. The real
destinations are in `cta_urls`, recovered separately from the editor payload.
See [OFFER-MAP.md](./OFFER-MAP.md).

`source_session` and `instagram_sibling` are blank in every file. They
cannot be derived from the API — only Whitney or Giselle know which call each
email came from, and that mapping is what turns this from a style sample into
input/output pairs.

| Sent | Subject | CTA | Recipients | File |
|---|---|---|---|---|
| 2026-09-16 | What I taught our clients this week | Ads Accelerators Sales Page | 840 | [2026-09-16-what-i-taught-our-clients-this-week.md](./2026-09-16-what-i-taught-our-clients-this-week.md) |
| 2026-08-20 | She didn't post on Instagram for 10 weeks 😱 | Reply | 832 | [2026-08-20-she-didn-t-post-on-instagram-for-10-weeks.md](./2026-08-20-she-didn-t-post-on-instagram-for-10-weeks.md) |
| 2026-08-06 | You can't optimize what you can't measure | Reply | 821 | [2026-08-06-you-can-t-optimize-what-you-can-t-measure.md](./2026-08-06-you-can-t-optimize-what-you-can-t-measure.md) |
| 2026-07-31 | "I honestly have no idea if this is working." | Ads Accelerator Reply | 822 | [2026-07-31-i-honestly-have-no-idea-if-this-is-working.md](./2026-07-31-i-honestly-have-no-idea-if-this-is-working.md) |
| 2026-07-01 | "It feels like our sales are on autopilot." | Join the ELEVATE waitlist | 803 | [2026-07-01-it-feels-like-our-sales-are-on-autopilot.md](./2026-07-01-it-feels-like-our-sales-are-on-autopilot.md) |
| 2026-06-30 | The conversation I can't stop thinking about | Reply | 803 | [2026-06-30-the-conversation-i-can-t-stop-thinking-about.md](./2026-06-30-the-conversation-i-can-t-stop-thinking-about.md) |
| 2026-06-23 | LIVE today at 11am CST | Register | 803 | [2026-06-23-live-today-at-11am-cst.md](./2026-06-23-live-today-at-11am-cst.md) |
| 2026-06-22 | Why some businesses convert more inquiries than others | Register | 802 | [2026-06-22-why-some-businesses-convert-more-inquiries-than-others.md](./2026-06-22-why-some-businesses-convert-more-inquiries-than-others.md) |
| 2026-06-18 | Workshop: Build a Brand That Converts More Leads | Register | 869 | [2026-06-18-workshop-build-a-brand-that-converts-more-leads.md](./2026-06-18-workshop-build-a-brand-that-converts-more-leads.md) |
| 2026-06-10 | The question we ask every new client | Reply | 804 | [2026-06-10-the-question-we-ask-every-new-client.md](./2026-06-10-the-question-we-ask-every-new-client.md) |
| 2026-06-04 | Visibility isn't just something you earn. | Watch | 806 | [2026-06-04-visibility-isn-t-just-something-you-earn.md](./2026-06-04-visibility-isn-t-just-something-you-earn.md) |
| 2026-05-20 | The goal isn’t going viral | Reply | 812 | [2026-05-20-the-goal-isn-t-going-viral.md](./2026-05-20-the-goal-isn-t-going-viral.md) |
| 2026-05-13 | Predictable marketing > viral marketing | Link in Bio | 816 | [2026-05-13-predictable-marketing-viral-marketing.md](./2026-05-13-predictable-marketing-viral-marketing.md) |
| 2026-05-05 | A smarter way to get in front of the right clients |  | 819 | [2026-05-05-a-smarter-way-to-get-in-front-of-the-right-clients.md](./2026-05-05-a-smarter-way-to-get-in-front-of-the-right-clients.md) |
| 2026-04-30 | More leads won’t fix this… |  | 784 | [2026-04-30-more-leads-won-t-fix-this.md](./2026-04-30-more-leads-won-t-fix-this.md) |
| 2026-04-22 | Join us live today at 2PM CST |  | 789 | [2026-04-22-join-us-live-today-at-2pm-cst.md](./2026-04-22-join-us-live-today-at-2pm-cst.md) |
| 2026-04-20 | Starting today 👀 don’t miss this |  | 790 | [2026-04-20-starting-today-don-t-miss-this.md](./2026-04-20-starting-today-don-t-miss-this.md) |
| 2026-04-15 | If your ads aren’t performing the way they should, read this |  | 824 | [2026-04-15-if-your-ads-aren-t-performing-the-way-they-should-read-.md](./2026-04-15-if-your-ads-aren-t-performing-the-way-they-should-read-.md) |
| 2026-04-07 | We're teaching at this and want you there |  | 785 | [2026-04-07-we-re-teaching-at-this-and-want-you-there.md](./2026-04-07-we-re-teaching-at-this-and-want-you-there.md) |
| 2026-03-31 | If your ads aren’t turning into bookings, read this |  | 818 | [2026-03-31-if-your-ads-aren-t-turning-into-bookings-read-this.md](./2026-03-31-if-your-ads-aren-t-turning-into-bookings-read-this.md) |
| 2026-03-25 | The mistake costing wedding pros the most bookings |  | 862 | [2026-03-25-the-mistake-costing-wedding-pros-the-most-bookings.md](./2026-03-25-the-mistake-costing-wedding-pros-the-most-bookings.md) |
| 2026-02-20 | Your giveaway application (and what's next) |  | 24 | [2026-02-20-your-giveaway-application-and-what-s-next.md](./2026-02-20-your-giveaway-application-and-what-s-next.md) |
| 2026-02-12 | Last chance to enter! |  | 785 | [2026-02-12-last-chance-to-enter.md](./2026-02-12-last-chance-to-enter.md) |
| 2026-02-10 | Why most wedding pros struggle with ads (and how we fix it) |  | 788 | [2026-02-10-why-most-wedding-pros-struggle-with-ads-and-how-we-fix-.md](./2026-02-10-why-most-wedding-pros-struggle-with-ads-and-how-we-fix-.md) |
| 2026-02-05 | 💝 Google & Meta Ads Giveaway 💝 |  | 796 | [2026-02-05-google-meta-ads-giveaway.md](./2026-02-05-google-meta-ads-giveaway.md) |
| 2026-02-04 | Why increasing ad spend isn’t always the answer |  | 803 | [2026-02-04-why-increasing-ad-spend-isn-t-always-the-answer.md](./2026-02-04-why-increasing-ad-spend-isn-t-always-the-answer.md) |
| 2026-02-03 | The shift that changed her ad results |  | 804 | [2026-02-03-the-shift-that-changed-her-ad-results.md](./2026-02-03-the-shift-that-changed-her-ad-results.md) |
| 2026-01-28 | Don’t spend a penny on ads until you hear this |  | 63 | [2026-01-28-don-t-spend-a-penny-on-ads-until-you-hear-this.md](./2026-01-28-don-t-spend-a-penny-on-ads-until-you-hear-this.md) |
| 2026-01-27 | The shift planners are being asked to make in 2026 |  | 63 | [2026-01-27-the-shift-planners-are-being-asked-to-make-in-2026.md](./2026-01-27-the-shift-planners-are-being-asked-to-make-in-2026.md) |
| 2026-01-26 | You’re invited: the 2026 Planners Workshop (it’s free this year!!) |  | 64 | [2026-01-26-you-re-invited-the-2026-planners-workshop-it-s-free-thi.md](./2026-01-26-you-re-invited-the-2026-planners-workshop-it-s-free-thi.md) |
| 2026-01-21 | This feels worth sharing |  | 803 | [2026-01-21-this-feels-worth-sharing.md](./2026-01-21-this-feels-worth-sharing.md) |
| 2026-01-14 | Paid Ads Don’t Have to Feel Spammy (or Risky) |  | 827 | [2026-01-14-paid-ads-don-t-have-to-feel-spammy-or-risky.md](./2026-01-14-paid-ads-don-t-have-to-feel-spammy-or-risky.md) |
| 2026-01-13 | How couples actually use Google when booking wedding vendors |  | 784 | [2026-01-13-how-couples-actually-use-google-when-booking-wedding-ve.md](./2026-01-13-how-couples-actually-use-google-when-booking-wedding-ve.md) |
| 2026-01-06 | Appointment Confirmation! Please read :) |  | 1 | [2026-01-06-appointment-confirmation-please-read.md](./2026-01-06-appointment-confirmation-please-read.md) |
| 2026-01-06 | Being good isn’t enough if couples can’t find you |  | 765 | [2026-01-06-being-good-isn-t-enough-if-couples-can-t-find-you.md](./2026-01-06-being-good-isn-t-enough-if-couples-can-t-find-you.md) |
| 2026-01-05 | Your 2026 Ads Investment Guide is Here! 🎉 |  | 213 | [2026-01-05-your-2026-ads-investment-guide-is-here.md](./2026-01-05-your-2026-ads-investment-guide-is-here.md) |
| 2026-01-05 | Your 2026 Ads Investment Guide is Here 🎉 |  | 550 | [2026-01-05-your-2026-ads-investment-guide-is-here.md](./2026-01-05-your-2026-ads-investment-guide-is-here.md) |
| 2025-12-30 | Where most wedding pros get stuck with Meta ads |  | 766 | [2025-12-30-where-most-wedding-pros-get-stuck-with-meta-ads.md](./2025-12-30-where-most-wedding-pros-get-stuck-with-meta-ads.md) |
| 2025-12-09 | Last call: Claim $3000+ in free wedding biz resources |  | 676 | [2025-12-09-last-call-claim-3000-in-free-wedding-biz-resources.md](./2025-12-09-last-call-claim-3000-in-free-wedding-biz-resources.md) |
| 2025-12-08 | 🎯 Free tools to book more couples in 2026 |  | 679 | [2025-12-08-free-tools-to-book-more-couples-in-2026.md](./2025-12-08-free-tools-to-book-more-couples-in-2026.md) |
| 2025-12-01 | Last Day: Save $200 on Your Google Search Campaign |  | 664 | [2025-12-01-last-day-save-200-on-your-google-search-campaign.md](./2025-12-01-last-day-save-200-on-your-google-search-campaign.md) |
| 2025-11-28 | Black Friday: Launch Your Google Search Campaign for Less |  | 667 | [2025-11-28-black-friday-launch-your-google-search-campaign-for-les.md](./2025-11-28-black-friday-launch-your-google-search-campaign-for-les.md) |
| 2025-11-25 | Your Expert-Built Google Search Campaign (Now $200 Off!) |  | 673 | [2025-11-25-your-expert-built-google-search-campaign-now-200-off.md](./2025-11-25-your-expert-built-google-search-campaign-now-200-off.md) |
| 2025-11-19 |  The moment you know your ads are working… |  | 675 | [2025-11-19-the-moment-you-know-your-ads-are-working.md](./2025-11-19-the-moment-you-know-your-ads-are-working.md) |
| 2025-11-13 | LAST CHANCE! Google Search Accelerator pricing increases tomorrow |  | 675 | [2025-11-13-last-chance-google-search-accelerator-pricing-increases.md](./2025-11-13-last-chance-google-search-accelerator-pricing-increases.md) |
| 2025-11-12 | The one mistake costing wedding pros thousands |  | 676 | [2025-11-12-the-one-mistake-costing-wedding-pros-thousands.md](./2025-11-12-the-one-mistake-costing-wedding-pros-thousands.md) |
| 2025-11-12 | What’s it costing you NOT to be at the top of Google? |  | 678 | [2025-11-12-what-s-it-costing-you-not-to-be-at-the-top-of-google.md](./2025-11-12-what-s-it-costing-you-not-to-be-at-the-top-of-google.md) |
| 2025-11-11 | Lock in intro pricing for Google Ads |  | 680 | [2025-11-11-lock-in-intro-pricing-for-google-ads.md](./2025-11-11-lock-in-intro-pricing-for-google-ads.md) |
| 2025-11-11 | Increase your Google leads this engagement season |  | 681 | [2025-11-11-increase-your-google-leads-this-engagement-season.md](./2025-11-11-increase-your-google-leads-this-engagement-season.md) |
| 2025-11-10 | Still on the fence about Google Ads? Let’s talk. |  | 34 | [2025-11-10-still-on-the-fence-about-google-ads-let-s-talk.md](./2025-11-10-still-on-the-fence-about-google-ads-let-s-talk.md) |
| 2025-11-05 |  Skip the guesswork with Google Ads |  | 651 | [2025-11-05-skip-the-guesswork-with-google-ads.md](./2025-11-05-skip-the-guesswork-with-google-ads.md) |
| 2025-11-05 | Here’s your replay + special bonus inside 👇 |  | 34 | [2025-11-05-here-s-your-replay-special-bonus-inside.md](./2025-11-05-here-s-your-replay-special-bonus-inside.md) |
| 2025-11-05 | We're live now for the Google Search Accelerator Q&A session! |  | 30 | [2025-11-05-we-re-live-now-for-the-google-search-accelerator-q-a-se.md](./2025-11-05-we-re-live-now-for-the-google-search-accelerator-q-a-se.md) |
| 2025-11-05 | LIVE in 1 hr: Google Ads made simple (and effective) |  | 666 | [2025-11-05-live-in-1-hr-google-ads-made-simple-and-effective.md](./2025-11-05-live-in-1-hr-google-ads-made-simple-and-effective.md) |
| 2025-11-05 | LIVE in 1 hr: Google Ads made simple (and effective) |  | 26 | [2025-11-05-live-in-1-hr-google-ads-made-simple-and-effective.md](./2025-11-05-live-in-1-hr-google-ads-made-simple-and-effective.md) |
| 2025-11-04 | Tomorrow: The truth about Google Ads for wedding pros |  | 20 | [2025-11-04-tomorrow-the-truth-about-google-ads-for-wedding-pros.md](./2025-11-04-tomorrow-the-truth-about-google-ads-for-wedding-pros.md) |
| 2025-11-04 | Tomorrow: The truth about Google Ads for wedding pros |  | 670 | [2025-11-04-tomorrow-the-truth-about-google-ads-for-wedding-pros.md](./2025-11-04-tomorrow-the-truth-about-google-ads-for-wedding-pros.md) |
| 2025-11-03 | Your Google Ads? Done in a day.  |  | 690 | [2025-11-03-your-google-ads-done-in-a-day.md](./2025-11-03-your-google-ads-done-in-a-day.md) |
| 2025-10-31 | Slay Google Ads 💀 |  | 692 | [2025-10-31-slay-google-ads.md](./2025-10-31-slay-google-ads.md) |
| 2025-10-31 | Don’t run Google Ads in the dark 😱 |  | 692 | [2025-10-31-don-t-run-google-ads-in-the-dark.md](./2025-10-31-don-t-run-google-ads-in-the-dark.md) |
| 2025-10-30 | Double your visibility on Google |  | 694 | [2025-10-30-double-your-visibility-on-google.md](./2025-10-30-double-your-visibility-on-google.md) |
| 2025-10-29 | Live Google Ads Q&A |  | 696 | [2025-10-29-live-google-ads-q-a.md](./2025-10-29-live-google-ads-q-a.md) |
| 2025-10-28 | 📣Google Search Accelerator is here |  | 701 | [2025-10-28-google-search-accelerator-is-here.md](./2025-10-28-google-search-accelerator-is-here.md) |
| 2025-10-28 | Google Search Accelerator drops today 🚀 |  | 702 | [2025-10-28-google-search-accelerator-drops-today.md](./2025-10-28-google-search-accelerator-drops-today.md) |
| 2025-10-27 | Something new drops tomorrow ✨ |  | 704 | [2025-10-27-something-new-drops-tomorrow.md](./2025-10-27-something-new-drops-tomorrow.md) |
| 2025-10-24 | Google Ads Glow Up 👀 |  | 696 | [2025-10-24-google-ads-glow-up.md](./2025-10-24-google-ads-glow-up.md) |
| 2025-10-23 |  Keep your Meta accounts protected |  | 727 | [2025-10-23-keep-your-meta-accounts-protected.md](./2025-10-23-keep-your-meta-accounts-protected.md) |
| 2025-10-21 | Happening TODAY: Sales Q&A with Maria Bayer |  | 735 | [2025-10-21-happening-today-sales-q-a-with-maria-bayer.md](./2025-10-21-happening-today-sales-q-a-with-maria-bayer.md) |
| 2025-10-20 | LIVE Sales Q&A is tomorrow (and it’s gonna be GOOD) |  | 736 | [2025-10-20-live-sales-q-a-is-tomorrow-and-it-s-gonna-be-good.md](./2025-10-20-live-sales-q-a-is-tomorrow-and-it-s-gonna-be-good.md) |
| 2025-10-15 | What to say when a client says “You’re too expensive” |  | 735 | [2025-10-15-what-to-say-when-a-client-says-you-re-too-expensive.md](./2025-10-15-what-to-say-when-a-client-says-you-re-too-expensive.md) |
| 2025-10-08 |  Only 1 Spot Left — Google Ads Done Right |  | 707 | [2025-10-08-only-1-spot-left-google-ads-done-right.md](./2025-10-08-only-1-spot-left-google-ads-done-right.md) |
| 2025-10-01 | It's time for a reality check |  | 714 | [2025-10-01-it-s-time-for-a-reality-check.md](./2025-10-01-it-s-time-for-a-reality-check.md) |
| 2025-09-24 | We’d never recommend this to venues & wedding pros  |  | 669 | [2025-09-24-we-d-never-recommend-this-to-venues-wedding-pros.md](./2025-09-24-we-d-never-recommend-this-to-venues-wedding-pros.md) |
| 2025-09-18 | Last Chance! Free Google Ads Audit |  | 650 | [2025-09-18-last-chance-free-google-ads-audit.md](./2025-09-18-last-chance-free-google-ads-audit.md) |
| 2025-09-16 | Trusting Someone with Your Ads… But Not Seeing Results? |  | 650 | [2025-09-16-trusting-someone-with-your-ads-but-not-seeing-results.md](./2025-09-16-trusting-someone-with-your-ads-but-not-seeing-results.md) |
| 2025-09-10 | Are your Google Ads even working? |  | 647 | [2025-09-10-are-your-google-ads-even-working.md](./2025-09-10-are-your-google-ads-even-working.md) |
| 2025-09-04 | I screwed up our IG account |  | 655 | [2025-09-04-i-screwed-up-our-ig-account.md](./2025-09-04-i-screwed-up-our-ig-account.md) |
| 2025-09-03 |  I just recorded this for you… |  | 661 | [2025-09-03-i-just-recorded-this-for-you.md](./2025-09-03-i-just-recorded-this-for-you.md) |
| 2025-08-21 |  Google Ads Mistakes 👀 |  | 613 | [2025-08-21-google-ads-mistakes.md](./2025-08-21-google-ads-mistakes.md) |
| 2025-08-13 | What’s working right now in the wedding industry (and for us) |  | 598 | [2025-08-13-what-s-working-right-now-in-the-wedding-industry-and-fo.md](./2025-08-13-what-s-working-right-now-in-the-wedding-industry-and-fo.md) |
| 2025-08-06 | This Google Ads tweak increased a venue's leads & tours  |  | 432 | [2025-08-06-this-google-ads-tweak-increased-a-venue-s-leads-tours.md](./2025-08-06-this-google-ads-tweak-increased-a-venue-s-leads-tours.md) |
| 2025-07-30 | 15X Return On Ad Spend?! Yes, please!  |  | 585 | [2025-07-30-15x-return-on-ad-spend-yes-please.md](./2025-07-30-15x-return-on-ad-spend-yes-please.md) |
| 2025-07-23 | Your copy of our new Ads Investment Guide |  | 52 | [2025-07-23-your-copy-of-our-new-ads-investment-guide.md](./2025-07-23-your-copy-of-our-new-ads-investment-guide.md) |
| 2025-07-23 | Our New Ads Investment Guide Is Here 🎉 |  | 530 | [2025-07-23-our-new-ads-investment-guide-is-here.md](./2025-07-23-our-new-ads-investment-guide-is-here.md) |
| 2025-07-17 | If you're a DIYer, this is for you |  | 582 | [2025-07-17-if-you-re-a-diyer-this-is-for-you.md](./2025-07-17-if-you-re-a-diyer-this-is-for-you.md) |
| 2025-06-24 | 🚀 Level Up Your Wedding Biz – 4‑Month Meta Ads Program |  | 582 | [2025-06-24-level-up-your-wedding-biz-4-month-meta-ads-program.md](./2025-06-24-level-up-your-wedding-biz-4-month-meta-ads-program.md) |
| 2025-06-18 | We’ve been working on something brand new… |  | 582 | [2025-06-18-we-ve-been-working-on-something-brand-new.md](./2025-06-18-we-ve-been-working-on-something-brand-new.md) |
| 2025-06-11 | Want more bookings — not just more likes? |  | 581 | [2025-06-11-want-more-bookings-not-just-more-likes.md](./2025-06-11-want-more-bookings-not-just-more-likes.md) |
| 2025-06-10 | The better alternative to boosting… |  | 582 | [2025-06-10-the-better-alternative-to-boosting.md](./2025-06-10-the-better-alternative-to-boosting.md) |
| 2025-06-04 | Who’s really seeing your posts? |  | 582 | [2025-06-04-who-s-really-seeing-your-posts.md](./2025-06-04-who-s-really-seeing-your-posts.md) |
| 2025-06-03 | Still boosting posts? Here’s what you need to know… |  | 584 | [2025-06-03-still-boosting-posts-here-s-what-you-need-to-know.md](./2025-06-03-still-boosting-posts-here-s-what-you-need-to-know.md) |
| 2025-05-15 | Take Control of Your Meta Ads with Expert Help |  | 582 | [2025-05-15-take-control-of-your-meta-ads-with-expert-help.md](./2025-05-15-take-control-of-your-meta-ads-with-expert-help.md) |
| 2025-05-14 |  The secret weapon most wedding pros can’t seem to master |  | 585 | [2025-05-14-the-secret-weapon-most-wedding-pros-can-t-seem-to-maste.md](./2025-05-14-the-secret-weapon-most-wedding-pros-can-t-seem-to-maste.md) |
| 2025-05-08 | It’s here! Meta Ads Immersive Experience |  | 586 | [2025-05-08-it-s-here-meta-ads-immersive-experience.md](./2025-05-08-it-s-here-meta-ads-immersive-experience.md) |
| 2025-05-07 | Want to Stand Out on Google? |  | 596 | [2025-05-07-want-to-stand-out-on-google.md](./2025-05-07-want-to-stand-out-on-google.md) |
| 2025-05-07 | You’ve been waiting for this… |  | 8 | [2025-05-07-you-ve-been-waiting-for-this.md](./2025-05-07-you-ve-been-waiting-for-this.md) |
| 2025-04-30 | Guess what’s coming?! |  | 602 | [2025-04-30-guess-what-s-coming.md](./2025-04-30-guess-what-s-coming.md) |
| 2025-04-22 | Join us at 11am CST to talk about  Luxury-Level Leads: Ads That Convert High-End! |  | 584 | [2025-04-22-join-us-at-11am-cst-to-talk-about-luxury-level-leads-ad.md](./2025-04-22-join-us-at-11am-cst-to-talk-about-luxury-level-leads-ad.md) |
| 2025-04-21 | High-end clients aren’t waiting—neither should you. |  | 588 | [2025-04-21-high-end-clients-aren-t-waiting-neither-should-you.md](./2025-04-21-high-end-clients-aren-t-waiting-neither-should-you.md) |
| 2025-04-17 | Attract luxury-level leads… |  | 587 | [2025-04-17-attract-luxury-level-leads.md](./2025-04-17-attract-luxury-level-leads.md) |
| 2025-04-16 | Unlock the Luxury Market—Learn from the Best in the Industry |  | 591 | [2025-04-16-unlock-the-luxury-market-learn-from-the-best-in-the-ind.md](./2025-04-16-unlock-the-luxury-market-learn-from-the-best-in-the-ind.md) |
| 2025-02-27 | Booking more weddings starts with speed to lead🚀 |  | 487 | [2025-02-27-booking-more-weddings-starts-with-speed-to-lead.md](./2025-02-27-booking-more-weddings-starts-with-speed-to-lead.md) |
| 2025-02-20 | The Foolproof Follow-Up Advantage |  | 511 | [2025-02-20-the-foolproof-follow-up-advantage.md](./2025-02-20-the-foolproof-follow-up-advantage.md) |
| 2025-02-20 | It’s today!!! Are you in?? |  | 521 | [2025-02-20-it-s-today-are-you-in.md](./2025-02-20-it-s-today-are-you-in.md) |
| 2025-02-17 | The key to running killer ad campaigns |  | 521 | [2025-02-17-the-key-to-running-killer-ad-campaigns.md](./2025-02-17-the-key-to-running-killer-ad-campaigns.md) |
| 2025-02-13 | Our secret weapon 🚀 |  | 524 | [2025-02-13-our-secret-weapon.md](./2025-02-13-our-secret-weapon.md) |
| 2025-02-12 | See you next week? |  | 525 | [2025-02-12-see-you-next-week.md](./2025-02-12-see-you-next-week.md) |
| 2025-02-06 | The Wedding Business CEO Summit is Getting Even Better! Don't Miss Out! |  | 528 | [2025-02-06-the-wedding-business-ceo-summit-is-getting-even-better-.md](./2025-02-06-the-wedding-business-ceo-summit-is-getting-even-better-.md) |
| 2025-01-30 | Want to Book More Weddings? Don’t Miss this Event! |  | 537 | [2025-01-30-want-to-book-more-weddings-don-t-miss-this-event.md](./2025-01-30-want-to-book-more-weddings-don-t-miss-this-event.md) |
| 2025-01-16 | The strategy for a 12x return on ad spend |  | 3 | [2025-01-16-the-strategy-for-a-12x-return-on-ad-spend.md](./2025-01-16-the-strategy-for-a-12x-return-on-ad-spend.md) |
| 2025-01-16 | The strategy for a 12x return on ad spend |  | 26 | [2025-01-16-the-strategy-for-a-12x-return-on-ad-spend.md](./2025-01-16-the-strategy-for-a-12x-return-on-ad-spend.md) |
| 2024-12-27 | Next Step |  | 203 | [2024-12-27-next-step.md](./2024-12-27-next-step.md) |
| 2024-12-16 | 🚨 Don’t Miss Out—Happening Tomorrow! |  | 887 | [2024-12-16-don-t-miss-out-happening-tomorrow.md](./2024-12-16-don-t-miss-out-happening-tomorrow.md) |
| 2024-12-04 | 🚀 Get More Perfect-Fit Leads This Engagement Season |  | 887 | [2024-12-04-get-more-perfect-fit-leads-this-engagement-season.md](./2024-12-04-get-more-perfect-fit-leads-this-engagement-season.md) |
| 2024-11-06 | Curious about paid ads? This is for you! |  | 358 | [2024-11-06-curious-about-paid-ads-this-is-for-you.md](./2024-11-06-curious-about-paid-ads-this-is-for-you.md) |
| 2024-09-03 | LAST CHANCE!!! $300 Off Meta Ads VIP Day |  | 324 | [2024-09-03-last-chance-300-off-meta-ads-vip-day.md](./2024-09-03-last-chance-300-off-meta-ads-vip-day.md) |
| 2024-09-02 | FLASH SALE!!! $300 Off Meta Ads VIP Day |  | 324 | [2024-09-02-flash-sale-300-off-meta-ads-vip-day.md](./2024-09-02-flash-sale-300-off-meta-ads-vip-day.md) |
| 2024-06-17 | hey there, ceo! |  | 66 | [2024-06-17-hey-there-ceo.md](./2024-06-17-hey-there-ceo.md) |
| 2024-06-10 | Wanna know the secrets the pros know to reach multi 6-figures? |  | 474 | [2024-06-10-wanna-know-the-secrets-the-pros-know-to-reach-multi-6-f.md](./2024-06-10-wanna-know-the-secrets-the-pros-know-to-reach-multi-6-f.md) |
| 2024-04-18 | Stop boosting posts on Instagram!! |  | 339 | [2024-04-18-stop-boosting-posts-on-instagram.md](./2024-04-18-stop-boosting-posts-on-instagram.md) |
| 2024-04-17 | Your Exclusive Invitation!! (and $100 off your ticket 👀) |  | 332 | [2024-04-17-your-exclusive-invitation-and-100-off-your-ticket.md](./2024-04-17-your-exclusive-invitation-and-100-off-your-ticket.md) |
| 2024-04-16 | Our Secret to Consistent Lead Generation |  | 330 | [2024-04-16-our-secret-to-consistent-lead-generation.md](./2024-04-16-our-secret-to-consistent-lead-generation.md) |
| 2024-04-12 | The secret sauce that delivers killer ad results  👀 |  | 104 | [2024-04-12-the-secret-sauce-that-delivers-killer-ad-results.md](./2024-04-12-the-secret-sauce-that-delivers-killer-ad-results.md) |
| 2024-04-09 | Flash Sale - $300 off expires at midnight! |  | 291 | [2024-04-09-flash-sale-300-off-expires-at-midnight.md](./2024-04-09-flash-sale-300-off-expires-at-midnight.md) |
| 2024-04-08 | [TIME SENSITIVE] Flash Sale: Elevate Your Advertising Game with $300 Off! |  | 291 | [2024-04-08-time-sensitive-flash-sale-elevate-your-advertising-game.md](./2024-04-08-time-sensitive-flash-sale-elevate-your-advertising-game.md) |
| 2024-04-04 | Welcome to Wedding Industry Ads! Let's Grow Together |  | 104 | [2024-04-04-welcome-to-wedding-industry-ads-let-s-grow-together.md](./2024-04-04-welcome-to-wedding-industry-ads-let-s-grow-together.md) |
