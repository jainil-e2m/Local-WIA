---
campaign_name: "GSA Info Session (for registered attendees) 11.5.25 (11 AM)"
subject: "We're live now for the Google Search Accelerator Q&A session!"
cta_from_name: ""
sent: 2025-11-05
recipients: 30
delivered: 30
failed: 0
sending_domain: ""
last_edited_by: "Yulia Burris"
tracking: on
schedule_id: "690b8589f6aca8a68857f8c3"
template_id: "689c8291ba28b0d2b23050f0"
raw_html: "raw/690b8589f6aca8a68857f8c3.html"
cta_urls:
  - https://zoom.us/j/95428361024?pwd=b35vscCYt2CaixB5o0d4dpxPzyLTle.1&jst=2￼
  - https://zoom.us/j/95428361024?pwd=b35vscCYt2CaixB5o0d4dpxPzyLTle.1&jst=2
# Only Whitney or Giselle can fill these two.
source_session: ""
instagram_sibling: ""
---

## Body

Hi {{contact.first_name}},
We're live now for the Google Search Accelerator Q&A session!
🎥 Join us here: https://zoom.us/j/95428361024?pwd=b35vscCYt2CaixB5o0d4dpxPzyLTle.1&jst=2
See you inside,
Daniela & Whitney
Copyright © {{right_now.year}} {{location.name}}, All rights reserved.
Our mailing address is:
{{location.email}}
Want to change how you receive these emails?
You can unsubscribe from this list .
