---
campaign_name: "Marketing Email 1.27.26"
subject: "The shift planners are being asked to make in 2026"
cta_from_name: ""
sent: 2026-01-27
recipients: 63
delivered: 61
failed: 1
sending_domain: ""
last_edited_by: "Whitney Hodges"
tracking: on
schedule_id: "6977709dc8461605c6bb1fbb"
template_id: "689c8291ba28b0d2b23050f0"
raw_html: "raw/6977709dc8461605c6bb1fbb.html"
cta_urls:
  - https://margauxfraise.mykajabi.com/a/2148205566/DAEHLMAk
# Only Whitney or Giselle can fill these two.
source_session: ""
instagram_sibling: ""
---

## Body

Hi {{contact.first_name}},
One thing I’ve noticed over the last year is this:
The role of a wedding planner is quietly changing — and not everyone has caught up yet.
Planners are being asked to step into bigger conversations:
Design leadership
Multi-day, multi-touch celebrations
Higher expectations and more complex clients
Clearer articulation of why they’re worth the investment
But most planners were never taught how to market that evolution.
That’s why I said yes to teaching inside the 2026 Planners Workshop tomorrow.
This isn’t about “doing more marketing.”
It’s about communicating your value in a way that matches the level of work you’re already doing (or want to be doing next).
In my live session, How Marketing-Savvy Wedding Planners Are Rising to the Top of Their Markets (and Beyond!), I’ll be breaking down:
What strategic digital advertising actually looks like for planners (no fluff, no agency jargon)
How planners are using Google and Meta Ads to attract better-aligned clients (not just more inquiries)
How to turn the content you already have into campaigns that support your growth
And how to know when ads make sense for your business...and when they don’t
The workshop itself runs January 26-28, and for the first time ever, it’s completely free for wedding planners.
It kicked off yesterday, but you can still join now to access the trainings. If you’re thinking seriously about where you want your business to be headed in 2026 — this is a smart room to be in.
👉You can grab your free ticket here
I’d love to see you live on Wednesday.
Whitney
P.S. Even if you’re not ready to run ads tomorrow, understanding how strategic planners are using them will change how you think about growth — and that clarity alone is worth the time.
Copyright © {{right_now.year}} {{location.name}}, All rights reserved.
Our mailing address is:
{{location.email}}
Want to change how you receive these emails?
You can unsubscribe from this list .
