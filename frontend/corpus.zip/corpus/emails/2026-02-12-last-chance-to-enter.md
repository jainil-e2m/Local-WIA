---
campaign_name: "Marketing Email 2.12.26"
subject: "Last chance to enter!"
cta_from_name: ""
sent: 2026-02-12
recipients: 785
delivered: 782
failed: 0
sending_domain: ""
last_edited_by: "Whitney Hodges"
tracking: on
schedule_id: "69836c9ffa83d99e138163e4"
template_id: "689c8291ba28b0d2b23050f0"
raw_html: "raw/69836c9ffa83d99e138163e4.html"
cta_urls:
  - https://weddingindustryads.com/giveaway
# Only Whitney or Giselle can fill these two.
source_session: ""
instagram_sibling: ""
---

## Body

Our Ads Accelerator Giveaway closes tonight!
{{contact.first_name}}, quick reminder that our Valentine’s giveaway closes tonight.
This is your last chance to enter to win:
✔ Google Search Accelerator
✔ Meta Ads Accelerator
✔ Guided support from our team
Click the link below to learn more and submit your application.
👉 Enter here before midnight
Winner announced tomorrow (February 13).
Good luck - we’ll be cheering you on 💕
Daniela & Whitney
Copyright © {{right_now.year}} {{location.name}}, All rights reserved.
Our mailing address is:
{{location.email}}
Want to change how you receive these emails?
You can unsubscribe from this list .
