---
campaign_name: "My Presentation"
subject: "It’s today!!! Are you in??"
cta_from_name: ""
sent: 2025-02-20
recipients: 521
delivered: 
failed: 1
sending_domain: ""
last_edited_by: "Whitney Hodges"
tracking: on
schedule_id: "67b37a1dd322715b27ca831a"
template_id: ""
raw_html: "raw/67b37a1dd322715b27ca831a.html"
cta_urls:
  - https://weddingbusinessceosummit.com/registration/?aff=84
# Only Whitney or Giselle can fill these two.
source_session: ""
instagram_sibling: ""
---

## Body

Hey {{contact.first_name}},
We’re excited to let you know that our presentation is going live today as part of the Wedding Business CEO Summit, where we’ll be diving into How Instantly Responding to Leads via Text Opens the Door for Better Sales Conversations and Higher Conversions!
In this session, we’ll be sharing:
The secret to automating your lead nurture process for better conversions.
How a strong sales funnel makes your ads (and organic efforts) work harder for you.
The exact text and email workflows that increase sales conversations and book more weddings.
Our goal is to help you create a streamlined process that allows you to nurture leads with ease and maximize your marketing ROI, whether you’re running ads or focusing on organic methods.
If you haven’t grabbed your ticket yet, don’t worry—you can stillget one here.
Based on your ticket type, our presentation will be live for 24 hours, or if you choose the all-access pass, you’ll get lifetime access, along with other amazing bonuses (including our beginner’s guide to Google ads!)
See you soon!
Best,
Whitney & Daniela
P.S. If you’re catching this a bit late, you can grab the All-Access Pass to get lifetime access to all the replays and a lot more amazing resources!
