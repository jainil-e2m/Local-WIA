---
campaign_name: "Weekly Marketing Email 10.28.25 (6AM)"
subject: "Google Search Accelerator drops today 🚀"
cta_from_name: ""
sent: 2025-10-28
recipients: 702
delivered: 701
failed: 0
sending_domain: ""
last_edited_by: "Yulia Burris"
tracking: on
schedule_id: "68ffd75bceb70f0fec23be71"
template_id: "689c8291ba28b0d2b23050f0"
raw_html: "raw/68ffd75bceb70f0fec23be71.html"
cta_urls: []
# Only Whitney or Giselle can fill these two.
source_session: ""
instagram_sibling: ""
---

## Body

Reply to get the details first
Hi {{contact.first_name}},
Today’s the day! We’re announcing all the details of our new Google Search Accelerator this afternoon, but if you want the inside scoop now, just say the word.
We’ve taken our most popular offer (the Google Ads VIP Day) and given it a major upgrade by layering in foundational curriculum to set you up for success, plus ongoing support to help you grow.
This is built for wedding pros who are ready to finally feel confident running profitable Google Ads — with hands-on setup (we build and launch your campaign for you) and the strategic tools to keep your ads working long after launch day.
We’re opening just 10 spots for founding members.
This is perfect for you if you…
✅ Know your dream clients are searching on Google
✅ Need a campaign that gets you conversions, not just clicks
✅ Want to skip the guesswork and go straight to what works
✅ Are looking for ongoing support after launch
✅ Have a professional website and a clear offer
✅ Are open-minded, resourceful, and ready to learn
If that’s you, reply to this email and let me know. I’ll send you the full details before the public announcement goes out later today.
Best,
Whitney
Copyright © {{right_now.year}} {{location.name}}, All rights reserved.
Our mailing address is:
{{location.email}}
Want to change how you receive these emails?
You can unsubscribe from this list .
