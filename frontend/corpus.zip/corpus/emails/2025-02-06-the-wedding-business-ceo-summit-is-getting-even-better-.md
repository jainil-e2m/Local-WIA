---
campaign_name: "Email 2: Reminder + Upsell Mention"
subject: "The Wedding Business CEO Summit is Getting Even Better! Don't Miss Out!"
cta_from_name: ""
sent: 2025-02-06
recipients: 528
delivered: 
failed: 2
sending_domain: ""
last_edited_by: "Nicole Bautista"
tracking: on
schedule_id: "67a4ea3a0b93530a40870263"
template_id: ""
raw_html: "raw/67a4ea3a0b93530a40870263.html"
cta_urls:
  - https://weddingbusinessceosummit.com/registration/?aff=84
# Only Whitney or Giselle can fill these two.
source_session: ""
instagram_sibling: ""
---

## Body

Hey {{contact.first_name}},
Last week, we told you about the Wedding Business CEO Summit, which kicks off on February 17th. As more details come out, this event just keeps getting better and better—you won’t want to miss it!
We can’t wait for you to hear from the incredible lineup of experts and learn the best strategies to escape long hours, take back your time, and confidently book more weddings without the overwhelm.
It’s going to be sooo good!
You’ll hear from us on Thursday, February 20, about how instantly responding to leads via text opens the door for better sales conversations and higher conversions.
You’ll also hear from some amazing experts, including:
Courtney Donilon
Tami Santini
Emily Foster
And more!
The best part? You can access all of this amazing content for free! Just click your Free ticket here to grab your spot.
We also highly recommend checking out the Wedding Pro Power Pack—it’s packed with an insane amount of valuable resources. With it, you’ll get:
We’ve even contributed a bonus to the Power Pack: The Beginner’s Guide to Building the Ultimate Google Search Campaign for Your Wedding Business. It’s a step-by-step guide to help you leverage Google Ads like a pro.
We can’t wait to see you at the summit and hear about your favorite takeaways.
Click here to grab your ticket now and join us for this incredible event!
Cheers,
Whitney & Daniela
