---
campaign_name: "Post-Giveaway Update Campaign"
subject: "Your giveaway application (and what's next)"
cta_from_name: ""
sent: 2026-02-20
recipients: 24
delivered: 23
failed: 1
sending_domain: ""
last_edited_by: "Whitney Hodges"
tracking: on
schedule_id: "6994cf0483e6d8c1a2618e01"
template_id: ""
raw_html: "raw/6994cf0483e6d8c1a2618e01.html"
cta_urls:
  - https://weddingindustryads.com/ads-clarity-call
# Only Whitney or Giselle can fill these two.
source_session: ""
instagram_sibling: ""
---

## Body

Hi {{contact.first_name}},
First — thank you.
Truly. Thank you for taking the time to complete the application and throw your name in the hat for our Accelerator Bundle giveaway. We were blown away by the number of submissions we received. Selecting the winner was a tough decision, and we’re so grateful to you for making it that hard.
Even applying says something important: you’re thinking about growth. You’re thinking about visibility. You’re not sitting back and hoping referrals just “work out.”
That matters.
While you weren’t selected as the bundle winner this time, we don’t want the momentum you created to stop here.
As a thank-you for raising your hand and putting yourself out there, I’d love to offer you a gift in return:
🗓️ A complimentary 30-minute Ads Clarity Call with me.
No pressure. Just a focused, strategic conversation about:
Your online marketing foundation as it relates to Google and/or Meta Ads
What’s working (or not working) right now, so you know where to focus first
Whether paid ads actually make sense for your next season of growth
If it does, I’ll show you what moving forward would look like. If not, you’ll still walk away with clarity and direction.
✨I’m only offering a handful of these calls, and they’ll be scheduled on a first-come, first-served basis through the end of this month.
👉 Book your Ads Clarity Call here
Whether we end up working together or not, I want you walking away with more direction than you had yesterday.
You already took the first step by entering the giveaway. Let’s keep that energy going.
Proud of you for taking action. That alone puts you ahead of most.
Talk soon,
Whitney🤍
