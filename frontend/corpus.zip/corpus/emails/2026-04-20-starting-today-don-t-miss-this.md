---
campaign_name: "WSS Tech & AI Email #6"
subject: "Starting today 👀 don’t miss this"
cta_from_name: ""
sent: 2026-04-20
recipients: 790
delivered: 786
failed: 2
sending_domain: ""
last_edited_by: "LeadLock Team"
tracking: on
schedule_id: "69d68228e545359adcfe7456"
template_id: "694b2a04c384d6817120dc5d"
raw_html: "raw/69d68228e545359adcfe7456.html"
cta_urls:
  - https://margauxfraise.mykajabi.com/wss-tech-ai-registration?ref=https%3A%2F%2Fmargauxfraise.mykajabi.com%2Fa%2F2148253283%2FDAEHLMAk
# Only Whitney or Giselle can fill these two.
source_session: ""
instagram_sibling: ""
---

## Body

Tech & AI for Wedding Pros!
Hey {{contact.first_name}},
Just a heads up if you haven’t already heard…
The Wedding Summit Series: Tech & AI Edition starts today, and we wanted to make sure you didn’t miss the chance to register.
From April 20-24, wedding professionals from across the industry will be diving into:
How technology and AI are actually showing up in client conversations
Using these tools to support your marketing and day-to-day work
How to make more confident decisions about what’s worth your time
It’s free, it’s designed specifically for wedding businesses, and it’s meant to give you clarity, not more noise.
Each day is organized around a different theme, with sessions you can watch on your own time (with 24-hour access), plus a few live opportunities to join in if you want to.
If you’ve been thinking “I’ll sign up later,” this is your final reminder.
You can register here
Hope to see you there,
— Daniela & Whitney
Copyright © {{right_now.year}} {{location.name}}, All rights reserved.
Our mailing address is:
{{location.email}}
Want to change how you receive these emails?
You can unsubscribe from this list .
