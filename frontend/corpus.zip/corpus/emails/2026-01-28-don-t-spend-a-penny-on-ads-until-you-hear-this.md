---
campaign_name: "Marketing Email 1.28.26"
subject: "Don’t spend a penny on ads until you hear this"
cta_from_name: ""
sent: 2026-01-28
recipients: 63
delivered: 63
failed: 0
sending_domain: ""
last_edited_by: "Whitney Hodges"
tracking: on
schedule_id: "6978cba750f92636a9f527ed"
template_id: "689c8291ba28b0d2b23050f0"
raw_html: "raw/6978cba750f92636a9f527ed.html"
cta_urls:
  - https://margauxfraise.mykajabi.com/a/2148205566/DAEHLMAk
# Only Whitney or Giselle can fill these two.
source_session: ""
instagram_sibling: ""
---

## Body

Hi {{contact.first_name}},
My session for the 2026 Planners Workshop is happening live today at 11am CST.
I’m teaching How Marketing-Savvy Wedding Planners Are Rising to the Top of Their Markets (and Beyond!) with Strategic Digital Advertising.
I created this session for planners who are ready to amplify what’s already working in their business.
When your marketing foundations are dialed in, ads become a strategic way to expand reach, reinforce positioning, and attract more aligned clients at scale.
Inside, we’ll cover:
Why Google and Meta Ads are the most powerful (and misunderstood) tools planners can use to attract better-aligned clients
How to turn the content you already have into ads that actually convert — without starting from scratch
What budgets, campaign types, and strategy look like when ads are supporting growth, not draining your energy
My goal is simple: to help you understand how paid ads fit into a modern planning business, so you can make smarter marketing decisions and book weddings that truly align with where you want to go next.
If you haven’t registered yet, you can still sign up:
👉Grab your free ticket here
I’d love for you to join me and Margaux today for this live session.
Whitney
P.S. Even if ads aren’t on your radar right now, this session will help you think differently about visibility, positioning, and long-term growth — and that perspective alone can change how you approach your marketing in 2026.
Copyright © {{right_now.year}} {{location.name}}, All rights reserved.
Our mailing address is:
{{location.email}}
Want to change how you receive these emails?
You can unsubscribe from this list .
