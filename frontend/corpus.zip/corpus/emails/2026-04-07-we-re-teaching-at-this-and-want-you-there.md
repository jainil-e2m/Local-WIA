---
campaign_name: "WSS Tech & AI Email #1"
subject: "We're teaching at this and want you there"
cta_from_name: ""
sent: 2026-04-07
recipients: 785
delivered: 784
failed: 1
sending_domain: ""
last_edited_by: "Whitney Hodges"
tracking: on
schedule_id: "69d543020168843e8b22db85"
template_id: "694b2a04c384d6817120dc5d"
raw_html: "raw/69d543020168843e8b22db85.html"
cta_urls:
  - https://margauxfraise.mykajabi.com/wss-tech-ai-registration?ref=https%3A%2F%2Fmargauxfraise.mykajabi.com%2Fa%2F2148253283%2FDAEHLMAk
# Only Whitney or Giselle can fill these two.
source_session: ""
instagram_sibling: ""
---

## Body

Tech & AI for Wedding Pros!
Hey {{contact.first_name}},
We wanted to share something we’re genuinely excited to be part of.
We’ll be speaking at the Wedding Summit Series: Tech & AI Edition, a free virtual event for wedding professionals focused on how technology and AI actually fit into our businesses right now.
Not in a theoretical way. In a “this is how it shows up in your inquiries, your marketing, and your day-to-day workflow” kind of way.
We’re teaching a session called Speed to Lead, where we’re breaking down how to strengthen your inquiry funnel so you can respond faster, create better first impressions, and actually convert more of the leads you’re already getting.
If you’ve been trying to figure out what’s actually worth your time when it comes to tech and AI, this is worth a look.
You can grab your free ticket here
It’s free, and we think you’ll walk away with a much clearer picture of what actually matters.
— Daniela & Whitney
Copyright © {{right_now.year}} {{location.name}}, All rights reserved.
Our mailing address is:
{{location.email}}
Want to change how you receive these emails?
You can unsubscribe from this list .
