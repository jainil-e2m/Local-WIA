---
campaign_name: "Email 3-One Week Reminder"
subject: "See you next week?"
cta_from_name: ""
sent: 2025-02-12
recipients: 525
delivered: 
failed: 1
sending_domain: ""
last_edited_by: "Nicole Bautista"
tracking: on
schedule_id: "67aa3d8d7a728803e81b4e42"
template_id: ""
raw_html: "raw/67aa3d8d7a728803e81b4e42.html"
cta_urls:
  - https://weddingbusinessceosummit.com/?aff=84
# Only Whitney or Giselle can fill these two.
source_session: ""
instagram_sibling: ""
---

## Body

Hi {{contact.first_name}},
Did you know there’s a secret weapon to help stop ghosting in its tracks? Here’s a hint — you’re probably holding it in your hand right now!
It’s TEXTING!
Instantly responding to leads via text creates better conversations, builds connections faster, and boosts conversions.
Want to know how to make it happen without lifting a finger?
Join us at the FREE virtual Wedding Business CEO Summit , where we’ll show you how to automate your inquiry response funnels so leads get the attention they deserve — without you staying glued to your phone to respond. We can’t wait to share this presentation with you!
Grab your free ticket and check out our training to be one of the first to learn how we can install our tried & true funnels in YOUR business.
See you there,
Whitney & Daniela
